'''
Created on Aug 26, 2020

@author: VanCampK
'''
from enum import Enum

'''
 Link types, for linked cases
'''
class LinkTypeCode(Enum):
    ORIGINAL_CASE = 1
    GENERATED_CASE = 2
