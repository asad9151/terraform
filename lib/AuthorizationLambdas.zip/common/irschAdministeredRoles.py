'''
Lists the subset of IResearchRole which are administered within the iResearch database (others administered in IDaas).

@author: VanCampK
'''
from enum import Enum

class IResearchAdministeredRole(Enum):
    IRESEARCH_MINIBATCH_SUBMITTER = "IRESEARCH_MINIBATCH_SUBMITTER"
    IRESEARCH_RESTRICTED_VIEW_REVIEWER = "IRESEARCH_RESTRICTED_VIEW_REVIEWER"
    IRESEARCH_CFPBATCH_SUBMITTER = "IRESEARCH_CFPBATCH_SUBMITTER"
    IRESEARCH_BATCH_ADMIN = "IRESEARCH_BATCH_ADMIN"
    IRESEARCH_DRSBATCH_SUBMITTER = "IRESEARCH_DRSBATCH_SUBMITTER"
    IRESEARCH_CAMPAIGNBATCH_SUBMITTER = "IRESEARCH_CAMPAIGNBATCH_SUBMITTER"
    IRESEARCH_BATCH_REVIEWER = "IRESEARCH_BATCH_REVIEWER"
    
    
    @classmethod
    def hasValue(cls, value):
        return any(value == item.value for item in cls)
    
    @classmethod
    def getAllRoles(cls):
        return list(cls)
        
    @classmethod
    def getAllRoleNames(cls):
        return [e.value for e in cls]