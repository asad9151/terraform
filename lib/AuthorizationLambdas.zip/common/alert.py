'''
Created on Jun 4, 2019

@author: VanCampK
'''


from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from common import envVblNames
import logging
import smtplib
import socket
import os
import sys
import traceback


class Alert(object):
    '''
    Class to handle generating operational "alerts" (current emails but possibly something else in the future)
    '''
    
    COMPONET_NAME_PROPERTY = "componentName"
    HOST_NAME_PROPERTY = "hostName"
    SUMMARY_PROPERTY = "summary"
    DETAILED_ERR_MSG_PROPERTY = "detailedErrMsg" 
    ALERT_TEMPLATE_PATH = "../conf/alert.txt"
    NON_ALERT_TEMPLATE_PATH = "../conf/nonAlert.txt"


    def __init__(self, environDict):
        self.environDict = environDict
        self.alert_dest = environDict.get(envVblNames.ENV_ERROR_TO)
        self.alert_source = environDict.get(envVblNames.ENV_ERROR_FROM)
        self.enabel_alert = environDict.get(envVblNames.ENV_MAIL_ENABLE)
        self.alert_env = environDict.get(envVblNames.ENV_ENVIRONMENT_NAME)
        self.smtp_service = None


    def raiseAlert(self, component, summary, detailedErrMsg=''):
        logging.critical('IRSCHALERT from component=' + str(component) + ' summary=' + summary + ' detailedErrMsg=' + detailedErrMsg)
        if self.enabel_alert in [True, "yes", "true", "True"]:
            self.sendMessage(component, summary, self.ALERT_TEMPLATE_PATH, detailedErrMsg)
        else:
            logging.info("Alert messages is disabled. So, email is not sent.")
    
    
    def sendMessage(self, component, summary, templatePath, detailedErrMsg=''):
        try:
            self.smtp_service = smtplib.SMTP(self.environDict.get(envVblNames.ENV_SMTP_HOST))
            self.smtp_service.starttls()
            message, msg_typ = self.format_message(templatePath, str(component), summary, detailedErrMsg)
            msg = MIMEMultipart()
            if msg_typ == "html":
                email_message = MIMEText(message, "html")
            else:
                email_message = MIMEText(message, "plain")
            msg.attach(email_message)
            msg["From"] = self.alert_source
            msg["To"] = self.alert_dest
            subject = self.formatSummary(self.alert_env, summary)
            msg["Subject"] = subject
            logging.info(f"Sending email from component {component} From={self.alert_source} To={self.alert_dest} Subject={subject} message={message}")
            self.smtp_service.send_message(msg)
        except Exception as e:
            logging.error("Occurred following error when sending an email: " + str(e))
            traceback.print_tb(sys.exc_info()[2])
        finally:
            if self.smtp_service is not None:
                try:
                    self.smtp_service.quit()
                except Exception:
                    pass    # Eat exception on quit
                
    
    def format_message(self, template_path, component, summary, detailedErrMsg):
        message = self.render_template(template_path)
        if message:
            message = message.format(
                **{
                    self.COMPONET_NAME_PROPERTY: component,
                    self.HOST_NAME_PROPERTY: self.get_hostname(),
                    self.SUMMARY_PROPERTY: summary,
                    self.DETAILED_ERR_MSG_PROPERTY: detailedErrMsg
                }
            )
            msg_typ = "html"
        else:
            logging.info("Sending email in text format as message can't be rendered or empty")
            message = "Alert from host=" + self.get_hostname() + ": component=" + component + " summary=" + summary + " : " + detailedErrMsg
            msg_typ = "text"
        return message, msg_typ
    
    
    def get_hostname(self):
        try:
            return socket.gethostname()
        except:
            return "iResearch Application"

    
    def render_template(self, template_path):
        try:
            if not os.path.isabs(template_path):
                current_path_of_file = os.path.abspath(os.path.dirname(__file__))
                template_path = os.path.join(current_path_of_file, template_path)
            with open(template_path) as template_content:
                return template_content.read()
        except Exception as e:
            logging.error("Unable to render the email template from " + str(template_path) + " due to the error" + str(e))
            traceback.print_tb(sys.exc_info()[2])

    
    def formatSummary(self, alertEnvName, summaryText):
        return "D&B iResearch :: " + alertEnvName + " :: " + summaryText


    def sendNonAlertMessage(self, component, summary, detailedErrMsg=''):
        self.sendMessage(component, summary, self.NON_ALERT_TEMPLATE_PATH, detailedErrMsg)


def main():
    environmentDict = {
        envVblNames.ENV_ERROR_TO: "vancampk@dnb.com",
        envVblNames.ENV_ERROR_FROM: "iresearch.alert@dnb.com",
        envVblNames.ENV_MAIL_ENABLE: True,
        envVblNames.ENV_ENVIRONMENT_NAME: "local",
        envVblNames.ENV_SMTP_HOST: "10.69.142.81"
    }
    from lambdas.lambdaCommon import initLambdaEnviron
    initLambdaEnviron({}, environmentDict)
    alerts = Alert(environDict=environmentDict)
    #alerts.raiseAlert("alertTest", "This is a test alert", 'Please ignore this test.')
    alerts.sendNonAlertMessage("Non-Alert Test", "This is a test non-alert email", "Please ignore this test.\r\nThis is the second line.")
    

if __name__ == "__main__":
    main()
    