'''
Created on Mar 3, 2021

@author: VanCampK
'''
from enum import IntEnum

class WarningCode(IntEnum):
    '''
    Warning codes
    If you add a new warning code here, please add it to the Java WarningCode module too.
    '''
    CASE_RESPONSE_TRUNCATED = 1
    NO_GET_NEXT_CASE_AVAILABLE = 2
    NO_AUTO_ASSIGN_CASE_AVAILABLE = 3
    NO_COUNTRY_TAT = 4
    STATUS_CHANGE_WARNING = 5
