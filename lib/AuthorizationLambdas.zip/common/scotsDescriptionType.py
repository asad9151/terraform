'''
Created on Jul 29, 2019

@author: VanCampK
'''
from enum import Enum

class ScotsDescriptionType(Enum):
    PROD_LITR_DESC = 1
    CD_VAL_SHRT_DESC = 2