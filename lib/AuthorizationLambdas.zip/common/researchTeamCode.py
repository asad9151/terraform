'''
Created on Apr 10, 2020

@author: JafferS
'''
from enum import Enum

class ResearchTeamCode(Enum):
    IRESEARCH_TEAM_UNITY = 135
    IRESEARCH_TEAM_CN_MINI = 121
    IRESEARCH_TEAM_DE_FULL = 156
    IRESEARCH_TEAM_AT_FULL = 153
    IRESEARCH_TEAM_CH_FULL = 157
    IRESEARCH_TEAM_FR_FULL = 148
    IRESEARCH_TEAM_BE_FULL = 150
    IRESEARCH_TEAM_LU_FULL = 152
    IRESEARCH_TEAM_NL_FULL = 162
    IRESEARCH_TEAM_ES_FULL = 147
    IRESEARCH_TEAM_AD_FULL = 173
    IRESEARCH_TEAM_IT_FULL = 154
    IRESEARCH_TEAM_TW_MINI = 119
    IRESEARCH_TEAM_PT_FULL = 174
    IRESEARCH_TEAM_CA_COFACE = 191
    IRESEARCH_TEAM_CA_PRIORITYFULLCREDITRISKREVIEW = 172
    IRESEARCH_TEAM_CA_FULL = 226

    
    @classmethod
    def hasName(cls, name):
        for name, member in cls.__members__.items():
            if member.name == name:
                return True
            
        return False
    
    @classmethod
    def hasValue(cls, value):
        for name, member in cls.__members__.items():
            if member.value == value:
                return True
            
        return False