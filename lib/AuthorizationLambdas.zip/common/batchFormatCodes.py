'''
Created on Apr 3, 2019

@author: VanCampK
'''
from enum import Enum

class BatchFormatCode(Enum):
    EXCEL_SPREADSHEET = 5187
    JSON = 29619
    FIXED_FORMAT = 3
