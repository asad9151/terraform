'''
Created on July 29, 2020

@author: GuardiolaR
'''
from enum import Enum

class BatchPriorityCode(Enum):
    '''
    These are the possible campaignPriority Code Values for campaignBatches
    '''
    HIGH = 1
    MEDIUM = 2
    LOW = 3
