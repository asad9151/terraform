'''
Created on Aug 3, 2020

@author: GuardiolaR
'''

from enum import Enum

class UsageTypeCode(Enum):
    # SNS Notification Type codes for usage records
    SUBJECT_CASE_REQUEST = 1
    RESEARCH_REQUEST = 2