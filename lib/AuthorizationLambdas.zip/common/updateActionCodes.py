'''
Created on Apr 3, 2019

@author: VanCampK
'''
from enum import Enum

class UpdateActionCode(Enum):
    ADD = 400
    MODIFY = 401
    DELETE = 402
