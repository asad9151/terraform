from enum import Enum

class ProcessResultCode(Enum):
    VIRUS_FOUND = 33805
    FILE_AVAILABLE = 33806
    SUCCESSFUL = 20095
    UNSUCCESSFUL = 20244
    FILE_DELETED = 33914
    FILE_ABORTED = 99999    # Failed all attempts to process 
