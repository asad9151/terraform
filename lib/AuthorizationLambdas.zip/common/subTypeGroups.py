'''
Created on Jan 15, 2020

@author: JafferS
'''
from enum import Enum

class SubTypeGroups(Enum):
    MINI_SUBMITTER = 34448