'''
Created on Aug 28, 2019

@author: VanCampK
'''
from enum import Enum

class SubmitterViewTypeCode(Enum):
    MY_INQUIRIES = 1
    TEAMS_INQUIRIES = 2
