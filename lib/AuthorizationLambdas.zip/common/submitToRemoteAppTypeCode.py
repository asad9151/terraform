'''
Created on Apr 20, 2020

@author: JafferS
'''
from enum import Enum

class SubmitToRemoteAppTypeCode(Enum):
    SUBMIT_TO_PARTNER = 1
    REROUTE_TO_PARTNER = 2
    SEND_CHALLENGE_TO_PARTNER = 3
    HANDLE_BATCH_AFTER_UPDATE_DUE_DATE = 4
