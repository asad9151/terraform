'''
Updated on March 2, 2019
Reusable database connection class

@author: MorganB
'''
import pymysql
import logging
from common import envVblNames

class DatabaseConnection():
    
    def __init__(self, environDict, autocommit=True):
        self.db_config = {
        'user': '',
        'password': '',
        'host': '',
        'database': '',
        'charset' :'utf8mb4',
        'cursorclass': pymysql.cursors.DictCursor,
        'autocommit': autocommit
        }
    
        self.db_config['user'] = environDict[envVblNames.ENV_DB_USER]
        self.db_config['password'] = environDict[envVblNames.ENV_DB_PASSWORD]
        self.db_config['host'] = environDict[envVblNames.ENV_DB_HOST]
        self.db_config['database'] = environDict[envVblNames.ENV_DB_SCHEMA]
        self.dbconn = None
        self.cursor = None
    
        try:
            logging.info('DatabaseConnection connecting to ' + self.db_config['host'] + ' with user=' + self.db_config['user'] + '...')
            self.dbconn = pymysql.connect(**self.db_config)
            self.cursor = self.dbconn.cursor()
        except pymysql.Error as err:
            logging.error('DatabaseConnection Class - error connecting to database.  error = %s', err)
            errmsg = "Other database connect error"
            if hasattr(err,'errno'):
                if err.errno == err.ER_ACCESS_DENIED_ERROR:
                    errmsg = "Something is wrong with your user name or password"
                elif err.errno == err.ER_BAD_DB_ERROR:
                    errmsg = "Database does not exist"
            logging.error(f"DatabaseConnection Class: {errmsg}: {err}")
            raise
        except Exception as e:
            logging.error('in dbConn init section.  error = %s', e)
            raise
        return
    
    
    def commit(self):
        self.dbconn.commit()
        
    
    def close(self):
        self.dbconn.close()
        
        
    def checkConnection(self):
        '''
        Tests the current database connection, and tries to reconnect if not already connected.
        Ref: https://github.com/PyMySQL/PyMySQL/blob/master/pymysql/connections.py#L740
        '''
        if self.dbconn.open:
            logging.info("DatabaseConnection: connection is open")
        else:
            logging.warning("DatabaseConnection: connection is NOT open")
            # In case connection not open, try to reconnect
            logging.info("DatabaseConnection: calling ping...")
            self.dbconn.ping(reconnect=True)
            if self.dbconn.open:
                logging.info("DatabaseConnection: connection is open(2)")
            else:
                logging.error("DatabaseConnection: connection is NOT open(2)")
        