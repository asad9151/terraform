'''
Created on Nov 9, 2019

@author: MorganB
'''

import csv
import logging

def writeCSV(recordList, fileName, csvFormatOrder, writeHeaders=True):
    if type(recordList) != list:
        logging.error ('writeCSV function: recordList - %s - must be a list', recordList)
        return None
    if type(csvFormatOrder) != list:
        logging.error ('writeCSF function: csvFormatOrder - %s - must be a list',csvFormatOrder)
        return None 
    if type(writeHeaders) != bool:
        logging.error ('writeCSF function: writeHeaders must be a boolean, it is type %s', type(writeHeaders))
        return None 
    if type(fileName) != str:
        logging.error ('writeCSF function: fileName - %s - must be a string with .csv suffix', fileName)
        return None 
    if fileName.split('.')[-1].lower() != 'csv':
        logging.error ('writeCSF function: fileName - %s - must have a suffix of csv or CSV', fileName)
        return None 
    
    try:
        with open(fileName, mode='w', newline='') as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=csvFormatOrder)
            if writeHeaders:
                writer.writeheader()
            for entry in recordList:
                writer.writerow(entry)
    except Exception as e:
        logging.error('writeCSV function: error writing to local CSV file - %s.  Error = %s', fileName,e)
        raise
    logging.info('writeCSV function: csv file - %s - created',fileName)
    return fileName 

if __name__ == '__main__':
    pass