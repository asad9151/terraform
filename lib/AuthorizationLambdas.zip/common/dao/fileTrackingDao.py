'''
Created on Apr 14, 2020

@author: VanCampK
'''
import json
import logging
import pymysql

from common.encoders import IResearchEncoder

from common.mappers.stpPartnerDeliveryFileMapper import mapToStpPartnerDeliveryFile

class FileTrackingDao(object):


    def insertFileTracking(self, dbConn, stpDeliveryFile, appModule, reuseIfDup=False):
        '''
CREATE TABLE fle_tkg
(
    fle_tkg_id           INTEGER NOT NULL AUTO_INCREMENT,
    inb_outb_ind         NUMERIC(1) NOT NULL,
    stp_dlvr_ind         NUMERIC(1) NOT NULL DEFAULT 1,
    s3_obj_key           VARCHAR(1024) NULL,
    fldr_key             VARCHAR(15) NULL,
    fle_nme              VARCHAR(250) NULL,
    stp_flnm             VARCHAR(250) NULL,
    fle_sz_msmt          NUMERIC(12) NULL,
    prcs_stat_cd         NUMERIC(7) NULL,
    prcs_rslt_cd         NUMERIC(7) NULL,
    lst_dlvr_atmpt_tmst  TIMESTAMP NULL,
    dlvr_atmpt_cnt       NUMERIC(7) NOT NULL DEFAULT 0,
    row_cre_tmst         TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    row_crer_id_txt      VARCHAR(32) NOT NULL,
    row_mod_tmst         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    row_modr_id_txt      VARCHAR(32) NOT NULL,
    PRIMARY KEY (fle_tkg_id)
) AUTO_INCREMENT = 1;
        '''
        query = '''
        insert into fle_tkg (inb_outb_ind,stp_dlvr_ind,s3_obj_key,fldr_key,fle_nme,stp_flnm,fle_sz_msmt,prcs_stat_cd,prcs_rslt_cd,lst_dlvr_atmpt_tmst,dlvr_atmpt_cnt,row_crer_id_txt,row_modr_id_txt)
        values (%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW(),%s,%s,%s)
        '''
        params = (stpDeliveryFile.inboundOutboundIndicator, stpDeliveryFile.stpDeliveryIndicator, stpDeliveryFile.s3Object.getS3ObjectKey(), stpDeliveryFile.relativeFolder,
                  stpDeliveryFile.s3Object.fileName, stpDeliveryFile.stpFileName, stpDeliveryFile.s3Object.fileSize, stpDeliveryFile.processStatusCode,
                  stpDeliveryFile.processResultCode, stpDeliveryFile.deliveryAttemptCount, appModule, appModule)
        logging.info(f"insertFileTracking: query={query} params={params}")
        try:
            dbConn.cursor.execute(query, params)
            stpDeliveryFile.fileTrackingId = dbConn.cursor.lastrowid
            logging.info(f"insertFileTracking: back from query assigned fileTrackingId={stpDeliveryFile.fileTrackingId}")
            return stpDeliveryFile.fileTrackingId
        except pymysql.err.IntegrityError as e:
            if e.args[0] == 1062 and reuseIfDup:    # (1062, "Duplicate entry '14-1' for key 'ptnr_detl_ie1'")
                # Reuse existing record (useful when resuming after partially completed transaction)
                stpDeliveryFile2 = self.queryPartnerFileTracking(dbConn, stpDeliveryFile.inboundOutboundIndicator, stpDeliveryFile.relativeFolder, stpDeliveryFile.s3Object.fileName, stpDeliveryFile.stpDeliveryIndicator)
                if stpDeliveryFile2 is None:
                    logging.error(f"insertFileTracking failed on duplicate entry but unable to query for dup - giving up.")
                    raise
                logging.warning(f"insertFileTracking failed on duplicate entry with dup fileTrackingId={stpDeliveryFile2.fileTrackingId}, continuing on with existing id")
                stpDeliveryFile.fileTrackingId = stpDeliveryFile2.fileTrackingId
                # Update to the desired initial statuses (so redelivery will occur)
                self.updateFileTracking(dbConn, stpDeliveryFile, appModule)
            else:
                # Anything else gets raised and alerted on
                raise



    def insertPartnerFileTracking(self, dbConn, stpPartnerDeliveryFile, appModule, reuseIfDup=False):
        '''
CREATE TABLE ptnr_fle_tkg
(
    ptnr_fle_tkg_id      INTEGER NOT NULL AUTO_INCREMENT,
    fle_tkg_id           INTEGER NOT NULL,
    api_app_entl_id      INTEGER NOT NULL,
    fle_typ_cd           NUMERIC(7) NOT NULL,
    rec_cnt              INTEGER NULL,
    rej_rec_cnt          INTEGER NULL,
    attm_cnt             INTEGER NULL,
    btch_prcs_stat_cd    NUMERIC(7) NOT NULL DEFAULT 33598,
    btch_rej_err_txt     VARCHAR(400) NULL,
    btch_reqs_id         INTEGER NULL,
    row_cre_tmst         TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    row_crer_id_txt      VARCHAR(32) NOT NULL,
    row_mod_tmst         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    row_modr_id_txt      VARCHAR(32) NOT NULL,
    PRIMARY KEY (ptnr_fle_tkg_id)
) AUTO_INCREMENT = 1;
        '''
        query = '''
        insert into ptnr_fle_tkg (fle_tkg_id,api_app_entl_id,fle_typ_cd,rec_cnt,attm_cnt,btch_reqs_id,row_crer_id_txt,row_modr_id_txt)
        values (%s,%s,%s,%s,%s,%s,%s,%s)
        '''
        params = (stpPartnerDeliveryFile.fileTrackingId, stpPartnerDeliveryFile.apiApplicationEntitlement.apiApplicationEntitlementId, stpPartnerDeliveryFile.fileTypeCode,
                  stpPartnerDeliveryFile.recordCount, stpPartnerDeliveryFile.attachmentCount, stpPartnerDeliveryFile.batchRequestId, appModule, appModule)
        logging.info(f"insertPartnerFileTracking: query={query} params={params}")
        try:
            dbConn.cursor.execute(query, params)
            stpPartnerDeliveryFile.partnerFileTrackingId = dbConn.cursor.lastrowid
            logging.info(f"insertPartnerFileTracking: back from query assigned partnerFileTrackingId={stpPartnerDeliveryFile.partnerFileTrackingId}")
            return stpPartnerDeliveryFile.partnerFileTrackingId
        except pymysql.err.IntegrityError as e:
            if e.args[0] == 1062 and reuseIfDup:    # (1062, "Duplicate entry '14-1' for key 'ptnr_detl_ie1'")
                # Reuse existing record (useful when resuming after partially completed transaction)
                stpPartnerDeliveryFile2 = self.queryPartnerFileTracking(dbConn, stpPartnerDeliveryFile.inboundOutboundIndicator, stpPartnerDeliveryFile.relativeFolder, stpPartnerDeliveryFile.s3Object.fileName, stpPartnerDeliveryFile.stpDeliveryIndicator)
                if stpPartnerDeliveryFile2 is None:
                    logging.error(f"insertPartnerFileTracking failed on duplicate entry but unable to query for dup - giving up.")
                    raise
                logging.warning(f"insertPartnerFileTracking failed on duplicate entry with dup partnerFileTrackingId={stpPartnerDeliveryFile2.partnerFileTrackingId}, continuing on with existing id")
                stpPartnerDeliveryFile.partnerFileTrackingId = stpPartnerDeliveryFile2.partnerFileTrackingId
            else:
                # Anything else gets raised and alerted on
                raise


    def updateFileTracking(self, dbConn, stpDeliveryFile, appModule):
        query = '''
        update fle_tkg set s3_obj_key=%s, fldr_key=%s, fle_nme=%s, stp_flnm=%s, fle_sz_msmt=%s, prcs_stat_cd=%s, prcs_rslt_cd=%s,
            lst_dlvr_atmpt_tmst=NOW(), dlvr_atmpt_cnt=%s, row_modr_id_txt=%s
            where fle_tkg_id=%s
        '''
        params = (stpDeliveryFile.s3Object.getS3ObjectKey(), stpDeliveryFile.relativeFolder,
                  stpDeliveryFile.s3Object.fileName, stpDeliveryFile.stpFileName, stpDeliveryFile.s3Object.fileSize,
                  stpDeliveryFile.processStatusCode, stpDeliveryFile.processResultCode, stpDeliveryFile.deliveryAttemptCount, appModule,
                  stpDeliveryFile.fileTrackingId)
        logging.info(f"updateFileTracking: query={query} params={params}")
        dbConn.cursor.execute(query, params)
        logging.info("updateFileTracking: back from update")


    def updatePartnerFileTracking(self, dbConn, stpPartnerDeliveryFile, appModule):
        query = '''
        update ptnr_fle_tkg set rec_cnt=%s, rej_rec_cnt=%s, attm_cnt=%s, btch_prcs_stat_cd=%s, btch_rej_err_txt=%s, btch_reqs_id=%s, row_modr_id_txt=%s
            where ptnr_fle_tkg_id=%s
        '''
        params = (stpPartnerDeliveryFile.recordCount, stpPartnerDeliveryFile.rejectRecordCount,
                  stpPartnerDeliveryFile.attachmentCount, stpPartnerDeliveryFile.batchProcessStatusCode, stpPartnerDeliveryFile.rejectErrorText,
                  stpPartnerDeliveryFile.batchRequestId, appModule, stpPartnerDeliveryFile.partnerFileTrackingId)
        logging.info(f"updatePartnerFileTracking: query={query} params={params}")
        dbConn.cursor.execute(query, params)
        logging.info("updatePartnerFileTracking: back from update")


    def queryPartnerFileTracking(self, dbConn, inboundOutboundIndicator, relativeFolder, fileName, stpDeliveryIndicator):
        '''
            Queries database for a single partner file tracking (or file tracking) record, by inbound-outbound indicator, relativeFolder, filename, and stp delivery indicator.
            Returns an StpDeliveryFile object (which may be StpPartnerDeliveryFile object).
        '''
        query = '''
select FT.fle_tkg_id, inb_outb_ind, stp_dlvr_ind, s3_obj_key, fldr_key, fle_nme, stp_flnm, fle_sz_msmt, prcs_stat_cd, prcs_rslt_cd, lst_dlvr_atmpt_tmst, dlvr_atmpt_cnt, FT.row_cre_tmst,
        ptnr_fle_tkg_id, fle_typ_cd, rec_cnt, attm_cnt, btch_prcs_stat_cd, rej_rec_cnt, btch_rej_err_txt,
        AAE.api_app_entl_id, dnb_app_id, app_nme, reqs_meth_cd, api_entl_obj, ptnr_fldr_nme, accss_key_nme, rsch_usr_lgin_key, prcs_optns_obj
from fle_tkg FT
left join ptnr_fle_tkg PFT on PFT.fle_tkg_id = FT.fle_tkg_id
left join api_app_entl AAE on AAE.api_app_entl_id = PFT.api_app_entl_id
where fle_nme = %s and fldr_key = %s and inb_outb_ind = %s and stp_dlvr_ind = %s
order by FT.row_cre_tmst desc
        '''
        params = (fileName, relativeFolder, inboundOutboundIndicator, stpDeliveryIndicator)
        logging.info(f"queryPartnerFileTracking: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryPartnerFileTracking: back from query")
        for result in rv:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(result, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            stpDeliveryFile = mapToStpPartnerDeliveryFile(dict_rslt, "", "", "")
            return stpDeliveryFile
        
        logging.info(f"queryPartnerFileTracking: Didn't find any row with inb_outb_ind={inboundOutboundIndicator} fldr_key={relativeFolder} fle_nme={fileName}")
        return None


    def queryFailedPartnerFileTracking(self, dbConn, inboundOutboundIndicator, stpDeliveryIndicator, minimumAgeMinutes):
        '''
            Queries database for any partner file tracking (or file tracking) record, by inbound-outbound indicator and stp delivery indicator,
            that are at least minAgeMinutes old.
            Returns a list of StpDeliveryFile objects (which may be StpPartnerDeliveryFile objects).
        '''
        query = '''
select FT.fle_tkg_id, inb_outb_ind, stp_dlvr_ind, s3_obj_key, fldr_key, fle_nme, stp_flnm, fle_sz_msmt, prcs_stat_cd, prcs_rslt_cd, lst_dlvr_atmpt_tmst, dlvr_atmpt_cnt, FT.row_cre_tmst,
        ptnr_fle_tkg_id, fle_typ_cd, rec_cnt, attm_cnt, btch_prcs_stat_cd, rej_rec_cnt, btch_rej_err_txt,
        AAE.api_app_entl_id, dnb_app_id, app_nme, reqs_meth_cd, api_entl_obj, ptnr_fldr_nme, accss_key_nme, rsch_usr_lgin_key, prcs_optns_obj
from fle_tkg FT
left join ptnr_fle_tkg PFT on PFT.fle_tkg_id = FT.fle_tkg_id
left join api_app_entl AAE on AAE.api_app_entl_id = PFT.api_app_entl_id
where inb_outb_ind = %s and stp_dlvr_ind = %s and prcs_stat_cd = 33804 and prcs_rslt_cd = 20244
and DATE_SUB(NOW(),INTERVAL %s MINUTE) > FT.ROW_CRE_TMST
order by FT.row_cre_tmst desc
        '''
        params = (inboundOutboundIndicator, stpDeliveryIndicator, minimumAgeMinutes)
        logging.info(f"queryFailedPartnerFileTracking: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryFailedPartnerFileTracking: back from query")
        stpDeliveryFiles = []
        for result in rv:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(result, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            stpDeliveryFile = mapToStpPartnerDeliveryFile(dict_rslt, "", "", "")
            stpDeliveryFiles.append(stpDeliveryFile)
        
        logging.info(f"queryFailedPartnerFileTracking: Found {len(stpDeliveryFiles)} records with inb_outb_ind={inboundOutboundIndicator}")
        return stpDeliveryFiles


    def queryPartnerFileByTrackingId(self, dbConn, fileTrackingId):
        '''
            Queries database for a single partner file tracking (or file tracking) record, by file tracking id.
            Returns an StpDeliveryFile object (which may be StpPartnerDeliveryFile object).
        '''
        query = '''
select FT.fle_tkg_id, inb_outb_ind, stp_dlvr_ind, s3_obj_key, fldr_key, fle_nme, stp_flnm, fle_sz_msmt, prcs_stat_cd, prcs_rslt_cd, lst_dlvr_atmpt_tmst, dlvr_atmpt_cnt, FT.row_cre_tmst,
        ptnr_fle_tkg_id, fle_typ_cd, rec_cnt, attm_cnt, btch_prcs_stat_cd, rej_rec_cnt, btch_rej_err_txt, btch_reqs_id,
        AAE.api_app_entl_id, dnb_app_id, app_nme, reqs_meth_cd, api_entl_obj, ptnr_fldr_nme, accss_key_nme, rsch_usr_lgin_key, prcs_optns_obj
from fle_tkg FT
left join ptnr_fle_tkg PFT on PFT.fle_tkg_id = FT.fle_tkg_id
left join api_app_entl AAE on AAE.api_app_entl_id = PFT.api_app_entl_id
where FT.fle_tkg_id = %s
        '''
        params = (fileTrackingId)
        logging.info(f"queryPartnerFileTracking: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryPartnerFileTracking: back from query")
        for result in rv:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(result, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            stpDeliveryFile = mapToStpPartnerDeliveryFile(dict_rslt, "", "", "")
            return stpDeliveryFile
        
        logging.info(f"queryPartnerFileTracking: Didn't find any row with fileTrackingId={fileTrackingId}")
        return None


    def queryPartnerFileTrackingByBatchStatus(self, dbConn, inboundOutboundIndicator, fileTypeCode, processStatusCode, processResultCode, batchProcessStatusCode):
        '''
            Queries database for any partner file tracking (or file tracking) record, by inbound-outbound indicator, file type, and statuses.
            Returns a list of StpDeliveryFile objects (which may be StpPartnerDeliveryFile objects).
        '''
        query = '''
select * from fle_tkg FT
left join ptnr_fle_tkg PFT on PFT.fle_tkg_id = FT.fle_tkg_id
left join api_app_entl AAE on AAE.api_app_entl_id = PFT.api_app_entl_id
where FT.inb_outb_ind = %s
and FT.prcs_stat_cd = %s
and FT.prcs_rslt_cd = %s
and PFT.btch_prcs_stat_cd = %s
and PFT.fle_typ_cd = %s
order by FT.row_cre_tmst asc
        '''
        params = (inboundOutboundIndicator, processStatusCode, processResultCode, batchProcessStatusCode, fileTypeCode)
        logging.info(f"queryPartnerFileTrackingByBatchStatus: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryPartnerFileTrackingByBatchStatus: back from query")
        stpDeliveryFiles = []
        for result in rv:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(result, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            stpDeliveryFile = mapToStpPartnerDeliveryFile(dict_rslt, "", "", "")
            stpDeliveryFiles.append(stpDeliveryFile)
        
        logging.info(f"queryFailedPartnerFileTracking: Found {len(stpDeliveryFiles)} records")
        return stpDeliveryFiles
        
        
    def queryElapsedMinutes(self, dbConn, partnerFileTrackingId):
        '''
            Queries database for the number of elapsed minutes since a partner tracking file was last modified
        '''
        query = '''
select TIMESTAMPDIFF(MINUTE, row_mod_tmst, NOW()) as pft_elapse_mins from ptnr_fle_tkg where ptnr_fle_tkg_id = %s
        '''
        params = (partnerFileTrackingId)
        logging.info(f"queryElapsedMinutes: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryElapsedMinutes: back from query")
        for result in rv:
            elapseMinutes = result.get("pft_elapse_mins")
            if elapseMinutes is not None:
                return elapseMinutes
        
        logging.error(f"queryElapsedMinutes: Didn't find any row with partnerFileTrackingId={partnerFileTrackingId}")
        return None
        
        
    def queryPartnerFileByBatchRequestIdAndFileType(self, dbConn, inboundOutboundIndicator, batchRequestId, partnerFileType):
        '''
            Queries database for the latest partner file tracking record, by inb/outb indicator, batch request id and partner file type.
            Returns an StpPartnerDeliveryFile object.
        '''
        query = '''
select FT.fle_tkg_id, inb_outb_ind, stp_dlvr_ind, s3_obj_key, fldr_key, fle_nme, stp_flnm, fle_sz_msmt, prcs_stat_cd, prcs_rslt_cd, lst_dlvr_atmpt_tmst, dlvr_atmpt_cnt, FT.row_cre_tmst,
        ptnr_fle_tkg_id, fle_typ_cd, rec_cnt, attm_cnt, btch_prcs_stat_cd, rej_rec_cnt, btch_rej_err_txt, btch_reqs_id,
        AAE.api_app_entl_id, dnb_app_id, app_nme, reqs_meth_cd, api_entl_obj, ptnr_fldr_nme, accss_key_nme, rsch_usr_lgin_key, prcs_optns_obj
from fle_tkg FT
left join ptnr_fle_tkg PFT on PFT.fle_tkg_id = FT.fle_tkg_id
left join api_app_entl AAE on AAE.api_app_entl_id = PFT.api_app_entl_id
where FT.inb_outb_ind = %s and btch_reqs_id = %s and fle_typ_cd = %s
order by FT.row_cre_tmst desc 
limit 1
        '''
        params = (inboundOutboundIndicator, batchRequestId, partnerFileType)
        logging.info(f"queryPartnerFileByBatchRequestIdAndFileType: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryPartnerFileByBatchRequestIdAndFileType: back from query")
        for result in rv:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(result, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            stpDeliveryFile = mapToStpPartnerDeliveryFile(dict_rslt, "", "", "")
            return stpDeliveryFile
        
        logging.info(f"queryPartnerFileByBatchRequestIdAndFileType: Didn't find any row with inboundOutboundIndicator={inboundOutboundIndicator} batchRequestId={batchRequestId} partnerFileType={partnerFileType}")
        return None
                
        
    def queryPartnerFilesByBatchRequestId(self, dbConn, batchRequestId):
        '''
            Queries database for all partner file tracking records, by batch request id.
            Returns a list of StpPartnerDeliveryFile objects.
        '''
        query = '''
select FT.fle_tkg_id, inb_outb_ind, stp_dlvr_ind, s3_obj_key, fldr_key, fle_nme, stp_flnm, fle_sz_msmt, prcs_stat_cd, prcs_rslt_cd, lst_dlvr_atmpt_tmst, dlvr_atmpt_cnt, FT.row_cre_tmst,
        ptnr_fle_tkg_id, fle_typ_cd, rec_cnt, attm_cnt, btch_prcs_stat_cd, rej_rec_cnt, btch_rej_err_txt, btch_reqs_id,
        AAE.api_app_entl_id, dnb_app_id, app_nme, reqs_meth_cd, api_entl_obj, ptnr_fldr_nme, accss_key_nme, rsch_usr_lgin_key, prcs_optns_obj
from fle_tkg FT
left join ptnr_fle_tkg PFT on PFT.fle_tkg_id = FT.fle_tkg_id
left join api_app_entl AAE on AAE.api_app_entl_id = PFT.api_app_entl_id
where btch_reqs_id = %s
order by FT.fle_tkg_id
        '''
        params = (batchRequestId)
        logging.info(f"queryPartnerFilesByBatchRequestId: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        stpDeliveryFiles = []
        for result in rv:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(result, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            stpDeliveryFile = mapToStpPartnerDeliveryFile(dict_rslt, "", "", "")
            stpDeliveryFiles.append(stpDeliveryFile)
        
        logging.info(f"queryPartnerFileByBatchRequestIdAndFileType: Query returned {len(stpDeliveryFiles)} files")
        return stpDeliveryFiles
