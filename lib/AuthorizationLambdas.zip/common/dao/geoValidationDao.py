'''
Created on Aug 29, 2019

@author: Dilip Teja
'''


import logging


class GeoValidationDao(object):
    
    def queryCountryCodes(self, dbConn, geoUnitTypeCode, geoCodeTypeCode):
        '''
            Queries database for getting all country codes.
        '''
        query = '''
select distinct GUP.geo_unit_id, GUPC.geo_code as countryCode
from geo_unit GUP
join geo_unit_code GUPC on GUPC.geo_unit_id = GUP.geo_unit_id
where 1=1
and GUP.expn_dt is null
and GUP.expd_by_dt is null
and GUPC.expn_dt is null
and GUPC.expd_by_dt is null
and GUP.geo_unit_typ_cd in (%s) 
and GUPC.geo_code_typ_cd in (%s)
order by GUP.geo_unit_id
        '''
        params = (geoUnitTypeCode, geoCodeTypeCode)
        dbConn.cursor.execute(query ,params)
        rv = dbConn.cursor.fetchall()
        logging.info("Country codes: " + str(rv))
        return rv
