'''
Created on Apr 26, 2019

@author: VanCampK
'''
import json
from common.encoders import IResearchEncoder

class ResearchUserDao(object):

    def queryUser(self, dbConn, userId):
        '''
            Queries database for a single user, returns a dictionary if found or None if not found.
        '''
        query = 'select * from rsch_usr where rsch_usr_id = %s'
        params = (userId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            # Only expect one row
            return dict_rslt
        
        return None
    

    def updateUser(self, dbConn, userId, userData, rowModifierIdTxt):
        '''
            Updates the rsch_usr_obj column of one row of the rsch_usr table.
        '''
        query = 'update rsch_usr set rsch_usr_obj=%s, row_modr_id_txt=%s where rsch_usr_id=%s'
    
        params = (userData, rowModifierIdTxt, userId)
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid;
    
    
    def getUserTeams(self, dbConn, userId, teamAdminIndc):
        '''
            Gets the list of teams the user is on.
            If teamAdminIndc is 1, gets the user's memberships as a LocalAdmin. If 0, gets memberships as a Researcher.
        '''
        query = '''
select RT.rsch_team_nme
from rsch_team_mbr TM
join rsch_team RT on RT.rsch_team_id = TM.rsch_team_id
join rsch_usr RU on RU.rsch_usr_id = TM.rsch_usr_id
where RU.rsch_usr_id = %s and TM.team_admr_indc = %s        
        '''
        params = (userId, teamAdminIndc)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        teamsList=[]
        for result in rv:
            teamName = result['rsch_team_nme']
            teamsList.append(teamName)
        
        return teamsList

    def getresearchAdminUser(self, dbConn, researchUserid):
        query = ''' 
        select rsch_usr_id,usr_eml_adr,lgin_key,rsch_usr_adm_obj,sbmt_org_nme,sbmt_ctry_code,UNIX_TIMESTAMP(row_mod_tmst) as timestamp from rsch_usr where rsch_usr_id=%s;
        '''
        params = (researchUserid)
        dbConn.cursor.execute(query, params)
        contents = dbConn.cursor.fetchone()
        return contents

    
    def updateResearchUser(self, dbConn, researchuserid, user_admin_json, modr_id_txt):
        query = "update rsch_usr set rsch_usr_adm_obj=%s, row_mod_tmst=now(), row_modr_id_txt=%s where rsch_usr_id=%s"
        params = (user_admin_json,modr_id_txt,researchuserid)
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()


    def expireActiveSessionsForUser(self, dbConn, userId):
        query = "update lgin_ses set expn_tmst=NOW() where rsch_usr_id = %s and expn_tmst > NOW() and lg_out_tmst is null"
        params = (userId)
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
