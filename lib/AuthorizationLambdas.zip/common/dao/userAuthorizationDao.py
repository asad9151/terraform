'''
Created on Oct 4, 2019
Class to help in querying and updating user level authorization information
TODO consider combining with researchUserDao

@author: VanCampK
'''
import json
from common.encoders import IResearchEncoder

class UserAuthorizationDao(object):

    def queryUserAuthorization(self, dbConn, loginKey):
        '''
            Queries database for a single user, returns a dictionary if found or None if not found.
            Sample rsch_usr_adm_obj: {"IDaaSUserRoles": [{"iDaaSRoleName": "IRESEARCH_SUBMITTER_US_SUPER7"}], "iResearchUserRoles": [], "researchSubTypesGroups": [{"researchSubTypesGroupCode": 34448}], "submitterRoutingCategories": [{"submitterRoutingCategoryCode": 34414}]}
            Sample rsch_usr_obj: {"isConsentOfTermsAndConditions": true, "termsAndConditionsLatestConsentTimestamp": "2019-07-29T17:41:56.505304+00:00", "termsAndConditionsInitialConsentTimestamp": "2019-07-29T17:41:56.505304+00:00"}
        '''
        query = 'select rsch_usr_id, rsch_usr_adm_obj, rsch_usr_obj from rsch_usr where lgin_key = %s'
        params = (loginKey)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            # Only expect one row
            return dict_rslt
        
        return None
    

    def updateUserAuthorization(self, dbConn, userId, userAdminData, rowModifierIdTxt):
        '''
            Updates the rsch_usr_adm_obj column of one row of the rsch_usr table.
        '''
        query = 'update rsch_usr set rsch_usr_adm_obj=%s, row_modr_id_txt=%s where rsch_usr_id=%s'
    
        params = (userAdminData, rowModifierIdTxt, userId)
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid
    

    def updateUserObject(self, dbConn, userId, userObjStr, rowModifierIdTxt):
        '''
            Updates the rsch_usr_obj column of one row of the rsch_usr table.
        '''
        query = 'update rsch_usr set rsch_usr_obj=%s, row_modr_id_txt=%s where rsch_usr_id=%s'
    
        params = (userObjStr, rowModifierIdTxt, userId)
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid
    
