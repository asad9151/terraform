'''
Created on Apr 14, 2020

@author: VanCampK
'''
import json
import logging

from common.encoders import IResearchEncoder
from common.mappers.partnerDetailMapper import mapToPartnerDetail


class PartnerDetailDao(object):


    def insertPartnerDetail(self, dbConn, partnerDetail, appModule):
        '''
CREATE TABLE ptnr_detl
(
    ptnr_detl_id         INTEGER NOT NULL AUTO_INCREMENT,
    ptnr_fle_tkg_id      INTEGER NOT NULL,
    rec_nbr              INTEGER NOT NULL,
    raw_data_obj         JSON NOT NULL,
    subj_rsch_id         INTEGER NULL,
    rej_indc             NUMERIC(1) NOT NULL DEFAULT 0,
    ptnr_reqs_rej_obj    JSON NOT NULL,
    row_cre_tmst         TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    row_crer_id_txt      VARCHAR(32) NOT NULL,
    row_mod_tmst         TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    row_modr_id_txt      VARCHAR(32) NOT NULL,
    PRIMARY KEY (ptnr_detl_id)
) AUTO_INCREMENT = 1;
        '''
        query = '''
        insert into ptnr_detl (ptnr_fle_tkg_id,rec_nbr,raw_data_obj,subj_rsch_id,rej_indc,ptnr_reqs_rej_obj,row_crer_id_txt,row_modr_id_txt)
        values (%s,%s,%s,%s,%s,%s,%s,%s)
        '''
        rawDataObjStr = None if partnerDetail.rawDataObject is None else json.dumps(partnerDetail.rawDataObject)
        partnerRequestRejectionObjectStr = None if partnerDetail.partnerRequestRejectionObject is None else json.dumps(partnerDetail.partnerRequestRejectionObject)
        params = (partnerDetail.partnerFileTrackingId, partnerDetail.recordNumber, rawDataObjStr,
                  partnerDetail.subjectResearchId, partnerDetail.rejectionIndicator, partnerRequestRejectionObjectStr,
                  appModule, appModule)
        
        logging.info(f"insertPartnerDetail: query={query} params={params}")
        dbConn.cursor.execute(query, params)
        partnerDetail.partnerDetailId = dbConn.cursor.lastrowid
        logging.info(f"insertPartnerDetail: back from query assigned partnerDetailId={partnerDetail.partnerDetailId}")
        return partnerDetail.partnerDetailId


    def queryCountPartnerDetail(self, dbConn, partnerFileTrackingId):
        '''
            Queries database for the count of partner detail records by partnerFileTrackingId.
            Returns a count.
        '''
        query = '''
select count(*) as detl_ct from ptnr_detl where ptnr_fle_tkg_id = %s
        '''
        params = (partnerFileTrackingId)
        logging.info(f"queryCountPartnerDetail: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryCountPartnerDetail: back from query")
        for result in rv:
            ct = result.get("detl_ct")
            if ct is not None:
                return ct
        
        logging.error(f"queryCountPartnerDetail: Didn't find any row with partnerFileTrackingId={partnerFileTrackingId}")
        return None


    def queryPartnerDetail(self, dbConn, partnerFileTrackingId):
        '''
            Queries database for all partner detail records by partnerFileTrackingId.
            Returns a list of PartnerDetail objects.
        '''
        query = '''
select * from ptnr_detl where ptnr_fle_tkg_id = %s
        '''
        params = (partnerFileTrackingId)
        logging.info(f"queryPartnerDetail: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryPartnerDetail: back from query")
        partnerDetails = []
        for result in rv:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(result, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            partnerDetail = mapToPartnerDetail(dict_rslt, "")
            partnerDetails.append(partnerDetail)
        
        logging.info(f"queryPartnerDetail: Read {len(partnerDetails)} records with partnerFileTrackingId={partnerFileTrackingId}")
        return partnerDetails
        