'''
Created on Jul 29, 2019

@author: VanCampK
'''
import json
from common.encoders import IResearchEncoder

class GeoDao(object):


    def queryTypeCodesToDescriptions(self, dbConn):
        '''
        Returns all ISO 2 letter country codes along with the country name
        '''
        query = '''
            select distinct GUPC.geo_code, GUPN.geo_nme
            from geo_unit GUP
            join geo_unit_code GUPC on GUPC.geo_unit_id = GUP.geo_unit_id
            join geo_unit_nme GUPN on GUPN.geo_unit_id = GUP.geo_unit_id 
            where 1=1
            and GUP.expn_dt is null
            and GUP.expd_by_dt is null
            and GUPC.expn_dt is null
            and GUPC.expd_by_dt is null
            and GUPN.expn_dt is null
            and GUPN.expd_by_dt is null
            and GUPN.lang_cd = 331
            and GUP.geo_unit_typ_cd = 128
            and GUPC.geo_code_typ_cd = 23416
            and GUPN.geo_nme_typ_cd = 32
            order by GUPC.geo_code, GUPN.geo_nme        
        '''
        dbConn.cursor.execute(query)
        rv = dbConn.cursor.fetchall()
        dict_data={}
        for res in rv:
            json_data = json.dumps(res, cls=IResearchEncoder)
            result = json.loads(json_data)
            dict_data[result['geo_code']] = result['geo_nme']
        
        return dict_data
