'''
Created on Jul 29, 2019

@author: VanCampK
'''
import json
import logging
from common.encoders import IResearchEncoder
from common.scotsDescriptionType import ScotsDescriptionType
from common.scotsLanguages import ScotsLanguage
from common.scotsSystemCodes import ScotsSystemCode

class ScotsDao(object):
    '''
    Queries for SCOTS data
    '''

    def queryTypeCodesToDescriptions(self, dbConn):
        '''
        Returns all type code to description mappings
        '''
        query = '''
select cv.cd_val_id, cv.cd_tbl_id, cvt.lang_cd, cvt.cd_val_shrt_desc, prod_litr_desc from cd_val cv
join cd_val_txt cvt
on cv.cd_val_id = cvt.cd_val_id
where cvt.expn_dt is null
        '''
        dbConn.cursor.execute(query)
        rv = dbConn.cursor.fetchall()
        dict_data={}
        for res in rv:
            json_data = json.dumps(res, cls=IResearchEncoder)
            result = json.loads(json_data)
            prod_litr_key = self.createKey(result['cd_tbl_id'], result['cd_val_id'], result['lang_cd'], ScotsDescriptionType.PROD_LITR_DESC.value)
            shrt_descr_key = self.createKey(result['cd_tbl_id'], result['cd_val_id'], result['lang_cd'], ScotsDescriptionType.CD_VAL_SHRT_DESC.value)
            dict_data[prod_litr_key] = result['prod_litr_desc']
            dict_data[shrt_descr_key] = result['cd_val_shrt_desc']
        
        return dict_data
    
    
    def createKey(self, cdTblId, cdValId, langId, scotsDescriptionType):
        '''
        Create a key for lookup in the TypeCodesToDescriptions dictionary
        '''
        ky = (cdTblId, cdValId, langId, scotsDescriptionType)
        return ky
    
    
    def getProductLiteralDescription(self, dict_data, cdTblId, cdValId, langId=None):
        '''
        Returns the product literal description for the given code in the given table.
        If langId not specified, then returns U.S. English
        '''
        if langId is None:
            langId = ScotsLanguage.US_ENGLISH.value
        ky = self.createKey(cdTblId, cdValId, langId, ScotsDescriptionType.PROD_LITR_DESC.value)
        return dict_data.get(ky)
    
    
    def getShortDescription(self, dict_data, cdTblId, cdValId, langId=None):
        '''
        Returns the short description for the given code in the given table.
        If langId not specified, then returns U.S. English
        '''
        if langId is None:
            langId = ScotsLanguage.US_ENGLISH.value
        ky = self.createKey(cdTblId, cdValId, langId, ScotsDescriptionType.CD_VAL_SHRT_DESC.value)
        return dict_data.get(ky)
    
    
    def queryScotsTypeCodeLists(self, dbConn, cdTblIds):
        '''
        Given a list of numeric table ids, will return the list of all valid SCOTS codes for those tables for the iResearch application
        '''
        query = '''
select distinct cv.cd_tbl_id as cdTblId, cv.cd_val_id as cdValId
from cd_val cv
left join sys_appy sa on (sa.cd_tbl_appy_indc=1 and sa.cd_tbl_id=cv.cd_tbl_id and sa.cd_val_id is null) or (sa.cd_tbl_appy_indc=0 and sa.cd_tbl_id=cv.cd_tbl_id and sa.cd_val_id=cv.cd_val_id)
where cv.expn_dt is null
and (sa.dnb_sys_cd is null or sa.dnb_sys_cd in (%s))
and cv.cd_tbl_id in (
        '''
        paramlist = [ScotsSystemCode.IRESEARCH.value]
        firstTable = True
        for cdTblId in cdTblIds:
            paramlist.append(cdTblId)
            if not firstTable:
                query += ","
            query += "%s"
            firstTable = False
        query += ") order by cv.cd_tbl_id, cv.cd_val_id" 
        params = tuple(paramlist)
        logging.debug("queryScotsTypeCodeLists: query='" + query + "' params='" + str(params) + "'")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for res in rv:
            json_data = json.dumps(res, cls=IResearchEncoder)
            result = json.loads(json_data)
            dict_data.append(result)
        
        #logging.debug("queryScotsTypeCodeLists result: " + str(dict_data))
        return dict_data
        
