'''
Created on Apr 26, 2019

@author: VanCampK
'''
import json
import logging

from common.encoders import IResearchEncoder
from common.mappers.apiApplicationEntitlementMapper import mapToApiApplicationEntitlement


class ApiApplicationEntitlementDao(object):

    def queryApiApplication(self, dbConn, dnbAppId):
        '''
            Queries database for a single D&B application ID, returns a dictionary if found or None if not found.
        '''
        query = 'select * from api_app_entl where dnb_app_id = %s'
        params = (dnbAppId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            # Only expect one row
            return dict_rslt
        
        return None


    def queryApiApplicationAsObject(self, dbConn, dnbAppId):
        '''
            Queries database for a single D&B application ID, returns an ApiApplicationEntitlement object if found or None if not found.
        '''
        dict_rslt = self.queryApiApplication(dbConn, dnbAppId)
        apiAppEntl = mapToApiApplicationEntitlement(dict_rslt, "")
        return apiAppEntl


    def queryAllApiApplications(self, dbConn):
        '''
            Queries database for all D&B applications, returns a list of apiApplicationEntitlement objects.
        '''
        query = 'select * from api_app_entl'
        params = ()
        logging.info(f"queryAllApiApplications: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryAllApiApplications: back from query")
        apiAppEntlList = []
        for result in rv:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(result, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            apiAppEntl = mapToApiApplicationEntitlement(dict_rslt, "")
            apiAppEntlList.append(apiAppEntl)
            
        return apiAppEntlList
    
    def queryAllApiApplicationsNoObjMapper(self, dbConn):
        '''
            Queries database for all D&B applications.
        '''
        query = 'select * from api_app_entl'
        params = ()
        logging.info(f"queryAllApiApplications: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryAllApiApplications: back from query")
        dict_data=[] = []
        for result in rv:
            dict_data.append(result)  
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)

        dict_arry = json.loads(json_data)
        return dict_arry;
    
    def queryApiAppUsingApiAppEntlId(self, dbConn, apiAppEntlId):
        '''
            Queries database for a single D&B application ID, returns a dictionary if found or None if not found.
        '''
        query = 'select *, UNIX_TIMESTAMP(row_mod_tmst) as mod_timestamp from api_app_entl where api_app_entl_id = %s'
        params = (apiAppEntlId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            # Only expect one row
            return dict_rslt
        
        return None
    
    def queryApiAppForExistingPartnerFolderName(self, dbConn, partnerFolderName):
        '''
            Queries database for existing Partner Folder Name
        '''
        query = 'select * from api_app_entl where ptnr_fldr_nme = %s;'
        params = (partnerFolderName)
        logging.info(f"queryAllApiApplications: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        logging.info("queryAllPartnerFolderNames: back from query")
        dict_data=[]
        for result in rv:
            dict_data.append(result)  
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)

        dict_arry = json.loads(json_data)
        return dict_arry;
