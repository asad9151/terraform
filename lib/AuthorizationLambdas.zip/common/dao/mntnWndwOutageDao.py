'''
Created on Feb 26, 2021
DAO for keepaliveservice to retrieve and build cache for maintenance window outages data.
DAO is also shared with retrieveAdminData in order to fetch maintenance window record or
all records for maintaining current and upcoming outages.
@author: GuardiolaR
'''

import json
from common.encoders import IResearchEncoder

def queryMntnWndwOutagesData(dbConn, mntnWindowId, lastOutage):
        paramList = []
        query = '''
            SELECT MW.mntn_wndw_id, MW.mntn_effv_tmst, MW.mntn_expn_tmst, MW.mntn_lckt_wrng_mins_cnt, UNIX_TIMESTAMP(MW.row_mod_tmst) as mntn_wndw_mod_timestamp,
            BM.bnr_msg_obj, BM.effv_tmst, BM.expn_tmst, BM.bnr_msg_act_ind, UNIX_TIMESTAMP(BM.row_mod_tmst) as bnr_mod_timestamp from mntn_wndw MW
            INNER JOIN bnr_msg BM on MW.bnr_msg_id = BM.bnr_msg_id
            AND DATE_SUB(NOW(),INTERVAL %s day) <= MW.mntn_expn_tmst
        '''
        
        # If mntnWindowId is included then query will get single record, otherwise summary is returned
        if mntnWindowId is None:
            paramList.append(lastOutage)
            params = tuple(paramList)
            dbConn.cursor.execute(query, params)
        else:
            query += ' WHERE MW.mntn_wndw_id  = %s'
            paramList = (lastOutage, mntnWindowId)
            params = tuple(paramList)
            dbConn.cursor.execute(query, params)
            
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
        
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print(json_data)
        dict_arry = json.loads(json_data)

        return dict_arry