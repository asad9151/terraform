'''
Created on Jun 19, 2019

@author: VanCampK
'''
import json
import logging
from common.encoders import IResearchEncoder
from common.linkTypeCodes import LinkTypeCode


class BatchRequestDao(object):
    '''
    Database access object for batch and reject processing
    '''

    def insertRejectRecord(self, dbConn, batchRequestId, origRequestObj, requestRejectionErrorObj, appModule):
        query = '''
        insert into btch_rsch_reqs_rej (btch_reqs_id,btch_rsch_reqs_obj,btch_rsch_reqs_rej_obj,row_crer_id_txt,row_modr_id_txt)
        values (%s,%s,%s,%s,%s)
        '''
    
        params = (batchRequestId, origRequestObj, requestRejectionErrorObj, appModule, appModule)
        logging.info('Insert reject: ' + query + ' params=' + str(params))
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid;


    def updateBatchStatusAndCounts(self, dbConn, batchRecord, appModule):
        query = '''
        update btch_reqs set prcs_stat_cd=%s, stat_tmst=NOW(), btch_rej_err_txt=%s, tot_entr_cnt=%s, tot_detl_cnt=%s, rej_entr_cnt=%s, due_date=%s, row_modr_id_txt=%s where btch_reqs_id=%s
        '''
        
        params = (batchRecord.processingStatusCode, batchRecord.batchRejectionErrorText, batchRecord.totalEntriesCount, batchRecord.totalDetailsCount, batchRecord.rejectedEntriesCount, batchRecord.dueTimestamp, appModule, batchRecord.batchRequestId)
        logging.info('Update batch: ' + query + ' params=' + str(params))
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()


    def getBatchCasesToCheckOpen(self, dbConn, batch_reqs_id):
        '''
        Returns batch counts in btch_reqs table, as well as actual counts from reject table, requests table, and detail table, for a single batchRequestId
        '''
        query = '''select BR.btch_reqs_id, BR.prcs_stat_cd, BR.tot_entr_cnt, BR.rej_entr_cnt, BR.tot_detl_cnt, BR.btch_rej_err_txt, BR.due_date, BR.btch_typ, BR.row_mod_tmst, BR.row_modr_id_txt,
                                (select count(*) from btch_rsch_reqs_rej BRR where BRR.btch_reqs_id=%s) as btch_rej_cnt,
                                (select count(distinct RR.rsch_reqs_id) from subj_rsch SR join rsch_reqs RR on RR.rsch_reqs_id = SR.rsch_reqs_id where RR.btch_reqs_id=%s and (lnk_typ is null or lnk_typ <> %s)) as btch_acc_cnt,
                                (select count(*) from btch_detl BD where BD.btch_reqs_id=%s) as btch_detl_cnt
                                from btch_reqs BR where BR.btch_reqs_id=%s
                                '''
        params = (batch_reqs_id, batch_reqs_id, LinkTypeCode.ORIGINAL_CASE.value, batch_reqs_id, batch_reqs_id)
        logging.info('getBatchCasesToCheckOpen: ' + query + ' params=' + str(params))
        dbConn.cursor.execute(query, params)
        contents = dbConn.cursor.fetchone()
        return contents
        
        
    def getBatchCasesToCheckClose(self, dbConn, batch_reqs_id):
        query = '''select BR.btch_reqs_id, BR.prcs_stat_cd, BR.tot_entr_cnt, BR.rej_entr_cnt, BR.due_date, BR.btch_typ, BR.row_mod_tmst, BR.row_modr_id_txt,
                                (select count(*) from subj_rsch SR join rsch_reqs RR on RR.rsch_reqs_id = SR.rsch_reqs_id where RR.btch_reqs_id=%s and SR.curr_rsch_intrl_stat_cd <> 33617 and (lnk_typ is null or lnk_typ <> %s)) as opn_subj_rsch_cnt
                                from btch_reqs BR where BR.btch_reqs_id=%s
                                '''
        params = (batch_reqs_id, LinkTypeCode.ORIGINAL_CASE.value, batch_reqs_id)
        logging.info('getBatchCasesToCheckClose: ' + query + ' params=' + str(params))
        dbConn.cursor.execute(query, params)
        contents = dbConn.cursor.fetchone()
        return contents
        
        
    def getBatchCountsForUnClosed(self, dbConn, batch_reqs_id):
        query = '''select BR.btch_reqs_id, BR.btch_typ,
                                (select count(distinct RR.rsch_reqs_id) from rsch_reqs RR join subj_rsch SR on SR.rsch_reqs_id = RR.rsch_reqs_id where RR.btch_reqs_id=%s and SR.curr_rsch_intrl_stat_cd <> 33617 and (lnk_typ is null or lnk_typ <> %s)) as unclsd_rsch_rqst_cnt
                                from btch_reqs BR where BR.btch_reqs_id=%s'''
        params = (batch_reqs_id, LinkTypeCode.ORIGINAL_CASE.value, batch_reqs_id)
        logging.info('getBatchCountsForUnClosed: ' + query + ' params=' + str(params))
        dbConn.cursor.execute(query, params)
        contents = dbConn.cursor.fetchone()
        return contents


    def getBatchCaseDetails(self, dbConn, batch_reqs_id):
        '''
        BatchWatchService query to return all the accepted and rejected records for a batch
        '''
        query = '''select 'ACCEPTED' as rec_typ, RR.rsch_reqs_id as reqs_id, RR.rsch_reqs_obj,
                                SR.subj_rsch_id, SR.subj_rsch_obj, SR.dnb_subj_data_obj, SR.subj_dnb_data_obj, SR.curr_rsch_intrl_stat_cd, SR.curr_rsch_extl_stat_cd, RRS.rsch_rslt_obj,
                                NULL as btch_rsch_reqs_rej_obj, RR.btch_rsch_reqs_obj, CR.rsch_cmnt as reqs_cmnt, CS.rsch_cmnt as resl_cmnt, RR.row_cre_tmst
                                from rsch_reqs RR  
                                join subj_rsch SR on SR.rsch_reqs_id = RR.rsch_reqs_id  
                                left join rsch_rslt RRS on RRS.subj_rsch_id = SR.subj_rsch_id  
                                left join cmnt CR on CR.rsch_reqs_id = RR.rsch_reqs_id and CR.cmnt_typ_cd = 33588
                                left join cmnt CS on CS.subj_rsch_id = SR.subj_rsch_id and CS.cmnt_typ_cd = 33590
                                where RR.btch_reqs_id=%s
                                and (CR.cmnt_typ_cd is null or CR.cmnt_typ_cd = 33588)
                                and (CS.cmnt_typ_cd is null or CS.cmnt_typ_cd = 33590)
                                UNION
                                select 'REJECTED' as rec_typ, BRR.btch_rsch_reqs_rej_id as reqs_id, NULL as rsch_reqs_obj,
                                NULL as subj_rsch_id, NULL as subj_rsch_obj, NULL as dnb_subj_data_obj, NULL as subj_dnb_data_obj, NULL as curr_rsch_intrl_stat_cd, NULL as curr_rsch_extl_stat_cd, NULL as rsch_rslt_obj,
                                BRR.btch_rsch_reqs_rej_obj, BRR.btch_rsch_reqs_obj,NULL as reqs_cmnt, NULL as resl_cmnt, NULL as row_cre_tmst
                                from btch_rsch_reqs_rej BRR
                                where BRR.btch_reqs_id=%s
                                order by 1, 2
                                '''
        params = (batch_reqs_id, batch_reqs_id)
        logging.info('getBatchCaseDetails: ' + query + ' params=' + str(params))
        dbConn.cursor.execute(query, params)
        contents = dbConn.cursor.fetchall()
        return contents


    def insertBatchDetailRecords(self, dbConn, batchRequestId, requestRecords, rowCreatorId):
        '''
        Inserts an array of requests into the batch detail table
        @param batchRequestId            ID of the batch
        @param requestRecords            Array of request records
        @param rowCreatorId              The module that created the entry
        @return                          The number of records inserted
        '''
        query = "insert into btch_detl (btch_reqs_id,rec_nbr,raw_data_obj,rej_indc,row_crer_id_txt,row_modr_id_txt) values (%s,%s,%s,%s,%s,%s)"
        batch_data = []
        nrecs = len(requestRecords)
        for i in range(nrecs):
            rec = requestRecords[i]
            isRejectedInd = 1 if rec.isRejected() == True else 0
            origRec = json.dumps(rec.originalRecords[0])
            params = (batchRequestId,i+1,origRec,isRejectedInd,rowCreatorId,rowCreatorId)
            batch_data.append(params)

        logging.info(f"insertBatchDetailRecords: query={query} nrecs={len(requestRecords)}")
        dbConn.cursor.executemany(query,batch_data)
        return nrecs
    
        
    def getBatchRecord(self, dbConn, batchRequestId):
        '''
            Queries database for a single batch record, returns a dictionary if found or None if not found.
        '''
        query = 'select BR.*, LS.auth_prin_id_obj from btch_reqs BR left join lgin_ses LS on LS.dnb_jti_val = BR.dnb_jti_val where btch_reqs_id=%s'
        params = (batchRequestId)
        logging.info(f"getBatchRecord: query={query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchone()
        if rv is not None:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(rv, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            return dict_rslt
        
        return None


    def getBatchDetails(self, dbConn, batchRequestId):
        query = "select * from btch_detl where btch_reqs_id=%s order by rec_nbr asc"
        params = (batchRequestId)
    
        logging.info(f"getBatchDetails: query={query} params={params}")
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        # {'btch_detl_id': 17501, 'btch_reqs_id': 2692, 'rec_nbr': 1, 'raw_data_obj': '{"D-U-N-S": 402005367, "internalRefId": "3", "Request Comment": "DUNS in Netherlands", "Subscriber Name": "", "Client Request Key": "KVC-20200122-1", "Business Owner Type": "", "Owner Business Name": "", "Owner D-U-N-S Number": "", "Subject Business URL": "", "Duplicate DUNS Number": "", "Expected Annual Sales": "", "Expected Control Year": "", "Expected Year Started": "", "Acquirer Business Name": "", "Expected Business Name": "Kens merger in Netherlands", "Owner Telephone Number": "", "Research Sub Type Code": "Merger occurred : 33768", "requestorOwnRequestKey": "KVC-20200122-1", "Acquirer D-U-N-S Number": "", "Expected Principal Name": "", "Expected Principal Title": "", "Acquirer Telephone Number": "", "Expected Share Owner Name": "", "Expected Trade Style Name": "", "Expected Operational Status": "", "Owner Physical Address Town": "", "Expected Number of Employees": "", "Financial Ratio Concern Text": "", "Expected % of Stock Ownership": "", "Owner Physical Address Region": "", "Owner Physical Address Street": "", "Subject Business Contact Name": "", "Acquirer Physical Address Town": "", "Expected Physical Address Town": "", "Financial Figures Concern Text": "", "Subject Business Contact Email": "", "Subject Business Contact Phone": "", "Expected Legal Form Description": "", "Expected Primary Principal Name": "", "Acquirer Physical Address Region": "", "Acquirer Physical Address Street": "", "Expected Physical Address Region": "", "Expected Physical Address Street": "", "Expected Primary Principal Title": "", "Financial Statement Concern Text": "", "Expected Business Telephone Number": "", "Owner Physical Address Postal Code": "", "Expected Industry Code / Description": "", "Acquirer Physical Address Postal Code": "", "Expected Physical Address Postal Code": "", "Owner Physical Address Country (ISO2)": "", "Acquirer Physical Address Country (ISO2)": "", "Expected Physical Address Country (ISO2)": "", "Expected Related Organization / Affiliate Name": ""}', 'ctry_code': 'NL', 'part_nme': 'NewCo Norway 3601', 'rsch_reqs_id': None, 'rej_indc': 0, 'row_cre_tmst': '2020-01-24T15:55:31.000+00:00', 'row_crer_id_txt': 'BatchDetail', 'row_mod_tmst': '2020-01-24T15:55:31.000+00:00', 'row_modr_id_txt': 'BatchDetail', 'btch_rsch_reqs_rej_id': None, 'part_id': 18}
        return dict_arry;


    def getBatchDetailRecordNumbers(self, dbConn, batchRequestId):
        '''
        Gets all the rec_nbr's of records in a batch whose batch details have been saved
        '''
        query = "select rec_nbr from btch_detl where btch_reqs_id=%s order by rec_nbr asc"
        params = (batchRequestId)
    
        logging.info(f"getBatchDetailRecordNumbers: query={query} params={params}")
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        # {'rec_nbr': 1}
        return dict_arry;


    def getBatchSubmittedOrRejectedRecordNumbers(self, dbConn, batchRequestId):
        '''
        Gets all the rec_nbr's of records in a batch that have been either submitted or rejected
        '''
        query = "select rec_nbr from btch_detl where btch_reqs_id = %s and (rsch_reqs_id is not null or btch_rsch_reqs_rej_id is not null) order by rec_nbr asc;"
        params = (batchRequestId)
    
        logging.info(f"getBatchSubmittedOrRejectedRecordNumbers: query={query} params={params}")
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        # {'rec_nbr': 1}
        return dict_arry;


    def updateKeywords(self, dbConn, batchRequestId):
        '''
        Updates the keywords field in the batch research table with the latest contents in the database in the btch_reqs table
        and all other tables that contribute keywords (such as rsch_usr).
        '''
        query = '''
        UPDATE btch_reqs BR join rsch_usr RU on RU.rsch_usr_id = BR.rsch_usr_id SET kywd_txt=CONCAT(CONVERT(BR.btch_reqs_id,CHAR(12)),' ',SUBSTR(COALESCE(RU.lgin_key,''), 1,50),' ',COALESCE(SUBSTR(COALESCE(BR.cust_nme,''), 1,50)),' ',SUBSTR(COALESCE(RU.sbmt_org_nme,''), 1,50))
        where btch_reqs_id = %s
        '''
        
        params = (batchRequestId)
        logging.info(f"updateKeywords: query={query} params={params}")
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
