'''
Created on Mar 19, 2019

@author: VanCampK
'''
import json
from common.encoders import IResearchEncoder

class SubjectResearchDao(object):
    '''
    DAO class for querying/updating a subject research (case)
    '''

    def querySubjResearch(self, dbConn, subjRschId):
        '''
            Queries database for a single case, returns a dictionary if found or None if not found.
        '''
        query = '''
select SR.*, RU.lgin_key 
from subj_rsch SR
left join rsch_usr RU on RU.rsch_usr_id = SR.curr_rsch_usr_id 
where subj_rsch_id = %s
        '''
        params = (subjRschId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            return dict_rslt
        
        return None


    def querySubjResearchByResearchRequestId(self, dbConn, rschReqsId):
        '''
            Queries database for all cases in a research request, returns an array of dictionaries.
            May return multiple cases if a multi-case request, or empty array if none found.
        '''
        query = '''
select SR.*, RU.lgin_key 
from subj_rsch SR
left join rsch_usr RU on RU.rsch_usr_id = SR.curr_rsch_usr_id 
where rsch_reqs_id = %s
        '''
        params = (rschReqsId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for res in rv:
            json_data = json.dumps(res, cls=IResearchEncoder)
            result = json.loads(json_data)
            dict_data.append(result)

        return dict_data
    
    
    def querySubjResearchTeams(self, dbConn, subjRschId, localAdminUserId):
        '''
            Queries database for the research team for a single subject research to which the local admin belongs.
            Returns a list of teams the admin is a member of, if any, or an empty list if none.
        '''
        query = '''
select rsch_team_id
from rsch_team_mbr TM
where rsch_usr_id = %s
and team_admr_indc = 1
and TM.rsch_team_id in (select curr_rsch_team_id from subj_rsch SR where SR.subj_rsch_id = %s)
        '''
        params = (localAdminUserId, subjRschId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        return rv
    
    def queryCountryCode(self, dbConn, subjRschId):
        '''
            Returns country code by following order of priority: firmographics, research results, submitted data
        '''
        query = '''
select 
CASE
    WHEN v_rslt_ctry_cd is not null THEN v_rslt_ctry_cd
    WHEN v_dnb_ctry_cd is not null THEN v_dnb_ctry_cd
    WHEN v_subm_ctry_cd is not null THEN v_subm_ctry_cd
END as countryCode
from subj_rsch sr
left join rsch_rslt rr
on sr.subj_rsch_id = rr.subj_rsch_id where sr.subj_rsch_id = %s
        '''
        params = (subjRschId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        if len(rv) > 0:
            return rv[0]
        
        return None