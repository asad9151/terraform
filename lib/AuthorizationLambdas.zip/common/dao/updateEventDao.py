'''
Created on Mar 19, 2019

@author: VanCampK
'''
import logging

class UpdateEventDao(object):
    '''
    DAO to insert entries into the update event table.
    '''

    def insertEvent(self, dbConn, userId, tableName, rowId, primaryColumnOrFieldName, newValue,
            internalStatusCode, updateActionCode, reasonCode, dnbJtiVal, eventResultCode, rowCreatorId):
        '''
        Inserts an event into the user update event table
        @param userId                    ID of the user that initiated the event (OPTIONAL - omit only if system-generated event).
        @param tableName                 Name of the primary table updated (MANDATORY).
        @param rowId                     RowId of the table that was updated (MANDATORY).
        @param primaryColumnOrFieldName  Name of the primary column (or primary field if inside a json object) that was updated (OPTIONAL).
                                         If the entire json was updated, just name the json object column.
        @param newValue                  The value stored in the primary column or field (OPTIONAL).
                                         This is generally only used for small-valued columns, e.g. status or new identifier.
        @param internalStatusCode        The status of the case at the time of update (only applies to case-level updates) (OPTIONAL).
        @param updateActionCode          The action taken (use UpdateActionCode) (MANDATORY).
        @param reasonCode                The reason the action was taken, if supplied (see TransferReasonCode) (OPTIONAL).
        @param dnbJtiVal                 The D&B JTI authenticated session token (OPTIONAL).
        @param eventResultCode           The result code, if applicable (OPTIONAL).
        @param rowCreatorId              The module that created the entry (OPTIONAL - if not present defaults to irschappwrite).
        @return                          ID of the newly inserted event entry.
        '''
        paramList = []
        query = 'insert into upd_evnt('
        values = 'values('
        if userId:
            query += 'rsch_usr_id,'
            values += '%s,'
            paramList.append(userId)
        query += 'tbl_nme,'                 # MANDATORY
        values += '%s,'
        paramList.append(tableName)
        query += 'tbl_row_id,'              # MANDATORY
        values += '%s,'
        paramList.append(rowId)
        if primaryColumnOrFieldName:
            query += 'colm_nme,'
            values += '%s,'
            paramList.append(primaryColumnOrFieldName)
        if newValue:
            query += 'data_ele_val,'
            values += '%s,'
            paramList.append(newValue)
        if internalStatusCode:
            query += 'rsch_intrl_stat_cd,'
            values += '%s,'
            paramList.append(internalStatusCode)
        query += 'data_chg_typ_cd,'              # MANDATORY
        values += '%s,'
        paramList.append(updateActionCode)
        if reasonCode:
            query += 'upd_reas_cd,'
            values += '%s,'
            paramList.append(reasonCode)
        if dnbJtiVal:
            query += 'dnb_jti_val,'
            values += '%s,'
            paramList.append(dnbJtiVal)
        if eventResultCode:
            query += 'evnt_rslt_cd,'
            values += '%s,'
            paramList.append(eventResultCode)
        query += 'row_crer_id_txt) '              # MANDATORY
        values += '%s'
        if rowCreatorId:
            paramList.append(rowCreatorId)
        else:
            paramList.append('irschappwrite')

        query += values + ')'

        params = tuple(paramList)
        logging.info('insertEvent: ' + query + " params=" + str(params))
        dbConn.cursor.execute(query,params)
        dbConn.dbconn.commit();
        # Return the id of the newly inserted row
        return dbConn.cursor.lastrowid