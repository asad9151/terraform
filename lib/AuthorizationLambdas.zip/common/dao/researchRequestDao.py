'''
Created on Mar 19, 2019

@author: VanCampK
'''
import json
from common.encoders import IResearchEncoder

class ResearchRequestDao(object):
    '''
    DAO class for querying/updating a research request
    '''

    def queryResearchRequest(self, dbConn, rschReqsId, submitterUserId=None):
        '''
            Queries database for a single research request, returns a dictionary if found or None if not found.
            The response includes the rsch_reqs row plus the lgin_key of the submitter
            Parameters:
                dbConn - database connection object
                rschReqsId - id of the request to return
                submitterUserId - optional login key of the submitter. If the supplied login key does not match
                  either the original submitter or a member of the submitter team, the row is not returned.
        '''
        query = '''
select RR.*, RRU.lgin_key 
from rsch_reqs RR
join rsch_usr RRU on RRU.rsch_usr_id = RR.rsch_usr_id 
where rsch_reqs_id = %s
        '''
        params = (rschReqsId)
        if submitterUserId is not None:
            query += " and RRU.rsch_usr_id in (select distinct SSG2.rsch_usr_id from sbmt_sbms_grp SSG2 where SSG2.sbms_grp_id in (select SSG1.sbms_grp_id from sbmt_sbms_grp SSG1 where SSG1.rsch_usr_id = %s) UNION DISTINCT select %s)"
            params = (rschReqsId, submitterUserId, submitterUserId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print('Result of fetchall/zip:')
            #print(json_data)
            dict_rslt = json.loads(json_data)
            return dict_rslt
        
        return None
    
    
    def queryResearchRequestTeams(self, dbConn, rschReqsId, localAdminUserId):
        '''
            Queries database for the list of research teams for a single research request to which the local admin belongs.
            Returns a list of teams the admin is a member of, if any, or an empty list if none.
        '''
        query = '''
select rsch_team_id
from rsch_team_mbr TM
where rsch_usr_id = %s
and team_admr_indc = 1
and TM.rsch_team_id in (select curr_rsch_team_id from subj_rsch SR where SR.rsch_reqs_id = %s)
        '''
        params = (localAdminUserId, rschReqsId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        return rv