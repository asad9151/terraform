'''
Created on Jun 2, 2019

@author: VanCampK
'''
import csv
from collections import OrderedDict
from openpyxl import load_workbook
# We aren't using defusedxml directly, it is used internally by openpyxl but we want our module to fail if it isn't installed
#from defusedxml.ElementTree import parse
#import defusedxml
from openpyxl import DEFUSEDXML
import logging
from lambdas.exceptions import LambdaConflictException
from common.util.stringUtils import isInt

class ExcelReader(object):
    '''
    Utility for reading an Excel workbook or CSV file
    '''


    def readWorkbookSheetAsJson(self, filePath, sheetName=None, minRowNum=1, convertAllValsToStr=False):
        '''
        Reads the named sheet from an excel workbook and parses into json.
        If sheet name is not provided, reads the active sheet.
        All rows before minRowNum (1-based) will be ignored.
        '''
        # DEFUSEDXML is needed to safeguard process against attacks
        if DEFUSEDXML is not True:
            logging.error('Internal Security Error: openpyxl is NOT using DEFUSEDXML')
            raise LambdaConflictException('Internal Security Error')
        
        wb = load_workbook(filePath, data_only=True, keep_links=False)
        logging.info("Back from load_workbook")
        #print (wb.sheetnames)
        if sheetName:
            sheet = wb[sheetName]
        else:
            sheet = wb.active
            
        return self._readSheetAsJson(sheet, minRowNum, convertAllValsToStr)
        
    
    def _readSheetAsJson(self, sheet, minRowNum, convertAllValsToStr):
        rowNum = 0
        rowHeaders = None
        jsonResult = []
        for row in sheet.iter_rows(min_row=minRowNum, min_col=1):
            #print('Row=' + str(rowNum), end=': ')
            if rowNum == 0:
                rowHeaders = self._row2List(row, convertAllValsToStr)
            else:
                rowVals = self._row2List(row, convertAllValsToStr)
                z = zip(rowHeaders, rowVals)
                rowdict = dict(z)
                jsonResult.append(rowdict)
            rowNum += 1
            
        return jsonResult


    def _row2List(self, row, convertAllValsToStr):
        vals = []
        for cell in row:
            val = cell.value if cell.value else ''
            if isinstance(val, str):
                vals.append(val.strip())
            else:
                if convertAllValsToStr:
                    vals.append(str(val))
                else:
                    vals.append(val)
        return vals
        

    def readCsvAsJson(self, filePath, minRowNum=1, convertInt=True):
        '''
        Reads the named CSV file and parses into json.
        All rows before minRowNum (1-based) will be ignored.
        If convertInt is True, then checks for keys or values that contain integer values and converts them to int types (to be more consistent with what Excel does in xlsx file)
        '''
        rows = []
        with open(filePath, "r", encoding='utf-8-sig') as csvFile:
            csvReader = csv.DictReader(csvFile)
            rowNum = 1
            for csvRow in csvReader:
                if rowNum >= minRowNum:
                    if convertInt:
                        csvDict = OrderedDict()
                        for k, v in csvRow.items():
                            if isInt(k):
                                k = int(k)
                            if isInt(v):
                                v = int(v)
                            csvDict[k] = v
                        rows.append(csvDict)
                    else:
                        rows.append(csvRow)
                rowNum += 1

        return rows
