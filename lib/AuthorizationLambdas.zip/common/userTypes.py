'''
Created on Jun 21, 2019

@author: VanCampK
'''
from enum import Enum

class UserType(Enum):
    USER_TYPE_UI = "UI"
    USER_TYPE_CS = "CS"     # Cloud Services, i.e. Direct+
    USER_TYPE_STP = "STP"   # User came via file dropped on STP
    