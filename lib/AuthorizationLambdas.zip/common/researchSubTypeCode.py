'''
Created on Apr 10, 2020

@author: JafferS
'''
from enum import Enum

class ResearchSubTypeCode(Enum):
    NEW_DUNS_FULL_RISK_REVIEW = 33574
    FULL_CREDIT_RISK_REVIEW = 34378