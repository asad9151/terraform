'''
Created on Sep 30, 2019

@author: VanCampK
'''
import logging
from itertools import groupby


def mapScotsTypeCodeListToDict(qryResult):
    '''
    Given the results of the scotsDao.getScotsTypeCodeLists,
    returns a dictionary mapping each table id to its list of valid SCOTS codes.
    Sample input:
    [{'cdTblId': 30, 'cdValId': 399}, {'cdTblId': 30, 'cdValId': 3599}, {'cdTblId': 31, 'cdValId': 1114}, {'cdTblId': 31, 'cdValId': 1116}]
    Sample output:
    {
        30: [ 399, 3599 ],
        31: [ 1114, 1116 ]
    }
    '''
    ddict = {}
    groups = groupby(qryResult, lambda qryResult: qryResult['cdTblId'])
    for cdTblId, children in groups:
        childList = list(children)
        cdValIdList = []
        for child in childList:
            cdValId = child['cdValId']
            cdValIdList.append(cdValId)
        ddict[cdTblId] = cdValIdList
        #print(f"cdTblId={cdTblId}: {cdValIdList}")
            
    logging.debug("mapScotsTypeCodeListToDict result: " + str(ddict))
    return ddict
        