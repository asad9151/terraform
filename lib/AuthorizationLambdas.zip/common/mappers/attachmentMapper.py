'''
Created on Apr 23, 2019

@author: VanCampK
'''
from attachmentClass import attachment
import constants

def mapToAttachmentObj(dict_rslt):
    attmObj = attachment()
    attmObj.setAttachmentId(dict_rslt.get('attm_id'))
    if dict_rslt.get('subj_rsch_id'):
        attmObj.setIncomingAttachmentKey(dict_rslt.get('subj_rsch_id'))
        attmObj.setSubjectResearchId(dict_rslt.get('subj_rsch_id'))
    if dict_rslt.get('rsch_reqs_id'):
        attmObj.setIncomingAttachmentKey(dict_rslt.get('rsch_reqs_id'))
        attmObj.setResearchRequestId(dict_rslt.get('rsch_reqs_id'))
    s3Obj = dict_rslt.get('s3_obj_key')
    attmObj.setS3Obj(s3Obj)
    attmObj.setIncomingType(dict_rslt.get('attm_typ_cd'))
    attmObj.setAttachmentTimestamp(dict_rslt.get('attm_tmst'))
    attmObj.setIncomingSize(dict_rslt.get('attm_sz_msmt'))
    attmObj.setUserID(dict_rslt.get('rsch_usr_id'))
    attmObj.setIncomingFolder(dict_rslt.get('fldr_key'))
    attmObj.setIncomingFileName(dict_rslt.get('fle_nme'))
    attmObj.setProcessStatusCd(dict_rslt.get('prcs_stat_cd'))
    attmObj.setProcessResultCd(dict_rslt.get('prcs_rslt_cd'))
    filename = s3Obj.split('/')[5]
    subfolder = s3Obj.split('/')[4]
    topfolder = s3Obj.split('/')[3]
    bucket = s3Obj.split('/')[2]
    s3path = topfolder + '/' + subfolder + '/' + filename
    attmObj.setIncomingS3Bucket(bucket)
    attmObj.setIncomingS3Key(s3path)
    if dict_rslt.get('btch_reqs_id'):
        attmObj.setIncomingAttachmentKey(dict_rslt.get('rsch_usr_id'))
        attmObj.setBatchRequestId(dict_rslt.get('btch_reqs_id'))
    attmObj.setBatchFormatCode(dict_rslt.get('BR_btch_frmt_cd'))
    attmObj.setBatchSourceCode(dict_rslt.get('BR_btch_src_cd'))
    attmObj.setBatchStatusCode(dict_rslt.get('BR_prcs_stat_cd'))
    attmObj.setBatchRejectReasonComment(dict_rslt.get('BR_btch_rej_reas_cmnt'))
    attmObj.setBatchRejectionErrorText(dict_rslt.get('BR_btch_rej_err_txt'))
    attmObj.setBatchTotalEntriesCount(dict_rslt.get('BR_tot_entr_cnt'))
    attmObj.setBatchRejectedEntriesCount(dict_rslt.get('BR_rej_entr_cnt'))
    attmObj.setSessionToken(dict_rslt.get('BR_dnb_jti_val'))
    attmObj.setAuthPrinIdObj(dict_rslt.get('auth_prin_id_obj'))
    attmObj.setLocalFileName(constants.LOCAL_DIRECTORY)
    attmObj.setBatchType(dict_rslt.get('BR_btch_typ'))
    
    return attmObj
