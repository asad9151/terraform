'''
Created on Apr 26, 2019

@author: VanCampK
'''

def mapToTeamSchema(rec, prefix):
    '''
    Returns one researchTeam from the record
    '''        
    result = {
        "researchTeamId": rec.get(prefix+"rsch_team_id"),
        "researchTeamOrganizationName": rec.get(prefix+"rsch_team_org_nme"),
        "countryCode": rec.get(prefix+"ctry_code"),
        "researchTeamName": rec.get(prefix+"rsch_team_nme"),
        "researchTeamDisplayName": rec.get(prefix+"rsch_team_dspl_nme"),
        "getNextIndicator" : True if rec.get(prefix+"get_nxt_indc") == 1 else False,
        "miniLinkageIndicator" : True if rec.get(prefix+"mini_lnkg_indc") == 1 else False
    }

    return result

