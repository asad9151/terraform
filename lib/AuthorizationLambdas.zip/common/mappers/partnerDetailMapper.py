'''
Created on Apr 27, 2020

@author: VanCampK
'''
import json

from common.model.partnerDetail import PartnerDetail

def mapToPartnerDetail(rec, prefix):
    pd = PartnerDetail()
    pd.partnerDetailId = rec.get(prefix+"ptnr_detl_id")
    pd.partnerFileTrackingId = rec.get(prefix+"ptnr_fle_tkg_id")
    pd.recordNumber = rec.get(prefix+"rec_nbr")
    rawDataObjectStr = rec.get(prefix+"raw_data_obj")
    if rawDataObjectStr is not None:
        pd.rawDataObject = json.loads(rawDataObjectStr)
    pd.subjectResearchId = rec.get(prefix+"subj_rsch_id")
    pd.rejectionIndicator = rec.get(prefix+"rej_indc")
    partnerRequestRejectionObjectStr = rec.get(prefix+"ptnr_reqs_rej_obj")
    if partnerRequestRejectionObjectStr is not None:
        pd.partnerRequestRejectionObject = json.loads(partnerRequestRejectionObjectStr)
    return pd