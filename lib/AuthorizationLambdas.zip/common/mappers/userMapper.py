'''
Created on Apr 26, 2019

@author: VanCampK
'''
import json

def mapToUserSchema(rec, prefix):
    # Sample input: {"rsch_usr_id": 1, "usr_firs_nme": "Ken", "usr_lst_nme": "Van Camp", "usr_eml_adr": "vancampk@dnb.com", "sbmt_org_nme": "Dun & Bradstreet", "sbmt_ctry_code": "US", "rsch_usr_obj": "{\"isConsentOfTermsAndConditions\": true, \"termsAndConditionsLatestConsentTimestamp\": \"2019-04-25T10:04:59+00:00\", \"termsAndConditionsInitialConsentTimestamp\": \"2018-10-25T18:04:59+00:00\"}", "acte_indc": 1, "acte_indc_tmst": "2018-10-25T18:04:59+00:00", "row_cre_tmst": "2018-10-25T18:04:59+00:00", "row_crer_id_txt": "kvc", "row_mod_tmst": "2019-04-26T15:40:00+00:00", "row_modr_id_txt": "kvc"}
    userObjStr = rec.get(prefix+"rsch_usr_obj")
    userObj = None
    if userObjStr:
        userObj = json.loads(userObjStr)
        
    result = {
        "researchUserId": rec.get(prefix+"rsch_usr_id"),
        "userFirstName": rec.get(prefix+"usr_firs_nme"),
        "userLastName": rec.get(prefix+"usr_lst_nme"),
        "userEmailAddress": rec.get(prefix+"usr_eml_adr"),
        "loginKey": rec.get(prefix+"lgin_key"),
        "submitterOrganizationName": rec.get(prefix+"sbmt_org_nme"),
        "submitterCountryCode": rec.get(prefix+"sbmt_ctry_code"),
        "isActive": (True if rec.get(prefix+"acte_indc") == 1 else False),
        "activeIndicatorTimestamp": rec.get(prefix+"acte_indc_tmst"),
        "user": userObj
    }

    return result
