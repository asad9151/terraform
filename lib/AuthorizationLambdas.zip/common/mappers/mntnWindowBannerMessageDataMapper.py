'''
Created on February 19, 2021
Mapper function for maintenance windows and banner messages data
@author: GuardiolaR
'''
import json

def mapMaintenanceOutageDataResultToSchema(qryResult, mntnWindowId):
    return _transformToSchema(qryResult, mntnWindowId)

def _transformToSchema(qryResult, mntnWindowId):
    '''
    If no mntnWindowId then request is for maintenanceOutagesData, else maintenanceOutageRecord will be returned
    '''
    if mntnWindowId is None:
        maintenanceOutagesData  = []
        for outage in qryResult:
            maintenanceOutage = _transformMaintenanceOutageDataToSchema(outage)
            maintenanceOutagesData.append(maintenanceOutage)
        data = {}
        data['maintenanceOutagesData'] = maintenanceOutagesData
        return data
    else:
        maintenanceOutageRecord = {}
        if (len(qryResult) > 0):
            maintenanceOutageRecord = _transformMaintenanceOutageDataToSchema(qryResult[0])
        data = {}
        data['maintenanceOutageRecord'] = maintenanceOutageRecord
        return data
        
        
def _transformMaintenanceOutageDataToSchema(rec):
    bannerMessageObject = rec.get('bnr_msg_obj')
    bannerMessageObject = json.loads(bannerMessageObject)
    
    result = {}
    result['mntnWindowId'] = rec.get('mntn_wndw_id')
    result['mntnStartDate'] = rec.get('mntn_effv_tmst')
    result['mntnEndDate'] = rec.get('mntn_expn_tmst')
    result['mntnLockoutWarningMinutes'] = rec.get('mntn_lckt_wrng_mins_cnt')
    result['mntnWindowLastModified'] = rec.get('mntn_wndw_mod_timestamp')
    result['messageBanner'] = {}
    result['messageBanner']['bannerTitle'] = bannerMessageObject['bannerTitle']
    result['messageBanner']['bannerMessage'] = bannerMessageObject['bannerMessage']
    result['messageBanner']['bannerSeverity'] = bannerMessageObject['bannerSeverity'] 
    result['messageBanner']['bannerDismissable'] = bannerMessageObject['bannerDismissable']
    result['messageBanner']['bannerStartDate'] = rec.get('effv_tmst')
    result['messageBanner']['bannerEndDate'] = rec.get('expn_tmst')
    result['messageBanner']['bannerActive'] = rec.get('bnr_msg_act_ind')
    result['messageBanner']['bannerLastModified'] = rec.get('bnr_mod_timestamp')
    
    return result