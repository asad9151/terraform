'''
Created on Apr 15, 2020

@author: VanCampK
'''
from common.mappers.apiApplicationEntitlementMapper import mapToApiApplicationEntitlement
from common.mappers.stpDeliveryFileMapper import mapToStpDeliveryFile
from common.model.stpPartnerDeliveryFile import StpPartnerDeliveryFile


def mapToStpPartnerDeliveryFile(rec, fileTrackingPefix, partnerFileTrackingPrefix, apiApplicationEntitlementPrefix):
    partnerFileTrackingId = rec.get(partnerFileTrackingPrefix+"ptnr_fle_tkg_id")
    if partnerFileTrackingId is None:
        # Not a StpPartnerDeliveryFile, just map to StpDeliveryFile
        return mapToStpDeliveryFile(rec, fileTrackingPefix)
    stpfl = StpPartnerDeliveryFile()
    mapToStpDeliveryFile(rec, fileTrackingPefix, stpDeliveryFile=stpfl)
    stpfl.partnerFileTrackingId = partnerFileTrackingId
    stpfl.apiApplicationEntitlement = mapToApiApplicationEntitlement(rec, apiApplicationEntitlementPrefix)
    stpfl.fileTypeCode = rec.get(partnerFileTrackingPrefix+"fle_typ_cd")
    stpfl.recordCount = rec.get(partnerFileTrackingPrefix+"rec_cnt")
    stpfl.attachmentCount = rec.get(partnerFileTrackingPrefix+"attm_cnt")
    stpfl.batchProcessStatusCode = rec.get(partnerFileTrackingPrefix+"btch_prcs_stat_cd")
    stpfl.rejectRecordCount = rec.get(partnerFileTrackingPrefix+"rej_rec_cnt")
    stpfl.rejectErrorText = rec.get(partnerFileTrackingPrefix+"btch_rej_err_txt")
    stpfl.batchRequestId = rec.get(partnerFileTrackingPrefix+"btch_reqs_id")
    return stpfl