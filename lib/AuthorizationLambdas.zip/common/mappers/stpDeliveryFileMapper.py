'''
Created on Apr 15, 2020

Mapper for StpDeliveryFile (fle_tkg table)

@author: VanCampK
'''
from common.model.s3Object import S3Object
from common.model.stpDeliveryFile import StpDeliveryFile

def mapToStpDeliveryFile(rec, prefix, stpDeliveryFile=None):
    if stpDeliveryFile is None:
        stpfl = StpDeliveryFile()
    else:
        stpfl = stpDeliveryFile
    stpfl.fileTrackingId = rec.get(prefix+"fle_tkg_id")
    stpfl.inboundOutboundIndicator = rec.get(prefix+"inb_outb_ind")
    stpfl.stpDeliveryIndicator = rec.get(prefix+"stp_dlvr_ind")
    s3 = S3Object()
    s3.setS3ObjectKey(rec.get(prefix+"s3_obj_key"))
    stpfl.s3Object = s3
    stpfl.relativeFolder = rec.get(prefix+"fldr_key")
    stpfl.stpFileName = rec.get(prefix+"stp_flnm")
    stpfl.s3Object.fileSize = rec.get(prefix+"fle_sz_msmt")
    stpfl.processStatusCode = rec.get(prefix+"prcs_stat_cd")
    stpfl.processResultCode = rec.get(prefix+"prcs_rslt_cd")
    stpfl.lastDeliveryAttemptTime = rec.get(prefix+"lst_dlvr_atmpt_tmst")
    stpfl.deliveryAttemptCount = rec.get(prefix+"dlvr_atmpt_cnt")
    stpfl.creationTime = rec.get(prefix+"row_cre_tmst")
    return stpfl