'''
Created on Apr 15, 2020

Mapper for ApiApplicationEntitlement (api_app_entl table)

@author: VanCampK
'''
import json
import logging

from common.model.apiApplicationEntitlement import ApiApplicationEntitlement

def mapToApiApplicationEntitlement(rec, prefix):
    apiapp = ApiApplicationEntitlement()
    apiapp.apiApplicationEntitlementId = rec.get(prefix+"api_app_entl_id")
    apiapp.dnbApplicationId = rec.get(prefix+"dnb_app_id")
    apiapp.applicationName = rec.get(prefix+"app_nme")
    apiapp.requestMethodCode = rec.get(prefix+"reqs_meth_cd")
    apiEntitlementObjectStr = rec.get(prefix+"api_entl_obj")
    if apiEntitlementObjectStr is not None:
        apiapp.apiEntitlementObject = json.loads(apiEntitlementObjectStr)
    apiapp.partnerFolderName = rec.get(prefix+"ptnr_fldr_nme")
    apiapp.accessKey = rec.get(prefix+"accss_key_nme")
    apiapp.researchUserLoginKey = rec.get(prefix+"rsch_usr_lgin_key")
    processingOptionsStr = rec.get(prefix+"prcs_optns_obj")
    if processingOptionsStr is not None:
        try:
            apiapp.processingOptionsObj = json.loads(processingOptionsStr)
        except Exception as e:
            logging.error(f"Failed to load prcs_optns_obj json for api_app_entl_id={apiapp.apiApplicationEntitlementId}: {processingOptionsStr}, {e}")
            
    return apiapp