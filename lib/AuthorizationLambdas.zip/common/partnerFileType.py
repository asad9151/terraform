'''
Created on Apr 14, 2020

@author: vancampk
'''
from enum import Enum

from common import envVblNames

class PartnerFileType(Enum):
    UNKNOWN_FILE_TYPE = { "fileTypeCode": 0, "fileNamePrefix": None, "queueEnvVbl": None, "fileNameSuffixes": [] }
    RESEARCH_REQUEST = { "fileTypeCode": 1, "fileNamePrefix": "ResearchRequest_", "queueEnvVbl": None, "fileNameSuffixes": [".ZIP"] }
    UPDATE_AND_CLOSE_REQUEST = { "fileTypeCode": 2, "fileNamePrefix": "UpdateAndCloseRequest_", "queueEnvVbl": envVblNames.ENV_UPDATEANDCLOSEBATCHPARSER_QUEUE_URL, "fileNameSuffixes": [".ZIP"] }
    UPDATE_AND_CLOSE_RESPONSE = { "fileTypeCode": 3, "fileNamePrefix": "UpdateAndCloseResponse_", "queueEnvVbl": None, "fileNameSuffixes": [".ZIP"] }
    CFP_REQUEST = { "fileTypeCode": 4, "fileNamePrefix": "FPC.", "queueEnvVbl": envVblNames.ENV_CFPPARSER_QUEUE_URL, "fileNameSuffixes": [".IRD1.HDR", ".IRD1.HDX", ".IRD3.HDR", ".IRD3.HDX", ".IRD3.DAT"] }
    CFP_RESPONSE = { "fileTypeCode": 5, "fileNamePrefix": "FPC.", "queueEnvVbl": None, "fileNameSuffixes": [".IRD1.OK", ".IRD1.ERR", ".IRD1.STAT", ".IRD3.OK", ".IRD3.ERR", ".IRD3.STAT"] }
