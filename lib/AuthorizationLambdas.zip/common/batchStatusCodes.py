'''
Created on Apr 3, 2019

@author: VanCampK
'''
from enum import Enum

class BatchStatusCode(Enum):
    ANY_NEW_STATUS = 0       # Fictitious status code that refers to statuses defined in getNewStatusList()
    ANY_IN_PROGRESS_STATUS = 1  # Fictitious status code that refers to statuses defined in getInProgressStatusList()
    ANY_COMPLETED_STATUS = 2   # Fictitious status code that refers to statuses defined in getCompletedStatusList()
    REOPEN_BATCH = 3         # Fictitious status (really a command) to reopen a batch
    RECEIVED = 33598        # Temporary state while batch being parsed or (for CFP) waiting for IRD3 files
    PARSED = 33602          # Temporary state after parsing before being either APPROVED or SUBMITTED
    PENDING_APPROVAL = 33599
    APPROVED = 33600        # Temporary state between approval and SUBMITTED state
    APPROVER_REJECTED = 34636
    REJECTED = 33601
    SUBMITTED = 33992
    COMPLETED = 33606
    READY_TO_SUBMIT = 34635 # Temporary state after batch detail
    CANCEL_IN_PROGRESS = 35826 # Temporary state between cancellation and CANCELLED state
    CANCELLED = 35827

    @staticmethod
    def getNewStatusList():
        return [BatchStatusCode.PENDING_APPROVAL.value, BatchStatusCode.PARSED.value,  BatchStatusCode.READY_TO_SUBMIT.value, BatchStatusCode.RECEIVED.value]
    
    @staticmethod
    def getInProgressStatusList():
        return [BatchStatusCode.APPROVED.value, BatchStatusCode.SUBMITTED.value, BatchStatusCode.CANCEL_IN_PROGRESS.value]
    
    @staticmethod
    def getCompletedStatusList():
        return [BatchStatusCode.COMPLETED.value, BatchStatusCode.REJECTED.value, BatchStatusCode.APPROVER_REJECTED.value, BatchStatusCode.CANCELLED.value]
