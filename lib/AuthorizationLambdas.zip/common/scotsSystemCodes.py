'''
Created on Jul 29, 2019

@author: VanCampK
'''
from enum import Enum

class ScotsSystemCode(Enum):
    IRESEARCH = 33484
    IRESEARCH_UI = 33485