'''
Created on Apr 3, 2019

@author: VanCampK
'''
from enum import Enum

class CfpStatusCode(Enum):
    IRD1_PARSED = 1
    IRD1_RESPONDED = 2
    IRD3_DAT_BEFORE_HDR = 3     # Received IRD3.DAT before IRD3.HDR (internal status, not persisted)
    # 4 is unused
    IRD3_HDR_PARSED = 5
    IRD3_DAT_PARSED = 6
    IRD3_DAT_RESPONDED = 7
    IRD4_DAT_RESPONDED = 8
