'''
Created on Apr 10, 2020

@author: JafferS
'''
from enum import Enum

class ResearchTypeCode(Enum):
    MINI_LINKAGE = 33530