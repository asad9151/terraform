'''
Created on Jul 29, 2019

@author: VanCampK
'''
from enum import Enum

class ScotsLanguage(Enum):
    US_ENGLISH = 331
    BRITISH_ENGLISH = 39