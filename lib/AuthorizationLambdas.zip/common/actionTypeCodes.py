'''
Created on Feb 13, 2020

@author: VanCampK
'''
from enum import Enum

'''
 * Case processing action types, such as for the TakeCaseAction or UpdateResearchResults service.
 * Also includes some "internal actions" (non-SCOTS-coded) used to manage state transitions.
'''
class ActionTypeCode(Enum):
    ASSIGN = 33687
    REROUTE = 33688
    UPDATE = 33690
    CLOSE = 33689
    CHALLENGE = 10
    