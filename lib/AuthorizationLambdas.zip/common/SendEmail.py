'''
Created on Nov 13, 2019

@author: MorganB
'''
import smtplib
import logging
import os
from time import sleep
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg

class SendEmail(object):
    '''
    classdocs
    '''

    def __init__(self, smtpServer, senderAddress):
        '''
        Constructor
        '''    
        self.senderAddress = senderAddress
        self.smptServer = smtpServer
        self.serverConnection = None
        
    def connectToMailServer(self):
        for i in range(3):
            try:    
                self.serverConnection = smtplib.SMTP(self.smptServer)
                self.serverConnection.starttls()
                return self.serverConnection
            except Exception as e:
                logging.error('sendEmail function: error connecting to SMTP server.  Error = %s', e)
                sleep (2)
        logging.error('sendEmail function: exhausted tries to connect to the SMTP server.')
        raise LambdaProcessingException(errmsg.ERR_EMAIL_SERVER_CONNECTION_FAILURE)

    
    def send(self, receiverList, subject, body, bodyType='plain', attachment=None):
        if type(receiverList) != list:
            logging.info('sendEmail function: recordList - %s - must be a list', receiverList)
            return False
        msg = MIMEMultipart()
        msg['From'] = self.senderAddress
        msg['Subject'] = subject
        msg['To'] = ' '.join(receiverList) 
        msg.attach(MIMEText(body, bodyType))
        
        ## if an attachment is being send ##
        if attachment != None:
            if os.path.isfile(attachment):
                pass
            else:
                logging.error('sendEmail function: file - %s - was specified as an attachment but it does not exist', attachment)
                return False
            part = MIMEBase('application', 'octet-stream')
            attmt = open(attachment, "rb")
            part.set_payload((attmt).read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', "attachment; filename= %s" % attachment)
            msg.attach(part)
        
        try:
            self.serverConnection = self.connectToMailServer()
        except Exception as e:
            logging.error('SendMail object encountered a problem connecting to the mail server.  Error = %s', e)
            raise 

        text = msg.as_string()
        for address in receiverList:
            strippedAddress = address.strip()
            try:
                self.serverConnection.sendmail(self.senderAddress, strippedAddress, text)
                logging.info('sendEmail function: %s email was sent to %s', msg['Subject'], strippedAddress, )
            except Exception as e:
                logging.error ('sendEmail function: error sending %s email to %s.  Error = %s', msg['Subject'], strippedAddress, e )
                self.serverConnection.quit()
                raise
        self.serverConnection.quit()
        return True