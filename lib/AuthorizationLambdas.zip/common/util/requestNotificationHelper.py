'''
Created on Aug 3, 2020

@author: GuardiolaR
'''
import logging
import json
from time import sleep


class RequestNotificationHelper(object):
    '''
    Helper to retrigger usage notifications to SNS queue.
    '''
    MAX_RETRIES = 3
    DEFAULT_DELAY_BETWEEN_RETRIES_SECS = 0.5
    MAX_MESSAGE_LOG_SZ = 100


    def __init__(self, snsClient, notificationTopicARN):
        self.snsClient = snsClient
        self.notificationTopicARN = notificationTopicARN
        
        
    def triggerUsageNotification(self, notificationTypeCode, researchRequestId=None, subjectResearchId=None):
        '''
        Triggers usage notifications for billing or application usage record by sending SNS message to the invokegenerateresearchnotificationlambda service.
        '''
        request = {
            'researchNotificationTypeCode': notificationTypeCode
        }
        gotId = False
        if researchRequestId:
            request['researchRequestId'] = researchRequestId
            request['isResend'] = True
            gotId = True
        if subjectResearchId:
            request['subjectResearchId'] = subjectResearchId
            gotId = True
        if not gotId:
            logging.error('triggerUsageNotification with no ID specified: type=' + str(notificationTypeCode))
            raise ValueError('triggerUsageNotification with no ID specified')
        
        msg = json.dumps(request)
        msglen=len(msg)
        logging.info(f"triggerUsageNotification Sending message to ARN={self.notificationTopicARN}: len={msglen} message={msg[:RequestNotificationHelper.MAX_MESSAGE_LOG_SZ]} ...")
        lastException = None
        for retryNo in range(RequestNotificationHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"triggerUsageNotification retry #{retryNo}")
            try:
                response = self.snsClient.publish(
                    TopicArn=self.notificationTopicARN,    
                    Message=msg    
                )
                logging.info('triggerUsageNotification response=' + str(response))
                return response
            except Exception as e:
                logging.error(f"triggerUsageNotification: Caught exception sending message: {e}. Sleeping for {RequestNotificationHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(RequestNotificationHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"triggerUsageNotification giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException
