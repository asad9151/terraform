'''
Created on Apr 13, 2020

@author: VanCampK
'''
import logging

from common.model.s3Object import S3Object
from common.util.s3Helper import S3Helper
from common.util.stringUtils import isBlank, isNotBlank


class SftpMockHelper(object):
    '''
    Mock Helper for emulating copying files to a remote server (instead writes files to s3 bucket).
    '''


    def __init__(self, bucket, rootFolder, outboundFolder, inboundFolder):
        self.bucket = bucket
        self.rootFolder = rootFolder
        self.outboundFolder = outboundFolder
        self.inboundFolder = inboundFolder
        self.currentFolder = None
        self.s3Helper = None
        
        
    def isProductionMode(self):
        # False because this is mock mode
        return False
        
        
    def connect(self):
        logging.info("SftpMockHelper: connect() does nothing.")
        
        
    def quit(self):
        logging.info("SftpMockHelper: quit() does nothing.")
        
    
    def chdir(self, folder):
        logging.info(f"SftpMockHelper: chdir {folder} ...")
        if isBlank(self.currentFolder):
            self.currentFolder = folder
        else:
            # TODO support for chdir("..") if needed...
            self.currentFolder += "/" + folder
        
    
    def putFile(self, localFile, destFileName, confirm=False):
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
            
        s3 = S3Object()
        s3.bucket = self.bucket
        s3.folder = self.rootFolder
        if isNotBlank(self.outboundFolder):
            if isBlank(s3.folder):
                s3.folder = self.outboundFolder
            else:
                s3.folder += "/" + self.outboundFolder
        if isNotBlank(self.currentFolder):
            if isBlank(s3.folder):
                s3.folder = self.currentFolder
            else:
                s3.folder += "/" + self.currentFolder
        s3.fileName = destFileName
        self.s3Helper.copyFromLocalToS3(localFile, s3)
        
    
    def getFile(self, fileName, localFile):
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
            
        s3 = S3Object()
        s3.bucket = self.bucket
        s3.folder = self.rootFolder
        if isNotBlank(self.inboundFolder):
            s3.folder += "/" + self.inboundFolder
        if isNotBlank(self.currentFolder):
            s3.folder += "/" + self.currentFolder
        s3.fileName = fileName
        self.s3Helper.copyFromS3ToLocal(s3, localFile)
        # Mock STP which automatically deletes on get
        self.s3Helper.deleteObject(s3)
        
    
    def listdir(self):
        '''
        Returns a listing of the current directory, a list of dictionaries with the follwing attributes:
            filename
            attrs {st_size ... }
        '''
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
        subDir = self.rootFolder + "/" + self.inboundFolder + "/" + self.currentFolder
        subDirSlash = subDir + "/"
        listing = self.s3Helper.s3listing(self.bucket, subDir)
        dl = []
        for la in listing:
            key = la.get('Key')
            fileName = key.split(subDirSlash, 1)[1]
            if isBlank(fileName):
                logging.info(f"Ignoring non-file entry: object={la}")
            else:
                d = DirEntry(fileName, la.get('Size'))
                logging.info(f"  DIR: fileName={fileName} object={la} d={d}")
                dl.append(d)
        return dl


    def doesAnyFileExist(self, fileNames):
        # Check if a file exists by doing a directory listing.
        # Checks multiple possible file names and returns True if ANY of them exist.
        listing = self.listdir()
        for la in listing:
            logging.debug(f"doesAnyFileExist: Comparing {fileNames} to filename={la.filename} st_size={la.st_size} la={la} attr={la.attr}")
            if la.filename in fileNames:
                logging.info(f"doesAnyFileExist: matched to filename={la.filename}")
                return True
        return False


class DirEntry(object):
    def __init__(self, filename, sz):
        self.filename = filename
        self.st_size = sz
    