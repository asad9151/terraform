'''
Created on Jul 9, 2019

@author: VanCampK
'''
import logging
import json
from time import sleep


class NotificationHelper(object):
    '''
    Helper for notifications
    '''
    MAX_RETRIES = 3
    DEFAULT_DELAY_BETWEEN_RETRIES_SECS = 0.5
    MAX_MESSAGE_LOG_SZ = 100


    def __init__(self, snsClient, notificationTopicARN):
        self.snsClient = snsClient
        self.notificationTopicARN = notificationTopicARN
        
        
    def triggerClientNotification(self, notificationTypeCode, researchRequestId=None, subjectResearchId=None, batchRequestId=None, batchRequestRejectId=None, s3ObjKey=None):
        '''
        Triggers email notifications to clients by sending SNS message to the SendNotification or BatchWatch service.
        '''
        request = {
            'notificationTypeCode': notificationTypeCode
        }
        gotId = False
        if researchRequestId:
            request['researchRequestId'] = researchRequestId
            gotId = True
        if subjectResearchId:
            request['subjectResearchId'] = subjectResearchId
            gotId = True
        if batchRequestId:
            request['batchRequestId'] = batchRequestId
            gotId = True
        if batchRequestRejectId:
            request['batchRequestRejectId'] = batchRequestRejectId
            gotId = True
        if s3ObjKey:
            request['s3ObjectKey'] = s3ObjKey
        if not gotId:
            logging.error('triggerClientNotification with no ID specified: type=' + str(notificationTypeCode))
            raise ValueError('triggerClientNotification with no ID specified')
        
        msg = json.dumps(request)
        msglen=len(msg)
        logging.info(f"triggerClientNotification Sending message to ARN={self.notificationTopicARN}: len={msglen} message={msg[:NotificationHelper.MAX_MESSAGE_LOG_SZ]} ...")
        lastException = None
        for retryNo in range(NotificationHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"triggerClientNotification retry #{retryNo}")
            try:
                response = self.snsClient.publish(
                    TopicArn=self.notificationTopicARN,    
                    Message=msg    
                )
                logging.info('triggerClientNotification response=' + str(response))
                return response
            except Exception as e:
                logging.error(f"triggerClientNotification: Caught exception sending message: {e}. Sleeping for {NotificationHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(NotificationHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"triggerClientNotification giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException
