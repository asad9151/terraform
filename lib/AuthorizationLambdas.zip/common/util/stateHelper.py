'''
Created on Aug 3, 2020

@author: VanCampK
'''
from common.internalStatusCode import InternalStatusCode
from common.externalStatusCode import ExternalStatusCode


class StateHelper(object):
    '''
    Helps in the transition of case and research request statuses
    '''
    _INTERNAL_TO_EXTERNAL_STATUS = {
        InternalStatusCode.RECEIVED.value: ExternalStatusCode.RECEIVED_ORIG_REQ.value,
        InternalStatusCode.SUBMITTED_TO_BDRS.value: ExternalStatusCode.RECEIVED_ORIG_REQ.value,
        InternalStatusCode.READY_TO_BE_ASSIGNED.value: ExternalStatusCode.RECEIVED_ORIG_REQ.value,
        InternalStatusCode.ASSIGNED.value: ExternalStatusCode.IN_PROGRESS.value,
        InternalStatusCode.RESEARCH_IN_PROGRESS.value: ExternalStatusCode.IN_PROGRESS.value,
        InternalStatusCode.REROUTED.value: ExternalStatusCode.IN_PROGRESS.value,
        InternalStatusCode.CLOSED.value: ExternalStatusCode.CLOSED.value,
        InternalStatusCode.CHALLENGED.value: ExternalStatusCode.CHALLENGED.value
    }


    @classmethod
    def mapInternalToExternalStatus(cls, internalStatus):
        return StateHelper._INTERNAL_TO_EXTERNAL_STATUS.get(internalStatus)
