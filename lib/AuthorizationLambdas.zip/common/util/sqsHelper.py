import logging
import json
import boto3
from time import sleep

from common.util.awsUtils import createClientConfiguration


class SqsHelper(object):
    
    sqsClient = None
    MAX_RETRIES = 3
    DEFAULT_DELAY_BETWEEN_RETRIES_SECS = 0.5
    MAX_MESSAGE_LOG_SZ = 100
    
    def __init__(self, queueUrl, sqsClient=None, regionName=None):
        if queueUrl is None:
            raise ValueError("QueueUrl cannot be NONE")
        else:
            self.queueUrl = queueUrl
            if sqsClient is None:
                if regionName is None:
                    raise ValueError("regionName cannot be NONE if sqsClient is NONE")
                self.sqsClient = boto3.client('sqs', region_name=regionName, config=createClientConfiguration())
            else:
                self.sqsClient = sqsClient
                
    
        
    def sendMessageToQueue(self, message, delaySecs=0):
        if message is None:
            raise ValueError("Message cannot be None")
        msglen=len(message)
        logging.info(f"sendMessageToQueue: Sending message to queueUrl={self.queueUrl} len={msglen} delaySecs={delaySecs} message={message[:SqsHelper.MAX_MESSAGE_LOG_SZ]} ...")
        lastException = None
        for retryNo in range(SqsHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"sendMessageToQueue retry #{retryNo}")
            try:
                response = self.sqsClient.send_message(
                                            QueueUrl=self.queueUrl,
                                            MessageBody=message,
                                            DelaySeconds=delaySecs
                                            )
                logging.info(f"sendMessageToQueue: Back from sending message to queueUrl={self.queueUrl}: response={response}")
                return response
            except Exception as e:
                logging.error(f"sendMessageToQueue: Caught exception sending message to queue: {e}. Sleeping for {SqsHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(SqsHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"sendMessageToQueue giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException
        
        
    def getAllMessagesFromQueue(self):
        all_messages = []
        while(True):
            logging.info(f"SqsHelper: Receiving all messages from queueUrl={self.queueUrl} with MaxNumberOfMessages=10 ...")
            response = self.sqsClient.receive_message(
                                    QueueUrl=self.queueUrl,
                                    AttributeNames=['All'],
                                    MaxNumberOfMessages=10 
                                    )
            resplen=len(response)
            logging.info(f"SqsHelper: Back from receiving all messages from queueUrl={self.queueUrl}: response len={resplen}")
            try:
                if 'Messages' in response:
                    for msg in response['Messages']:
                        logging.info(str(msg) + " Before ")
                        msg = msg['Body']
                        logging.info(str(msg) + " After ")
                        if isinstance(msg, str):
                            msg = json.loads(msg)
                        all_messages.append(msg)
                else:
                    break
            except KeyError:
                break
            
            entries_in_response = [
                    {'Id' : response_item['MessageId'], 'ReceiptHandle' : response_item['ReceiptHandle']}
                    for response_item in response['Messages']
                ]
            logging.info(f"SqsHelper: deleting messages from queueUrl={self.queueUrl}: entries_in_response={entries_in_response} ...")
            del_response = self.sqsClient.delete_message_batch(QueueUrl=self.queueUrl, Entries=entries_in_response)
            logging.info(f"SqsHelper: Back from deleting messages from queueUrl={self.queueUrl}: del_response={del_response}")
            
            if (len(del_response['Successful']) != len(entries_in_response)):
                raise RuntimeError("Deletion of messages failed")
        return all_messages
    
    
    def getOneMessageFromQueue(self):
        try:
            logging.info(f"SqsHelper: Receiving one message from queueUrl={self.queueUrl} ...")
            msgs = self.sqsClient.receive_message(QueueUrl=self.queueUrl,
                                              MaxNumberOfMessages=1)
            logging.info('SqsHelper: msgs is %s', msgs)
        except Exception as err:
            logging.error(err)
            raise
        
        if msgs is not None and 'Messages' in msgs and len(msgs['Messages']) > 0:
            return msgs['Messages'][0]
        
        return None   
            
    def deleteOneMessageFromQueue(self, msg_receipt_handle):
        logging.info(f"deleteOneMessageFromQueue: deleting one message from queueUrl={self.queueUrl}: msg_receipt_handle={msg_receipt_handle} ...")
        for retryNo in range(SqsHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"deleteOneMessageFromQueue retry #{retryNo}")
            try:
                self.sqsClient.delete_message(QueueUrl=self.queueUrl,
                              ReceiptHandle=msg_receipt_handle)
                logging.info(f"deleteOneMessageFromQueue: Back from deleting one messages from queueUrl={self.queueUrl}")
                return
            except Exception as e:
                logging.error(f"deleteOneMessageFromQueue: Caught exception deleting message from queue: {e}. Sleeping for {SqsHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(SqsHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"deleteOneMessageFromQueue giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException
        
        
    def getAllMessagesNoDelete(self):
        all_messages = []
        while(True):
            logging.info(f"SqsHelper: Receiving all messages from queueUrl={self.queueUrl} with MaxNumberOfMessages=10 ...")
            response = self.sqsClient.receive_message(
                                    QueueUrl=self.queueUrl,
                                    AttributeNames=['All'],
                                    MaxNumberOfMessages=10 
                                    )
            resplen=len(response)
            logging.info(f"SqsHelper: Back from receiving all messages from queueUrl={self.queueUrl}: response len={resplen}")
            try:
                if 'Messages' in response:
                    for msg in response['Messages']:
                        all_messages.append(msg)
                else:
                    break
            except KeyError:
                break
        logging.info(all_messages)
        return all_messages
