'''
Created on Jun 23, 2019
Common string utilities

@author: VanCampK
'''
import re
from decimal import Decimal
from lambdas.submitcaseapi import submitCaseApiErrors

    
def isBlank(s):
    '''
    Returns True if the string is None, or blank after stripping all leading and trailing whitespace
    '''
    return not isNotBlank(s)

    
def isNotBlank(s):
    '''
    Returns True if the object has some non-empty value after stripping all leading and trailing whitespace (None-safe)
    '''
    if s is None:
        return False
    if isinstance(s, str):
        return bool(s and s.strip())
    return True


def defaultNone(s):
    '''
    If the passed value is a non-string object other than None, returns it.
    If the passed value is a non-blank string, returns it after stripping.
    Otherwise, returns None.
    '''
    if isinstance(s, str):
        if isNotBlank(s):
            return s.strip()
        else:
            return None
    return s


def defaultEmptyStr(s):
    '''
    If the passed value is a non-string object other than None, converts it to a str.
    If the passed value is a non-blank string, returns it after stripping.
    If the passed value is None, converts it to an empty string.
    '''
    if s is None:
        return ""
    elif isinstance(s, str):
        return s.strip()
    else:
        return str(s)


def isInt(s):
    '''
    Returns True if the string contains an integer value
    '''
    if s is None:
        return False
    if isinstance(s, int):
        return True
    return re.match(r"[-+]?\d+$", s) is not None


def intDefaultNone(n, defaultValue=None):
    '''
    If the passed value is an integer, returns it.
    If the passed value is a string containing an integer, tries to parse the value as an int (may raise ValueError if unparsable)
    Otherwise, returns defaultValue.
    '''
    if n is not None:
        if isinstance(n, int):
            return n
        else:
            if isBlank(n):
                return defaultValue
            else:
                return int(n)
    return defaultValue


def isDecimal(s):
    '''
    Returns True if the string contains a decimal value
    '''
    if s is None:
        return False
    return re.match(r"[-+]?[\d\.]+$", s) is not None


def decimalDefaultNone(n):
    '''
    If the passed value is a decimal, returns it.
    If the passed value is a float or int, returns the value as a decimal.
    If the passed value is a string containing an integer, tries to parse the value as a decimal (may raise decimal.ConversionSyntax if unparsable)
    Otherwise, returns None.
    '''
    if n is not None:
        if isinstance(n, Decimal):
            return n
        elif isinstance(n, float):
            return Decimal(n)
        elif isinstance(n, int):
            return Decimal(n)
        else:
            if isBlank(n):
                return None
            else:
                return Decimal(n)
    return None


def normalizeDuns(duns):
    '''
    If the supplied DUNS is 7-9 digits, will return a stringified version of the DUNS with prepending 0's.
    Also strips any non-digit characters (such as hyphens) from the string.
    If invalid format, will raise ValueError if unparsable
    '''
    if duns is not None:
        # Convert to string even if it came in as number
        duns = str(duns).strip()
        if len(duns) == 0:
            return None
        duns = stripNonDigit(duns)
        if len(duns) < 7 or len(duns) > 9:
            raise ValueError(submitCaseApiErrors.FAILREC_NOT_A_VALID_DUNS)
        if len(duns) == 7:
            # Prepend leading zeros
            duns = '00' + duns
        if len(duns) == 8:
            # Prepend leading zero
            duns = '0' + duns
        return duns
    else:
        return None


def stripNonDigit(s):
    '''
    Strips any non-digit characters from a string
    '''
    if isinstance(s,str):
        s = s.strip()
        if len(s) == 0:
            return ""
        newstr=""
        for ch in s:
            if ch.isdigit():
                newstr += ch
        return newstr
    elif isinstance(s,int):
        return str(s)
    else:
        return s


_HAS_HTML_CLOSETAG_REGEXP = re.compile(r'\<.*\/\>')
_HAS_HTML_OPENCLOSETAG_REGEXP = re.compile(r'\<\/')

def stringHasHtml(s):
    '''
    Returns True if the provided string contains any HTML tags, False if not
    '''
    if _HAS_HTML_CLOSETAG_REGEXP.search(s):
        return True
    elif _HAS_HTML_OPENCLOSETAG_REGEXP.search(s):
        return True
    else:
        return False


def booleanToJson(b):
    if b:
        return "true"
    else:
        return "false"
    
    
def replaceSpacesAndNonLatin(s, replcStr="_"):
    '''
    Returns the provided string with all spaces and non-Latin characters replaced with replcStr
    Ref: https://stackoverflow.com/questions/23680976/python-removing-non-latin-characters
    result = re.sub(ur'[^\x00-\x7F\x80-\xFF\u0100-\u017F\u0180-\u024F\u1E00-\u1EFF]', u'', text) 
    '''
    return re.sub(u'[^\\x00-\\x7F\\x80-\\xFF\\u0100-\\u017F\\u0180-\\u024F\\u1E00-\\u1EFF]', replcStr, s).replace(" ", replcStr)


def removeLastPartOfJsonPath(s):
    '''
    Removes the last part of a json path, e.g. a.b.c becomes a.b
    '''
    l = s.split(".")
    return ".".join(l[:-1])


def getLastPartOfJsonPath(s):
    '''
    Returns the last part of a json path, e.g. a.b.c becomes c
    '''
    if s is None:
        return None
    if (isBlank(s)):
        return ""
    l = s.split(".")
    return l[-1]


STRIP_SPECIAL_CHARS_TRANSLATE_TABLE = dict.fromkeys(map(ord, ('\n', '\t', '\r')), None)

def isPrintable(s):
    '''
    Returns True if the provided string is empty or contains only printable characters (including newlines)
    Returns False otherwise
    '''
    if isBlank(s):
        return True
    if isinstance(s, str):
        isPrint = s.isprintable()
        if not isPrint:
            # If any special characers, strip them out and check again
            new_s = s.translate(STRIP_SPECIAL_CHARS_TRANSLATE_TABLE)
            isPrint = new_s.isprintable()
        return isPrint
    return False


def convertNewlines(s):
    '''
    Strips out any Windows-style carriage return characters.
    '''
    if s is None:
        return None
    if isinstance(s, str):
        return s.replace('\r', '')
    return s


def str2bool(v):
    '''
    Converts a string to bool.
    If string is None or blank, returns None.
    If string does not match expected values (see code for expected values), returns a ValueError
    '''
    if isBlank(v):
        return None 
    if v.lower() in ("yes", "true", "t", "1"):
        return True
    elif v.lower() in ("no", "false", "f", "0"):
        return False
    else:
        raise ValueError("Unexpected value cannot convert to bool")
    