'''
Created on Jan 13, 2021

@author: VanCampK
'''
import importlib
import logging
import os
#from aws_xray_sdk.core import patch_all

from common import envVblNames
from common.envVblNames import getEnvironAsBool

xrayEnable = False


def setupXray(environDict):
    global xrayEnable
    # If Xray context is missing, just log an error (instead of raising SegmentNotFoundException):
    os.environ["AWS_XRAY_CONTEXT_MISSING"] = "LOG_ERROR"

    # Don't enable xray if running locally
    xrayEnable = getEnvironAsBool(environDict.get(envVblNames.ENV_XRAY_ENABLE), default=True) if environDict is not None else True
    if xrayEnable:
        haveXrayLib = importlib.util.find_spec("aws_xray_sdk")
        if haveXrayLib is not None:
            from aws_xray_sdk.core import patch_all
            # Set up Xray patching
            patch_all()
        else:
            xrayEnable = False
    else:
        # Disable X-ray patching when running locally:
        os.environ["AWS_XRAY_SDK_ENABLED"] = "false"
