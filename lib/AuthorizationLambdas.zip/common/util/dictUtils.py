'''
Created on Jun 23, 2019
Common dictionary utilities

@author: VanCampK
'''
import re

from common.util.stringUtils import isNotBlank, isBlank, defaultNone

def mergeDictionaries(a, b, path=None, update=True):
    '''
    Merges dictionary b into a
    Ref: https://stackoverflow.com/questions/7204805/dictionaries-of-dictionaries-merge
    The answer I used: https://stackoverflow.com/a/25270947/1971144
    Updated to handle not overwriting with None values
    Updated to handle unequal-sized lists
    '''
    if path is None: path = []
    for key in b:
        if key in a:
            if isinstance(a[key], dict) and isinstance(b[key], dict):
                mergeDictionaries(a[key], b[key], path + [str(key)])
            elif a[key] == b[key]:
                pass # same leaf value
            elif isinstance(a[key], list) and isinstance(b[key], list):
                for idx, val in enumerate(b[key]):
                    alen = len(a[key])
                    blen = len(b[key])
                    if alen > idx and blen > idx:
                        a[key][idx] = mergeDictionaries(a[key][idx], b[key][idx], path + [str(key), str(idx)], update=update)
                    elif blen > idx:
                        a[key].append(b[key][idx])
                    # TODO consider appending to list as many unique members as exist
            elif update:
                if b[key] is not None:
                    a[key] = b[key]
            else:
                raise Exception('Conflict at %s' % '.'.join(path + [str(key)]))
        else:
            a[key] = b[key]
    return a
    
        
def isEmptyDictionary(rec):
    if not rec:
        return True
    
    # Empty rows in spreadsheet need to be ignored
    for k, v in rec.items():
        if isNotBlank(v):
            return False
    return True


def removeEmptyFromDictionary(d, nPasses=1):
    if isBlank(d):
        return d
    # We do it multiple times due to a bug in the recursive function that it sometimes leaves behind empty dictionaries
    for i in range(0, nPasses):
        d1 = _removeEmptyFromDictionary_Impl(d)
        if d1 is None:
            return d
        else:
            d = d1
    return d1


def _removeEmptyFromDictionary_Impl(d):
    if not isinstance(d, (dict, list)):
        return defaultNone(d)
    if len(d) == 0:
        return None
    if isinstance(d, dict) and len(d.keys()) == 0:
        return None
    if isinstance(d, list):
        return [v for v in (_removeEmptyFromDictionary_Impl(v) for v in d) if isNotBlank(v)]
    return {k: v for k, v in ((k, _removeEmptyFromDictionary_Impl(v)) for k, v in d.items()) if isNotBlank(v)}


def removeEmptyValsFromArrayIfOnlyTypeCode(d, typeCodeElt):
    '''
    Takes an array of dictionaries.
    Scans all elts in the array and removes any elts that are empty, or which contain only a type code and nothing else that is non-empty.
    '''
    if not isinstance(d, (list)):
        return
    d[:] = [x for x in d if not dictHasOnlyTypeCode(x, typeCodeElt)]
    return


def dictHasOnlyTypeCode(d, typeCodeElt):
    '''
    Returns True if the given dictionary is empty, or if its only non-empty element is the named typeCodeElt
    '''
    isEmpty = True
    for k,v in d.items():
        if isNotBlank(v):
            if k != typeCodeElt:
                isEmpty = False
    return isEmpty


def createUpperCaseDict(d):
    '''
    Given a dictionary with mixed-case keys, will create a new dictionary in which all the keys are upper-cased as a simple way to create a case-insensitive dictionary.
    Warning: If the input dictionary contains 2 keys that are the same but different case, e.g. "abc":1 and "Abc":2, the result will have only one of them.
    Limitation: If the dictionary contains other nested dictionaries, this function only upper-cases the top-level keys.
    '''
    du = {}
    if d is not None:
        for k, v in d.items():
            du[k.upper()] = v
    return du


def copyDictWithoutSecureElements(d, suffixes=('token','key','secret','password')):
    '''
    Returns a copy of the supplied dictionary, minus any elements whose name ends in one of the words in the suffixes set (case-insensitive compare).
    This is intended for use when logging a dictionary, but when secure tokens, passwords and keys need to be suppressed from the logs.
    '''
    du = {}
    if d is not None:
        for k, v in d.items():
            isSecure = False
            for suffix in suffixes:
                if k.lower().endswith(suffix.lower()):
                    isSecure = True
            if not isSecure:
                du[k] = v
    return du


def findAllElementsThatContains(var, regExp, path=None):
    '''
    Returns an array of json paths within the provided dictionary, which contain the supplied regular expression.
    Compare is case-insensitive.
    Based on: https://stackoverflow.com/questions/9807634/find-all-occurrences-of-a-key-in-nested-dictionaries-and-lists
    '''
    retval = []
    if hasattr(var,'items'):
        for k, v in var.items():
            if isinstance(k,str) and regExp.match(k):
                appstr = k if path is None else path+"."+k
                retval.append(appstr)
            if isinstance(v, dict):
                newpath = k if path is None else path+"."+k
                result = findAllElementsThatContains(v, regExp, path=newpath)
                retval.extend(result)
            elif isinstance(v, list):
                for i in range(len(v)):
                    d = v[i]
                    arryStr = "["+str(i)+"]"
                    newpath = k+arryStr if path is None else path+"."+k+arryStr
                    result = findAllElementsThatContains(d, regExp, path=newpath)
                    retval.extend(result)
    return retval


def parseFixedFormatAsDict(line, CFG):
    '''
    Takes a fixed-format record and a configuration list, and parses the record into a dictionary.
    Not the most efficient implementation if you have lots of data to parse, but simple and does what we need...
    For examples and CFG format see unit test test_parseFixedFormatAsDict()
    '''
    values = {}
    for rec in CFG:
        for k, v in rec.items():
            startPos = v.get("start")
            endPos   = v.get("end")
            if startPos is None or endPos is None:
                raise KeyError(f"parseFixedFormatAsDict: Missing either start or end config for key={k}")
            values[k] = line[startPos-1:endPos].strip()
    return values


def generateFixedFormatFromDict(d, CFG):
    '''
    Takes a dictionary and a configuration list, and generates a fixed format record.
    For examples and CFG format see unit test test_generateFixedFormatFromDict()
    '''
    s = ""
    for rec in CFG:
        for k, v in rec.items():
            startPos = v.get("start")
            endPos   = v.get("end")
            if startPos is None or endPos is None:
                raise KeyError(f"parseFixedFormatAsDict: Missing either start or end config for key={k}")
            startPos -= 1
            endPos -= 1
            length = endPos - startPos + 1
            val = d.get(k)
            if val is None:
                padval = ''.ljust(length)[:length]
            elif isinstance(val, int):
                # Integer gets zero-padded on the left
                padval = str(val).zfill(length)
            else:
                sval = str(val)
                padval = sval.ljust(length)[:length]
            #print(f"key={k} start={startPos} end={endPos} val='{val}' padval='{padval}' s='{s}'")
            news = s[:startPos] + padval + s[endPos + 1:]
            s = news
            #print(f"news={s}")
    return s