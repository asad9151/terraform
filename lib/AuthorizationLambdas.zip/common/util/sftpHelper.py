'''
Created on Apr 13, 2020

@author: VanCampK
'''
import logging
import paramiko
import sys
from time import sleep

from SetLambdaLogging import setLogging


class SftpHelper(object):
    '''
    Helper for copying files to a remote server using SFTP.
    IMPORTANT NOTE: This helper uses paramiko, which currently requires Python 3.6.
    '''
    DEFAULT_SFTP_PORT = 22
    MAX_RETRIES = 3
    DEFAULT_DELAY_BETWEEN_RETRIES_SECS = 0.5
    LOCAL_DIRECTORY = '/tmp/'


    def __init__(self, sftpServer, sftpUserId, sftpPassword, sftpPort=None):
        logging.info(f"SftpHelper using paramiko version {paramiko.__version__}")
        if sftpServer is None or sftpUserId is None or sftpPassword is None:
            logging.error(f"Missing expected minimum configuration for sftpHelper: sftpServer={sftpServer} sftpUserId={sftpUserId} sftpPassword={sftpPassword}")
            raise ValueError("Missing expected minimum configuration for sftpHelper")
        self.sftpServer = sftpServer
        self.sftpPort = SftpHelper.DEFAULT_SFTP_PORT if sftpPort is None else sftpPort
        self.sftpUserId = sftpUserId
        self.sftpPassword = sftpPassword
        self.transport = None
        self.sftp = None
        self.isConnected = False
        
        
    def isProductionMode(self):
        # Override in mock mode implementation
        return True
    
        
    def connect(self):
        logging.info(f"connecting to sftpServer={self.sftpServer} on sftpPort={self.sftpPort} with sftpUserId={self.sftpUserId} ...")
        lastException = None
        for retryNo in range(SftpHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"connect retry #{retryNo}")
            try:
                logging.info("Creating transport...")
                self.transport = paramiko.Transport(self.sftpServer, self.sftpPort)
                logging.info("Transport created, attempting to connect...")
                self.transport.connect(username = self.sftpUserId, password = self.sftpPassword)
                logging.info(f"connect: Back from connect, attempting to get sftp from_transport...")
                self.sftp = paramiko.SFTPClient.from_transport(self.transport)
                logging.info("connect: Back getting sftp from_transport")
                self.isConnected = True
                return
            #except paramiko.ssh_exception.AuthenticationException as ae:
            # Retry is enabled on AuthenticationException because we're getting this on timeout.
            #    logging.error(f"connect: Caught AuthenticationException: {ae}. Will not retry.")
            #    raise ae
            except Exception as e:
                logging.error(f"connect: Caught exception: {e}. Sleeping for {SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"connect giving up after {retryNo} retries.")
        #ftpQuit(transport, None)
        if lastException is not None:
            raise lastException
        
        
    def quit(self):
        '''
        Closes the connection to the SFTP server
        '''
        self.isConnected = False
        try:
            logging.info("quit: closing sftp ...")
            if self.sftp is not None:
                self.sftp.close()
                self.sftp = None
            logging.info("quit: closing transport...")
            if self.transport is not None:
                self.transport.close()
                self.transport = None
            logging.info("quit: back from closing transport")
        except Exception as e:
            logging.error(f"quit: Caught exception trying to quit: {e}")
        
    
    def chdir(self, folder):
        '''
        Changes the current working directory to the folder specified on the SFTP server
        '''
        if not self.isConnected:
            self.connect()
        
        logging.info(f"chdir {folder} ...")
        lastException = None
        for retryNo in range(SftpHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"chdir retry #{retryNo}")
            try:
                # TODO support chdir to multi-level directories
                self.sftp.chdir(folder)
                logging.info("successfully back from chdir")
                return
            # TODO differentiate "directory does not exist" from retryable exception
            except Exception as e:
                logging.error(f"chdir: Caught exception: {e}. Sleeping for {SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"chdir giving up after {retryNo} retries.")
        self.quit()
        if lastException is not None:
            raise lastException
        
    
    def putFile(self, localFile, destFileName, confirm=False):
        if not self.isConnected:
            self.connect()
        
        logging.info(f"putFile {localFile} to sftpServer={self.sftpServer} destFileName={destFileName} ...")
        lastException = None
        for retryNo in range(SftpHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"putFile retry #{retryNo}")
            try:
                logging.info(f"putFile: put localFile={localFile} to destFileName={destFileName} with confirm={confirm}...")
                self.sftp.put(localFile, destFileName, confirm=confirm)
                logging.info("putFile: successfully put file")
                return
            except paramiko.ssh_exception.AuthenticationException as ae:
                logging.error(f"putFile: Caught AuthenticationException: {ae}. Will not retry.")
                self.quit()
                raise ae
            except Exception as e:
                logging.error(f"putFile: Caught exception: {e}. Sleeping for {SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"putFile giving up after {retryNo} retries.")
        self.quit()
        if lastException is not None:
            raise lastException
        
    
    def getFile(self, fileName, localFile):
        if not self.isConnected:
            self.connect()
        
        logging.info(f"getFile {fileName} to {localFile} ...")
        lastException = None
        for retryNo in range(SftpHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"getFile retry #{retryNo}")
            try:
                self.sftp.get(fileName, localFile)
                logging.info("getFile: successfully get file")
                return
            except paramiko.ssh_exception.AuthenticationException as ae:
                logging.error(f"getFile: Caught AuthenticationException: {ae}. Will not retry.")
                self.quit()
                raise ae
            except Exception as e:
                logging.error(f"getFile: Caught exception: {e}. Sleeping for {SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"getFile giving up after {retryNo} retries.")
        self.quit()
        if lastException is not None:
            raise lastException
        
    
    def listdir(self):
        '''
        Returns a listing of the current directory, a list of dictionaries with the follwing attributes:
            filename
            st_size
            st_uid
            st_gid
            st_mode
            st_atime
            st_mtime      
            attr  
        '''
        if not self.isConnected:
            self.connect()
        
        logging.info(f"listdir ...")
        lastException = None
        for retryNo in range(SftpHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"listdir retry #{retryNo}")
            try:
                list_attr = self.sftp.listdir_attr()
                logging.info(f"DIR: Successfully got back directory listing of length {len(list_attr)}")
                dl = []
                for at in list_attr:
                    logging.debug(f"  DIR: filename={at.filename} st_size={at.st_size} la={at} attr={at.attr}")
                    dl.append(at)
                return dl
            except paramiko.ssh_exception.AuthenticationException as ae:
                logging.error(f"listdir: Caught AuthenticationException: {ae}. Will not retry.")
                self.quit()
                raise ae
            except Exception as e:
                logging.error(f"listdir: Caught exception: {e}. Sleeping for {SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"listdir giving up after {retryNo} retries.")
        self.quit()
        if lastException is not None:
            raise lastException
        
    
    def removeFile(self, remoteFileName):
        if not self.isConnected:
            self.connect()
        
        logging.info(f"removeFile {remoteFileName} from sftpServer={self.sftpServer} ...")
        lastException = None
        for retryNo in range(SftpHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"removeFile retry #{retryNo}")
            try:
                logging.info(f"removeFile: remove remoteFileName={remoteFileName} ...")
                self.sftp.remove(remoteFileName)
                logging.info("removeFile: successfully removed file")
                return
            except paramiko.ssh_exception.AuthenticationException as ae:
                logging.error(f"removeFile: Caught AuthenticationException: {ae}. Will not retry.")
                self.quit()
                raise ae
            except Exception as e:
                logging.error(f"removeFile: Caught exception: {e}. Sleeping for {SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"removeFile giving up after {retryNo} retries.")
        self.quit()
        if lastException is not None:
            raise lastException


    def doesAnyFileExist(self, fileNames):
        # Check if a file exists by doing a directory listing.
        # Checks multiple possible file names and returns True if ANY of them exist.
        for retryNo in range(SftpHelper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"doesAnyFileExist retry #{retryNo}")
            listing = self.listdir()
            for la in listing:
                logging.debug(f"doesAnyFileExist: Comparing {fileNames} to filename={la.filename} st_size={la.st_size} la={la} attr={la.attr}")
                if la.filename in fileNames:
                    logging.info(f"doesAnyFileExist: matched to filename={la.filename}")
                    return True
            sleep(SftpHelper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
        return False
    

if __name__ == '__main__':
    if len(sys.argv) < 5:
        sys.exit("usage: sftpServer sftpUserId sftpPassword cmd:option [cmd:option ...] where valid commands are cd/dir/get/put/del/quit/sleep")
    
    for argNo in range(4, len(sys.argv)):
        print(f"arg[{argNo}] = {sys.argv[argNo]}")

    setLogging(logging.DEBUG)
    
    sftpServer = sys.argv[1]
    sftpUserId = sys.argv[2]
    sftpPassword =  sys.argv[3]
    sftpHelper = SftpHelper(sftpServer, sftpUserId, sftpPassword)
    print(f"Connecting to {sftpServer} with sftpUserId={sftpUserId}")
    sftpHelper.connect()
    
    try:
        for argNo in range(4, len(sys.argv)):
            logging.info(f"arg[{argNo}] = {sys.argv[argNo]}")
            if sys.argv[argNo].startswith("#"):
                # Ignore commented-out arguments start with '#'
                logging.info(f"Ignoring commented argument {sys.argv[argNo]}")
                continue
            cmdopt = sys.argv[argNo].split(":")
            if len(cmdopt) < 2:
                logging.error("Invalid argument missing colon - skipped.")
                continue
            cmd = cmdopt[0]
            opt = cmdopt[1]
            if cmd == "cd":
                sftpHelper.chdir(opt)
            elif cmd == "dir":
                listing = sftpHelper.listdir()
                for la in listing:
                    logging.info(f"  DIR: filename={la.filename} st_size={la.st_size} la={la} attr={la.attr}")
            elif cmd == "get":
                srcFileName = opt if len(cmdopt) < 3 else cmdopt[1]
                destFileName = opt if len(cmdopt) < 3 else cmdopt[2]
                sftpHelper.getFile(srcFileName, destFileName)
            elif cmd == "put":
                sftpHelper.putFile(opt, opt)
            elif cmd == "del":
                sftpHelper.removeFile(opt)
            elif cmd == "quit":
                sftpHelper.quit()
            elif cmd == "sleep":
                sleep(int(opt))
            else:
                logging.error(f"Unknown command {cmd}")
    except Exception as e:
        logging.error(f"Caught exception {e} from sftpHelper")
        
    sftpHelper.quit()
    