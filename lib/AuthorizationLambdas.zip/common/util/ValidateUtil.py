'''
Created on Sep 4, 2019

@author: jaffers
'''
import json
import os
from jsonschema.validators import Draft4Validator, RefResolver
import schema
import inspect

class ValidateUtil(object):
    full_path = os.path.dirname(inspect.getfile(schema))

    def __init__(self, schema_file_name):
        self.resolver = self.initResolver()
        self.theValidator = self.initValidator(schema_file_name)
            
    def initValidator(self, schemaFileName):
        with open(os.path.join(ValidateUtil.full_path, schemaFileName)) as schema_file:
            schema_data = schema_file.read()
        current_schema = json.loads(schema_data)
        v = Draft4Validator (current_schema, resolver=self.resolver)
        v.check_schema(current_schema)
        return v
   
    def initResolver(self):
        r = RefResolver('file:///%s/' % ValidateUtil.full_path, None)
        return r

        
        