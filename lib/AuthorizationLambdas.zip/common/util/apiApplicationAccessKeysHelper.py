import csv
import logging
import os

from SetLambdaLogging import setLogging
from common import envVblNames
from common.model.s3Object import S3Object
from common.util.s3Helper import S3Helper
from common.util.stringUtils import isBlank


class ApiApplicationAccessKeysHelper(object):
    '''
    Utility class to load the ApplicationAccessKeys map from reference data.
    '''
    LOCAL_FILE_PATH = '/tmp/tmpApiApplicationAccessKeys.csv'
    REFDATA_FILE_PATH = 'applicationconfig/ApiApplicationAccessKeys.csv'

    
    def __init__(self, environDict):
        self.environDict = environDict
        self.s3Helper = None
        if environDict is None:
            raise ValueError("environDict cannot be NONE")                

        
    def loadAccessKeysDict(self):
        '''
        Loads the reference data file from S3 and returns a dictionary for the current environment, of the form:
        {
            "ABCDEFGHIJKLMNO": { "DnbAppId":"12345", "ApplicationName":"Human-readable-name", "UserLoginKey":"AbcDef" },
            ...
        }
        Notes: DnbAppId can be None, indicating that any DnbAppId is acceptable.
               UserLoginKey can be None, indicating that any UserLoginKey is acceptable.
        '''
        accessKeysDict = {}
        self._copyFileFromS3()
        
        with open(ApiApplicationAccessKeysHelper.LOCAL_FILE_PATH, 'r', encoding='utf-8-sig') as appConfigFile:
            csv_data = csv.DictReader(appConfigFile)
            for row in csv_data:
                if self.environDict[envVblNames.ENV_ENVIRONMENT_NAME] == row.get("Environment"):
                    if isBlank(row.get("AccessKey")) or isBlank(row.get("DnbAppId")) or isBlank(row.get("UserLoginKey")):
                        logging.warning(f"Ignoring invalid row, missing required fields: {row}")
                    else:
                        configObj = {
                            "DnbAppId": None if row["DnbAppId"] == '*' else row["DnbAppId"],
                            "ApplicationName": row["ApplicationName"],
                            "UserLoginKey": None if row["UserLoginKey"] == '*' else row["UserLoginKey"]
                        }
                        logging.debug(f"Adding key {row['AccessKey'].strip()} : {configObj}")
                        accessKeysDict[row["AccessKey"].strip()] = configObj
                        
        if len(accessKeysDict) == 0:
            logging.error(f"Empty accessKeysDict: Apparently no accessKey registered for environment {envVblNames.ENV_ENVIRONMENT_NAME}")
        else:
            logging.info(f"accessKeysDict = {accessKeysDict}")
        
        try:
            logging.info(f"Removing temp file {ApiApplicationAccessKeysHelper.LOCAL_FILE_PATH}")
            os.remove(ApiApplicationAccessKeysHelper.LOCAL_FILE_PATH)
        except Exception as e:
            logging.error(f"Failed removing local file {ApiApplicationAccessKeysHelper.LOCAL_FILE_PATH} - error={e}.")
            # eat exception and continue
            
        return accessKeysDict
    
    
    def _copyFileFromS3(self):
        if self.s3Helper is None:
            self.s3Helper = S3Helper()              
        bucket = self.environDict[envVblNames.ENV_REFDATA_BUCKET]
        key = ApiApplicationAccessKeysHelper.REFDATA_FILE_PATH

        s3Object = S3Object()
        s3Object.setS3ObjectKey('s3://' + bucket + '/' + key)
        self.s3Helper.copyFromS3ToLocal(s3Object, ApiApplicationAccessKeysHelper.LOCAL_FILE_PATH)
        
        
if __name__ == '__main__':
    testEnvironDict = {
        "ENVIRONMENT_NAME": "DEV2",
        "REFDATABUCKET": "irsch-d1-refdata"
    }
    setLogging("INFO")
    helper = ApiApplicationAccessKeysHelper(testEnvironDict)
    accKeyDict = helper.loadAccessKeysDict()
    print(f"accessKeysDict={accKeyDict}")
    print(f"config for AKIAXCKN37WLPLCH3DMU is {accKeyDict['AKIAXCKN37WLPLCH3DMU']}")
    