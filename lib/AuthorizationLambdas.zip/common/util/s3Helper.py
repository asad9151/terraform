'''
Created on Apr 10, 2020

@author: VanCampK
'''
import boto3
import logging
import sys
from time import sleep
from urllib.parse import unquote_plus

# Begin iResearch imports
from common.model.s3Object import S3Object
from common.util.awsUtils import createClientConfiguration
from common.util.stringUtils import isBlank
import lambdas.lambdaConstants as consts
from SetLambdaLogging import setLogging


class S3Helper(object):
    '''
    Helper for copying files to/from an S3 bucket
    '''
    MAX_RETRIES = 3
    DEFAULT_DELAY_BETWEEN_RETRIES_SECS = 0.5
    LOCAL_DIRECTORY = '/tmp/'
    
    
    def __init__(self, s3handle=None):
        if s3handle is None:
            #self.s3Client = boto3.client('s3', config=Config(signature_version='s3v4'))
            self.s3handle = boto3.resource('s3', config=createClientConfiguration())
        else:
            self.s3handle = s3handle


    def parseS3ObjectsFromEvent(self, event, ignoreNonFileEvents=True):
        '''
        Decodes the S3 attributes from an S3 event and stores them into a list of S3Object.
        If ignoreNonFileEvents is True, then S3 events without a filename (e.g. folder creation events) will not be returned.
        Raises a KeyError if the event is missing one of the required elements
        If no S3 record found in the event, returns an empty list
        '''
        s3List = []
        if consts.EVENT_RECORDS not in event:
            logging.error('getS3Attributes - missing Records in event data')
            return s3List
        records = event[consts.EVENT_RECORDS]
        for record in records:
            if consts.EVENT_RECORD_S3 in record:
                s3Object = S3Object()
                s3Object.bucket = record[consts.EVENT_RECORD_S3]['bucket']['name']
                s3Path = unquote_plus(record[consts.EVENT_RECORD_S3]['object']['key'])
                #s3Object.s3Arn = record[consts.EVENT_RECORD_S3]['bucket']['arn']
                s3Object.folder = '/'.join(s3Path.split('/')[0:-1])
                s3Object.fileName = s3Path.split('/')[-1]
                s3Object.fileSize = record[consts.EVENT_RECORD_S3]['object']['size']
                logging.info(f"getS3Attributes s3Object={s3Object}")
                if isBlank(s3Object.fileName) and ignoreNonFileEvents:
                    logging.info("Ignoring event with empty fileName")
                else:
                    s3List.append(s3Object)
        
        return s3List


    def copyFromS3ToLocal(self, s3Object, localFileName):
        '''
        Downloads a file from S3 to the local filesystem.
        Returns the S3 response, but you can assume anything other than a raised exception is success.
        '''
        #localFileName = S3Helper.LOCAL_DIRECTORY + s3Object.folder + '_' + s3Object.fileName
        
        logging.info(f"copyFromS3ToLocal: Copy from bucket={s3Object.bucket} obj={s3Object.getS3ObjectPath()} to localfile={localFileName} ...")
        lastException = None
        for retryNo in range(S3Helper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"copyFromS3ToLocal retry #{retryNo}")
            try:
                response = self.s3handle.Bucket(s3Object.bucket).download_file(s3Object.getS3ObjectPath(), localFileName)
                #response = self.s3Client.download_file(s3Object.bucket, s3Object.getS3ObjectPath(), localFileName)
                logging.info(f"copyFromS3ToLocal: Back from copying file to local: response={response}")
                return response
            except Exception as e:
                logging.error(f"copyFromS3ToLocal: Caught exception copying file to local: {e}. Sleeping for {S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"copyFromS3ToLocal giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException


    def copyFromLocalToS3(self, localFileName, s3Object):
        '''
        Copies a file from local to S3 location.
        Returns the S3 response, but you can assume anything other than a raised exception is success.
        '''
        logging.info(f"copyFromLocalToS3: Copy from localfile={localFileName} to bucket={s3Object.bucket} obj={s3Object} ...")
        lastException = None
        for retryNo in range(S3Helper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"copyFromLocalToS3 retry #{retryNo}")
            try:
                response = self.s3handle.Object(s3Object.bucket, s3Object.getS3ObjectPath()).upload_file(Filename=localFileName)
                #response = self.s3Client.Object(s3Object.bucket, s3Object.getS3ObjectPath()).copy_from(CopySource={'Bucket': s3Object.bucket, 'Key': s3Object.getS3ObjectPath()})
                logging.info(f"copyFromLocalToS3: Back from copying local file to S3: response={response}")
                return response
            except Exception as e:
                logging.error(f"copyFromLocalToS3: Caught exception copying local file to S3: {e}. Sleeping for {S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"copyFromLocalToS3 giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException


    def copyFromS3ToS3(self, s3ObjectExisting, s3ObjectNew):
        '''
        Copies a file from one S3 location to another S3 location.
        Returns the S3 response, but you can assume anything other than a raised exception is success.
        '''
        logging.info(f"copyFromS3ToS3: Copy from bucket={s3ObjectExisting.bucket} obj={s3ObjectExisting} to bucket={s3ObjectNew.bucket} obj={s3ObjectNew} ...")
        lastException = None
        for retryNo in range(S3Helper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"copyFromS3ToS3 retry #{retryNo}")
            try:
                response = self.s3handle.Object(s3ObjectNew.bucket, s3ObjectNew.getS3ObjectPath()).copy_from(CopySource={'Bucket': s3ObjectExisting.bucket, 'Key': s3ObjectExisting.getS3ObjectPath()})
                logging.info(f"copyFromS3ToS3: Back from copying S3 to S3: response={response}")
                return response
            except Exception as e:
                logging.error(f"copyFromS3ToS3: Caught exception copying S3 to S3: {e}. Sleeping for {S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"copyFromS3ToS3 giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException
        
        
    def deleteObject(self, s3Object):
        '''
        Deletes an S3 object
        Returns the S3 response, but you can assume anything other than a raised exception is success.
        '''
        logging.info(f"deleteObject: obj={s3Object} ...")
        lastException = None
        for retryNo in range(S3Helper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"deleteObject retry #{retryNo}")
            try:
                response = self.s3handle.Object(s3Object.bucket, s3Object.getS3ObjectPath()).delete()
                logging.info(f"deleteObject: Back from deleting: response={response}")
                return response
            except Exception as e:
                logging.error(f"deleteObject: Caught exception deleting object: {e}. Sleeping for {S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"deleteObject giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException
        
        
    def s3listing(self, bucket, folderPrefix, maxKeys=100):
        '''
        Returns a "directory listing" from an S3 bucket and folder/subfolder (e.g. 'DIR1/DIR2') - a list of dictionaries like:
        {'Key': 'stp-dead-files/iResearchDEV.0.test.txt', 'LastModified': datetime.datetime(2020, 4, 20, 23, 21, 57, tzinfo=tzutc()), 'ETag': '"6f083f3bc8213c3f56cf2b0c8b9b36db"', 'Size': 40, 'StorageClass': 'STANDARD'}
        '''
        s3client = self.s3handle.meta.client
        logging.info(f"s3listing for bucket={bucket} folderPrefix={folderPrefix} maxKeys={maxKeys}")
        lastException = None
        for retryNo in range(S3Helper.MAX_RETRIES):
            if retryNo > 0:
                logging.info(f"s3listing retry #{retryNo}")
            try:
                response = s3client.list_objects_v2(
                    Bucket  = bucket,
                    Prefix  = folderPrefix,
                    MaxKeys = maxKeys)
                contents = []
                if response.get("Contents") is not None:
                    for content in response["Contents"]:
                        contents.append(content)
                return contents
            except Exception as e:
                logging.error(f"s3listing: Caught exception: {e}. Sleeping for {S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
                sleep(S3Helper.DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
                lastException = e

        logging.error(f"s3listing giving up after {retryNo} retries.")
        if lastException is not None:
            raise lastException
        
    def getS3ObjectForS3Trigger(self, event):
        s3Object = S3Object()
        try:
            incomingS3Bucket = (event['Records'][0]['s3']['bucket']['name'])
        except Exception as e:
            logging.error('getS3Overrides: missing bucket name from event data.  error msg = %s',e)
            raise        
        try: 
            incomingS3Key = (unquote_plus(event['Records'][0]['s3']['object']['key']))
        except Exception as e:
            logging.error('_getS3ObjectForS3Trigger: missing S3Key from event data  error msg = %s',e)
            raise    
        logging.info('_getS3ObjectForS3Trigger:  bucket = %s', incomingS3Bucket)
        logging.info('_getS3ObjectForS3Trigger:  key = %s', incomingS3Key)

        s3Object.setS3ObjectKey('s3://' + incomingS3Bucket + '/' + incomingS3Key)
        return s3Object   



if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit("usage: bucket cmd:option [cmd:option[:option] ...] where valid commands are get/put/cp/dir/del/sleep")
    
    for argNo in range(2, len(sys.argv)):
        print(f"arg[{argNo}] = {sys.argv[argNo]}")

    setLogging(logging.DEBUG)
    
    bckt = sys.argv[1]
    s3Helper = S3Helper()
    
    try:
        for argNo in range(2, len(sys.argv)):
            logging.info(f"arg[{argNo}] = {sys.argv[argNo]}")
            cmdopt = sys.argv[argNo].split(":")
            if len(cmdopt) < 2:
                logging.error("Invalid argument missing colon - skipped.")
                continue
            cmd = cmdopt[0]
            opt = ":".join(cmdopt[1:])
            if cmd == "dir":
                subDir = opt
                subDirSlash = subDir + '/'
                listing = s3Helper.s3listing(bckt, subDir)
                for la in listing:
                    key = la.get('Key')
                    fileParts = key.split(subDirSlash, 1)
                    if len(fileParts) > 1:
                        fileName = key.split(subDirSlash, 1)[1]
                        logging.info(f"  DIR: fileName={fileName} object={la}")
                    else:
                        logging.info(f"  IGNORE: object={la}")
            elif cmd == "get":
                # usage: get:s3name[:localfilename]
                s3o = S3Object()
                srcFileName = opt if len(cmdopt) < 3 else cmdopt[1]
                destFilePath = opt if len(cmdopt) < 3 else cmdopt[2]
                s3o.setS3ObjectKey(f"s3://{bckt}/{srcFileName}")
                destFileParts = destFilePath.split("/")
                destFileName = destFileParts[-1]
                s3Helper.copyFromS3ToLocal(s3o, destFileName)
            elif cmd == "put":
                # usage: put:localfilename[:s3name]
                srcFileName = opt if len(cmdopt) < 3 else cmdopt[1]
                destFileName = opt if len(cmdopt) < 3 else cmdopt[2]
                s3o = S3Object()
                s3o.setS3ObjectKey(f"s3://{bckt}/{destFileName}")
                s3Helper.copyFromLocalToS3(srcFileName, s3o)
            elif cmd == "cp":
                # usage: cp:oldS3name:newS3name]
                if len(cmdopt) < 3:
                    logging.error("Invalid argument (cp command requires 2 arguments) - skipped.")
                    continue
                srcFileName = cmdopt[1]
                destFileName = cmdopt[2]
                s3oSrc = S3Object()
                s3oSrc.setS3ObjectKey(f"s3://{bckt}/{srcFileName}")
                s3oDest = S3Object()
                s3oDest.setS3ObjectKey(f"s3://{bckt}/{destFileName}")
                s3Helper.copyFromS3ToS3(s3oSrc, s3oDest)
            elif cmd == "del":
                s3o = S3Object()
                s3o.setS3ObjectKey(f"s3://{bckt}/{opt}")
                s3Helper.deleteObject(s3o)
            elif cmd == "sleep":
                sleep(int(opt))
            else:
                logging.error(f"Unknown command {cmd}")
    except Exception as e:
        logging.error(f"Caught exception {e} from s3Helper")
        
        

    