'''
Created on Jun 21, 2019

@author: VanCampK
'''
from enum import Enum

class AddressUsageTypeCode(Enum):
    PRIMARY_ADDRESS = 1114
    MAILING_ADDRESS = 1116