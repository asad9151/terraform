'''
Created on Jan 15, 2020

@author: JafferS
'''
from enum import Enum

class ExternalStatusCode(Enum):
    RECEIVED_ORIG_REQ = 33621
    IN_PROGRESS = 33622
    CLOSED = 33624
    CHALLENGED = 33626
