'''
Provides a way to do json.dumps on mysql data with a variety of types
Ref: https://stackoverflow.com/questions/1960516/python-json-serialize-a-decimal-object
Ref: https://stackoverflow.com/questions/11875770/how-to-overcome-datetime-datetime-not-json-serializable

@author: VanCampK
'''
import decimal
import json
from datetime import datetime
from datetime import date
from datetime import timezone
from common.util.dateUtils import dateTimeToIsoFormat

'''
This is an attempt at a generic iResearch encoder that covers all the encoding cases found to date
'''
class IResearchEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return int(o)
        if isinstance(o, datetime):
            # Set timezone as UTC and format into std ISO 860, e.g. 2018-10-25T18:04:59+00:00
            dt = o.replace(tzinfo=timezone.utc)
            #print('ISO:' + dt.isoformat())
            #return dt.isoformat()
            return dateTimeToIsoFormat(dt)
        if isinstance(o, date):
            return str(o)
        
        return super(IResearchEncoder, self).default(o)
    
'''
Encodes Decimal as float
'''
class DecimalAsFloatEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        return super(DecimalAsFloatEncoder, self).default(o)

'''
Encodes Decimal as int
'''
class DecimalAsIntEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return int(o)
        return super(DecimalAsIntEncoder, self).default(o)
    