'''
Created on Nov 9, 2019

@author: MorganB
'''
import logging
import os
from zipfile import ZipFile
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg

def zipFiles(filesToZipList, zipFileName):
    if type(filesToZipList) != list:
        logging.error ('zipFile function: filesToZipList - %s - must be a list', filesToZipList)
        return None
    if type(zipFileName) != str:
        logging.error ('zipFile function: zipFileName - %s - must be a striung with .zip suffix', zipFileName)
        return None 
    if zipFileName.split('.')[-1].lower() != 'zip':
        logging.error ('zipFile function: fileName - %s - must have a suffix of zip or ZIP', zipFileName)
        return None
    for file in filesToZipList:
        if os.path.isfile(file):
            pass
        else:
            logging.error('zipFile function: file - %s - does not exist', file)
            raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_DOES_NOT_EXIST)
    
    #writing files to a zipfile 
    try:
        with ZipFile(zipFileName,'w') as zipped: 
            for file in filesToZipList: 
                zipped.write(file)
    except Exception as e:
        logging.error('zipFile function: Error zipping the files.  error message = %s ',e) 
        raise 
    logging.info('zipFile function: zipfile - %s - was created',zipFileName)
    return zipFileName


if __name__ == '__main__':
    pass