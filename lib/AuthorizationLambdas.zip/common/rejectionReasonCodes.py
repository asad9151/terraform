'''
Created on Apr 3, 2019

@author: VanCampK
'''
from enum import Enum

class RejectionReasonCode(Enum):
    # Reasons why a single research request may have been rejected
    INVALID_SUBJECT_DUNS = 34206    # "Provided D-U-N-S not in database"
    VALIDATION_ERROR = 34207        # "Data Validations Failed"
    UNSUPPORTED_REQUEST = 20642     # "Out of scope request", e.g. routing rules failure
    INTERNAL_ERROR = 19054          # "Service internal error"
    INVALID_CLOUDSERVICES_HEADER = 34367    # Problem with one or more of the HTTP headers in the received message
    PREVIOUSLY_DETECTED_ERROR = -1  # This record was rejected during earlier processing, actual rejection reason unimportant to this module
    