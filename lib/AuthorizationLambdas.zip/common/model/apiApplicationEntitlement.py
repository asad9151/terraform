'''
Created on Apr 15, 2020

@author: VanCampK
'''

class ApiApplicationEntitlement(object):
    '''
    Model class for api_app_entl table
    '''


    def __init__(self):
        self.apiApplicationEntitlementId = None
        self.dnbApplicationId = None
        self.applicationName = None
        self.requestMethodCode = None
        self.apiEntitlementObject = None
        self.partnerFolderName = None
        self.accessKey = None
        self.researchUserLoginKey = None
        self.processingOptionsObj = None
        
        
    def __str__(self):
        return f"\
apiApplicationEntitlementId={self.apiApplicationEntitlementId} dnbApplicationId={self.dnbApplicationId} \
applicationName={self.applicationName} requestMethodCode={self.requestMethodCode} apiEntitlementObject={self.apiEntitlementObject} \
partnerFolderName={self.partnerFolderName} accessKey={self.accessKey} researchUserLoginKey={self.researchUserLoginKey} processingOptionsObj={self.processingOptionsObj}"
