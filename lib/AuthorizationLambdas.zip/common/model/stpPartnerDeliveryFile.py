'''
Created on Apr 15, 2020

@author: VanCampK
'''
import copy

from common.model.stpDeliveryFile import StpDeliveryFile


class StpPartnerDeliveryFile(StpDeliveryFile):
    '''
    Model class for a partner delivery file (ptnr_fle_tkg table)
    '''


    def __init__(self, stpDeliveryFile=None):
        super().__init__(orig=stpDeliveryFile)
        if stpDeliveryFile is not None and hasattr(stpDeliveryFile, 'partnerFileTrackingId'):
            self.partnerFileTrackingId = stpDeliveryFile.partnerFileTrackingId
            self.apiApplicationEntitlement = copy.deepcopy(stpDeliveryFile.apiApplicationEntitlement)
            self.fileTypeCode = stpDeliveryFile.fileTypeCode
            self.recordCount = stpDeliveryFile.recordCount
            self.attachmentCount = stpDeliveryFile.attachmentCount
            self.batchProcessStatusCode = stpDeliveryFile.batchProcessStatusCode
            self.rejectRecordCount = stpDeliveryFile.rejectRecordCount
            self.rejectErrorText = stpDeliveryFile.rejectErrorText
            self.batchRequestId = stpDeliveryFile.batchRequestId
        else:
            self.partnerFileTrackingId = None
            self.apiApplicationEntitlement = None
            self.fileTypeCode = None
            self.recordCount = None
            self.attachmentCount = None
            self.batchProcessStatusCode = None
            self.rejectRecordCount = None
            self.rejectErrorText = None
            self.batchRequestId = None
        
        
    @classmethod        
    def mapNameForNewType(cls, originalFileName, oldFileTypeCode, newFileTypeCode):
        '''
        Maps one file type filename to a new filename based on change in file type.
        Intended to help when naming an outgoing response file to match the incoming request filename.
        Sample incoming:  iResearchDEV.0.UpdateAndCloseRequest_20200428_7.zip
        Maps to outgoing: UpdateAndCloseResponse_20200428_7.zip
        '''
        flnmParts = originalFileName.split(".")
        newFileName = originalFileName
        if len(flnmParts) >= 4:
            # Strip off first 2 parts, e.g. iResearchDEV.0
            newFileName = ".".join(flnmParts[2:])
        newFileName = newFileName.replace(oldFileTypeCode["fileNamePrefix"], newFileTypeCode["fileNamePrefix"])
        return newFileName

        
    def __str__(self):
        return super().__str__() + f" \
partnerFileTrackingId={self.partnerFileTrackingId} apiApplicationEntitlement={self.apiApplicationEntitlement} fileTypeCode={self.fileTypeCode} \
recordCount={self.recordCount} attachmentCount={self.attachmentCount} batchProcessStatusCode={self.batchProcessStatusCode} \
rejectRecordCount={self.rejectRecordCount} rejectErrorText={self.rejectErrorText} batchRequestId={self.batchRequestId}"
        
