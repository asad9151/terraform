'''
Created on Apr 10, 2020

@author: VanCampK
'''
from common.util.stringUtils import isBlank


class S3Object(object):
    '''
    Stores attributes of an S3 object for use with S3Helper and StpDeliveryFile
    '''


    def __init__(self, orig=None):
        self.bucket   = None if orig is None else orig.bucket
        self.folder   = None if orig is None else orig.folder
        self.fileName = None if orig is None else orig.fileName
        self.fileSize = None if orig is None else orig.fileSize
        
        
    def setS3ObjectKey(self, s3ObjectKey):
        if isBlank(s3ObjectKey):
            return
        minusPrefix = s3ObjectKey.replace('s3://', '')
        fileparts = minusPrefix.split('/')
        if len(fileparts) < 3:
            return
        self.bucket = fileparts[0]
        self.folder = '/'.join(fileparts[1:-1])
        self.fileName = fileparts[-1]
        
        
    def getS3ObjectKey(self):
        return 's3://' + self.bucket + '/' + self.getS3ObjectPath()
        
        
    def getS3ObjectPath(self):
        return self.folder + '/' + self.fileName
        
        
    def __str__(self):
        return f"bucket={self.bucket} folder={self.folder} fileName={self.fileName} fileSize={self.fileSize}"
