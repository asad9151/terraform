'''
Created on Apr 27, 2020

@author: VanCampK
'''

class PartnerDetail(object):
    '''
    Model object for partner detail record (ptnr_detl table)
    '''


    def __init__(self):
        self.partnerDetailId = None
        self.partnerFileTrackingId = None
        self.recordNumber = None
        self.rawDataObject = None
        self.subjectResearchId = None
        self.rejectionIndicator = None
        self.partnerRequestRejectionObject = None
        
    def getRawDataObject(self):
        return self.rawDataObject

    def __str__(self):
        return f"\
partnerDetailId={self.partnerDetailId} partnerFileTrackingId={self.partnerFileTrackingId} recordNumber={self.recordNumber} rawDataObj={self.rawDataObject} \
subjectResearchId={self.subjectResearchId} rejectionIndicator={self.rejectionIndicator} partnerRequestRejectionObj={self.partnerRequestRejectionObject}"
        