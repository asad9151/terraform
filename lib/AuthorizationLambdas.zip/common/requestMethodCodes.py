'''
Created on Apr 3, 2019

@author: VanCampK
'''
from enum import Enum

class RequestMethodCode(Enum):
    '''
    List of supported request method codes.
    These are used to tell us what type of user submitted a research request
    If you add to this list, also consider updating:
    - api_app_entl table
    - and probably also the Java RequestMethodCodes enum
    '''
    #CUSTOMER_API_PORTAL = 33584         # No longer used for Direct+
    IRESEARCH_UI = 33585
    DNB_DIRECT_PLUS = 34306
    SALES_FORCE = 34487
    GOVT_PORTAL = 34627
    ER_AND_C = 34626
    
    FDA_PORTAL = 0          # TODO consider switching GOVT_PORTAL to FDA_PORTAL
    CUSTOMER_FILE_PROCESSING = 33586
    DBIA = 14182
    UNITY = 34628
    MYDNB_COM = 20645
    DNB_CREDIT = 33587     #29068 also relates to D&B Credit
    DNBI = 14186
    DBAI_EUROPE = 12848
    IRG = 23607
    DUNSTEL = 12842
    SUPPLIER_PORTAL = 19677
    DATA_INTEGRATION_TOOLKIT = 15229
    ONBOARD_UI = 24970
    DIRECT_2_0 = 26330 
    DNBI_AUSTRALIA = 28411 
    DIRECT_ONBOARD_API = 29094
    DAAS_COMPLIANCE = 14184
    IRESEARCH_TEST_API = 34629
    CHINA_APPLE = 47
    MINI_PORTAL = 35688
    TAIWAN = 69
    ASCENT_EXCLUSIONS = 35935
    ASCENT_VIOLATIONS = 36124
    ASCENT_SAMUEI = 36186
    SFDC_ENTERPRISE = 36322