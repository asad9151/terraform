from enum import Enum

class ResearchSubTypesGroupCode(Enum):
    # Just the special ones we care about (entitlements driven entirely by SCOTS reference data)
    #INTERNAL_UI_SUBMITTER = 34447
    BASIC_API_SUBMITTER = 34450
    