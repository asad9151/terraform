from enum import Enum

class ResearchRefDataTypeCode(Enum):
    TEAM_GROUP = 1
    COUNTRY_GROUP = 2
    USER_ORGANIZATION = 3
    