'''
Created on Jan 21, 2020

@author: JafferS
'''
from enum import Enum

class BatchType(Enum):
    GENERIC_BATCH  = "GENERIC_BATCH"    # aka "BDR_ComplexBatch", formerly known as "mini-batch"
    NEW_DUNS_MINI_BATCH  = "NEW_DUNS_MINI_BATCH"    # aka "BDR_SimpleBatch"
    CFP_LOOKUP_BATCH = "CFP_LOOKUP_BATCH"           # Look-up only (CFP code 300) Maps to research subtype 34659 - Manual Match Lookup
                                                    # Also used for: Browse & review (CFP code 700) - Maps to research subtype 34659 - Manual Match Lookup
    CFP_INV_BATCH = "CFP_INV_BATCH"                 # Investigation (CFP code 100) Maps to research subtype 33575 - Add business - Mini Inquiry - Identity Data Only
    CFP_LOOKUP_INV_BATCH = "CFP_LOOKUP_INV_BATCH"   # Look-up and investigation (CFP code 400) Map to research subtype 35028 - Manual Lookup to Add Business - Mini
    CAMPAIGN_BATCH = "CAMPAIGN_BATCH"
    
    @classmethod
    def hasValue(cls, value):
        return any(value == item.value for item in cls)
    
    @classmethod
    def getBatchTypes(cls):
        return list(cls)
        
    @classmethod
    def getAllBatchNames(cls):
        return [e.value for e in cls]
    
    @classmethod
    def isCfpBatch(cls, batchType):
        if batchType == BatchType.CFP_LOOKUP_BATCH.name or batchType == BatchType.CFP_INV_BATCH.name or batchType == BatchType.CFP_LOOKUP_INV_BATCH.name:
            return True
        else:
            return False