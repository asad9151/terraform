from enum import Enum

class BatchWatchTypeCode(Enum):
    # BatchWatchService notification types
    REQUEST_SUBMITTED = 1 #BWS
    CASE_CLOSED = 3
    BATCH_REJECTED = 7 
    REQUEST_REJECTED = 8
    BATCH_REJECTED_INVALID = 9
    BATCH_STARTED = 10
    BATCH_CLOSED = 11
    BATCH_DETAIL = 13