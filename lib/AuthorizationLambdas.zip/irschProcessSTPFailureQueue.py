'''
Updated on April 4, 2019

@author: MorganB
'''
import logging
import boto3
import json
import traceback
import sys
import constants
from sendFileToSTP import sendFileToSTP
from databaseClass import databaseClass
from buildEnvironVarDict import buildEnvironVarDict
from deleteLocalFile import deleteLocalFile
from SetLambdaLogging import setLogging
from attachmentClass import attachment
from downloadFromS3ToLocal import downloadFromS3ToLocal
from common import envVblNames
from common.alert import Alert
from common.util.awsUtils import createClientConfiguration

sqsObj = None
dbObj = type('',(object,),{})() 
environDict = {}

def queueLoop(environDict, dbObj):
    loopTripCounter = 0
    while True:
        attribDict = {}
        attribDict = sqsObj.get_queue_attributes(QueueUrl=environDict['queueURL'],AttributeNames=['ApproximateNumberOfMessages'])
        logging.info('irschProcessSTPFailure-I005: attribDict = %s', attribDict)
        logging.info('irschProcessSTPFailure-I001: Number of items on the queue = %s', attribDict['Attributes']['ApproximateNumberOfMessages'])
        if int(attribDict['Attributes']['ApproximateNumberOfMessages']) == 0:
            logging.info('irschProcessSTPFailure-I002: No more messages on queue')
            break
        queueRecordsProcessed = processSTPFailureQueue(environDict, dbObj)
        logging.info('irschProcessSTPFailure-I003: Attachments submitted to STP = %s', queueRecordsProcessed)
        if loopTripCounter >= constants.MAX_LOOP_COUNTER:
            if constants.RESTART_LAMBDA_IF_MESSAGES_LEFT_ON_QUEUE:
                restartLambda()
            break 
        loopTripCounter += 1
    return 

def processSTPFailureQueue(environDict, dbObj):
    queueRecordsProcessed = 0
    
    message = sqsObj.receive_message(QueueUrl=environDict['queueURL'],MaxNumberOfMessages=constants.MESSAGES_PER_RECEIVE, MessageAttributeNames=['All'])
    
    if message is None or 'Messages' not in message:
         return queueRecordsProcessed
    
    for msg in message['Messages']:
        msgDict = json.loads(msg['Body'])
        msgHandle = msg['ReceiptHandle']
        attmObj = attachment()
        
        try:
            attmObj.loadSTPRetry(msgDict) 
        except Exception as e:
            logging.error('irschProcessSTPFailure-E001: error raised creating attmObj.  this record will be deleted  Error = %s', e)
            try:
                logging.info(f"processSTPFailureQueue: delete_message with msgHandle={msgHandle} ...")
                sqsObj.delete_message(QueueUrl=environDict['queueURL'], ReceiptHandle=msgHandle)
                logging.info(f"processSTPFailureQueue: back from delete_message")
            except Exception as e:
                logging.error('irschProcessSTPFailure-E002: error deleting message from the queue.  Error message = %s', e)
            continue
        
        try:
            if downloadFromS3ToLocal(environDict, attmObj):
                pass
            else:
                logging.error('irschProcessSTPFailure-E003: unable to download file from S3.')
                continue
        except Exception as e:
            logging.error('irschProcessSTPFailure-E004: error raised downloading file from S3.  Error = %s', e)
            continue
        
        try:
            sendStatus = sendFileToSTP(attmObj,environDict)
        except Exception as e:
            unsuccessfulSTPSend(attmObj, environDict, None)
            continue
        if sendStatus != 'successful':
            unsuccessfulSTPSend(attmObj, environDict, sendStatus)
            continue
        
        queueRecordsProcessed += 1
        try:
            dbObj.attachmentSentToSTP(attmObj,'ProcessSTPFailure', constants.SUCCESSFUL)
        except Exception as e:
            logging.error('irschProcessUploadedAttachment-E005: error raised updating database that file was sent to STP.  Error msg = %s', e)
            traceback.print_tb(sys.exc_info()[2])
        
        try:
            deleteLocalFile(attmObj.getLocalFileName())
        except:
            pass
        
        try:
            sqsObj.delete_message(QueueUrl=environDict['queueURL'], ReceiptHandle=msgHandle)
            logging.info('irschProcessSTPFailure-I004: message deleted from the queue.  ReceiptHandle = %s', msgHandle)
        except Exception as e:
            logging.error('irschProcessSTPFailure-E006: error deleting message from the queue.  Error message = %s', e)
    
    return queueRecordsProcessed

def restartLambda():
    try:
        client = boto3.client('lambda', region_name=environDict[envVblNames.ENV_LAMBDA_REGION], config=createClientConfiguration(environDict))
    except Exception as e:
        logging.error('irschProcessSTPFailure-E007: error - problem defining client for lambda restart.  Error = %s', e)
        raise
    try:
        client.invoke(
            FunctionName= environDict['selfArn'],
            InvocationType='Event')
    except Exception as e:
        logging.error('iirschProcessSTPFailure-E008 problem invoking lambda function.  Err = %s', e)
        raise

def unsuccessfulSTPSend(attmObj, environDict, sendStatus):
    try:
        logging.error('irschProcessSTPFailure-E009: error sending request to STP.  Send Status = %s', sendStatus)
        #writeSTPFailureToSQS(attmObj, environDict)
        deleteLocalFile(attmObj.getLocalFileName())
        dbObj.attachmentSentToSTP(attmObj,'ProcessSTPFailure', constants.UNSUCCESSFUL)
    except Exception as e:
        logging.error('irschProcessSTPFailure-E010: STP-send failure processing error.  Error = %s', e)

def lambdaHandler(event, context):
    global sqsObj
    global dbObj
    global environDict
    
    if not environDict:
        try:
            environDict = buildEnvironVarDict()
            environDict['s3Handle'] = boto3.resource('s3', config=createClientConfiguration(environDict))
            setLogging(environDict['loggingLevel'])
        except Exception as e:
            logging.error('irschProcessUploadedAttachment-E011: error building environDict.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return 
    
    environDict['selfArn'] = context.invoked_function_arn
    
    if not sqsObj:
        sqsObj = boto3.client('sqs', config=createClientConfiguration(environDict))
        environDict['queueURL'] = sqsObj.get_queue_url(QueueName= environDict["stpFailureQueue"])['QueueUrl']
        
    errror_alert = Alert(environDict)
    if not isinstance(dbObj, databaseClass):
        try:
            dbObj = databaseClass(environDict)
        except Exception as e:
            logging.error('irschProcessSTPFailureQueue-E012: error building database object.  error msg = %s', e)
            errror_alert.raiseAlert("irschProcessSTPFailureQueue", "Database Object was not created", str(e))
            return    
    else:
        # warm start
        try:
            logging.info('irschProcessSTPFailureQueue warm start - testing database connection...')
            dbObj.checkConnection() 
            logging.info('irschProcessSTPFailureQueue continuing after database connection tested')
        except Exception as e:
            logging.error('irschProcessSTPFailureQueue - error testing database connection.  error = %s', e)
            errror_alert.raiseAlert("irschProcessSTPFailureQueue", "error testing database connection", str(e))
            return
    
    # processSTPFailureQueue(environDict, dbObj)
    queueLoop(environDict, dbObj)
    