'''
Updated on Feb 12, 2019

@author: MorganB
'''

import os
import logging
import boto3
from base64 import b64decode
import time
import timeit

from common.util.awsUtils import createClientConfiguration

# Global variables reset only at cold start
kmsClient = None

MAX_RETRIES = 3
DEFAULT_DELAY_BETWEEN_RETRIES_SECS = .5

def buildEnvironVarDict():
    global kmsClient
    
    tempDict = {}
    try:
        for k, v in os.environ.items():
            #print(k + '=' + v)
            if k[0:5].upper() != 'IRSCH':
                continue
            if k[0:6].upper() == 'IRSCH_':
                tempDict[k[6:]] = v
                tempDict[k[6:].upper()] = v     # second copy in uppercase
                continue
            elif k[0:15].upper() == 'IRSCHENCRYPTED_':
                if kmsClient is None:
                    kmsClient = boto3.client('kms', config=createClientConfiguration())
                ciphertextBlob=b64decode(v)
                logging.info('Starting to decrypt environment variable %s ' %  k)
                t = _decryptVariable(ciphertextBlob, k)
                logging.info('successfully decrypted environment variable %s ' %  k)
                tempDict[k[15:]] = t
                tempDict[k[15:].upper()] = t
                continue
            else:
                logging.error('buildEnviornVarDict - bad key in environment variables. Key = %s, Value = %s', k, v)
                continue
    except Exception as e:
        logging.error('buildEnvironVarDict - error when creating environ variables.  error = %s',e )
        raise
    logging.info ('environment variable dictionary has keys: ' + ','.join(tempDict.keys()))
    return tempDict
    
    
def _decryptVariable(ciphertextBlob, k):
    global kmsClient

    t = None
    lastException = None
    retryNo = 0
    while retryNo < MAX_RETRIES:
        if retryNo > 0:
            logging.info(f"_decryptVariable: retry #{retryNo}")
        try:
            logging.info(f"_decryptVariable: About to call kmsClient.decrypt")
            tic=timeit.default_timer()
            t = kmsClient.decrypt(CiphertextBlob=ciphertextBlob)['Plaintext'].decode()
            toc=timeit.default_timer()
            logging.info(f"_decryptVariable: KMS decrypt complete in {(toc-tic)*1000} msecs (success)")
            return t
        except Exception as e:
            logging.error(f"_decryptVariable: Caught exception: {e}. Sleeping for {DEFAULT_DELAY_BETWEEN_RETRIES_SECS} secs before retry...")
            toc=timeit.default_timer()
            logging.info(f"_decryptVariable: KMS decrypt complete in {(toc-tic)*1000} msecs (error)")
            time.sleep(DEFAULT_DELAY_BETWEEN_RETRIES_SECS)
            lastException = e
        retryNo = retryNo + 1
    if retryNo >= MAX_RETRIES:
        logging.error('Decrypting environment variable giving up after %s ' % str(retryNo) + ' retries.')
    if lastException is not None:
        raise lastException

    return t
        
if __name__ == '__main__':
    pass