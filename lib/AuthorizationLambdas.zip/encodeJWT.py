'''
Created on Oct 14, 2018

@author: MorganB
'''
import jwt
import logging

def encodeJWT(payload, secret, alg='HS256'):
    
    if type(payload) is dict:
        pass
    else:
        print ('encodeJWT error - improper type for payload - it should be a dictionary.  payload type = ', type(payload))
        raise
    
    try: 
        return jwt.encode(payload, secret, algorithm=alg)
    except Exception as err:
        logging.error ('encodeJWT error - JWT encoding failed')
        logging.error ('encodeJWT error - failing payload = %s', payload)
        logging.error ('encodeJWT error - encoding failure error = %s', err)
        raise
    
if __name__ == '__main__':
    pass