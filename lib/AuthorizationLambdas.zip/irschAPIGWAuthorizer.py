'''
Updated on March 8, 2019

@author: MorganB
'''

import ast
import base64
import logging 
import json
import sys
import traceback

from decodeJWT import decodeJWT
from determineStartType import determineStartType
from buildEnvironVarDict import buildEnvironVarDict
from SetLambdaLogging import setLogging
from lambdas.statsLogger import StatsLogger
from common.util.xrayUtils import setupXray


# Global variables reset only at cold start
environDict = {}
statsLogger = None


def interpretAuthToken(authorizationToken, environDict):
    validatedJWT = None
     
    print ('ApigwAuthorizer-I001: incoming authorizationToken =', authorizationToken)

    splitToken = authorizationToken.split()
    
    if len(splitToken) != 2:
        logging.error ('ApigwAuthorizer-E001: invalid authenticationToken received %s', authorizationToken)
        return 'invalid', None
    elif splitToken[0] != 'Bearer':
        logging.error ('ApigwAuthorizer-E002: first entry in authenticationToken should be Bearer.  %s received', splitToken[0])
        return 'invalid', None 
    
    try:
        tokenStatus, validatedJWT = decodeJWT(splitToken[1], verifyOption=True, key=environDict['tokenSigningKey'], alg='HS256')
        if tokenStatus == 'expiredToken':
            decodedToken = ast.literal_eval(base64.b64decode(splitToken[1].split('.')[1] + '===').decode('utf-8'))
            logging.error ('ApigwAuthorizer-I003: Email associated with expired token = %s', decodedToken['email'])
            logging.info ('ApigwAuthorizer-I004: Expired Token information = %s', decodedToken)
            return 'expiredToken', None 
        
        if validatedJWT != None or validatedJWT != '':
            return 'validToken', validatedJWT
        else:
            logging.error ('ApigwAuthorizer-E003: invalid authenticationToken received %s', splitToken[1])
            return 'invalidToken', None
    except:
        logging.error ('ApigwAuthorizer-E004: invalid authenticationToken received %s', splitToken[1])
        raise

def generatePolicy(principalId, effect, methodArn):
    authResponse = {}
    authResponse['principalId'] = json.dumps(principalId) 

    if effect and methodArn:
        arnPolicyAppend = '/*/*'
        arnSplit = methodArn.split('/')
        finParts = [arnSplit[i] for i in range(len(arnSplit)-2)]   ## strip off the method and resource
        initialRejoin = '/'.join(finParts)
        policyArn = initialRejoin + arnPolicyAppend               ## add on the wildcard method and resource 
        
        policyDocument = {
            'Version': '2012-10-17',
            'Statement': [
                {
                    'Action': 'execute-api:Invoke',
                    'Effect': effect,
                    'Resource': policyArn
                }
            ]
        }
        authResponse['policyDocument'] = policyDocument
    else:
        logging.error ('ApigwAuthorizer-E008: something screwed up, we are missing either the effect or the methodARN')
        sys.exit(-1)
        
    logging.info ('authorization policy being returned to API-GW = %s', authResponse)
    return authResponse
 
def lambda_handler(event, context):
    global environDict
    global statsLogger
    
    # set logging level
    try:
        setLogging(environDict['loggingLevel'])
    except:
        logging.error('ApigwAuthorizer-E005: *** loggingLevel environment variable missing ***')

    if statsLogger is None:
        statsLogger = StatsLogger()

    if not environDict:
        try:
            environDict = buildEnvironVarDict()
            setupXray(environDict)
        except Exception as e:
            logging.error('APIGWAuthorizer-E009: error generating environDict.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            raise
    
    if determineStartType(event) == 'timer':
        statsLogger.logStats(True, False)
        return None
    statsLogger.logStats(False, True)

    # record incoming information 
    logging.info('ApigwAuthorizer-I002: incoming event = %s', event)
   
    if 'authorizationToken' not in event:
        logging.error ('ApigwAuthorizer-E006: missing Authentication token')
        return generatePolicy(None, 'Deny', event['methodArn'])
    if 'methodArn' not in event:
        logging.error ('ApigwAuthorizer-E007: missing methodARN')
        sys.exit()
    
    try:
        tokenAuthentic, principalId = interpretAuthToken(event['authorizationToken'], environDict)
    except:
        traceback.print_tb(sys.exc_info()[2])
        return generatePolicy(None, 'Deny', event['methodArn'])
    
    if tokenAuthentic == 'validToken':
        logging.info ('ApigwAuthorizer-I005: principalId = %s', principalId)
        return generatePolicy(principalId, 'Allow', event['methodArn'])
    elif tokenAuthentic == 'expiredToken':
        logging.info ('expired Token.  Token = %s', principalId)
        raise Exception('Unauthorized')
    else:
        return generatePolicy(None, 'Deny', event['methodArn'])

if __name__ == '__main__':
    pass