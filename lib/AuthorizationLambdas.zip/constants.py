'''
Created on Mar 13, 2019

@author: MorganB

DEPRECATED - Use lambdas.lambdaConstants for truly global constants. Constants like status and result codes should be stored in enum's in common. Others probably defined directly within their services.
'''
# prcs_stat_cd - deprecated, use ProcessStatusCodes instead
URL_ISSUED = 33802
FILE_RECEIVED =  33803
FILE_SUBMITTED_TO_VIRUS_SCAN = 33804
FILE_RETURNED_FROM_VIRUS_SCAN = 33901
FILE_RENAMED_DUE_TO_SPECIAL_CHARACTERS = 33902
PROCESSING_COMPLETE = 29169

# prcs_rslt_cd - deprecated, use ProcessResultCodes instead
VIRUS_FOUND = 33805
FILE_AVAILABLE = 33806
SUCCESSFUL = 20095
UNSUCCESSFUL = 20244
FILE_DELETED = 33914

# upload types 
SUBMITTER_ATTACHMENT = 33762
CASE_RESOLUTION_ATTACHMENT = 33763
RESEARCHER_INTERNAL_ATTACHMENT = 33764
BDRS_ATTACHMENT = 33693
SUBMISSION_BATCH_FILE = 33994
CFP_BATCH_FILE = 34631
CHALLENGE_ATTACHMENT = 34630
TRAINING_MEDIA_ATTACHMENT = 1

#SFTP constants
SFTP_PORT = 22
MAX_LOOP_COUNTER=10
RESTART_LAMBDA_IF_MESSAGES_LEFT_ON_QUEUE=False
MESSAGES_PER_RECEIVE=10

# attachment constants 
UPLOAD_FOLDER = 'attachment-upload'
EXPOSED_ATTACHMENT_FOLDER = 'attachments'
MAX_ATTACHMENT_SIZE = 5120000
TRAINING_MEDIA_MAX_ATTACHMENT_SIZE = 50000000
LOCAL_DIRECTORY = '/tmp/'
VALID_FILE_TYPES = ['txt','jpg','jpeg','png','doc','docx','xls','xlsx','ppt','pptx','pdf','csv','gif','dat']
VALID_BATCH_FILE_TYPES = ['xlsx']
VALID_CFP_FILE_TYPES = ['txt','dat']
VALID_TRAINING_MEDIA_TYPES = ['pdf', 'mov', 'mp4', 'jpeg', 'gif', 'png', 'doc', 'docx', 'xls', 'xlsx', 'html', 'zip', 'xltx']
MEDIA_ATTACHMENT_FOLDER = 'M'

# Batch Attachment Codes
EXCEL_FORMAT_CODE = 5187

#Batch Source Codes
IRSCH_CUSTOM_WEB_PORTAL_CODE = 33584

# Batch Submission Codes
BATCH_SUBMISSION_RECEIVED = 33598
BATCH_SUBMISSION_REJECTED = 33601
BATCH_SUBMISSION_PARSED = 33602
BATCH_SUBMISSION_SUBMMITTED = 33992
BATCH_SUBMISSION_COMPLETED = 33606

# Batch Watch service
S3_UPLOAD_FOLDER = 'batchStatus'

# RetrieveAdminData service
BATCH_RAW_DATA_S3_FOLDER = 'batchrawdata'

# TrainingMediaService Attachments Key
TRAINING_MEDIA_DATA_S3_FOLDER = 'attachments/M/'
