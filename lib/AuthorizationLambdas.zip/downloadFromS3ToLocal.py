'''
Created on Mar 21, 2019

@author: MorganB

Deprecated: Use s3Helper instead.
'''

import logging
import constants

def downloadFromS3ToLocal(environDict, attmObj):
    attmObj.setLocalFileName(constants.LOCAL_DIRECTORY)
    try:
        logging.info(f"downloadFromS3ToLocal: Copy from bucket {attmObj.getIncomingS3Bucket()} file={attmObj.getIncomingS3Key()} to localfile={attmObj.getLocalFileName()} ...")
        environDict['s3Handle'].Bucket(attmObj.getIncomingS3Bucket()).download_file(attmObj.getIncomingS3Key(), attmObj.getLocalFileName())
        logging.info('downloadFromS3ToLocal-I001: Copied to Local file name = %s', attmObj.getLocalFileName())
    except Exception as e:
        logging.error('downloadFromS3ToLocal-E001: error pulling S3 file to local disk. Error msg = %s', e)
        return False
    return True 

if __name__ == '__main__':
    pass