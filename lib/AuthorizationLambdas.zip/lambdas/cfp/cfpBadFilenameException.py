'''
Created on Jun 22, 2020

@author: VanCampK
'''
from lambdas.exceptions import LambdaProcessingException
from lambdas.lambdaStatusCodes import LambdaStatusCodes


class CfpBadFilenameException(LambdaProcessingException):
    '''
    Exception thrown when the CFP filename cannot be parsed - needs to raise alert because we have no way to communicate it back to CFP team
    '''

    
    def __init__(self, errmsg, requestRejection=None):
        super().__init__(errmsg, requestRejection)
        self.statusCode = LambdaStatusCodes.BAD_REQUEST
