'''
Created on Jun 25, 2020

@author: VanCampK
'''
# CFP-specific error messages
CFP_ERR_INVALID_PROCESS_ID = "The provided process id is not valid"
CFP_IRD3_BATCH_WRONG_STATUS = "The batch must be in RECEIVED status in order to process an IRD3 file"
CFP_ERR_INVALID_COUNTRY_CODE = "The provided country code is not a known WorldBase country code"
CFP_ERR_UNKNOWN_FILE_EXTENSION = "The extension of the CFP file does not match any known extension for this flow"
CFP_UNKNOWN_STATUS = "Unknown CFP status"
CFP_INVALID_STEP_NAME = "Invalid step file for current step"
CFP_INVALID_FILE_EXTENSION = "Invalid file extension for current step"
CFP_UNEXPECTED_RECORD_COUNT = "The number of records in the IRD3 DAT file does not match the numRecs specified in the IRD3 HDR file"
CFP_REJECTED_RECORDS = "One or more records in the batch have failed validation"
CFP_MISSING_LOOKUP_RULE = "A valid lookup rule is required"
CFP_INVALID_LOOKUP_RULE = "An invalid lookup rule has been provided"
CFP_IRD3_DAT_WITHOUT_HDR = "Received IRD3 DAT file but HDR file still has not arrived, wait time expired"
