'''
Created on Jun 22, 2020

@author: VanCampK
'''

from common.batchStatusCodes import BatchStatusCode


class CfpRecord(object):
    '''
    Holds information about one CFP batch record
    '''


    def __init__(self, stpPartnerDeliveryFile, startingRecordNumber):
        self.stpPartnerDeliveryFile = stpPartnerDeliveryFile
        self.outgoingStpPartnerDeliveryFile = None
        self.startingRecordNumber = startingRecordNumber
        self.localFileName = None
        self.cfpFilePrefix = None
        self.cfpStepName = None
        self.cfpFileExtension = None
        self.batchRecord = None
        self.requestRejectionErrors = []    # list of RequestRejectionError, if any
        self.rejectionReasonCode = None     # reason for rejection, if any
        self.repushMsg = None
        
        
    def isRejected(self):
        # First check for batch-level rejections
        #if len(self.requestRejectionErrors) > 0 or (self.batchRecord is not None and (self.batchRecord.processingStatusCode == BatchStatusCode.REJECTED.value or self.batchRecord.processingStatusCode == BatchStatusCode.APPROVER_REJECTED.value)):
        if len(self.requestRejectionErrors) > 0 or (self.batchRecord is not None and (self.batchRecord.processingStatusCode == BatchStatusCode.REJECTED.value)):
            return True
        return False
    
    
    def isAnyRejected(self):
        if self.isRejected():
            return True
        for requestRecord in self.batchRecord.requestRecords:
            if requestRecord.isRejected():
                return True
        return False
    
    
    def addRejection(self, requestRejectionError, rejectionReasonCode):
        self.requestRejectionErrors.append(requestRejectionError)
        self.rejectionReasonCode = rejectionReasonCode


    def requestRejectionErrorsToDict(self):
        errs = []
        for err in self.requestRejectionErrors:
            errs.append(err.toDict())
        return errs
        
        
    def getFirstFailingRequestRecord(self):
        for requestRecord in self.batchRecord.requestRecords:
            if requestRecord.isRejected():
                return requestRecord
        return None