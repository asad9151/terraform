'''
Created on Jun 22, 2020

@author: VanCampK
'''
import logging
import os
import sys

from common.rejectionReasonCodes import RejectionReasonCode
from common.util.dictUtils import parseFixedFormatAsDict
from common.util.s3Helper import S3Helper
from common.util.stringUtils import isBlank
from lambdas.cfp.batchRecord import BatchRecord
import lambdas.cfp.cfpErrorMessages as cfperrmsgs
from lambdas.cfp.cfpRecord import CfpRecord
from lambdas.cfp.cfpUtil import mapIrdProcessIdToBatchType, updateBatchAttributes
import lambdas.errorMessages as errmsgs
from lambdas.exceptions import LambdaProcessingException
from lambdas.requestRejectionError import RequestRejectionError
from SetLambdaLogging import setLogging


class CfpParserIrd1(object):
    '''
    Parses the IRD-1 incoming HDX file from CFP
    '''
    #                                                                                                   1                                                                                                   2                                                                                                   3
    #....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0
    #          000000000                           Akamai Technologies Inc300                                                                 02100                                                                     B9050620564J08000000
    IRD1_CFG = [
        {'irdCustAgn': {'start': 1, 'end': 10}},
        {'custDuns': {'start': 11, 'end': 19}},
        {'custName': {'start': 20, 'end': 69}},
        {'irdProcessId': {'start': 70, 'end': 72}},
        {'empty1': {'start': 73, 'end': 137}},
        {'irdBatchType': {'start': 138, 'end': 139}},
        {'irdAcceptLvl': {'start': 140, 'end': 142}},
        {'dueDate': {'start': 143, 'end': 152}},
        {'dueTime': {'start': 153, 'end': 160}},
        {'empty2': {'start': 161, 'end': 211}},
        {'prjId': {'start': 212, 'end': 219}},
        {'tr': {'start': 220, 'end': 223}},
        {'irdPriority': {'start': 224, 'end': 226}},
        {'zero': {'start': 227, 'end': 231}}
    ]


    def __init__(self):
        self.s3Helper = None


    def parseIrd1File(self, requestContext, cfpRecord):
        self._createServices(requestContext)
        cfpRecord.localFileName = S3Helper.LOCAL_DIRECTORY + '/' + cfpRecord.stpPartnerDeliveryFile.s3Object.fileName
        logging.info(f"Copying IRD-1 file from S3 to {cfpRecord.localFileName}")
        self.s3Helper.copyFromS3ToLocal(cfpRecord.stpPartnerDeliveryFile.s3Object, cfpRecord.localFileName)
        saveException = None
        
        try:
            self.parseIrd1FileImpl(requestContext, cfpRecord)
        except Exception as e:
            logging.error(f"Caught exception {e} from parseIrd1FileImpl")
            saveException = e
        finally:
            # cleanup
            logging.info(f"parseIrd1File: remove local file {cfpRecord.localFileName}")
            try:
                os.remove(cfpRecord.localFileName)
                logging.info("parseIrd1File: Back from removeing local file")
            except Exception as e:
                logging.warning(f"parseIrd1File: Failed to remove local file, continuing anyway: {e}")
        
        if saveException is not None:
            raise saveException
        
        
    def _createServices(self, requestContext):
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
            
            
    def parseIrd1FileImpl(self, requestContext, cfpRecord):
        with open(cfpRecord.localFileName) as fp:
            try:
                line = fp.readline()
                # Single-line file, parse it directly
                result = parseFixedFormatAsDict(line, CfpParserIrd1.IRD1_CFG)
                logging.info(f"Parsed from IRD1 file: {result}")
            except Exception as e:
                # Should only happen if error reading file
                errmsg = f"parseIrd1FileImpl: Caught exception processing file: {e}"
                logging.error(errmsg)
                raise LambdaProcessingException(errmsg)
        
        cfpRecord.batchRecord.customerName = result.get('custName')
        if isBlank(cfpRecord.batchRecord.customerName):
            reqRejErr = RequestRejectionError('cust_name', errmsgs.ERR_REQUIRED_FIELD_MISSING, None)
            cfpRecord.addRejection(reqRejErr, RejectionReasonCode.VALIDATION_ERROR)
        cfpRecord.batchRecord.batchType = mapIrdProcessIdToBatchType(result.get('irdProcessId'))
        if cfpRecord.batchRecord.batchType is None:
            reqRejErr = RequestRejectionError('ird_process_id', cfperrmsgs.CFP_ERR_INVALID_PROCESS_ID, result.get('irdProcessId'))
            cfpRecord.addRejection(reqRejErr, RejectionReasonCode.VALIDATION_ERROR)
        updateBatchAttributes(cfpRecord, prjId=result["prjId"], tr=result["tr"])

# main function for command line testing
if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit("usage: cfpParserIrd1 localFile.HDX/.HDR [other .HDX/HDR files]")

    setLogging(logging.DEBUG)
    
    cfpParserIrd1 = CfpParserIrd1()
    for argNo in range(1, len(sys.argv)):
        cfpRecord = CfpRecord(None, None)
        cfpRecord.localFileName = sys.argv[argNo]
        cfpRecord.batchRecord = BatchRecord()
        
        cfpParserIrd1.parseIrd1FileImpl(None, cfpRecord)
        if cfpRecord.isRejected():
            logging.error(f"{cfpRecord.localFileName} Rejected: {cfpRecord.requestRejectionErrorsToDict()}")
        else:
            logging.info(f"{cfpRecord.localFileName} Success: customerName={cfpRecord.batchRecord.customerName} batchType={cfpRecord.batchRecord.batchType}")
