'''
Created on Jun 22, 2020

@author: VanCampK

Small utility functions for CFP processing
'''
import json
import logging
import os
import random

from common.batchStatusCodes import BatchStatusCode
from common.batchType import BatchType
from common.cfpStatusCodes import CfpStatusCode
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.stringUtils import isBlank, isNotBlank, intDefaultNone
from common import envVblNames
from lambdas.cfp.cfpBadFilenameException import CfpBadFilenameException
from lambdas.cfp import cfpErrorMessages
from lambdas.cfp.cfpStepName import CfpStepName
from lambdas.exceptions import LambdaProcessingException
from lambdas.requestRejectionError import RequestRejectionError


def parseCfpFilename(cfpRecord):
    # FPC.cust.project.tracking.flow.fileType
    # Sample (old using STP):  CFPDev.CN2KTGFE.iResearchDEV.0.FPC.AKAMAITE.B9050620.TR564J.IRD1.HDX
    # Sample (new using Sftp): CFPDev1/global/FPC.KEN.CFP_LOOKUP_INV_BATCH1_20200814_1.TR458I.IRD1.HDX
    flnmParts = cfpRecord.stpPartnerDeliveryFile.stpFileName.split(".")
    if len(flnmParts) < 5:
        errmsg = f"Incoming CFP filename cannot be parsed - no file name? - Got {cfpRecord.stpPartnerDeliveryFile.stpFileName}"
        logging.error(errmsg)
        raise CfpBadFilenameException(errmsg)
    #if len(flnmParts) != 10 or flnmParts[4] != "FPC":
    if len(flnmParts) != 6 or (not flnmParts[0].endswith("/FPC")):
        errmsg = f"Incoming CFP filename cannot be parsed - does not conform to expected file format FPC.cust.project.tracking.flow.fileType - Got {cfpRecord.stpPartnerDeliveryFile.stpFileName}"
        logging.error(errmsg)
        raise CfpBadFilenameException(errmsg)
    
    cfpRecord.cfpFilePrefix = "FPC." + ".".join(flnmParts[1:5])
    stepName = flnmParts[4]
    if CfpStepName.hasValue(stepName):
        cfpRecord.cfpStepName = stepName
    else:
        errmsg = f"Unknown CfpStepName {stepName} could not be processed - Got {cfpRecord.stpPartnerDeliveryFile.stpFileName}"
        logging.error(errmsg)
        raise CfpBadFilenameException(errmsg)
    cfpRecord.cfpFileExtension = flnmParts[5]
    
    
def mapIrdProcessIdToBatchType(irdProcessId):
    if irdProcessId is None:
        return None
    elif irdProcessId == '300':
        # Look-up only (CFP code 300) Maps to research subtype 34659 - Manual Match Lookup
        return BatchType.CFP_LOOKUP_BATCH.value
    elif irdProcessId == '700':
        # Browse & review (CFP code 700) - Maps to research subtype 34659 - Manual Match Lookup
        #return BatchType.CFP_LOOKUP_BATCH.value
        raise NotImplementedError("irdProcessId 700 not supported")
    elif irdProcessId == '100':
        # Investigation (CFP code 100) Maps to research subtype 33575 - Add business - Mini Inquiry - Identity Data Only
        return BatchType.CFP_INV_BATCH.value
    elif irdProcessId == '400':
        # Look-up and investigation (CFP code 400) Map to research subtype 35028 - Manual Lookup to Add Business - Mini
        return BatchType.CFP_LOOKUP_INV_BATCH.value
    else:
        return None
    
    
def mapBatchTypeToIrdProcessId(batchType):
    if batchType is None:
        return None
    elif batchType == BatchType.CFP_LOOKUP_BATCH.value:
        # Look-up only (CFP code 300) Maps to research subtype 34659 - Manual Match Lookup
        return '300' 
    elif batchType == BatchType.CFP_INV_BATCH.value:
        # Investigation (CFP code 100) Maps to research subtype 33575 - Add business - Mini Inquiry - Identity Data Only
        return '100'
    elif batchType == BatchType.CFP_LOOKUP_INV_BATCH.value:
        # Look-up and investigation (CFP code 400) Map to research subtype 35028 - Manual Lookup to Add Business - Mini
        return '400'
    else:
        return None


def mapBatchTypeToResearchSubType(batchType):
    rschType = None
    rschSubType = None
    if batchType == BatchType.CFP_LOOKUP_BATCH.value:
        # Look-up only (CFP code 300) Maps to research subtype 34659 - Manual Match Lookup
        rschType = 34658
        rschSubType = 34659
    elif batchType == BatchType.CFP_INV_BATCH.value:
        # Investigation (CFP code 100) Maps to research subtype 33575 - Add business - Mini Inquiry - Identity Data Only
        rschType = 33532
        rschSubType = 33575
    elif batchType == BatchType.CFP_LOOKUP_INV_BATCH.value:
        # Look-up and investigation (CFP code 400) Map to research subtype 35028 - Manual Lookup to Add Business - Mini
        rschType = 33532
        rschSubType = 35028
    #return [rschType, rschSubType]
    return rschSubType
    

def replaceFileExtension(incomingFilename, newExtension):
    return os.path.splitext(incomingFilename)[0] + '.' + newExtension


def mapCfpStatusCodeToCfpStepName(cfpStatusCode):
    if cfpStatusCode in (CfpStatusCode.IRD1_PARSED.value, CfpStatusCode.IRD1_RESPONDED.value):
        return CfpStepName.IRD1.name
    elif cfpStatusCode in (CfpStatusCode.IRD3_HDR_PARSED.value, CfpStatusCode.IRD3_DAT_PARSED.value, CfpStatusCode.IRD3_DAT_RESPONDED.value):
        return CfpStepName.IRD3.name
    else:
        return None


# Workflow maps the current CFP status code to the expected next file step name and list of possible extensions
CFP_WORKFLOW_DICT = {
    None: { 'cfpStepName': CfpStepName.IRD1.name, 'cfpFileExtensions': ['HDX','HDR'], 'cfpNextStatusCode': CfpStatusCode.IRD1_PARSED.value},
    CfpStatusCode.IRD1_PARSED.value: { 'cfpStepName': CfpStepName.IRD1.name, 'cfpFileExtensions': ['OK','ERR','STAT'], 'cfpNextStatusCode': CfpStatusCode.IRD1_RESPONDED.value},
    CfpStatusCode.IRD1_RESPONDED.value: { 'cfpStepName': CfpStepName.IRD3.name, 'cfpFileExtensions': ['HDX','HDR'], 'cfpNextStatusCode': CfpStatusCode.IRD3_HDR_PARSED.value},
    CfpStatusCode.IRD3_HDR_PARSED.value: { 'cfpStepName': CfpStepName.IRD3.name, 'cfpFileExtensions': ['REC','DAT'], 'cfpNextStatusCode': CfpStatusCode.IRD3_DAT_PARSED.value},
    CfpStatusCode.IRD3_DAT_PARSED.value: { 'cfpStepName': CfpStepName.IRD3.name, 'cfpFileExtensions': ['OK','ERR','STAT'], 'cfpNextStatusCode': CfpStatusCode.IRD3_DAT_RESPONDED.value}
}

def validateAndGetCfpStatus(cfpRecord): # cfpStepName, cfpFileExtension):
    # Validates the incoming file step and extension against current CFP status
    # Generates a rejection if not in expected state
    # Or returns the next status code if ok
    wkflDict = CFP_WORKFLOW_DICT.get(cfpRecord.batchRecord.cfpStatusCode)
    logging.info(f"validateAndGetCfpStatus: incoming cfpStatusCode={cfpRecord.batchRecord.cfpStatusCode} wkflDict={wkflDict}")
    if wkflDict is None:
        cfpRecord.addRejection(RequestRejectionError(jsonPathName="cfpStatusCode", errorDescription=cfpErrorMessages.CFP_UNKNOWN_STATUS, providedValue=cfpRecord.batchRecord.cfpStatusCode), RejectionReasonCode.VALIDATION_ERROR)
        return None
    if cfpRecord.cfpStepName != wkflDict.get('cfpStepName'):
        cfpRecord.addRejection(RequestRejectionError(jsonPathName="cfpStepName", errorDescription=cfpErrorMessages.CFP_INVALID_STEP_NAME, providedValue=cfpRecord.cfpStepName), RejectionReasonCode.VALIDATION_ERROR)
        return None
    if cfpRecord.cfpFileExtension not in wkflDict.get('cfpFileExtensions'):
        if cfpRecord.cfpFileExtension in ['REC','DAT'] and cfpRecord.batchRecord.cfpStatusCode == CfpStatusCode.IRD1_RESPONDED.value:
            # Special case, IRD3.DAT received before IRD3.HDR - need to wait
            return CfpStatusCode.IRD3_DAT_BEFORE_HDR.value
        cfpRecord.addRejection(RequestRejectionError(jsonPathName="cfpFileExtension", errorDescription=cfpErrorMessages.CFP_INVALID_FILE_EXTENSION, providedValue=cfpRecord.cfpFileExtension), RejectionReasonCode.VALIDATION_ERROR)
        return None
    return wkflDict.get('cfpNextStatusCode')
    
    
def createCfpRequestKey(cfpRecord, originalRecord):
    # Creates a structured requestorOwnRequestKey by concatenating a few fields we need to pass through
    requestKey = str(cfpRecord.batchRecord.batchRequestId) + "_" + originalRecord.get("sequenceNo") + "_" + originalRecord.get("accountNumb")# + "," + originalRecord.get("matchGrade")
    return requestKey


def parseCfpRequestKey(requestKey):
    # Parses the requestorOwnRequestKey and returns a dictionary with the fields contained in it
    if requestKey is None:
        return {}
    requestKeyArr = requestKey.split("_")
    if len(requestKeyArr) < 3:
        logging.error(f"parseCfpRequestKey: Unparsable requestKey={requestKey}")
        return {} 
    intRefDict = {
        "batchRequestId": int(requestKeyArr[0]),
        "sequenceNo": requestKeyArr[1],
        "accountNumb": requestKeyArr[2]
        #"matchGrade": intRefArr[3]
    }
    return intRefDict


HEADER_FILE_EXTENSIONS = ['HDR', 'HDX']


def isHeaderFile(cfpFileExtension):
    return (cfpFileExtension in HEADER_FILE_EXTENSIONS)


def gotIrd3Hdr(cfpRecord):
    if cfpRecord.batchRecord.totalEntriesCount is not None and cfpRecord.batchRecord.totalEntriesCount > 0:
        return True
    elif cfpRecord.batchRecord.cfpStatusCode == CfpStatusCode.IRD3_HDR_PARSED.value:
        return True
    else:
        return False


def gotIrd3Dat(cfpRecord):
    if cfpRecord.batchRecord.requestRecords is not None and len(cfpRecord.batchRecord.requestRecords) > 0:
        return True
    elif cfpRecord.batchRecord.cfpStatusCode == CfpStatusCode.IRD3_DAT_PARSED.value:
        return True
    else:
        return False
    

def isBothIrd3FilesReceived(cfpRecord):
    if gotIrd3Hdr(cfpRecord) and gotIrd3Dat(cfpRecord):
        return True
    else:
        return False


def isLookupRuleOk(lookupRule):
    # Make sure there's something left after we remove the word "custom" from the lookup rule
    #lookupMinusCustom = re.sub('custom', '', lookupRule, flags=re.IGNORECASE)
    #lookupMinusNonAlphaNumeric = re.sub(r'\W+', '', lookupMinusCustom)
    #if isBlank(lookupMinusNonAlphaNumeric):
    #    return False
    #else:
    #    return True
    return True


def updateBatchRejectionError(cfpRecord):
    if cfpRecord.isRejected():
        if cfpRecord.batchRecord.processingStatusCode != BatchStatusCode.REJECTED.value and cfpRecord.batchRecord.processingStatusCode != BatchStatusCode.APPROVER_REJECTED.value:
            cfpRecord.batchRecord.processingStatusCode = BatchStatusCode.REJECTED.value
        if isBlank(cfpRecord.batchRecord.batchRejectionErrorText):
            if len(cfpRecord.requestRejectionErrors) > 0:
                cfpRecord.batchRecord.batchRejectionErrorText = cfpRecord.requestRejectionErrors[0].errorDescription
            else:
                cfpRecord.addRejection(RequestRejectionError(jsonPathName=None, errorDescription=cfpErrorMessages.CFP_REJECTED_RECORDS, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
    elif cfpRecord.isAnyRejected():
        cfpRecord.batchRecord.processingStatusCode = BatchStatusCode.REJECTED.value
        if isBlank(cfpRecord.batchRecord.batchRejectionErrorText):
            # Make sure there is a batch-level rejection message to show in the batch admin screen
            cfpRecord.addRejection(RequestRejectionError(jsonPathName=None, errorDescription=cfpErrorMessages.CFP_REJECTED_RECORDS, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)


MAX_IRD_ERR_LEN = 117


def generateIrdErrorRec(cfpRecord):
    reasonCode = cfpRecord.rejectionReasonCode
    if len(cfpRecord.requestRejectionErrors) > 0:
        errorMessage = cfpRecord.requestRejectionErrors[0]
    else:
        errorMessage = None
    if reasonCode is None or errorMessage is None:
        if isNotBlank(cfpRecord.batchRecord.batchRejectionErrorText):
            errorMessage = cfpRecord.batchRecord.batchRejectionErrorText
        elif cfpRecord.batchRecord.rejectedEntriesCount > 0:
            requestRecord = cfpRecord.getFirstFailingRequestRecord()
            if requestRecord is not None:
                reasonCode = requestRecord.rejectionReasonCode
                errorMessage = f"{cfpRecord.batchRecord.rejectedEntriesCount} rejected records, first error is {requestRecord.requestRejectionErrors[0].errorDescription}"
    if errorMessage is None:
        errorMessage = "Unknown error"
    if reasonCode is None:
        reasonCode = RejectionReasonCode.VALIDATION_ERROR.value
    errRec = {
        'errorCode': reasonCode,
        'errorMessage': errorMessage[:MAX_IRD_ERR_LEN]
    }
    return errRec
        
        
def postCfpResponseGeneratorRequest(cfpResponseGeneratorSqsHelper, cfpRecord, appModuleNm, delaySecs=0):
    cfpMessage = {
        'fileTrackingId': cfpRecord.stpPartnerDeliveryFile.fileTrackingId,
        'cfpStatusCode': cfpRecord.batchRecord.cfpStatusCode,
        'source': appModuleNm
    }
    outgoingBody = json.dumps(cfpMessage)
    logging.info(f"notifyCfpResponseGenerator posting msg to queue {cfpResponseGeneratorSqsHelper.queueUrl} for batchRequestId {cfpRecord.batchRecord.batchRequestId}: outgoingBody {outgoingBody}")
    queueResp = cfpResponseGeneratorSqsHelper.sendMessageToQueue(outgoingBody, delaySecs=delaySecs)
    messageId = queueResp.get('MessageId')
    logging.info(f"notifyCfpResponseGenerator: messageId={messageId} queueResp={queueResp}")
    if messageId is None:
        raise LambdaProcessingException(f"Failed to post message to queue {cfpResponseGeneratorSqsHelper.queueUrl} for batchRequestId {cfpRecord.batchRecord.batchRequestId}")


def calcCfpResponseCloseMsgDelay(requestContext):
    '''
    Before IRD4 file response files sent, use a configurable/randomized delay
    '''
    fixedDelay = intDefaultNone(requestContext.environDict[envVblNames.ENV_CFP_CLOSE_MSG_FIXED_DELAY_SECS], defaultValue=0)
    randomDelay = random.randint(0,intDefaultNone(requestContext.environDict[envVblNames.ENV_CFP_CLOSE_MSG_RANDOM_DELAY_SECS], defaultValue=0))
    return fixedDelay + randomDelay


def transformCfpFilePrefixForStatFile(cfpRecord):
    # Strip the ending off the cfpFilePrefix, e.g. change FPC.IMMANTES.A2101620.TR039B.IRD1 to FPC.IMMANTES.A2101620.TR039B
    return ".".join(cfpRecord.cfpFilePrefix.split(".")[0:-1])


def updateBatchAttributes(cfpRecord, prjId=None, tr=None, numRecs=None, projDesc=None):
    if cfpRecord.batchRecord.batchAttributes is None:
        cfpRecord.batchRecord.batchAttributes = {}
    batchAttrs = cfpRecord.batchRecord.batchAttributes
    if prjId is not None:
        batchAttrs["cfpProjectId"] = prjId
    if tr is not None:
        batchAttrs["cfpTrackingId"] = tr
    if numRecs is not None:
        batchAttrs["cfpEntriesCount"] = numRecs
    if projDesc is not None:
        lookupRules = []
        if projDesc.lower().startswith("global match rules:") or projDesc.lower().startswith("lookup rules:"):
            pdescflds = projDesc.split(":")
            lookupRules.append(pdescflds[1].strip())
        if len(lookupRules) > 0:
            batchAttrs["lookupRules"] = []
            for lookupRule in lookupRules:
                if isLookupRuleOk(lookupRule):
                    batchAttrs["lookupRules"].append({"lookupRule": lookupRule})
                else:
                    cfpRecord.addRejection(RequestRejectionError(jsonPathName="projDesc", errorDescription=cfpErrorMessages.CFP_INVALID_LOOKUP_RULE, providedValue=lookupRule), RejectionReasonCode.VALIDATION_ERROR)
