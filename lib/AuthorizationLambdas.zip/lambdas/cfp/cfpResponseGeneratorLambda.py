'''
Created on Apr 23, 2020

@author: VanCampK
'''
import logging
import json
import sys
import traceback

from common import envVblNames
from common.util.stringUtils import isBlank
from common.util.sqsHelper import SqsHelper
from lambdas.cfp.cfpResponseGeneratorService import CfpResponseGeneratorService
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaValidationException
from lambdas.lambdaBase import LambdaBase


class CfpResponseGeneratorLambda(LambdaBase):
    '''
    Handler class for CfpResponseGenerator service.
    Responsible for generating response files to respond to a CFP incoming request and sending them to the STP outbound delivery service
    Handler: lambdas.cfp.cfpResponseGeneratorLambda.handler
    '''
    
    def __init__(self):
        super().__init__()
        LambdaBase.raiseAlertWhenRequestFails = True
        self.service = None
        self.cfpResponseGeneratorSqsHelper = None
    
    
    def needsDbConn(self):
        return True
    
    
    def handleRequest(self):
        incomingEvent = self.requestContext.event
        cfpResponseGeneratorQueueUrl = CfpResponseGeneratorLambda.environDict[envVblNames.ENV_CFPRESPONSEGENERATOR_QUEUE_URL]
        if self.cfpResponseGeneratorSqsHelper is None:
            regionName = CfpResponseGeneratorLambda.environDict.get(envVblNames.ENV_SQS_REGION)
            self.cfpResponseGeneratorSqsHelper = SqsHelper(cfpResponseGeneratorQueueUrl, regionName=regionName)
        if self.service is None:
            self.service = CfpResponseGeneratorService(self.dbConn, self.cfpResponseGeneratorSqsHelper)
        logging.info(f"CfpResponseGeneratorLambda got incomingEvent {incomingEvent}")
        if 'Records' in incomingEvent:
            # Invoked via queue with batch size 1
            records = incomingEvent['Records']
            logging.info(f"Got multi-event request from queue with {len(records)} messages")
            lastException = None
            alertErrMsg = None
            fileTrackingId = None
            for record in records:
                logging.info(f"CfpResponseGeneratorLambda record={record}")
                try:
                    sbody = record.get('body')
                    if isinstance(sbody, str):
                        body = json.loads(sbody)
                    else:
                        body = sbody
                    messageId = record.get('messageId')
                    messageReceiptHandle = record.get('receiptHandle')
                    fileTrackingId = body.get('fileTrackingId')
                    startingRecordNumber = body.get('startingRecordNumber')
                    batchRequestId = body.get('batchRequestId')
                    self.service.processCfpResponseRequest(self.requestContext, fileTrackingId, batchRequestId, startingRecordNumber)
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except LambdaValidationException as lve:
                    alertErrMsg = f"LambdaValidationException trying to process fileTrackingId={fileTrackingId}: {lve}"
                    # Raise alert but do not retry batch
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except Exception as e:
                    alertErrMsg = f"Unexpected exception trying to process fileTrackingId={fileTrackingId}: {e}"
                    traceback.print_tb(sys.exc_info()[2])
                    # Raise alert and retry batch (i.e. don't delete message from queue)
                    lastException = e
                # Continue on to next record regardless of failure of one message
                
            if lastException is not None:
                # Tells lambda to retry, also raises alert from LambdaBase
                raise lastException
            elif alertErrMsg is not None:
                # No retry but raise alert anyway
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=alertErrMsg)
        
        
    def _markMessageComplete(self, messageId, messageReceiptHandle):
        '''
        Deletes a message from the queue because we successfully processed it
        '''
        if isBlank(messageId) or isBlank(messageReceiptHandle):
            logging.warning("Not deleting message from queue because no messageId or messageReceiptHandle")
            return
        logging.info(f"Delete message from queue {self.cfpResponseGeneratorSqsHelper.queueUrl}: messageId={messageId} messageReceiptHandle={messageReceiptHandle}")
        self.cfpResponseGeneratorSqsHelper.deleteOneMessageFromQueue(messageReceiptHandle)
        logging.info("Back from deleteOneMessageFromQueue")
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = CfpResponseGeneratorLambda.get_handler(...)