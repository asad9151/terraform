'''
Created on Jun 22, 2020

@author: VanCampK
'''
import json
import logging

from common.batchFormatCodes import BatchFormatCode
from common.encoders import IResearchEncoder


class CfpDao(object):
    '''
    Database access methods for CFP processing
    '''


    def insertCfpBatchRecord(self, dbConn, cfpRecord, requestContext, appModule):
        query = '''
        insert into btch_reqs (rsch_usr_id,btch_frmt_cd,btch_src_cd,prcs_stat_cd,stat_tmst,dnb_jti_val,btch_reqs_obj,row_crer_id_txt,row_modr_id_txt)
        values (%s,%s,%s,%s,NOW(),%s,%s,%s,%s)
        '''
        batchAttributesStr = None if cfpRecord.batchRecord.batchAttributes is None else json.dumps(cfpRecord.batchRecord.batchAttributes)
        params = (requestContext.userSession.userId, BatchFormatCode.FIXED_FORMAT.value, cfpRecord.stpPartnerDeliveryFile.apiApplicationEntitlement.requestMethodCode,
                  cfpRecord.batchRecord.processingStatusCode, requestContext.userSession.sessionToken, batchAttributesStr, appModule, appModule)
        logging.info(f"insertCfpBatchRecord: {query} params={params}")
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        batchId = dbConn.cursor.lastrowid
        logging.info(f"insertCfpBatchRecord: batchId={batchId}")
        return batchId
        
        
    def updateCfpBatchRecord(self, dbConn, batchRecord, requestContext, appModule):
        query = '''
        update btch_reqs set prcs_stat_cd=%s, stat_tmst=NOW(), btch_rej_err_txt=%s, tot_entr_cnt=%s, tot_detl_cnt=%s, rej_entr_cnt=%s, due_date=%s, cust_nme=%s, cfp_stat_cd=%s, btch_typ=%s, btch_reqs_obj=%s, row_modr_id_txt=%s where btch_reqs_id=%s
        '''
        batchAttributesStr = None if batchRecord.batchAttributes is None else json.dumps(batchRecord.batchAttributes)
        params = (batchRecord.processingStatusCode, batchRecord.batchRejectionErrorText, batchRecord.totalEntriesCount, batchRecord.totalDetailsCount,
                  batchRecord.rejectedEntriesCount, batchRecord.dueTimestamp, batchRecord.customerName, batchRecord.cfpStatusCode, batchRecord.batchType,
                  batchAttributesStr, appModule, batchRecord.batchRequestId)
        logging.info(f"updateCfpBatchRecord: {query} params={params}")
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        logging.info(f"updateCfpBatchRecord: updated batchId={batchRecord.batchRequestId}")
    
        
    def queryCfpBatchRecord(self, dbConn, batchRequestId):
        '''
            Queries database for a single batch record, returns a dictionary if found or None if not found.
        '''
        query = 'select BR.*, LS.auth_prin_id_obj, CS.cust_agn from btch_reqs BR left join lgin_ses LS on LS.dnb_jti_val = BR.dnb_jti_val left join cust CS on CS.cust_nme = BR.cust_nme where btch_reqs_id=%s'
        params = (batchRequestId)
        logging.info(f"queryCfpBatchRecord: {query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchone()
        if rv is not None:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(rv, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            logging.info(f"queryCfpBatchRecord: {dict_rslt}")
            return dict_rslt
        
        logging.info(f"queryCfpBatchRecord: None")
        return None
    
        
    def queryCfpBatchRecordByFileName(self, dbConn, irdFilename):
        '''
            Queries database for a single batch record, based on an earlier flow filename.
            Returns a dictionary if found or None if not found.
        '''
        query = '''
select BR.*, LS.auth_prin_id_obj, CS.cust_agn
from btch_reqs BR
join lgin_ses LS on LS.dnb_jti_val = BR.dnb_jti_val 
join cust CS on CS.cust_nme = BR.cust_nme
join ptnr_fle_tkg PFT on PFT.btch_reqs_id = BR.btch_reqs_id
join fle_tkg FT on FT.fle_tkg_id = PFT.fle_tkg_id
where FT.fle_nme=%s
        '''
        params = (irdFilename)
        logging.info(f"queryCfpBatchRecord: {query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchone()
        if rv is not None:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(rv, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            logging.info(f"queryCfpBatchRecord: {dict_rslt}")
            return dict_rslt
        
        logging.info(f"queryCfpBatchRecord: None")
        return None

        
    def queryCustomerAgn(self, dbConn, customerName):
        query = "select cust_agn from cust where cust_nme=%s"
        params = (customerName)
        logging.info(f"queryCustomerAgn: {query} params={params}")
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchone()
        if rv is not None:
            # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
            json_data = json.dumps(rv, cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            logging.info(f"queryCustomerAgn: {dict_rslt}")
            return dict_rslt.get('cust_agn')
        
        return None
    
    
    def insertCustomerAgn(self, dbConn, customerName, appModule):
        query = "insert into cust (cust_nme,row_crer_id_txt,row_modr_id_txt) values (%s,%s,%s)"
        params = (customerName, appModule, appModule)
        logging.info(f"insertCustomerAgn: {query} params={params}")
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        customerAgn = dbConn.cursor.lastrowid
        logging.info(f"insertCustomerAgn: customerAgn={customerAgn}")
        return customerAgn


    def insertRejectRecord(self, dbConn, batchRequestId, origRequestObj, requestRejectionErrorObj, appModule):
        query = '''
        insert into btch_rsch_reqs_rej (btch_reqs_id,btch_rsch_reqs_obj,btch_rsch_reqs_rej_obj,row_crer_id_txt,row_modr_id_txt)
        values (%s,%s,%s,%s,%s)
        '''
    
        params = (batchRequestId, origRequestObj, requestRejectionErrorObj, appModule, appModule)
        logging.info('Insert reject: ' + query + ' params=' + str(params))
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid


    def queryBatchDetailsAndRejects(self, dbConn, batchRequestId):
        # 3-way union where:
        # Part 1 returns Unlinked cases or cases not yet submitted
        # Part 2 returns Linked cases
        # Part 3 returns rejects
        query = '''
select rej_indc, btch_detl_id as id, SR.subj_rsch_id, SR.lnk_typ, BD.raw_data_obj, null as btch_rsch_reqs_rej_obj, SR.subj_rsch_obj, RT.rsch_rslt_obj, BD.rec_nbr
from btch_detl BD
left join rsch_reqs RR on RR.btch_reqs_id = BD.btch_reqs_id and RR.v_intl_ref_id = BD.rec_nbr
left join subj_rsch SR on SR.rsch_reqs_id = RR.rsch_reqs_id
left join rsch_rslt RT on RT.subj_rsch_id = SR.subj_rsch_id
where BD.btch_reqs_id in (%s) and BD.rej_indc = 0
and SR.lnkd_subj_rsch_id is null
UNION
select rej_indc, btch_detl_id as id, SR2.subj_rsch_id, SR2.lnk_typ, BD.raw_data_obj, null as btch_rsch_reqs_rej_obj, SR2.subj_rsch_obj, RT.rsch_rslt_obj, BD.rec_nbr
from btch_detl BD
join rsch_reqs RR on RR.btch_reqs_id = BD.btch_reqs_id and RR.v_intl_ref_id = BD.rec_nbr
join subj_rsch SR on SR.rsch_reqs_id = RR.rsch_reqs_id
join subj_rsch SR2 on SR2.lnkd_subj_rsch_id = SR.subj_rsch_id
left join rsch_rslt RT on RT.subj_rsch_id = SR2.subj_rsch_id
where BD.btch_reqs_id in (%s) and BD.rej_indc = 0
and SR.lnkd_subj_rsch_id is not null and SR.lnk_typ = 1
and SR2.lnk_typ = 2
UNION
select 1 as rej_indc, btch_rsch_reqs_rej_id as id, null as subj_rsch_id, null as lnk_typ, btch_rsch_reqs_obj as raw_data_obj, btch_rsch_reqs_rej_obj, null as subj_rsch_obj, null as rsch_rslt_obj, v_intl_ref_id as rec_nbr
from btch_rsch_reqs_rej
where btch_reqs_id in (%s)
order by 9
        '''
        params = (batchRequestId, batchRequestId, batchRequestId)
        logging.info(f"queryBatchDetailsAndRejects: {query} params={params}")
    
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        logging.info(f"queryBatchDetailsAndRejects: Returned {len(dict_data)} rows")
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        return dict_arry
