'''
Created on Apr 23, 2020

@author: VanCampK
'''
import boto3
import logging
import json
import sys
import traceback

from common import envVblNames
from common.util.awsUtils import createClientConfiguration
from common.util.stringUtils import isBlank
from common.util.sqsHelper import SqsHelper
from lambdas.cfp.cfpParserService import CfpParserService
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaValidationException
from lambdas.lambdaBase import LambdaBase


class CfpParserLambda(LambdaBase):
    '''
    Handler class for CfpParser service.
    Responsible for parsing an CfpParser request file and forwarding all requests to the CfpParser service.
    Handler: lambdas.cfp.cfpParserLambda.handler
    '''
    
    def __init__(self):
        super().__init__()
        LambdaBase.raiseAlertWhenRequestFails = True
        self.service = None
        self.cfpParserSqsHelper = None
        self.lambdaClient = None
        self.cfpParserQueueUrl = None
    
    
    def needsDbConn(self):
        return True
    
    
    def handleRequest(self):
        incomingEvent = self.requestContext.event
        self._createServices()
        logging.info(f"CfpParserLambda got incomingEvent {incomingEvent}")
        if 'Records' in incomingEvent:
            # Invoked via queue with batch size 1
            records = incomingEvent['Records']
            logging.info(f"Got multi-event request from queue with {len(records)} messages")
            lastException = None
            alertErrMsg = None
            fileTrackingId = None
            for record in records:
                logging.info(f"CfpParserLambda record={record}")
                try:
                    sbody = record.get('body')
                    if isinstance(sbody, str):
                        body = json.loads(sbody)
                    else:
                        body = sbody
                    messageId = record.get('messageId')
                    messageReceiptHandle = record.get('receiptHandle')
                    fileTrackingId = body.get('fileTrackingId')
                    startingRecordNumber = body.get('startingRecordNumber')
                    repushMsg = self.service.processCfpParseRequest(self.requestContext, fileTrackingId, startingRecordNumber)
                    if repushMsg is not None:
                        self._repushMessageToQueue(repushMsg)
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except LambdaValidationException as lve:
                    alertErrMsg = f"LambdaValidationException trying to process fileTrackingId={fileTrackingId}: {lve}"
                    # Raise alert but do not retry batch
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except Exception as e:
                    alertErrMsg = f"Unexpected exception trying to process fileTrackingId={fileTrackingId}: {e}"
                    traceback.print_tb(sys.exc_info()[2])
                    # Raise alert and retry batch (i.e. don't delete message from queue)
                    lastException = e
                # Continue on to next record regardless of failure of one message
                
            if lastException is not None:
                # Tells lambda to retry, also raises alert from LambdaBase
                raise lastException
            elif alertErrMsg is not None:
                # No retry but raise alert anyway
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=alertErrMsg)
        
        
        
    def _markMessageComplete(self, messageId, messageReceiptHandle):
        '''
        Deletes a message from the queue because we successfully processed it
        '''
        if isBlank(messageId) or isBlank(messageReceiptHandle):
            logging.warning("Not deleting message from queue because no messageId or messageReceiptHandle")
            return
        logging.info(f"Delete message from queue {self.cfpParserQueueUrl}: messageId={messageId} messageReceiptHandle={messageReceiptHandle}")
        self.cfpParserSqsHelper.deleteOneMessageFromQueue(messageReceiptHandle)
        logging.info("Back from deleteOneMessageFromQueue")
        
        
    def _repushMessageToQueue(self, repushMsg):
        '''
        Re-pushes a message to the queue in case it needs to wait for some other event to occur
        '''
        logging.info(f"Re-pushing message to queue {self.cfpParserQueueUrl}: {repushMsg}")
        resp = self.cfpParserSqsHelper.sendMessageToQueue(repushMsg)
        logging.info(f"Got back response from sendMessageToQueue: {resp}")
        
        
    def _createServices(self):
        if self.lambdaClient is None:
            self.lambdaClient = boto3.client('lambda', region_name=self.requestContext.environDict[envVblNames.ENV_LAMBDA_REGION], config=createClientConfiguration(self.requestContext.environDict))
        if self.service is None:
            self.service = CfpParserService(self.dbConn, self.lambdaClient)
        self.cfpParserQueueUrl = CfpParserLambda.environDict[envVblNames.ENV_CFPPARSER_QUEUE_URL]
        if self.cfpParserSqsHelper is None:
            regionName = CfpParserLambda.environDict.get(envVblNames.ENV_SQS_REGION)
            self.cfpParserSqsHelper = SqsHelper(self.cfpParserQueueUrl, regionName=regionName)
        
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = CfpParserLambda.get_handler(...)