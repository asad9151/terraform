'''
Created on Jun 8, 2019

@author: VanCampK
'''


class RequestRecord(object):
    '''
    Holds attributes about one CFP IRD request record
    '''

    def __init__(self):
        self.originalRecord = None          # original record transformed into json
        self.miniBatchRecord = None         # originalRecord transformed into minibatch record format
        self.iResearchSchemaRecord = None   # originalRecord transformed into iResearch SubmitCase schema 
        self.requestRejectionErrors = []    # list of RequestRejectionError, if any
        self.rejectionReasonCode = None     # reason for rejection, if any
        self.batchRequestRejectId = None    # ID of rejected record, if rejected
        self.batchDetailRecord = None       # transformed to BatchDetail schema
        self.recordNumber = None            # sequential record number in the batch
        self.subjectResearchId = None       # case id
        self.linkTypeCode = None            # linkTypeCode if set
        self.subjectResearchRecord = None   # subj_rsch.subj_rsch_obj as dict, if case is submitted
        self.researchResultRecord = None    # rsch_rslt.rsch_rslt_obj as dict, if case is closed
        
        
    def isRejected(self):
        if self.requestRejectionErrors:
            if len(self.requestRejectionErrors) > 0:
                return True
        return False
    
    
    def addRejection(self, requestRejectionError, rejectionReasonCode):
        self.requestRejectionErrors.append(requestRejectionError)
        self.rejectionReasonCode = rejectionReasonCode
            
            
    def requestRejectionErrorsToString(self):
        errmsg = '['
        for err in self.requestRejectionErrors:
            if len(errmsg) > 1:
                errmsg += ','
            errmsg += str(err)
        errmsg += ']'
        return errmsg


    def requestRejectionErrorsToDict(self):
        errs = []
        for err in self.requestRejectionErrors:
            errs.append(err.toDict())
        return errs
    
    
    def hasDuns(self):
        return False