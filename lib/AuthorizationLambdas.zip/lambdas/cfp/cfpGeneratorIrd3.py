'''
Created on Jun 26, 2020

@author: VanCampK
'''
import datetime
import logging

from common.util.dictUtils import generateFixedFormatFromDict
from lambdas.cfp.cfpUtil import mapBatchTypeToIrdProcessId, generateIrdErrorRec, transformCfpFilePrefixForStatFile


class CfpGeneratorIrd3(object):
    '''
    Generates IRD3 flow response files
    '''
    IRD3_OK_CFG_ROW_1 = [
        {'keyword': {'start': 1, 'end': 6}},
        {'custAgn': {'start': 7, 'end': 16}},
        {'irdProcessId': {'start': 17, 'end': 19}},
        {'batchAgn': {'start': 20, 'end': 29}}
    ]
    IRD3_OK_CFG_ROW_2 = [
        {'keyword': {'start': 1, 'end': 6}},
        {'recordsSent': {'start': 7, 'end': 16}},
        {'recordsLoaded': {'start': 17, 'end': 26}},
        {'recordsRejected': {'start': 27, 'end': 36}},
    ]
    IRD3_OK_CFG_ROW_3 = [
        {'keyword': {'start': 1, 'end': 6}},
        {'batchStat': {'start': 7, 'end': 9}}
    ]
    IRD3_ERR_CFG = [
        {'errorCode': {'start': 1, 'end': 9}},
        {'errorMessage': {'start': 10, 'end': 126}}
    ]


    def __init__(self):
        pass
    
    
    def generateIrd3OkFile(self, requestContext, cfpRecord):
        okRec1 = {
            'keyword': 'LOADED',
            'custAgn': cfpRecord.batchRecord.customerAgn,
            'irdProcessId': mapBatchTypeToIrdProcessId(cfpRecord.batchRecord.batchType),
            'batchAgn': int(cfpRecord.batchRecord.batchRequestId)
        }
        okRec2 = {
            'keyword': 'TOTALS',
            'recordsSent': cfpRecord.batchRecord.batchAttributes["cfpEntriesCount"],
            'recordsLoaded': cfpRecord.batchRecord.totalEntriesCount - cfpRecord.batchRecord.rejectedEntriesCount,
            'recordsRejected': cfpRecord.batchRecord.rejectedEntriesCount
        }
        okRec3 = {
            'keyword': 'STATUS',
            'batchStat': '1'
        }

        logging.info(f"generateIrd3OkFile: Writing to local file {cfpRecord.localFileName}")
        with open(cfpRecord.localFileName, "w") as fp:
            line1 = generateFixedFormatFromDict(okRec1, CfpGeneratorIrd3.IRD3_OK_CFG_ROW_1)
            fp.write(line1 + "\n")
            line2 = generateFixedFormatFromDict(okRec2, CfpGeneratorIrd3.IRD3_OK_CFG_ROW_2)
            fp.write(line2 + "\n")
            line3 = generateFixedFormatFromDict(okRec3, CfpGeneratorIrd3.IRD3_OK_CFG_ROW_3)
            fp.write(line3 + "\n")
    
    
    def generateIrd3ErrorFile(self, requestContext, cfpRecord):
        errRec = generateIrdErrorRec(cfpRecord)

        logging.info(f"generateIrd3ErrorFile: Writing to local file {cfpRecord.localFileName}")
        with open(cfpRecord.localFileName, "w") as fp:
            line1 = generateFixedFormatFromDict(errRec, CfpGeneratorIrd3.IRD3_ERR_CFG)
            fp.write(line1 + "\n")
    
    
    def generateIrd3StatFile(self, requestContext, cfpRecord):
        logging.info(f"generateIrd3StatFile: Writing to local file {cfpRecord.localFileName}")
        DATE_FORMAT = "%m/%d/%y"
        TIME_FORMAT = "%H:%M:%S"
        currDateTime = datetime.datetime.now()
        dateStr = currDateTime.strftime(DATE_FORMAT)
        timeStr = currDateTime.strftime(TIME_FORMAT)
        cfpStatFilePrefix = transformCfpFilePrefixForStatFile(cfpRecord)
        successErrInd = f"ABEND~0~" if cfpRecord.isRejected() else f"END~{cfpRecord.batchRecord.batchRequestId}~"

        with open(cfpRecord.localFileName, "w") as fp:
            line1 = f"FPCREQUEST|IRDSENDPROCESS|GIRD00|00|{cfpStatFilePrefix}|{dateStr}|{timeStr}|0~|{successErrInd}|||"
            fp.write(line1 + "\n")
