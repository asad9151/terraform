'''
Created on Jul 8, 2020

@author: VanCampK
'''
from common.dao.batchRequestDao import BatchRequestDao
from common import envVblNames
from lambdas.submitcaseapi.submitCaseApiSubmissionService import SubmitCaseApiSubmissionService


class CfpSubmissionService(object):


    def __init__(self, dbConn):
        self.dbConn = dbConn
        self.batchRequestDao = None
        self.submitCaseApiSubmissionService = None

    
    def submitBatch(self, requestContext, cfpRecord):
        # Submits all requests in a batch to BatchDetail service queue
        if self.batchRequestDao is None:
            self.batchRequestDao = BatchRequestDao()
        if self.submitCaseApiSubmissionService is None:
            self.submitCaseApiSubmissionService = SubmitCaseApiSubmissionService(None, self.dbConn, self.batchRequestDao)
        cfpRecord.batchRecord.totalDetailsCount = len(cfpRecord.batchRecord.requestRecords)
        cfpParserQueueUrl = requestContext.environDict[envVblNames.ENV_CFPPARSER_QUEUE_URL]
        self.submitCaseApiSubmissionService.submitAllBatchDetailRequests(requestContext, cfpRecord.batchRecord, cfpParserQueueUrl, fileTrackingId=cfpRecord.stpPartnerDeliveryFile.fileTrackingId)
        # TODO if all reqeusts rejected, then directly notify response generator (or BWS?) that batch is complete/rejected (see submitCaseApiSubmissionService._notifyBatchWatchSubmissionComplete)