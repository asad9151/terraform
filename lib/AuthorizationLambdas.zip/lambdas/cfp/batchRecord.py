'''
Created on Jun 22, 2020

@author: VanCampK
'''
import json

class BatchRecord(object):

        
    def __init__(self):
        self.batchRequestId = None
        self.batchFormatCode = None
        self.processingStatusCode = None        # BatchStatusCode
        self.statusTimestamp = None             # Time of last status change
        self.batchRejectReasonComment = None    # Only used whan administrator rejects the reason
        self.batchRejectionErrorText = None     # Used when service rejects batch
        self.totalEntriesCount = 0              # Total number of submitted or rejected requests
        self.totalDetailsCount = 0              # Total number of detail records (original records from user before combining)
        self.rejectedEntriesCount = 0           # Number of records in the batch that were rejected
        self.sessionToken = None
        self.userId = None
        self.authPrinIdObj = None
        self.dueTimestamp = None
        self.batchType = None                   # Format of batch input file
        self.customerName = None                # CFP customer name
        self.customerAgn = None                 # Internally assigned AGN
        self.cfpStatusCode = None
        self.batchAttributes = None             # Misc attributes of a batch, e.g. cfpFolderName and lookupRules
        self.requestRecords = []                # Array of RequestRecord
        self.isParseInProgress = False          # Used internally to track current state of parsing
        
        
    def __str__(self):
        return 'Batch Record batchRequestId=' + str(self.batchRequestId) + \
            ' batchFormatCode=' + str(self.batchFormatCode) + \
            ' processingStatusCode=' + str(self.processingStatusCode) + \
            ' batchRejectReasonComment=' + str(self.batchRejectReasonComment) + \
            ' batchRejectionErrorText=' + str(self.batchRejectionErrorText) + \
            ' totalEntriesCount=' + str(self.totalEntriesCount) + \
            ' totalDetailsCount=' + str(self.totalDetailsCount) + \
            ' rejectedEntriesCount=' + str(self.rejectedEntriesCount) + \
            ' sessionToken=' + str(self.sessionToken) + \
            ' userId=' + str(self.userId) + \
            ' authPrinIdObj=' + str(self.authPrinIdObj) + \
            ' batchType=' + str(self.batchType) + \
            ' dueTimestamp=' + str(self.dueTimestamp) + \
            ' customerName=' + str(self.customerName) + \
            ' customerAgn=' + str(self.customerAgn) + \
            ' cfpStatusCode=' + str(self.cfpStatusCode) + \
            ' batchAttributes=' + str(self.batchAttributes) + \
            ' isParseInProgress=' + str(self.isParseInProgress) + \
            ' with ' + str(len(self.requestRecords)) + ' requestRecords'
    
    
    def mapFromDict(self, d):
        self.batchRequestId = d.get("btch_reqs_id")
        self.batchFormatCode = d.get("btch_frmt_cd")
        self.processingStatusCode = d.get("prcs_stat_cd")
        self.batchRejectReasonComment = d.get("btch_rej_reas_cmnt")
        self.batchRejectionErrorText = d.get("btch_rej_err_txt")
        self.totalEntriesCount = d.get("tot_entr_cnt")
        self.totalDetailsCount = d.get("tot_detl_cnt")
        self.rejectedEntriesCount = d.get("rej_entr_cnt")
        self.sessionToken = d.get("dnb_jti_val")
        self.userId = d.get("rsch_usr_id")
        self.batchType = d.get("btch_typ")
        self.dueTimestamp = d.get("due_date")
        self.statusTimestamp = d.get("stat_tmst")
        self.authPrinIdObj = d.get("auth_prin_id_obj")
        self.customerName = d.get("cust_nme")
        self.cfpStatusCode = d.get("cfp_stat_cd")
        self.customerAgn = d.get("cust_agn")
        batchAttributesStr = d.get("btch_reqs_obj")
        if batchAttributesStr is not None and isinstance(batchAttributesStr, str):
            self.batchAttributes = json.loads(batchAttributesStr)
        elif batchAttributesStr is not None and isinstance(batchAttributesStr, dict):
            self.batchAttributes = batchAttributesStr
        else:
            self.batchAttributes = None
            