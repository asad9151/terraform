'''
Possible authorized roles for IResearch project users.
This is the combined set of roles administered within both iResearch and IDaaS.
If a new role is added which is administered within iResearch, also add it to IResearchAdministeredRole.

@author: VanCampK
'''
from enum import Enum

class CfpStepName(Enum):
    IRD1 = "IRD1"
    IRD3 = "IRD3"
    IRD4 = "IRD4"
    
    @classmethod
    def hasValue(cls, value):
        return any(value == item.value for item in cls)
