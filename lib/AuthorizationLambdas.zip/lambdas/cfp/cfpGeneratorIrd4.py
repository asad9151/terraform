'''
Created on Jun 26, 2020

@author: VanCampK
'''
import datetime
import jmespath
import logging
import os

from common.dao.geoValidationDao import GeoValidationDao
from common.excelReader import ExcelReader
from common.util.dictUtils import generateFixedFormatFromDict
from common.util.stringUtils import isBlank, isNotBlank, defaultEmptyStr, intDefaultNone
from lambdas.cfp.cfpUtil import replaceFileExtension, parseCfpRequestKey, transformCfpFilePrefixForStatFile
from lambdas import lambdaConstants
from lambdas.exceptions import LambdaConflictException
from lambdas.retrieveInitialData.geoCodeTypeCodes import GeoCodeTypeCode
from lambdas.retrieveInitialData.geoUnitTypeCodes import GeoUnitTypeCode


class CfpGeneratorIrd4(object):
    '''
    Generates IRD4 flow response files
    '''
    countryWbMap = {}
    MIN_COUNTRIES = 2
    REQUEST_CANCELLED_IRD_RESOLUTION_CODE = 299     # Use this IRD code when batch rejected by admin
    NO_INVESTIGATION_COVERAGE_IN_COUNTRY_IRD_RESOLUTION_CODE = 270  # Use this IRD code when request failed to submit
    
    
    IRD4_XTR_CFG_ROW_1 = [
        {'empty': {'start': 1, 'end': 17}},
        {'ird_batch_agn': {'start': 18, 'end': 23}},
        {'ird_audit': {'start': 24, 'end': 24}},
        {'ird_extract_type': {'start': 25, 'end': 25}},
        {'ird_extract_date': {'start': 25, 'end': 35}},
        {'batch_status_update': {'start': 36, 'end': 36}},
        {'ird_format_type': {'start': 37, 'end': 37}},
        {'db_option': {'start': 38, 'end': 38}},
        {'extract_data': {'start': 39, 'end': 75}}
    ]
    
    IRD4_XOK_CFG = [
        {'keyword': {'start': 1, 'end': 6}},
        {'irdstatus': {'start': 7, 'end': 9}},
        {'batch_agn': {'start': 10, 'end': 19}},
        {'ird_tot_extr': {'start': 20, 'end': 28}},
        {'ird_orig_cnt': {'start': 29, 'end': 37}},
        {'ird_accept_lvl': {'start': 38, 'end': 40}},
        {'ird_batch_status': {'start': 41, 'end': 43}}
    ]

    IRD4_ERR_CFG = [
        {'errorCode': {'start': 1, 'end': 9}},
        {'errorMessage': {'start': 10, 'end': 126}}
    ]


    def __init__(self, dbConn):
        self.dbConn = dbConn
        self.resolutionsMappingCache = None # Maps key "resolutionCode:subResolutionCode" to GIRD-code
        self.excelReader = None
        self.geoValidationDao = None
    
    
    def generateIrd4XtrFile(self, requestContext, cfpRecord, outboundFileName):
        xtrRec1 = {
            'empty': '',
            'ird_batch_agn': int(cfpRecord.batchRecord.batchRequestId),
            'ird_audit': 0,
            'ird_extract_type': 'F',     # Full (as opposed to I = Trickle-back incrementally)
            'ird_extract_date': '',
            'batch_status_update': 0,
            'ird_format_type': 1,
            'db_option': 'I',
            'extract_data': replaceFileExtension(outboundFileName, "DAT")
        }

        logging.info(f"generateIrd4XtrFile: Writing to local file {cfpRecord.localFileName}")
        with open(cfpRecord.localFileName, "w") as fp:
            line1 = generateFixedFormatFromDict(xtrRec1, CfpGeneratorIrd4.IRD4_XTR_CFG_ROW_1)
            fp.write(line1 + "\n")
    
    
    def generateIrd4DatFile(self, requestContext, cfpRecord):
        self._loadResolutionsMappingCache()
        self._buildcountryWbMap()
            
        logging.info(f"generateIrd4DatFile: Writing to local file {cfpRecord.localFileName}")
        with open(cfpRecord.localFileName, "w") as fp:
            recNo = 0
            for rr in cfpRecord.batchRecord.requestRecords:
                recNo += 1
                try:
                    intRefDict = parseCfpRequestKey(rr.originalRecord.get("requestorOwnRequestKey"))
                    flds = [
                        str(cfpRecord.batchRecord.batchRequestId),                                                      # ird_batch_agn
                        cfpRecord.batchRecord.customerName,                                                             # cust_name
                        defaultEmptyStr(intRefDict.get("accountNumb")),                                                 # ACCOUNT-NUMB
                        "D",                                                                                            # Indicator
                        defaultEmptyStr(self._getDuns(rr)),                                                             # DUNS
                        defaultEmptyStr(self._getResearchResultOrSubmittedDataField(rr, "organizationName")),           # NAME
                        defaultEmptyStr(self._getResearchResultOrSubmittedDataField(rr, "addresses[0].streetAddress")), # PHY-ADD
                        "",                                                                                             # TBD
                        defaultEmptyStr(self._getResearchResultOrSubmittedDataField(rr, "addresses[0].town")),          # CITY
                        defaultEmptyStr(self._getResearchResultOrSubmittedDataField(rr, "addresses[0].territory")),     # ST
                        defaultEmptyStr(self._convertCountry(self._getResearchResultOrSubmittedDataField(rr, "countryCode"))),  # COUNTRY-CODE
                        defaultEmptyStr(self._getResearchResultOrSubmittedDataField(rr, "addresses[0].postalCode")),    # ZIP
                        defaultEmptyStr(self._getResearchResultOrSubmittedDataField(rr, "organizationPhones[0].telephone")), # PHONE
                        "",                                                                                             # TBD
                        "",                                                                                             # TBD
                        defaultEmptyStr(self._getResolutionStatus(rr)),                                                 # TStatus
                        defaultEmptyStr(intDefaultNone(intRefDict.get("sequenceNo"))),                                  # Sequence (without leading zeros)
                        "",                                                                                             # MATCH-GRADE
                        "",                                                                                             # TBD
                        ""                                                                                              # TBD
                    ]
                    logging.info(f"Create IRD4.DAT record from {flds}")
                    line = "~".join(flds)
                    fp.write(line + "\n")
                except Exception as e:
                    logging.error(f"generateIrd4DatFile: Caught exception {e} from recNo={recNo}, skipping output of this record")
    
    
    def _getDuns(self, rr):
        if rr.researchResultRecord is None:
            return None
        else:
            return rr.researchResultRecord.get("duns")
        
        
    def _getResearchResultOrSubmittedDataField(self, rr, fldName):
        # This function implements common logic for fields that follow the business rule:
        #   Take researchResult.fldName first, OR:
        #   Take submittedData.fldName if researchResult.duns is populated or if a negative resolution status is returned.
        resolutionStatus = self._getResolutionStatus(rr)
        isNegativeResolution = True if resolutionStatus.startswith('2') else False
        hasDuns = False if isBlank(self._getDuns(rr)) else True
        
        if rr.researchResultRecord is not None and isNotBlank(jmespath.search(fldName, rr.researchResultRecord)):
            return jmespath.search(fldName, rr.researchResultRecord)
        if hasDuns or isNegativeResolution:
            return jmespath.search("submittedData."+fldName, rr.subjectResearchRecord)
        return None


    def _getResolutionStatus(self, rr):
        if rr.isRejected() == True:
            logging.warning(f"_getResolutionStatus isRejected so using error status {CfpGeneratorIrd4.NO_INVESTIGATION_COVERAGE_IN_COUNTRY_IRD_RESOLUTION_CODE}")
            return str(CfpGeneratorIrd4.NO_INVESTIGATION_COVERAGE_IN_COUNTRY_IRD_RESOLUTION_CODE)
        resolutionCode = jmespath.search("researchTypes[0].resolutionCode", rr.subjectResearchRecord)
        subResolutionCode = jmespath.search("researchTypes[0].subResolutionCode", rr.subjectResearchRecord)
        if resolutionCode is None or subResolutionCode is None:
            # Only reason to be here with no resolution codes is because batch was rejected by admin, so use special rejection code
            logging.warning(f"_getResolutionStatus no resolution/subresolution code so using cancelled status {CfpGeneratorIrd4.REQUEST_CANCELLED_IRD_RESOLUTION_CODE}")
            return str(CfpGeneratorIrd4.REQUEST_CANCELLED_IRD_RESOLUTION_CODE)
        else:
            ky = f"{resolutionCode}:{subResolutionCode}"
        irdCode = self.resolutionsMappingCache.get(ky)
        if isNotBlank(irdCode):
            return str(irdCode)
        # Code not mapped, get default
        irdCode = self.resolutionsMappingCache.get("OTHER:OTHER")
        logging.warning(f"_getResolutionStatus could not find IRD code for resolutionCode={resolutionCode} subResolutionCode={subResolutionCode} so using default {irdCode}")
        return str(irdCode)
    
    
    def generateIrd4XokFile(self, requestContext, cfpRecord, isDomestic):
        okRec1 = {
            'keyword': 'EXTRCT',
            'irdstatus': '000',
            'batch_agn': int(cfpRecord.batchRecord.batchRequestId),
            'ird_tot_extr': len(cfpRecord.batchRecord.requestRecords),
            'ird_orig_cnt': len(cfpRecord.batchRecord.requestRecords),
            'ird_accept_lvl': '100',
            'ird_batch_status': '040' if isDomestic else '050'
        }

        logging.info(f"generateIrd4XokFile: Writing to local file {cfpRecord.localFileName}")
        with open(cfpRecord.localFileName, "w") as fp:
            line1 = generateFixedFormatFromDict(okRec1, CfpGeneratorIrd4.IRD4_XOK_CFG)
            fp.write(line1 + "\n")
    
    
    def generateIrd4StatFile(self, requestContext, cfpRecord):
        logging.info(f"generateIrd4StatFile: Writing to local file {cfpRecord.localFileName}")
        DATE_FORMAT = "%m/%d/%y"
        TIME_FORMAT = "%H:%M:%S"
        currDateTime = datetime.datetime.now()
        dateStr = currDateTime.strftime(DATE_FORMAT)
        timeStr = currDateTime.strftime(TIME_FORMAT)
        cfpStatFilePrefix = transformCfpFilePrefixForStatFile(cfpRecord)
        successErrInd = f"ABEND~0~" if cfpRecord.isRejected() else f"END~{cfpRecord.batchRecord.batchRequestId}~"

        with open(cfpRecord.localFileName, "w") as fp:
            line1 = f"FPCREQUEST|IRDENDPROCESS|GIRD00|00|{cfpStatFilePrefix}|{dateStr}|{timeStr}|0~|{successErrInd}|||"
            fp.write(line1 + "\n")


    def _loadResolutionsMappingCache(self):
        if self.resolutionsMappingCache is not None:
            return
        if self.excelReader is None:
            self.excelReader = ExcelReader()
            
        filePathForResolutions = lambdaConstants.IRESEARCH_TO_GIRD_RESOLUTIONS_XWALK_CFG
        currentPathOfFile = os.path.abspath(os.path.dirname(__file__))
        resolutionCsvPath = os.path.join(currentPathOfFile, filePathForResolutions)
        logging.info(f"Loading the resolution crosswalk from this path: {resolutionCsvPath}")

        records = self.excelReader.readCsvAsJson(resolutionCsvPath)
        logging.info(f"Loaded {len(records)} records from config: {resolutionCsvPath}")
        self.resolutionsMappingCache = {}
        for record in records:
            resolutionCode = record.get("Resolution Code")
            subResolutionCode = record.get("Sub Resolution Code")
            irdCode = record.get("IRD Code")
            #if resolutionCode == "OTHER" and subResolutionCode == "OTHER": default value
            ky = f"{resolutionCode}:{subResolutionCode}"
            self.resolutionsMappingCache[ky] = irdCode
        

    def _buildcountryWbMap(self):
        # Builds a map from ISO 2-ALpha countryCode to WorldBase country code
        if CfpGeneratorIrd4.countryWbMap is not None and len(CfpGeneratorIrd4.countryWbMap) >= CfpGeneratorIrd4.MIN_COUNTRIES:
            return
        if self.geoValidationDao is None:
            self.geoValidationDao = GeoValidationDao()
        # First build a temporary map from geoUnitId to iso2Alpha
        iso2Alphas = self.geoValidationDao.queryCountryCodes(self.dbConn, GeoUnitTypeCode.GEO_UNIT_TYPE_CODE_COUNTRY.value, GeoCodeTypeCode.GEO_CODE_TYPE_CODE_ISO2ALPHA.value)
        geoUnit2Iso2Alpha = {}
        if type(iso2Alphas) is list:
            for iso2Alpha in iso2Alphas:
                geoUnitId = iso2Alpha["geo_unit_id"]
                isoCode = iso2Alpha["countryCode"]
                #print(f" geoUnitId={geoUnitId} isoCode={isoCode}")
                geoUnit2Iso2Alpha[geoUnitId] = isoCode
        # Then build the real map from Iso2Alpha countryCode to WB countryCode
        wbCountries = self.geoValidationDao.queryCountryCodes(self.dbConn, GeoUnitTypeCode.GEO_UNIT_TYPE_CODE_COUNTRY.value, GeoCodeTypeCode.GEO_CODE_TYPE_CODE_WORLDBASE.value)
        usWbCountry = None
        if type(wbCountries) is list and len(geoUnit2Iso2Alpha) > 0:
            CfpGeneratorIrd4.countryWbMap = {}
            for wbCountry in wbCountries:
                geoUnitId = wbCountry["geo_unit_id"]
                wbCountryCode = wbCountry["countryCode"]
                #print(f" geoUnitId={geoUnitId} wbCountryCode={wbCountryCode}")
                isoCode = geoUnit2Iso2Alpha.get(geoUnitId)
                if isoCode is not None:
                    CfpGeneratorIrd4.countryWbMap[isoCode] = wbCountryCode
                    if isoCode == 'US':
                        usWbCountry = wbCountryCode
                    #print(f"{isoCode} {wbCountryCode}")
            if len(CfpGeneratorIrd4.countryWbMap) < CfpGeneratorIrd4.MIN_COUNTRIES or usWbCountry is None:
                logging.error("Failed to load countryWbMap: len={len(CfpGeneratorIrd4.countryWbMap)} usWbCountry={usWbCountry}")
                raise LambdaConflictException("Failed to load countryWbMap")
            # Special case because WB code 785 actually maps to territory 'England'
            CfpGeneratorIrd4.countryWbMap['GB'] = '785'
            # Special case VI/PR should map to US
            CfpGeneratorIrd4.countryWbMap['VI'] = usWbCountry
            CfpGeneratorIrd4.countryWbMap['PR'] = usWbCountry
        else:
            logging.error(f"Failed to load countryWbMap: iso2Alphas={iso2Alphas} wbCountries={wbCountries}")
            raise LambdaConflictException("Failed to load countryWbMap")


    def _convertCountry(self, countryCode):
        return CfpGeneratorIrd4.countryWbMap.get(countryCode)