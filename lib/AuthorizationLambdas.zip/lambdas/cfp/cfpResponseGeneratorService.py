'''
Created on Jun 17, 2020

@author: VanCampK
'''
import json
import logging
import os

from common import envVblNames
from common.batchStatusCodes import BatchStatusCode
from common.cfpStatusCodes import CfpStatusCode
from common.dao.batchRequestDao import BatchRequestDao
from common.dao.fileTrackingDao import FileTrackingDao
from common.dao.partnerDetailDao import PartnerDetailDao
from common.dao.updateEventDao import UpdateEventDao
from common.model.stpDeliveryFile import StpDeliveryFile
from common.model.stpPartnerDeliveryFile import StpPartnerDeliveryFile
from common.partnerFileType import PartnerFileType
from common.processResultCodes import ProcessResultCode
from common.processStatusCodes import ProcessStatusCode
from common.rejectionReasonCodes import RejectionReasonCode
from common import updateEventConstants
from common.updateActionCodes import UpdateActionCode
from common.util.s3Helper import S3Helper

from lambdas.cfp.batchRecord import BatchRecord
from lambdas.cfp.cfpDao import CfpDao
from lambdas.cfp.cfpGeneratorIrd1 import CfpGeneratorIrd1
from lambdas.cfp.cfpGeneratorIrd3 import CfpGeneratorIrd3
from lambdas.cfp.cfpGeneratorIrd4 import CfpGeneratorIrd4
from lambdas.cfp.cfpRecord import CfpRecord
from lambdas.cfp.cfpStepName import CfpStepName
from lambdas.cfp.cfpUtil import replaceFileExtension, mapCfpStatusCodeToCfpStepName, parseCfpFilename, postCfpResponseGeneratorRequest, calcCfpResponseCloseMsgDelay
from lambdas.cfp.requestRecord import RequestRecord
from lambdas.exceptions import LambdaConflictException
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.stpdelivery.stpDeliveryIndicator import StpDeliveryIndicator


class CfpResponseGeneratorService(object):
    '''
    Service to generate the outgoing response files to a CFP request file
    '''
    APP_MODULE_NM = "CfpResponseGeneratorService"


    def __init__(self, dbConn, cfpResponseGeneratorSqsHelper):
        self.dbConn = dbConn
        self.cfpResponseGeneratorSqsHelper = cfpResponseGeneratorSqsHelper
        self.cfpDao = None
        self.batchRequestDao = None
        self.cfpGeneratorIrd1 = None
        self.cfpGeneratorIrd3 = None
        self.cfpGeneratorIrd4 = None
        self.s3Helper = None
        self.fileTrackingDao = None
        self.partnerDetailDao = None
        self.updateEventDao = None
        
        
    def processCfpResponseRequest(self, requestContext, fileTrackingId, batchRequestId, startingRecordNumber):
        self._createServices(requestContext)
        if fileTrackingId is not None:
            stpPartnerDeliveryFile = self.fileTrackingDao.queryPartnerFileByTrackingId(self.dbConn, fileTrackingId)
        elif batchRequestId is not None:
            stpPartnerDeliveryFile = self.fileTrackingDao.queryPartnerFileByBatchRequestIdAndFileType(self.dbConn, StpDeliveryFile.STP_DELIVERY_INBOUND, batchRequestId, PartnerFileType.CFP_REQUEST.value["fileTypeCode"])
            
        if stpPartnerDeliveryFile is None:
            errmsg = f"Unknown fileTrackingId={fileTrackingId} or batchRequestId={batchRequestId}"
            logging.error(errmsg)
            raise LambdaConflictException(errmsg)
        cfpRecord = CfpRecord(stpPartnerDeliveryFile, startingRecordNumber)
        try:
            self._processCfpResponseRequestImpl(requestContext, cfpRecord)
        except Exception as e:
            logging.error(f"Uncaught exception, passing on so message is retried: {e}")
            raise e
    
    
    def _createServices(self, requestContext):
        if self.cfpDao is None:
            self.cfpDao = CfpDao()
        if self.batchRequestDao is None:
            self.batchRequestDao = BatchRequestDao()
        if self.cfpGeneratorIrd1 is None:
            self.cfpGeneratorIrd1 = CfpGeneratorIrd1()
        if self.cfpGeneratorIrd3 is None:
            self.cfpGeneratorIrd3 = CfpGeneratorIrd3()
        if self.cfpGeneratorIrd4 is None:
            self.cfpGeneratorIrd4 = CfpGeneratorIrd4(self.dbConn)
        if self.fileTrackingDao is None:
            self.fileTrackingDao = FileTrackingDao()
        if self.partnerDetailDao is None:
            self.partnerDetailDao = PartnerDetailDao()
        if self.updateEventDao is None:
            self.updateEventDao = UpdateEventDao()
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
    
    
    def _processCfpResponseRequestImpl(self, requestContext, cfpRecord):
        parseCfpFilename(cfpRecord)
        self._readBatchRecord(requestContext, cfpRecord)
        localFileName = S3Helper.LOCAL_DIRECTORY + cfpRecord.stpPartnerDeliveryFile.s3Object.fileName
        try:
            os.mkdir(S3Helper.LOCAL_DIRECTORY)
            logging.info(f"_processCfpResponseRequestImpl: made local directory")
        except Exception:
            # eat exception, /tmp usually already exists
            #logging.warning(f"_processCfpResponseRequestImpl: Failed to make local directory (but OK): {e}")
            pass
            
        cfpRecord.cfpStepName = mapCfpStatusCodeToCfpStepName(cfpRecord.batchRecord.cfpStatusCode)
        if cfpRecord.cfpStepName == CfpStepName.IRD1.name:
            self._processIrd1CfpResponse(requestContext, cfpRecord, CfpStatusCode.IRD1_RESPONDED.value, localFileName)
        elif cfpRecord.cfpStepName == CfpStepName.IRD3.name:
            if (cfpRecord.batchRecord.cfpStatusCode == CfpStatusCode.IRD3_DAT_RESPONDED.value
                    and cfpRecord.batchRecord.processingStatusCode in (BatchStatusCode.COMPLETED.value, BatchStatusCode.CANCEL_IN_PROGRESS.value, BatchStatusCode.CANCELLED.value, BatchStatusCode.APPROVER_REJECTED.value)):
                self._processIrd4CfpResponse(requestContext, cfpRecord, CfpStatusCode.IRD4_DAT_RESPONDED.value, localFileName)
            else:
                self._processIrd3CfpResponse(requestContext, cfpRecord, CfpStatusCode.IRD3_DAT_RESPONDED.value, localFileName)
                if cfpRecord.batchRecord.processingStatusCode == BatchStatusCode.APPROVER_REJECTED.value:
                    self._notifyCfpResponseGenerator(requestContext, cfpRecord)
                    
        elif cfpRecord.batchRecord.cfpStatusCode == CfpStatusCode.IRD4_DAT_RESPONDED.value:
            raise LambdaConflictException(f"Attempt to reprocess IRD4 for batchRequestId={cfpRecord.batchRecord.batchRequestId}")
        else:
            # Query batch record
            raise NotImplementedError(f"Step {cfpRecord.cfpStepName} not supported")
        
    
    def _readBatchRecord(self, requestContext, cfpRecord):
        if cfpRecord.stpPartnerDeliveryFile.batchRequestId is None:
            errmsg = f"_readBatchRecord Can't handle fileTrackingId={cfpRecord.stpPartnerDeliveryFile.fileTrackingId} because no batchRequestId"
            logging.error(errmsg)
            raise LambdaConflictException(errmsg)
        else:
            logging.info(f"_readBatchRecord reading existing batchRequestId={cfpRecord.stpPartnerDeliveryFile.batchRequestId}")
            dict_rslt = self.cfpDao.queryCfpBatchRecord(self.dbConn, cfpRecord.stpPartnerDeliveryFile.batchRequestId)
            if dict_rslt is None:
                logging.error(f"Failed to read batchRequestId={cfpRecord.stpPartnerDeliveryFile.batchRequestId}")
                raise LambdaConflictException(f"Failed to read batchRequestId={cfpRecord.stpPartnerDeliveryFile.batchRequestId}")
            cfpRecord.batchRecord = BatchRecord()
            cfpRecord.batchRecord.mapFromDict(dict_rslt)
            logging.info(f"Got batchRecord={cfpRecord.batchRecord}")


    def _nameOutboundFileFromInboundFile(self, cfpRecord, fileExtension):
        return replaceFileExtension(cfpRecord.stpPartnerDeliveryFile.s3Object.fileName[cfpRecord.stpPartnerDeliveryFile.s3Object.fileName.find('FPC'):], fileExtension)
       
        
    def _deliverToStp(self, requestContext, cfpRecord, outboundFileName, isDeliverCfp):
        '''
        Delivers an outgoing file via SFTP-S3 service
        '''
        self._createOutgoingStpPartnerDeliveryFile(requestContext, cfpRecord, os.path.getsize(cfpRecord.localFileName), outboundFileName, isDeliverCfp)
        logging.info(f"Copying {cfpRecord.localFileName} to s3 {cfpRecord.outgoingStpPartnerDeliveryFile.s3Object}")
        self._insertFileTrackingRecords(requestContext, cfpRecord)
        self.s3Helper.copyFromLocalToS3(cfpRecord.localFileName, cfpRecord.outgoingStpPartnerDeliveryFile.s3Object)
        os.remove(cfpRecord.localFileName)
        
        
    def _createOutgoingStpPartnerDeliveryFile(self, requestContext, cfpRecord, outboundFileSize, outboundFileName, isDeliverCfp):
        spdf = StpPartnerDeliveryFile(cfpRecord.stpPartnerDeliveryFile)
        spdf.fileTrackingId = None
        spdf.partnerFileTrackingId = None
        spdf.inboundOutboundIndicator = StpDeliveryFile.STP_DELIVERY_OUTBOUND
        if isDeliverCfp:
            spdf.stpDeliveryIndicator = StpDeliveryIndicator.CFP.value
        else:
            spdf.stpDeliveryIndicator = StpDeliveryIndicator.SFTP_S3.value
        inbounds3 = cfpRecord.stpPartnerDeliveryFile.s3Object
        outboundFolder = self._getS3DeliveryFolder(isDeliverCfp)
        if isDeliverCfp:
            #s3://irsch-d1-datastores/cfp-sftp-outbound/dnbusr1/fpcuser/mftincomingreq/Global/FPC.IMMANTES.A1102220.TR055B.IRD1.STAT.cfp
            cfpSftpDirectory = requestContext.environDict.get(envVblNames.ENV_CFP_SFTP_DIRECTORY)
            spdf.relativeFolder = cfpSftpDirectory[1:] if cfpSftpDirectory[0] == '/' else cfpSftpDirectory
            s3ObjKey = f"s3://{inbounds3.bucket}/{outboundFolder}{cfpSftpDirectory}/{outboundFileName}"
        else:
            #s3://irsch-d1-datastores/sftp-outbound/CFPUserD2/Global/FPC.IMMANTES.A1102220.TR055B.IRD1.OK
            s3ObjKey = f"s3://{inbounds3.bucket}/{outboundFolder}/{cfpRecord.stpPartnerDeliveryFile.relativeFolder}/{outboundFileName}"
        spdf.s3Object.setS3ObjectKey(s3ObjKey)
        spdf.stpFileName = spdf.relativeFolder + "/" + spdf.s3Object.fileName
        spdf.s3Object.fileSize = outboundFileSize
        spdf.processStatusCode = ProcessStatusCode.FILE_RECEIVED.value
        spdf.processResultCode = ProcessResultCode.SUCCESSFUL.value
        spdf.lastDeliveryAttemptTime = None
        spdf.deliveryAttemptCount = 1
        spdf.fileTypeCode = PartnerFileType.CFP_RESPONSE.value["fileTypeCode"]
        spdf.recordCount = len(cfpRecord.batchRecord.requestRecords)
        spdf.attachmentCount = 0
        spdf.batchProcessStatusCode = BatchStatusCode.RECEIVED.value
        spdf.rejectRecordCount = 1 if cfpRecord.isRejected() else 0
        cfpRecord.outgoingStpPartnerDeliveryFile = spdf
    

    def _insertFileTrackingRecords(self, requestContext, cfpRecord):
        spdf = cfpRecord.outgoingStpPartnerDeliveryFile
        self.fileTrackingDao.insertFileTracking(self.dbConn, spdf, CfpResponseGeneratorService.APP_MODULE_NM, reuseIfDup=True)
        logging.info(f"_insertFileTrackingRecords: fileTrackingId={spdf.fileTrackingId}")
        self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_FILE_TRACKING_TABLE,
                                        spdf.fileTrackingId, updateEventConstants.AUDIT_ELEMENT_FILE_TRACKING_ID,
                                        spdf.s3Object.fileName, spdf.processStatusCode, UpdateActionCode.ADD.value, None,
                                        None, None, CfpResponseGeneratorService.APP_MODULE_NM)
        self.fileTrackingDao.insertPartnerFileTracking(self.dbConn, spdf, CfpResponseGeneratorService.APP_MODULE_NM, reuseIfDup=True)
        logging.info(f"_insertFileTrackingRecords Inserted partnerFileTrackingId={spdf.partnerFileTrackingId}")
        self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_PARTNER_FILE_TRACKING_TABLE,
                                        spdf.partnerFileTrackingId, updateEventConstants.AUDIT_ELEMENT_PARTNER_FILE_TRACKING_ID,
                                        spdf.s3Object.fileName, spdf.processStatusCode, UpdateActionCode.ADD.value, None,
                                        None, None, CfpResponseGeneratorService.APP_MODULE_NM)

    
    def _updateBatchRecord(self, requestContext, cfpRecord):
        self.cfpDao.updateCfpBatchRecord(self.dbConn, cfpRecord.batchRecord, requestContext, CfpResponseGeneratorService.APP_MODULE_NM)
        logging.info(f"_updateBatchRecord Updated batchRequestId={cfpRecord.batchRecord.batchRequestId} - calling updateKeywords...")
        self.batchRequestDao.updateKeywords(self.dbConn, cfpRecord.batchRecord.batchRequestId)
        logging.info(f"_updateBatchRecord Updated keywords for batchRequestId={cfpRecord.batchRecord.batchRequestId}")
        self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_BATCH_REQUEST_TABLE,
                                        cfpRecord.batchRecord.batchRequestId, updateEventConstants.AUDIT_ELEMENT_BATCH_CFP_STATUS,
                                        cfpRecord.batchRecord.cfpStatusCode, cfpRecord.batchRecord.processingStatusCode, UpdateActionCode.MODIFY.value, None,
                                        None, None, CfpResponseGeneratorService.APP_MODULE_NM)
        
        
    def _readBatchDetails(self, requestContext, cfpRecord):
        dict_arry = self.cfpDao.queryBatchDetailsAndRejects(self.dbConn, cfpRecord.batchRecord.batchRequestId)
        for rec in dict_arry:
            logging.debug(f"_readBatchDetails rec={rec}")
            rr = RequestRecord()
            isRejected = rec.get("rej_indc")
            
            if isRejected != 0:
                rr.batchRequestRejectId = rec.get("id")
                rejObjList = json.loads(rec.get("btch_rsch_reqs_rej_obj"))
                rr.addRejection(RequestRejectionError.fromDict(rejObjList[0]), RejectionReasonCode.VALIDATION_ERROR.value)
                rr.originalRecord = json.loads(rec.get("raw_data_obj")) if rec.get("raw_data_obj") is not None else None
            else:
                rr.originalRecord = json.loads(rec.get("raw_data_obj")) if rec.get("raw_data_obj") is not None else None
                rr.subjectResearchId = rec.get("subj_rsch_id")
                rr.linkTypeCode = rec.get("lnk_typ")
                rr.subjectResearchRecord = json.loads(rec.get("subj_rsch_obj")) if rec.get("subj_rsch_obj") is not None else None
                rr.researchResultRecord = json.loads(rec.get("rsch_rslt_obj")) if rec.get("rsch_rslt_obj") is not None else None
                
            cfpRecord.batchRecord.requestRecords.append(rr)
        
        
    def _processIrd1CfpResponse(self, requestContext, cfpRecord, cfpNextStatusCode, localFileName):
        if cfpRecord.isRejected():
            fileExtension = "ERR"
            cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
            self.cfpGeneratorIrd1.generateIrd1ErrorFile(requestContext, cfpRecord)
            cfpRecord.batchRecord.processingStatusCode = BatchStatusCode.REJECTED.value
        else:
            fileExtension = "OK"
            cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
            self.cfpGeneratorIrd1.generateIrd1OkFile(requestContext, cfpRecord)
            
        outboundFileName = self._nameOutboundFileFromInboundFile(cfpRecord, fileExtension)
        self._deliverToStp(requestContext, cfpRecord, outboundFileName, False)
        
        # Send STAT file last
        fileExtension = "STAT.cfp"
        cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
        self.cfpGeneratorIrd1.generateIrd1StatFile(requestContext, cfpRecord)
        outboundFileName = replaceFileExtension(outboundFileName, fileExtension)
        self._deliverToStp(requestContext, cfpRecord, outboundFileName, True)
        
        cfpRecord.batchRecord.cfpStatusCode = cfpNextStatusCode
        self._updateBatchRecord(requestContext, cfpRecord)
        
        
    def _processIrd3CfpResponse(self, requestContext, cfpRecord, cfpNextStatusCode, localFileName):
        self._readBatchDetails(requestContext, cfpRecord)
        if cfpRecord.isRejected():
            # This can be the result of either a failure on IRD3 HDR or DAT
            fileExtension = "ERR"
            cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
            self.cfpGeneratorIrd3.generateIrd3ErrorFile(requestContext, cfpRecord)
            cfpRecord.batchRecord.processingStatusCode = BatchStatusCode.REJECTED.value
        else:
            fileExtension = "OK"
            cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
            self.cfpGeneratorIrd3.generateIrd3OkFile(requestContext, cfpRecord)

        outboundFileName = self._nameOutboundFileFromInboundFile(cfpRecord, fileExtension)
        self._deliverToStp(requestContext, cfpRecord, outboundFileName, False)

        # Send STAT file last
        fileExtension = "STAT.cfp"
        cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
        self.cfpGeneratorIrd3.generateIrd3StatFile(requestContext, cfpRecord)
        outboundFileName = replaceFileExtension(outboundFileName, fileExtension)
        self._deliverToStp(requestContext, cfpRecord, outboundFileName, True)
        
        cfpRecord.batchRecord.cfpStatusCode = cfpNextStatusCode
        self._updateBatchRecord(requestContext, cfpRecord)
        
        
    def _processIrd4CfpResponse(self, requestContext, cfpRecord, cfpNextStatusCode, localFileName):
        isDomestic = self._getIsDomestic(cfpRecord)
        self._readBatchDetails(requestContext, cfpRecord)
        # Send XTR file first
        fileExtension = "XTR"
        localFileName = localFileName.replace(".IRD3", ".IRD4")
        cfpRecord.cfpFilePrefix = cfpRecord.cfpFilePrefix.replace(".IRD3", ".IRD4")
        cfpRecord.cfpStepName = CfpStepName.IRD4.name
        cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
        outboundFileName = self._nameOutboundFileFromInboundFile(cfpRecord, fileExtension).replace(".IRD3", ".IRD4")
        self.cfpGeneratorIrd4.generateIrd4XtrFile(requestContext, cfpRecord, outboundFileName)
        self._deliverToStp(requestContext, cfpRecord, outboundFileName, False)
        # Send DAT file next
        fileExtension = "DAT"
        cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
        self.cfpGeneratorIrd4.generateIrd4DatFile(requestContext, cfpRecord)
        outboundFileName = replaceFileExtension(outboundFileName, fileExtension)
        self._deliverToStp(requestContext, cfpRecord, outboundFileName, False)
        # Send XOK file next
        fileExtension = "XOK"
        cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
        self.cfpGeneratorIrd4.generateIrd4XokFile(requestContext, cfpRecord, isDomestic)
        outboundFileName = replaceFileExtension(outboundFileName, fileExtension)
        self._deliverToStp(requestContext, cfpRecord, outboundFileName, False)
        # Send STAT file last
        fileExtension = "STAT.cfp"
        cfpRecord.localFileName = replaceFileExtension(localFileName, fileExtension)
        self.cfpGeneratorIrd4.generateIrd4StatFile(requestContext, cfpRecord)
        outboundFileName = replaceFileExtension(outboundFileName, fileExtension)
        self._deliverToStp(requestContext, cfpRecord, outboundFileName, True)
        
        cfpRecord.batchRecord.cfpStatusCode = cfpNextStatusCode
        self._updateBatchRecord(requestContext, cfpRecord)
    
    
    def _notifyCfpResponseGenerator(self, requestContext, cfpRecord):
        logging.info(f"Admin rejected batch {cfpRecord.batchRecord.batchRequestId} so generating IRD4 too")
        delaySecs = calcCfpResponseCloseMsgDelay(requestContext)
        postCfpResponseGeneratorRequest(self.cfpResponseGeneratorSqsHelper, cfpRecord, CfpResponseGeneratorService.APP_MODULE_NM, delaySecs=delaySecs)


    def _getS3DeliveryFolder(self, isDeliverCfp):
        if isDeliverCfp:
            return "cfp-sftp-outbound"
        else:
            return "sftp-outbound"


    def _getIsDomestic(self, cfpRecord):
        if "Domestic" in cfpRecord.stpPartnerDeliveryFile.s3Object.folder:
            return True
        return False
    