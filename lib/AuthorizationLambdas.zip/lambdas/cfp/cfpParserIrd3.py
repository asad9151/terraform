'''
Created on Jun 22, 2020

@author: VanCampK
'''
import logging
import os

from common.rejectionReasonCodes import RejectionReasonCode
from common.util.dictUtils import parseFixedFormatAsDict
from common.util.s3Helper import S3Helper
from common.util.stringUtils import isBlank, intDefaultNone
from lambdas.cfp.requestRecord import RequestRecord
from lambdas.cfp.cfpUtil import isHeaderFile, updateBatchAttributes
from lambdas import errorMessages
from lambdas.exceptions import LambdaProcessingException
from lambdas.requestRejectionError import RequestRejectionError


class CfpParserIrd3(object):
    '''
    Parses the IRD-3 incoming HDR or DAT file from CFP
    '''
    #                                                                                                   1                                                                                                   2                                                                                                   3
    #....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0
    #                                                                                                                                   12491401100                   Global Match Rules: Custom-SMS Delivery Match- HQ BU050620444J   00402        I              
    IRD3_HDR_CFG = [
        {'empty1': {'start': 1, 'end': 131}},
        {'irdBatchAgn': {'start': 132, 'end': 137}},
        {'irdBatchType': {'start': 138, 'end': 139}},
        {'irdAcceptLvl': {'start': 140, 'end': 142}},
        {'dueDate': {'start': 143, 'end': 152}},
        {'empty2': {'start': 153, 'end': 153}},
        {'dueTime': {'start': 154, 'end': 161}},
        {'projDesc': {'start': 162, 'end': 211}},
        {'prjId': {'start': 212, 'end': 219}},
        {'tr': {'start': 220, 'end': 223}},
        {'empty3': {'start': 224, 'end': 226}},
        {'numRecs': {'start': 227, 'end': 231}},
        {'empty4': {'start': 232, 'end': 239}},
        {'dbOption': {'start': 240, 'end': 241}}
    ]

    #                                                                                                   1                                                                                                   2                                                                                                   3
    #....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0....v....1....v....2....v....3....v....4....v....5....v....6....v....7....v....8....v....9....v....0
    #00000000200000000000002           000000000A.M.A.T HAKLAUT LTD                                                                                                                                                                 HARISHONIM 9                                                                                                                    GIV AT ADA IS                                               37808    353                                                                            00000       00000000000000000000000000 N0000              
    IRD3_DAT_CFG = [
        {'sequenceNo': {'start': 1, 'end': 9}},
        {'candidateSeq': {'start': 10, 'end': 14}},
        {'accountNumb': {'start': 15, 'end': 34}},
        {'duns': {'start': 35, 'end': 43}},
        {'name': {'start': 44, 'end': 133}},
        {'tradeStyle': {'start': 134, 'end': 223}},
        {'phyAdd': {'start': 224, 'end': 287}},
        {'mailAdd': {'start': 288, 'end': 351}},
        {'city': {'start': 352, 'end': 381}},
        {'st': {'start': 382, 'end': 411}},
        {'zip': {'start': 412, 'end': 420}},
        {'countryCode': {'start': 421, 'end': 423}},
        {'mailCity': {'start': 424, 'end': 463}},
        {'mailSt': {'start': 464, 'end': 465}},
        {'mailZip': {'start': 466, 'end': 474}},
        {'phone': {'start': 475, 'end': 494}},
        {'matchCode': {'start': 495, 'end': 496}},
        {'dunsLocInd': {'start': 497, 'end': 497}},
        {'tradeStyleInd': {'start': 498, 'end': 498}},
        {'dunsSupportInd': {'start': 499, 'end': 499}},
        {'confCode': {'start': 500, 'end': 501}},
        {'accuracy': {'start': 502, 'end': 504}},
        {'matchGrade': {'start': 505, 'end': 511}},
        {'pgName': {'start': 512, 'end': 514}},
        {'pgStNum': {'start': 515, 'end': 517}},
        {'pgStName': {'start': 518, 'end': 520}},
        {'pgCity': {'start': 521, 'end': 523}},
        {'pgSt': {'start': 524, 'end': 526}},
        {'pgPoBox': {'start': 527, 'end': 529}},
        {'pgPhone': {'start': 530, 'end': 532}},
        {'sic5': {'start': 533, 'end': 537}},
        {'acInd': {'start': 538, 'end': 538}},
        {'phoneInd': {'start': 539, 'end': 539}},
        {'sic4': {'start': 540, 'end': 543}}
    ]


    def __init__(self):
        self.s3Helper = None
        self.wbCountryMap = None
        self.geoValidationDao = None


    def parseIrd3File(self, requestContext, cfpRecord):
        self._createServices(requestContext)
        cfpRecord.localFileName = S3Helper.LOCAL_DIRECTORY + '/' + cfpRecord.stpPartnerDeliveryFile.s3Object.fileName
        logging.info(f"Copying IRD-3 file from S3 to {cfpRecord.localFileName}")
            
        self.s3Helper.copyFromS3ToLocal(cfpRecord.stpPartnerDeliveryFile.s3Object, cfpRecord.localFileName)
        saveException = None
        
        try:
            if isHeaderFile(cfpRecord.cfpFileExtension):
                self.parseIrd3HdrFile(requestContext, cfpRecord)
            else:
                self.parseIrd3DatFile(requestContext, cfpRecord)
        except Exception as e:
            logging.error(f"Caught exception {e} from parseIrd3FileImpl")
            saveException = e
        finally:
            # cleanup
            logging.info(f"parseIrd3File: remove local file {cfpRecord.localFileName}")
            try:
                os.remove(cfpRecord.localFileName)
                logging.info("parseIrd3File: Back from removeing local file")
            except Exception as e:
                logging.warning(f"parseIrd3File: Failed to remove local file, continuing anyway: {e}")
        
        if saveException is not None:
            raise saveException
        
        
    def _createServices(self, requestContext):
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
            
            
    def parseIrd3HdrFile(self, requestContext, cfpRecord):
        result = None
        with open(cfpRecord.localFileName) as fp:
            try:
                line = fp.readline()
                # Single-line file, parse it directly
                result = parseFixedFormatAsDict(line, CfpParserIrd3.IRD3_HDR_CFG)
                logging.info(f"Parsed from IRD3-HDR file: {result}")
            except Exception as e:
                # Should only happen if error reading file
                errmsg = f"parseIrd3HdrFile: Caught exception processing file: {e}"
                logging.error(errmsg)
                raise LambdaProcessingException(errmsg)
        
        #cfpRecord.batchRecord.batchRequestId = None if result.get('irdBatchAgn') is None else int(result.get('irdBatchAgn'))
        cfpRecord.batchRecord.totalEntriesCount = intDefaultNone(result.get('numRecs'))
        updateBatchAttributes(cfpRecord, numRecs=cfpRecord.batchRecord.totalEntriesCount, projDesc=result.get('projDesc'))
        logging.info(f"Parsed IRD3 HDR file: {cfpRecord.batchRecord}")
        return result
            
            
    def parseIrd3DatFile(self, requestContext, cfpRecord):
        results = []
        lineNo = 0
        line = None
        # Note we use errors='replace' because we were seeing occasional parsing errors on test file during CFP integration testing: Caught exception processing file: 'utf-8' codec can't decode byte 0xdb in position 2366: invalid continuation byte
        # Since this replaces the offending character by a unicode '?' character this could cause problems if inside a real field
        # but so far we've only seen it on the end of line so it's ignored.
        # Other option is errors='ignore', see: https://stackoverflow.com/questions/35028683/python3-unicodedecodeerror-with-readlines-method
        with open(cfpRecord.localFileName, errors='replace') as fp:
            try:
                lineNo += 1
                line = fp.readline()
                while line:
                    result = parseFixedFormatAsDict(line, CfpParserIrd3.IRD3_DAT_CFG)
                    results.append(result)
                    #jsonResult = json.dumps(result)
                    #logging.info(f"Parsed from IRD3 file: {jsonResult}")
                    lineNo += 1
                    line = fp.readline()
            except Exception as e:
                # Should only happen if error reading file
                errmsg = f"parseIrd3FileImpl: Caught exception processing file: {e} at line# {lineNo}"
                logging.error(errmsg)
                raise LambdaProcessingException(errmsg)
        
        recordNumber = 0
        lastSequenceNo = None
        for result in results:
            recordNumber += 1
            requestRecord = RequestRecord()
            requestRecord.recordNumber = recordNumber
            requestRecord.originalRecord = result
            requestRecord.originalRecord["internalRefId"] = str(recordNumber)
            if isBlank(result.get("sequenceNo")):
                requestRecord.addRejection(RequestRejectionError(jsonPathName="sequenceNo", errorDescription=errorMessages.ERR_REQUIRED_FIELD_MISSING, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
                cfpRecord.batchRecord.requestRecords.append(requestRecord)
            else:
                if result.get("sequenceNo") == lastSequenceNo:
                    logging.warning(f"Ignoring candidate record with duplicate sequenceNo {lastSequenceNo}")
                    recordNumber -= 1
                else:
                    cfpRecord.batchRecord.requestRecords.append(requestRecord)
                    lastSequenceNo = result.get("sequenceNo")

        # Validate and update totalEntriesCount
        if recordNumber > cfpRecord.batchRecord.totalEntriesCount:
            cfpRecord.batchRecord.batchRejectionErrorText = f"Expected no more than {cfpRecord.batchRecord.totalEntriesCount} records but got {recordNumber} records in batch."
        else:
            cfpRecord.batchRecord.totalEntriesCount = recordNumber
