'''
Created on Jun 26, 2020

@author: VanCampK
'''
import datetime
import logging

from common.util.dictUtils import generateFixedFormatFromDict
from lambdas.cfp.cfpUtil import mapBatchTypeToIrdProcessId, generateIrdErrorRec, transformCfpFilePrefixForStatFile


class CfpGeneratorIrd1(object):
    '''
    Generates IRD1 flow response files
    '''
    IRD1_OK_CFG_ROW_1 = [
        {'keyword': {'start': 1, 'end': 6}},
        {'custAgn': {'start': 7, 'end': 16}},
        {'irdProcessId': {'start': 17, 'end': 19}},
        {'batchAgn': {'start': 20, 'end': 29}}
    ]
    IRD1_OK_CFG_ROW_2 = [
        {'keyword': {'start': 1, 'end': 6}},
        {'batchStat': {'start': 7, 'end': 9}}
    ]
    IRD1_ERR_CFG = [
        {'errorCode': {'start': 1, 'end': 9}},
        {'errorMessage': {'start': 10, 'end': 126}}
    ]


    def __init__(self):
        pass
    
    
    def generateIrd1OkFile(self, requestContext, cfpRecord):
        okRec1 = {
            'keyword': 'LOADED',
            'custAgn': cfpRecord.batchRecord.customerAgn,
            'irdProcessId': mapBatchTypeToIrdProcessId(cfpRecord.batchRecord.batchType),
            'batchAgn': int(cfpRecord.batchRecord.batchRequestId)
        }
        okRec2 = {
            'keyword': 'STATUS',
            'batchStat': '2'
        }

        logging.info(f"generateIrd1OkFile: Writing to local file {cfpRecord.localFileName}")
        with open(cfpRecord.localFileName, "w") as fp:
            line1 = generateFixedFormatFromDict(okRec1, CfpGeneratorIrd1.IRD1_OK_CFG_ROW_1)
            fp.write(line1 + "\n")
            line2 = generateFixedFormatFromDict(okRec2, CfpGeneratorIrd1.IRD1_OK_CFG_ROW_2)
            fp.write(line2 + "\n")
    
    
    def generateIrd1ErrorFile(self, requestContext, cfpRecord):
        errRec = generateIrdErrorRec(cfpRecord)

        logging.info(f"generateIrd1ErrorFile: Writing to local file {cfpRecord.localFileName}")
        with open(cfpRecord.localFileName, "w") as fp:
            line1 = generateFixedFormatFromDict(errRec, CfpGeneratorIrd1.IRD1_ERR_CFG)
            fp.write(line1 + "\n")
    
    
    def generateIrd1StatFile(self, requestContext, cfpRecord):
        logging.info(f"generateIrd1StatFile: Writing to local file {cfpRecord.localFileName}")
        DATE_FORMAT = "%m/%d/%y"
        TIME_FORMAT = "%H:%M:%S"
        currDateTime = datetime.datetime.now()
        dateStr = currDateTime.strftime(DATE_FORMAT)
        timeStr = currDateTime.strftime(TIME_FORMAT)
        cfpStatFilePrefix = transformCfpFilePrefixForStatFile(cfpRecord)
        successErrInd = f"ABEND~0~" if cfpRecord.isRejected() else f"END~{cfpRecord.batchRecord.batchRequestId}~"

        with open(cfpRecord.localFileName, "w") as fp:
            line1 = f"FPCREQUEST|IRDADDPROCESS|GIRD00|00|{cfpStatFilePrefix}|{dateStr}|{timeStr}|0~|{successErrInd}|||"
            fp.write(line1 + "\n")
        