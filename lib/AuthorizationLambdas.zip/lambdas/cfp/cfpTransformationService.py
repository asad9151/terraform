'''
Created on Jul 7, 2020

@author: VanCampK
'''
import logging

from common.dao.geoValidationDao import GeoValidationDao
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.stringUtils import isBlank, defaultNone, isInt
from lambdas.cfp import cfpErrorMessages
from lambdas.cfp.cfpUtil import createCfpRequestKey, mapBatchTypeToResearchSubType
from lambdas import errorMessages
from lambdas.exceptions import LambdaConflictException
from lambdas.retrieveInitialData.geoCodeTypeCodes import GeoCodeTypeCode
from lambdas.retrieveInitialData.geoUnitTypeCodes import GeoUnitTypeCode
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.submitcaseapi import submitCaseApiFields as apiFields


class CfpTransformationService(object):
    '''
    Transforms a batch of incoming CFP IRD3 record into iResearch format
    '''
    wbCountryMap = {}     # cache worldbase country code to iso2ALpha country code
    US_WORLDBASE_COUNTRY_CODE = '805'


    def __init__(self, dbConn):
        self.dbConn = dbConn
        self.batchRequestDao = None
        self.geoValidationDao = None
        
        
    def transformBatch(self, requestContext, cfpRecord):
        self._buildWbCountryMap()
        # TODO consider taking up where it previously left off
        #cfpRecord.batchRecord.totalEntriesCount = 0
        cfpRecord.batchRecord.rejectedEntriesCount = 0
        for requestRecord in cfpRecord.batchRecord.requestRecords:
            #cfpRecord.batchRecord.totalEntriesCount += 1
            if requestRecord.isRejected():
                logging.info(f"Skipping rejected record {requestRecord}")
                cfpRecord.batchRecord.rejectedEntriesCount += 1
            else:
                self._transformOneRecord(requestContext, cfpRecord, requestRecord)
                if requestRecord.isRejected(): # in case rejected during transformation
                    cfpRecord.batchRecord.rejectedEntriesCount += 1

    
    def _transformOneRecord(self, requestContext, cfpRecord, requestRecord):
        originalRecord = requestRecord.originalRecord
        # Transform to mini-batch record format so submitCaseBatchSubmitter can transform it to iResearch format
        rschSubType = mapBatchTypeToResearchSubType(cfpRecord.batchRecord.batchType)
        requestRecord.miniBatchRecord = {
            apiFields.MNB_FLD_RSCH_SUB_TYPE: f"Unused Description : {rschSubType}",
            apiFields.MNB_FLD_ORGANIZATION_NAME: cfpRecord.batchRecord.customerName,
            apiFields.API_FLD_INTERNAL_REF_ID: str(requestRecord.recordNumber),
            apiFields.API_FLD_REQUEST_KEY: createCfpRequestKey(cfpRecord, originalRecord),
            apiFields.MNB_FLD_COUNTRY_ISO2: self._convertCountry("countryCode", True, requestRecord),
            apiFields.MNB_FLD_ORG_PRIMARY_NAME: self._convertToString("name", True, requestRecord),
            apiFields.MNB_FLD_PRIM_ADDR_TOWN: self._convertToString("city", False, requestRecord),
            apiFields.MNB_FLD_PRIM_ADDR_REGION: self._convertToString("st", False, requestRecord),
            apiFields.MNB_FLD_PRIM_ADDR_POSTAL_CODE: self._convertToString("zip", False, requestRecord),
            apiFields.MNB_FLD_PRIM_ADDR_STREET: self._convertToString("phyAdd", False, requestRecord),
            apiFields.MNB_FLD_ORG_TELEPHONE: self._convertToString("phone", False, requestRecord),
            apiFields.MNB_FLD_LOOKUP_RULE: self._getLookupRule(cfpRecord)
        }
        self._transformOneRecordToBatchDetail(requestContext, requestRecord, cfpRecord.batchRecord.batchRequestId)
        
        
    def _convertCountry(self, fldName, isRequired, requestRecord):
        rec = requestRecord.originalRecord
        inp = rec.get(fldName)
        if isBlank(inp):
            inp = CfpTransformationService.US_WORLDBASE_COUNTRY_CODE    # If no countryCode, default to US
            #if isRequired:
            #    requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=errorMessages.ERR_REQUIRED_FIELD_MISSING, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
            #return None
        if not isInt(inp):
            logging.error(f"Adding {errorMessages.ERR_INTEGER_EXPECTED} rejection on {fldName} with providedValue={inp} on rec={rec}")
            requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=errorMessages.ERR_INTEGER_EXPECTED, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)            
            return None
        iso2CountryCode = CfpTransformationService.wbCountryMap.get(inp)
        if iso2CountryCode is None:
            logging.error(f"Adding {cfpErrorMessages.CFP_ERR_INVALID_COUNTRY_CODE} rejection on {fldName} with providedValue={inp} on rec={rec}")
            requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=cfpErrorMessages.CFP_ERR_INVALID_COUNTRY_CODE, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
        return iso2CountryCode


    def _convertToString(self, fldName, isRequired, requestRecord):
        rec = requestRecord.originalRecord
        inp = defaultNone(rec.get(fldName))
        isRejected = False
        outp = None
        if inp:
            if isinstance(inp, str):
                outp = defaultNone(inp)
            else:
                try:
                    outp = str(inp)
                except:
                    # Input could not be stringified
                    logging.error(f"Adding {errorMessages.ERR_STRING_EXPECTED} rejection on {fldName} with providedValue={inp} on rec={rec}")
                    requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=errorMessages.ERR_STRING_EXPECTED, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
                    isRejected = True
             
        if not isRejected and outp is None and isRequired == True:
            logging.error(f"Adding {errorMessages.ERR_REQUIRED_FIELD_MISSING} rejection on {fldName} with providedValue={inp} on rec={rec}")
            requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=errorMessages.ERR_REQUIRED_FIELD_MISSING, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
            
        return outp
        
        
    def _getLookupRule(self, cfpRecord):
        # {"lookupRules": [{"lookupRule": " Custom-SMS HQ-OK"}]}
        lookupRules = cfpRecord.batchRecord.batchAttributes.get("lookupRules")
        if lookupRules is not None and len(lookupRules) > 0:
            return lookupRules[0].get("lookupRule")
        
        
    def _transformOneRecordToBatchDetail(self, requestContext, requestRecord, batchRequestId):
        requestRecord.batchDetailRecord = {
            "batchRequestId": batchRequestId,
            "recordNumber": requestRecord.recordNumber,
            "batchResearchRequest": requestRecord.miniBatchRecord,
            "countryCode": requestRecord.miniBatchRecord.get(apiFields.MNB_FLD_COUNTRY_ISO2),
            "duns": None,
            "batchRequestRejectId": requestRecord.batchRequestRejectId,
            "isRejected": requestRecord.isRejected(),
            "isSuppressed": False
        }        
        

    def _buildWbCountryMap(self):
        # Builds a map from WorldBase country code to ISO 2-ALpha countryCode
        if CfpTransformationService.wbCountryMap is not None and len(CfpTransformationService.wbCountryMap) > 0:
            return 
        if self.geoValidationDao is None:
            self.geoValidationDao = GeoValidationDao()
        # First build a temporary map from geoUnitId to iso2Alpha
        iso2Alphas = self.geoValidationDao.queryCountryCodes(self.dbConn, GeoUnitTypeCode.GEO_UNIT_TYPE_CODE_COUNTRY.value, GeoCodeTypeCode.GEO_CODE_TYPE_CODE_ISO2ALPHA.value)
        geoUnit2Iso2Alpha = {}
        if type(iso2Alphas) is list:
            for iso2Alpha in iso2Alphas:
                geoUnitId = iso2Alpha["geo_unit_id"]
                isoCode = iso2Alpha["countryCode"]
                geoUnit2Iso2Alpha[geoUnitId] = isoCode
        # Then build the real map from WB countryCode to Iso2Alpha countryCode
        wbCountries = self.geoValidationDao.queryCountryCodes(self.dbConn, GeoUnitTypeCode.GEO_UNIT_TYPE_CODE_COUNTRY.value, GeoCodeTypeCode.GEO_CODE_TYPE_CODE_WORLDBASE.value)
        if type(wbCountries) is list and len(geoUnit2Iso2Alpha) > 0:
            CfpTransformationService.wbCountryMap = {}
            for wbCountry in wbCountries:
                geoUnitId = wbCountry["geo_unit_id"]
                wbCountryCode = wbCountry["countryCode"]
                isoCode = geoUnit2Iso2Alpha.get(geoUnitId)
                if isoCode is not None:
                    CfpTransformationService.wbCountryMap[wbCountryCode] = isoCode
                    #print(f"{wbCountryCode} {isoCode}")
            if len(CfpTransformationService.wbCountryMap) < 2:
                logging.error("Failed to load wbCountryMap")
                raise LambdaConflictException("Failed to load wbCountryMap")
            # Special case because WB code 785 actually maps to territory 'England'
            CfpTransformationService.wbCountryMap['785'] = 'GB'
        else:
            logging.error(f"Failed to load wbCountryMap: iso2Alphas={iso2Alphas} wbCountries={wbCountries}")
            raise LambdaConflictException("Failed to load wbCountryMap")
