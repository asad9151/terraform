'''
Created on Mar 7, 2019

@author: VanCampK
'''
import boto3
import botocore
import chardet
from datetime import datetime
import json
import logging
import requests
import sys
import traceback
import urllib3

from common.alert import Alert
from common.dbConn import DatabaseConnection
from common.util.xrayUtils import setupXray
from buildUIResponse import buildUIResponse
from determineStartType import determineStartType
import lambdas.errorMessages as errmsg
from lambdas.lambdaCommon import initLambdaEnviron, createRequestContext, logRequest
import lambdas.lambdaConstants as consts
from lambdas.statsLogger import StatsLogger
from lambdas.exceptions import LambdaValidationException, LambdaAlreadyAlertedException

print(f"IRSCHINIT LambdaBase static initialization called at UTC {datetime.utcnow()}")

class LambdaBase(object):
    '''
    Abstract base class for any python lambda
    Ref: https://gist.github.com/benkehoe/efb75a793f11d071b36fed155f017c8f
    '''

    # Class-level variables in the lambda are cached:
    environDict = {}
    dbConn = None
    statsLogger = None
    alert = None
    raiseAlertWhenRequestFails = False


    @classmethod
    def get_handler(cls, *args, **kwargs):
        def handler(event, context):
            #return cls(*args, **kwargs).handle(event, context)
            return cls().handle(event, context)
        return handler


    def __init__(self):
        self.requestContext = None


    def handle(self, event, context):
        '''
        Base lambda class handler
        '''
        try:
            setupXray(LambdaBase.environDict)
            
            LambdaBase.environDict = initLambdaEnviron(event, LambdaBase.environDict)
            startType = determineStartType(event)
            if not LambdaBase.alert:
                LambdaBase.alert = Alert(LambdaBase.environDict)
        except Exception as e:
            logging.error('error initializing LambdaBase environment.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            if self.raiseAlertWhenRequestFails and LambdaBase.alert is not None and not isinstance(e, LambdaAlreadyAlertedException):
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=str(e))
            return
    
        logging.info(f"Running python version {sys.version} boto3=={boto3.__version__} botocore=={botocore.__version__} requests=={requests.__version__} urllib3=={urllib3.__version__} chardet=={chardet.__version__}")
        if LambdaBase.statsLogger is None:
            LambdaBase.statsLogger = StatsLogger()

        LambdaBase.statsLogger.logStats(False, True)
        
        # Set up the database connection
        if self.needsDbConn() == True:
            if LambdaBase.dbConn is None:
                try:
                    logging.info('LambdaBase cold start initializing dbConn')
                    LambdaBase.dbConn = DatabaseConnection(LambdaBase.environDict)
                except Exception as e:
                    logging.error('LambdaBase caught exception initializing dbConn: ' + str(e))
                    logging.error('LambdaBase - error building DatabaseConnection object.  error = %s', e)
                    traceback.print_tb(sys.exc_info()[2])
                    if self.raiseAlertWhenRequestFails and not isinstance(e, LambdaAlreadyAlertedException):
                        LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=str(e))
                    return
            else:
                logging.info('LambdaBase warm start - testing database connection...')
                try:
                    LambdaBase.dbConn.checkConnection()
                    logging.info('LambdaBase continuing after database connection tested')
                except Exception as e:
                    logging.error('LambdaBase - error testing database connection.  error = %s', e)
                    traceback.print_tb(sys.exc_info()[2])
                    #if self.raiseAlertWhenRequestFails:
                    #    LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=str(e))
                    return
        
        # Allow subclass to initialize anything else needed during a keep-warm event...
        try:
            self.initializeKeepWarm()
        except Exception as e:
            logging.error('initializeKeepWarm error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            if self.raiseAlertWhenRequestFails and not isinstance(e, LambdaAlreadyAlertedException):
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=str(e))
            return
        
        if startType == consts.LAMBDA_START_TYPE_TIMER:
            if self.exitOnTimerEvent():
                LambdaBase.statsLogger.logStats(True, False)
                logging.info('LambdaBase Keep-warm exiting')
                return

        # Set up request context and user session
        try:
            self.requestContext = createRequestContext(event, LambdaBase.environDict, context, self, isBodyJson=self.isBodyJson())
        except LambdaValidationException as lve:
            logging.error('validation error creating request context.  error = %s', lve)
            # Should only happen when request has 'body' element so better to throw a UIResponse:
            statusCode = lve.statusCode.value
            errorMessage = lve.errmsg
            requestRejection = lve.requestRejection
            if requestRejection is None:
                body = errorMessage
            else:
                body = json.dumps(requestRejection.toDict())
            if self.raiseAlertWhenRequestFails and not isinstance(lve, LambdaAlreadyAlertedException):
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=errorMessage)
            return self.buildErrorResponse(statusCode, body)
        except Exception as e:
            logging.error('error creating request context.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            if self.raiseAlertWhenRequestFails and not isinstance(e, LambdaAlreadyAlertedException):
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=str(e))
            return
        
        logRequest(self.requestContext)
        
        # Delegate handling to subclass
        response = None
        try:
            response = self.handleRequest()
        except Exception as e:
            logging.error('error from handleRequest.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            if self.raiseAlertWhenRequestFails and not isinstance(e, LambdaAlreadyAlertedException):
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=str(e))
            return

        return response
    
    
    def handleRequest(self):
        '''
        Override this in subclass
        '''
        raise NotImplementedError
    
    def needsDbConn(self):
        '''
        Override this in subclass if database connection needed
        '''
        return False

    def initializeKeepWarm(self):
        '''
        Subclass can override this if they have any class level variables to initialize
        '''
        return

    def exitOnTimerEvent(self):
        '''
        Subclass can override this if they want to keep going on timer event
        '''
        return True
    
    def isApi(self):
        '''
        By default we are behaving as there is a browser on the other side.
        Subclass can override this if they want API-type behavior.
        '''
        return False
    
    def isBodyJson(self):
        '''
        Subclass can override this to set to False if a non-json (e.g. XML) body is expected
        '''
        return True
    
    
    def buildErrorResponse(self, statusCode, body):
        if self.isApi():
            return buildUIResponse(statusCode, body, contentType = 'application/json')
        else:
            return buildUIResponse(statusCode, body)
        
        
    def getModuleName(self):
        '''
        Subclass can override this if same lambda handler class is deployed for multiple lambdas
        '''
        if self.requestContext.path is not None:
            return self.requestContext.path
        else:
            return str(type(self)).replace("<","").replace(">","")