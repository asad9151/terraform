'''
Created on Feb 12, 2020

@author: VanCampK
'''
import json
import logging
from common import envVblNames
from common.encoders import DecimalAsFloatEncoder
from common.rejectionReasonCodes import RejectionReasonCode
from lambdas.exceptions import LambdaValidationException, LambdaProcessingException, LambdaAuthorizationException, LambdaAuthenticationException
from lambdas import errorMessages
from lambdas import lambdaConstants
from lambdas.lambdaCommon import buildLambdaSecureInvokeEvent, invokeLambdaFunction, parsePayloadFromInvokeResponse, parseHTTPStatusCodeFromInvokeResponse, parseStatusCodeFromPayload
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.requestRejection import RequestRejection
from lambdas.requestRejectionError import RequestRejectionError
import lambdas.updateandcloseapi.updateAndCloseApiFields as apiFields
from lambdas.updateandcloseapi.updateAndCloseApiUtils import lookupResearchSubTypeInDbRec


class UpdateAndCloseApiSubmissionService(object):
    '''
    Submits the requests to the UpdateResearchResults or TakeCaseAction service
    '''
    # Elements of the submitOneRequest response dictionary:
    RESULT_STATUS_CODE = "statusCode"
    RESULT_ERR_MSG = "errmsg"
    RESULT_BODY = "responseBody"
    RESULT_ERR_RESPONSE = "errorResponse"
    ERROR_MESSAGE = "errorMessage"
    ERROR_TYPE = "errorType"


    def submitOneRequest(self, requestContext, requestRecord, lambdaClient):
        resultDict = self._submitToBackEndService(requestContext, requestRecord.updateResearchResultsRequest, requestContext.environDict[envVblNames.ENV_UPDATERESEARCHRESULTS_ARN], lambdaClient)
        statusCode = resultDict[UpdateAndCloseApiSubmissionService.RESULT_STATUS_CODE]
        if statusCode != LambdaStatusCodes.OK.value:
            self._handleBackEndServiceFailure(requestContext, resultDict, statusCode, requestRecord)
        
        resultDict = self._submitToBackEndService(requestContext, requestRecord.takeCaseActionRequest, requestContext.environDict[envVblNames.ENV_TAKECASEACTION_ARN], lambdaClient)
        statusCode = resultDict[UpdateAndCloseApiSubmissionService.RESULT_STATUS_CODE]
        if statusCode != LambdaStatusCodes.OK.value:
            self._handleBackEndServiceFailure(requestContext, resultDict, statusCode, requestRecord)
        # Success
        return { apiFields.ALL_FLD_SUBJECT_RESEARCH_ID: requestRecord.subjectResearchId }
    
    def _handleBackEndServiceFailure(self, requestContext, resultDict, statusCode, requestRecord):
        logging.error('_handleBackEndServiceFailure: resultDict=' + str(resultDict))
        responseBody = resultDict[UpdateAndCloseApiSubmissionService.RESULT_BODY]
        errmsg = None
        if responseBody is not None:
            errorResponse = responseBody.get("errorResponse")
            if errorResponse is not None:
                errmsg = errorResponse.get("errorMessage")
        if statusCode == LambdaStatusCodes.BAD_REQUEST.value or statusCode == LambdaStatusCodes.NOT_FOUND.value:
            rejectionError = RequestRejectionError(jsonPathName=apiFields.ALL_FLD_SUBJECT_RESEARCH_ID, errorDescription=errmsg, providedValue=requestRecord.subjectResearchId)
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrors=[rejectionError])
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.FORBIDDEN.value:
            if errmsg is None:
                errmsg = errorMessages.ERR_NOT_AUTHORIZED
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrorMessage=errmsg)
            raise LambdaAuthorizationException(errmsg, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.UNAUTHORIZED.value:
            raise LambdaAuthenticationException(errorMessages.ERR_NOT_AUTHENTICATED)
        else:
            #Other technical error
            requestRejection = RequestRejection(RejectionReasonCode.INTERNAL_ERROR, rejectionErrorMessage=errorMessages.ERR_INTERNAL_REQUEST)
            raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST, requestRejection=requestRejection)
        
        
    def _submitToBackEndService(self, requestContext, backEndSvcRequest, backEndSvcArn, lambdaClient):
        outgoingBody = json.dumps(backEndSvcRequest, cls=DecimalAsFloatEncoder)
        logging.info(f'_submitToBackEndService: Arn={backEndSvcArn} outgoingBody={outgoingBody}')
        #print('outgoingBody=' + outgoingBody)
        event = buildLambdaSecureInvokeEvent(requestContext.userSession.principalId, 'POST', '/update', body=outgoingBody)
        response = invokeLambdaFunction(lambdaClient, event, backEndSvcArn, lambdaConstants.INVOKE_LAMBDA_REQUEST_RESPONSE)
        
        resultDict = {
            UpdateAndCloseApiSubmissionService.RESULT_STATUS_CODE: None,
            UpdateAndCloseApiSubmissionService.RESULT_ERR_MSG: None,
            UpdateAndCloseApiSubmissionService.RESULT_BODY: None
        }
        isSuccess = True
        httpStatusCode = parseHTTPStatusCodeFromInvokeResponse(response)
        resultDict[UpdateAndCloseApiSubmissionService.RESULT_STATUS_CODE] = httpStatusCode
        if httpStatusCode != LambdaStatusCodes.OK.value and httpStatusCode != LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
            isSuccess = False
            resultDict[UpdateAndCloseApiSubmissionService.RESULT_ERR_MSG] = 'Failed to _submitToBackEndService: response=' + str(response)
            errmsg = 'httpStatusCode=' + str(httpStatusCode)
            logging.error('Failed to _submitToBackEndService #1: errmsg=' + errmsg + ' response=' + str(response))
        else:
            # Handle synchronous invoke response
            responsePayload = parsePayloadFromInvokeResponse(response)
            if responsePayload:
                logging.info('Response payload from _submitToBackEndService:' + str(responsePayload))
                #print('Response payload from SubmitCase:' + str(responsePayload))
                statusCode = parseStatusCodeFromPayload(responsePayload)
                resultDict[UpdateAndCloseApiSubmissionService.RESULT_STATUS_CODE] = statusCode
                responseBody = responsePayload.get('body')
                if responseBody is not None:
                    resultDict[UpdateAndCloseApiSubmissionService.RESULT_BODY] = json.loads(responseBody)
                if statusCode != LambdaStatusCodes.OK.value:
                    isSuccess = False
                    resultDict[UpdateAndCloseApiSubmissionService.RESULT_ERR_MSG] = 'Failed to _submitToBackEndService #3: response payload=' + str(responsePayload)
                    errmsg = 'statusCode=' + str(statusCode)
                    logging.error('Failed to _submitToBackEndService: errmsg=' + errmsg + ' response=' + str(response))
                    #self._addSubmitRejection(requestContext, requestRecord, resultDict)
                
        logging.info('_submitToBackEndService invoked: success=' + str(isSuccess))
        return resultDict
        
    def invokeValidateUpdateAndClose(self, requestContext, singleRequestRecord, lambdaClient):

        applicationEntitlementObject = requestContext.serviceDict['applicationEntitlementObject']
        if applicationEntitlementObject.processingOptionsObj is not None:
            if applicationEntitlementObject.processingOptionsObj.get('updateAndCloseValidationOption') is None:
                logging.info(f'Full ValidateUpdateAndClose validations will be applied for application: {applicationEntitlementObject.applicationName}')
            elif applicationEntitlementObject.processingOptionsObj.get('updateAndCloseValidationOption') == 'full':
                logging.info(f'Full ValidateUpdateAndClose validations will be applied for application: {applicationEntitlementObject.applicationName}') 
            elif applicationEntitlementObject.processingOptionsObj.get('updateAndCloseValidationOption') == 'minimal':
                logging.info(f'No ValidateUpdateAndClose validations will be applied for application: {applicationEntitlementObject.applicationName}')
                return
        else:
            logging.info(f'Full ValidateUpdateAndClose validations will be applied for application: {applicationEntitlementObject.applicationName}')
            
        researchTypes = requestContext.incomingContent.get(apiFields.UAC_FLD_RESOLUTIONS)
        if researchTypes is None:
            logging.error("No researchTypes, so full validation is skipped")
            # No need to create additional rejection error, this should have been caught earlier
            return

        # Get the researchTypeCode needed by ValidateUpdateAndClose Node Lambda
        for res in researchTypes:
            lkupRschSubType = lookupResearchSubTypeInDbRec(singleRequestRecord.dbRec, res['researchSubTypeCode'])
            if lkupRschSubType is not None:
                res['researchTypeCode'] = lkupRschSubType[1]
            
        subjectResearch = singleRequestRecord.dbRec['subj_rsch_obj']
        subjectResearchObject = json.loads(subjectResearch)
        submittedData = subjectResearchObject['submittedData']
        subjectDnbData = singleRequestRecord.dbRec['subj_dnb_data_obj']
        if subjectDnbData is None:
            subjectDuns = None
        else:
            subjectDnbDataObject = json.loads(subjectDnbData)
            subjectDuns = subjectDnbDataObject['organization']['duns']
        
        researchResult = requestContext.incomingContent.get(apiFields.BOTH_UAC_URR_FLD_RESEARCH_RESULT)
        researchComment = requestContext.incomingContent.get(apiFields.BOTH_UAC_TCA_FLD_RESEARCH_COMMENT)

        body = {
            "researchTypes": researchTypes,
            "submittedData": submittedData,
            "researchResult": researchResult,
            "researchComment": researchComment,
            "subjectDuns": subjectDuns
        }
        
        event = {
            "body": body
        }
        
        # logging.info(f'invokeValidateUpdateAndClose: Arn={requestContext.environDict[envVblNames.ENV_VALIDATEUPDATEANDCLOSE_ARN]} outgoingBody={event}')
        response = invokeLambdaFunction(lambdaClient, event, requestContext.environDict[envVblNames.ENV_VALIDATEUPDATEANDCLOSE_ARN], lambdaConstants.INVOKE_LAMBDA_REQUEST_RESPONSE)
        responsePayload = parsePayloadFromInvokeResponse(response)
        if responsePayload.get('body') is not None:
            responseBody = json.loads(responsePayload.get('body'))
            responseData = responseBody['data']
            rejectionErrors = responseData['rejectionErrors']
            # print(f"Rejection Errors: {rejectionErrors}")
            for err in rejectionErrors:
                singleRequestRecord.addRejection(RequestRejectionError.fromDict(err), RejectionReasonCode.VALIDATION_ERROR)
                #err = RequestRejectionError.fromDict(err)
        else:
            logging.error(f"Got no body in response payload from ValidateUpdateAndClose: responsePayload={responsePayload}")
            reqRejErrObj = RequestRejectionError(None, errorMessages.ERR_INTERNAL_REQUEST, None)
            singleRequestRecord.addRejection(reqRejErrObj, RejectionReasonCode.VALIDATION_ERROR)
            
        # logging.info(f'invokeValidateUpdateAndClose Response: {response} \nResponseBody: {responseBody}')
        