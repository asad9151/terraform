'''
Created on Feb 13, 2020
Common utilities for UpdateAndCloseApi
@author: VanCampK
'''
import json
import lambdas.updateandcloseapi.updateAndCloseApiFields as apiFields

def lookupResearchSubTypeInDbRec(dbRec, researchSubTypeCode):
    '''
    Scans the researchTypes array for the provided researchSubTypeCode.
    If found, returns a tuple of ( idx, researchTypeCode ) where idx is the 0-based index in the researchTypes array.
    If not found, returns None
    '''
    subjRschObj = dbRec.get(apiFields.DB_FLD_SUBJECT_RESEARCH)
    subjectResearch = json.loads(subjRschObj)
    researchTypes = subjectResearch.get(apiFields.DB_FLD_RESEARCH_TYPES)
    for idx, resType in enumerate(researchTypes):
        if resType.get(apiFields.ALL_FLD_RESEARCH_SUBTYPE_CODE) == researchSubTypeCode:
            return (idx, resType.get(apiFields.ALL_FLD_RESEARCH_TYPE_CODE))
        
    return None