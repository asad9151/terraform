'''
Created on Aug 28, 2019

@author: VanCampK
'''

class RequestRecord(object):
    '''
    Holds attributes about one UpdateAndCloseApi request
    '''

    def __init__(self):
        self.updateAndCloseRequest = None   # Incoming UpdateAndCloseApi request
        self.subjectResearchId = None       # Case# being updated
        self.isValidationOnly = False       # True if user only wants to validate and not actually submit the request
        self.dbRec = None                   # Attributes of the case as currently stored in the database
        self.updateResearchResultsRequest = None    # Outgoing UpdateResearchResults request
        self.takeCaseActionRequest = None   # Outgoing TakeCaseAction request
        self.requestRejectionErrors = []    # list of RequestRejectionError, if any
        self.rejectionReasonCode = None     # reason for rejection, if any
        self.recordNumber = None            # if being processed in a batch
        self.fileTrackingId = None          # if being processed in a batch
        self.partnerFileTrackingId = None   # if being processed in a batch
        self.partnerDetail = None           # partner detail record (used in batch response processing)
        
        
    def isRejected(self):
        if self.requestRejectionErrors:
            if len(self.requestRejectionErrors) > 0:
                return True
        return False
    
    
    def addRejection(self, requestRejectionError, rejectionReasonCode):
        self.requestRejectionErrors.append(requestRejectionError)
        self.rejectionReasonCode = rejectionReasonCode


    def requestRejectionErrorsToDict(self):
        errs = []
        for err in self.requestRejectionErrors:
            errs.append(err.toDict())
        return errs
