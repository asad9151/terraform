'''
Created on Apr 29, 2020

@author: VanCampK
'''
import json
import logging
import os
import shutil
from zipfile import ZipFile

from common.batchStatusCodes import BatchStatusCode
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.dateUtils import getCurrentDatetimestamp
from common.util.s3Helper import S3Helper
from common.util.ValidateUtil import ValidateUtil
from lambdas import errorMessages
from lambdas.requestRejection import RequestRejection
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.updateandcloseapi.requestRecord import RequestRecord


class UpdateAndCloseResponseFileGenerator(object):
    '''
    Generates a json UAC response file
    '''
    RECORDS_FILE_NAME = "records.json"
    RESPONSE_SCHEMA = "iResearchUpdateAndCloseSubjectResearchResponse.json"
    
    
    def __init__(self, alert):
        self.s3Helper = None
        self.responseValidateUtil = None
        self.alert = alert


    def generateLocalFile(self, requestContext, batchRecord):
        self._createServices()
        spdf = batchRecord.outgoingStpPartnerDeliveryFile
        dateTimeStr = getCurrentDatetimestamp()
        batchRecord.localDirectoryName = S3Helper.LOCAL_DIRECTORY + dateTimeStr + '/'
        logging.info(f"generateLocalFile: make local directory {batchRecord.localDirectoryName}")
        try:
            os.mkdir(batchRecord.localDirectoryName)
            logging.info(f"generateLocalFile: made local directory")
        except Exception as e:
            logging.warning(f"generateLocalFile: Failed to make local directory: {e}")
            
        batchRecord.localFileName = batchRecord.localDirectoryName + spdf.s3Object.fileName
        batchRecord.localRecordsFileName = batchRecord.localDirectoryName + UpdateAndCloseResponseFileGenerator.RECORDS_FILE_NAME
        
        self._writeLocalFile(requestContext, batchRecord)
        self._writeZipFile(requestContext, batchRecord)
        spdf.s3Object.fileSize = os.path.getsize(batchRecord.localFileName)
        

    def _writeLocalFile(self, requestContext, batchRecord):
        logging.info(f"_writeLocalFile: Writing to local file {batchRecord.localRecordsFileName}")
        with open(batchRecord.localRecordsFileName, "w") as fp:
            if batchRecord.stpPartnerDeliveryFile.batchProcessStatusCode == BatchStatusCode.REJECTED.value:
                # Incoming batch was rejected - create fake requestRecord to pass the error
                requestRecord = RequestRecord()
                requestRecord.addRejection(RequestRejectionError(jsonPathName=None, errorDescription=batchRecord.stpPartnerDeliveryFile.rejectErrorText, providedValue=None), RejectionReasonCode.VALIDATION_ERROR.value)
                outgoingRecord = self._createOutgoingRecord(requestRecord)
                logging.info(f"_writeLocalFile: Writing reject record {outgoingRecord}")
                fp.write(str(outgoingRecord) + "\n")
            else:
                logging.info(f"_writeLocalFile: Writing {len(batchRecord.requestRecords)} records:")
                for requestRecord in batchRecord.requestRecords:
                    outgoingRecord = self._createOutgoingRecord(requestRecord)
                    logging.info(f"_writeLocalFile: Writing response record {outgoingRecord}")
                    fp.write(str(outgoingRecord) + "\n")

            
    def _writeZipFile(self, requestContext, batchRecord):
        logging.info(f"_writeZipFile: Writing to local zip file {batchRecord.localFileName}")
        with ZipFile(batchRecord.localFileName, "w") as zf:
            logging.info(f"_writeZipFile: Adding to zip file {batchRecord.localRecordsFileName} as {UpdateAndCloseResponseFileGenerator.RECORDS_FILE_NAME}")
            zf.write(batchRecord.localRecordsFileName, arcname=UpdateAndCloseResponseFileGenerator.RECORDS_FILE_NAME)
        
        
    def _createOutgoingRecord(self, requestRecord):
        outgoingDict = {}
        if requestRecord.partnerDetail is None:
            # Special outgoing record has no subjectResearchId because entire batch was rejected
            rejectionErrors = requestRecord.requestRejectionErrors
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR.value, rejectionErrors)
            outgoingDict["rejectionInformation"] = requestRejection.toDict()["rejectionInformation"]
        else:
            pd = requestRecord.partnerDetail
            outgoingDict["subjectResearchId"] = pd.subjectResearchId
            if pd.partnerRequestRejectionObject is not None:
                rejectionErrors = []
                logging.debug(f"_createOutgoingRecord: Using partnerRequestRejectionObject={pd.partnerRequestRejectionObject}")
                for rreDict in pd.partnerRequestRejectionObject:
                    rejectionErrors.append(RequestRejectionError.fromDict(rreDict))
                requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR.value, rejectionErrors)
                outgoingDict["rejectionInformation"] = requestRejection.toDict()["rejectionInformation"]
                
        # Validate that outgoing record conforms to schema
        self._validateResponse(outgoingDict)
        outgoingRecord = json.dumps(outgoingDict)
        return outgoingRecord
    
    
    def _validateResponse(self, responseBodyDict):
        errors = sorted(self.responseValidateUtil.theValidator.iter_errors(responseBodyDict), key=lambda e: e.path)
        if len(errors) == 0:
            return
        errorSummary = f"{errorMessages.ERR_INVALID_RESPONSE} {UpdateAndCloseResponseFileGenerator.RESPONSE_SCHEMA}"
        errorMessage = "UPDATEANDCLOSE VALIDATERESPONSE ERROR: "
        for error in errors:
            if error.absolute_path:
                jsonPath = ''
                for ele in error.absolute_path:
                    if type(ele) is int:
                        jsonPath = jsonPath.strip(".") + "[" + str(ele) + "]."
                    else:
                        jsonPath += ele + "."
                jsonPath = jsonPath.strip(".")
            else:
                jsonPath = ""
            errorMessage += jsonPath + ": " + error.message
        #self.alert.raiseAlert(UpdateAndCloseResponseFileGenerator.MODULE_NAME, errorSummary, detailedErrMsg=errorMessage)
        logging.error(f"{errorSummary}: {errorMessage}")
        
        
    def deliverFile(self, requestContext, batchRecord):
        logging.info(f"Copying {batchRecord.localFileName} to s3 {batchRecord.outgoingStpPartnerDeliveryFile.s3Object}")
        self.s3Helper.copyFromLocalToS3(batchRecord.localFileName, batchRecord.outgoingStpPartnerDeliveryFile.s3Object)
    
    
    def deleteLocalFile(self, requestContext, batchRecord):
        logging.info(f"Removing local diretory tree {batchRecord.localDirectoryName}")
        shutil.rmtree(batchRecord.localDirectoryName)
    
    
    def _createServices(self):
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
        if self.responseValidateUtil is None:
            self.responseValidateUtil = ValidateUtil(UpdateAndCloseResponseFileGenerator.RESPONSE_SCHEMA)
            