'''
Created on Feb 12, 2020

@author: VanCampK
'''
import json
import logging
import pymysql
import sys
import traceback
from common.dao.apiApplicationEntitlementDao import ApiApplicationEntitlementDao
from common.dao.partnerDetailDao import PartnerDetailDao
from common.dao.subjectResearchDao import SubjectResearchDao
from common.model.partnerDetail import PartnerDetail
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.stringUtils import isBlank
from lambdas import errorMessages
from lambdas.exceptions import LambdaValidationException, LambdaProcessingException, LambdaAuthorizationException
from lambdas.requestRejection import RequestRejection
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.updateandcloseapi.requestRecord import RequestRecord
from lambdas.updateandcloseapi.updateAndCloseApiSubmissionService import UpdateAndCloseApiSubmissionService
from lambdas.updateandcloseapi.updateAndCloseApiTransformationService import UpdateAndCloseApiTransformationService
from lambdas.updateandcloseapi.updateAndCloseApiValidationService import UpdateAndCloseApiValidationService
import lambdas.updateandcloseapi.updateAndCloseApiFields as apiFields
from lambdas.lambdaCommon import invokeLambdaFunction


class UpdateAndCloseApiService(object):
    '''
    Service for UpdateAndCloseApi
    '''
    MODULE_NAME = "UpdateAndCloseApiService"
    updateAndCloseApiValidationService = None
    updateAndCloseApiTransformationService = None
    updateAndCloseApiSubmissionService = None
    
    
    def __init__(self, dbConn):
        self.dbConn = dbConn
        #self.lambdaClient = lambdaClient
        self.singleRequestRecord = None
        self.subjectResearchDao = None
        self.partnerDetailDao = None
        self.apiApplicationEntitlementDao = None


    def _createServices(self):
        '''
        Instantiates each dependent service that is not already instantiated
        '''
        if UpdateAndCloseApiService.updateAndCloseApiValidationService is None:
            UpdateAndCloseApiService.updateAndCloseApiValidationService = UpdateAndCloseApiValidationService(self.dbConn)
        if UpdateAndCloseApiService.updateAndCloseApiTransformationService is None:
            UpdateAndCloseApiService.updateAndCloseApiTransformationService = UpdateAndCloseApiTransformationService()
        if UpdateAndCloseApiService.updateAndCloseApiSubmissionService is None:
            UpdateAndCloseApiService.updateAndCloseApiSubmissionService =  UpdateAndCloseApiSubmissionService()
    
    
    def processUpdateAndCloseRequest(self, requestContext, incomingContent, lambdaClient):
        '''
        Main entry point to process a new ResearchRequest
        '''
        self._createServices()
        responseRecord= None
        try:
            responseRecord = self._processUpdateAndCloseRequestImpl(requestContext, incomingContent, lambdaClient)
            self._storeOrRaise(requestContext, None)
            
        except Exception as e:
            logging.error('processUpdateAndCloseRequest error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            # TODO retry if not a LambdaValidationException
            # Propagate exception to send back error result and set http error code
            requestRejection = RequestRejection(RejectionReasonCode.INTERNAL_ERROR, rejectionErrorMessage=errorMessages.ERR_INTERNAL_REQUEST)
            if isinstance(e, LambdaAuthorizationException):
                # TODO different error code for authorization error?
                requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrorMessage=errorMessages.ERR_NOT_AUTHORIZED)
                if e.requestRejection is None:
                    e.requestRejection = requestRejection
                self._storeOrRaise(requestContext, e)
            elif isinstance(e, LambdaValidationException):
                self._storeOrRaise(requestContext, e)
            elif isinstance(e, LambdaProcessingException):
                if e.requestRejection is None:
                    e.requestRejection = requestRejection
                raise e
            else:
                # Make sure we have requestRejection so client gets back properly formatted response
                raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST, requestRejection=requestRejection)
        
        return responseRecord


    def _processUpdateAndCloseRequestImpl(self, requestContext, incomingContent, lambdaClient):
        responseRecord = None
        self.singleRequestRecord = RequestRecord()
        self.singleRequestRecord.updateAndCloseRequest = incomingContent
        # print(f"Incoming Content: {self.singleRequestRecord.updateAndCloseRequest}")
        self.singleRequestRecord.recordNumber = incomingContent.get(apiFields.UAC_FLD_RECORD_NUMBER)
        self.singleRequestRecord.fileTrackingId = incomingContent.get(apiFields.UAC_FLD_TRACKING_ID)
        self.singleRequestRecord.partnerFileTrackingId = incomingContent.get(apiFields.UAC_FLD_PARTNER_TRACKING_ID)
        if self.singleRequestRecord.partnerFileTrackingId is not None:
            logging.info(f"Processing batch record fileTrackingId={self.singleRequestRecord.fileTrackingId} partnerFileTrackingId={self.singleRequestRecord.partnerFileTrackingId} recordNumber={self.singleRequestRecord.recordNumber}")
        
        self._loadAndAuthorizeCase(requestContext)
        
        UpdateAndCloseApiService.updateAndCloseApiValidationService.validateAgainstSchema(requestContext, self.singleRequestRecord)
        UpdateAndCloseApiService.updateAndCloseApiValidationService.validateRecord(requestContext, self.singleRequestRecord)
        # Invokes Shared Validations Module
        UpdateAndCloseApiService.updateAndCloseApiSubmissionService.invokeValidateUpdateAndClose(requestContext, self.singleRequestRecord, lambdaClient)
        if not self.singleRequestRecord.isRejected():
            UpdateAndCloseApiService.updateAndCloseApiTransformationService.transformOneRecordToIResearch(requestContext, self.singleRequestRecord)
        if self.singleRequestRecord.isRejected():
            logging.error(f"request is rejected due to {self.singleRequestRecord.requestRejectionErrorsToDict()}")
            requestRejection = RequestRejection(self.singleRequestRecord.rejectionReasonCode, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        
        if self.singleRequestRecord.isValidationOnly == True:
            logging.info(f"isValidationOnly=True so done")
            return responseRecord

        logging.info("Submitting to back end services...")        
        responseRecord = UpdateAndCloseApiService.updateAndCloseApiSubmissionService.submitOneRequest(requestContext, self.singleRequestRecord, lambdaClient)
        logging.info("Submitted to back end services.")
        return responseRecord
    
    
    def _loadAndAuthorizeCase(self, requestContext):
        '''
        Loads the dbRec from the database and verifies that the current user is the assigned researcher
        '''
        
        self.singleRequestRecord.subjectResearchId = self.singleRequestRecord.updateAndCloseRequest.get(apiFields.ALL_FLD_SUBJECT_RESEARCH_ID)
        if isBlank(self.singleRequestRecord.subjectResearchId):
            logging.error("No subjectResearchId in request")
            reqRejErrObj = RequestRejectionError(apiFields.ALL_FLD_SUBJECT_RESEARCH_ID, errorMessages.ERR_REQUIRED_FIELD_MISSING, None)
            self.singleRequestRecord.addRejection(reqRejErrObj, RejectionReasonCode.VALIDATION_ERROR)
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        if self.subjectResearchDao is None:
            self.subjectResearchDao = SubjectResearchDao()
        logging.info(f"_loadAndAuthorizeCase: subjectResearchId={self.singleRequestRecord.subjectResearchId}")
        self.singleRequestRecord.dbRec = self.subjectResearchDao.querySubjResearch(self.dbConn, self.singleRequestRecord.subjectResearchId)
        if self.singleRequestRecord.dbRec is None:
            logging.error(f"subjectResearchId={self.singleRequestRecord.subjectResearchId} not found")
            reqRejErrObj = RequestRejectionError(apiFields.ALL_FLD_SUBJECT_RESEARCH_ID, errorMessages.ERR_KEY_NOT_FOUND, self.singleRequestRecord.subjectResearchId)
            self.singleRequestRecord.addRejection(reqRejErrObj, RejectionReasonCode.VALIDATION_ERROR)
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        logging.info(f"Read case from database: {self.singleRequestRecord.dbRec}")
        assignedResearchUserId = self.singleRequestRecord.dbRec.get("curr_rsch_usr_id")
        logging.info(f"_loadAndAuthorizeCase: subjectResearchId={self.singleRequestRecord.subjectResearchId} assignedResearchUserId={assignedResearchUserId} currentUser={requestContext.userSession.userId}")
        if assignedResearchUserId is None:
            logging.error(f"_loadAndAuthorizeCase no researcher assigned for case: subjectResearchId={self.singleRequestRecord.subjectResearchId}")
            reqRejErrObj = RequestRejectionError(apiFields.ALL_FLD_SUBJECT_RESEARCH_ID, errorMessages.ERR_CASE_NOT_ASSIGNED, self.singleRequestRecord.subjectResearchId)
            self.singleRequestRecord.addRejection(reqRejErrObj, RejectionReasonCode.VALIDATION_ERROR)
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        if int(assignedResearchUserId) != int(requestContext.userSession.userId):
            logging.error(f"_loadAndAuthorizeCase researcher not authorized for case: subjectResearchId={self.singleRequestRecord.subjectResearchId} assignedResearchUserId={assignedResearchUserId} currentUser={requestContext.userSession.userId}")
            reqRejErrObj = RequestRejectionError(apiFields.ALL_FLD_SUBJECT_RESEARCH_ID, errorMessages.ERR_NOT_AUTHORIZED, self.singleRequestRecord.subjectResearchId)
            self.singleRequestRecord.addRejection(reqRejErrObj, RejectionReasonCode.VALIDATION_ERROR)
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaAuthorizationException(errorMessages.ERR_NOT_AUTHORIZED, requestRejection=requestRejection)
        if self.apiApplicationEntitlementDao is None:
            self.apiApplicationEntitlementDao = ApiApplicationEntitlementDao()
        applicationEntitlementObject = self.apiApplicationEntitlementDao.queryApiApplicationAsObject(self.dbConn, requestContext.userSession.applicationId)
        requestContext.serviceDict['applicationEntitlementObject'] = applicationEntitlementObject


    def _storeOrRaise(self, requestContext, exc):
        '''
        If a batch request, stores the data (and rejection if any) into the partner detail record.
        If a non-batch request, just raises the exception so it propagates.
        '''
        isBatch = True if (self.singleRequestRecord.recordNumber is not None and self.singleRequestRecord.fileTrackingId is not None and self.singleRequestRecord.partnerFileTrackingId is not None) else False
        if isBatch:
            self._storeDetail(requestContext, exc)
        else:
            if exc is not None:
                raise exc


    def _storeDetail(self, requestContext, exc):
        if self.partnerDetailDao is None:
            self.partnerDetailDao = PartnerDetailDao()
        partnerDetail = self._createPartnerDetail(exc)
        try:
            self.partnerDetailDao.insertPartnerDetail(self.dbConn, partnerDetail, UpdateAndCloseApiService.MODULE_NAME)
        except pymysql.err.IntegrityError as e:
            if e.args[0] == 1062:    # (1062, "Duplicate entry '14-1' for key 'ptnr_detl_ie1'")
                logging.warning(f"_storeDetail failed on duplicate entry (ignoring as duplicate message processing partnerFileTrackingId={partnerDetail.partnerFileTrackingId} recordNumber={partnerDetail.recordNumber})")
            else:
                # Anything else gets raised and alerted on
                raise
        
        
    def _createPartnerDetail(self, exc):
        pd = PartnerDetail()
        pd.partnerFileTrackingId = self.singleRequestRecord.partnerFileTrackingId
        pd.recordNumber = self.singleRequestRecord.recordNumber
        pd.rawDataObject = self.singleRequestRecord.updateAndCloseRequest
        pd.subjectResearchId = self.singleRequestRecord.subjectResearchId
        if exc is not None and not self.singleRequestRecord.isRejected():   # TODO should add the reject even if already there, and let common code weed out dups
            if exc.requestRejection is not None and len(exc.requestRejection.rejectionErrors) > 0:
                self.singleRequestRecord.addRejection(exc.requestRejection.rejectionErrors[0], RejectionReasonCode.VALIDATION_ERROR)
            else:
                reqRejErrObj = RequestRejectionError(None, errorMessages.ERR_INTERNAL_REQUEST, None)
                self.singleRequestRecord.addRejection(reqRejErrObj, RejectionReasonCode.VALIDATION_ERROR)
                
        if self.singleRequestRecord.isRejected():
            pd.rejectionIndicator = 1
            pd.partnerRequestRejectionObject = self.singleRequestRecord.requestRejectionErrorsToDict()
        else:
            pd.rejectionIndicator = 0
            pd.partnerRequestRejectionObject = None
        return pd
    