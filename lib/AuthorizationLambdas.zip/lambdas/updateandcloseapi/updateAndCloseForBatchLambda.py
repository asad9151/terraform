'''
@author: VanCampK
'''
import boto3
import logging
import json
import sys
import traceback

from common.dao.fileTrackingDao import FileTrackingDao
from common.irschRoles import IResearchRole
from common import envVblNames
from common.util.awsUtils import createClientConfiguration
from common.util.stringUtils import isBlank
from common.util.sqsHelper import SqsHelper
from lambdas.exceptions import LambdaAuthorizationException, LambdaValidationException
import lambdas.errorMessages as errmsg
from lambdas.lambdaBase import LambdaBase
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.lambdaCommon import createRequestContext, logRequest
from lambdas.loginSessionDao import LoginSessionDao
from lambdas.updateandcloseapi.updateAndCloseApiService import UpdateAndCloseApiService
import lambdas.updateandcloseapi.updateAndCloseApiFields as apiFields
from lambdas.util.cloudServicesHelper import CloudServicesHelper


class UpdateAndCloseForBatchLambda(LambdaBase):
    '''
    Handler class for UpdateAndCloseForBatch service.
    Responsible for updating and closing 1 or more cases from batch researchers (invoked via queue with batches of up to 10).
    Handler: lambdas.updateandcloseapi.updateAndCloseForBatchLambda.handler
    '''
    
    
    def __init__(self):
        super().__init__()
        self.service = None
        self.sqsHelper = None
        self.lambdaClient = None                    # Used to invoke RecordLogin when establishing new session
        self.lambdaClientForUpdateAndTCA = None     # Used to invoke both UpdateResearchResults and TakeCaseAction
        self.fileTrackingDao = None
        self.loginSessionDao = None
        self.cloudServicesHelper = None
        
    
    def handleRequest(self):
        UpdateAndCloseForBatchLambda.raiseAlertWhenRequestFails = True
        incomingEvent = self.requestContext.event
        self._createServices()
        logging.info(f"UpdateAndCloseForBatchLambdagot incomingEvent {incomingEvent}")
        if 'Records' in incomingEvent:
            # Invoked via queue with batch size 1
            records = incomingEvent['Records']
            logging.info(f"Got multi-event request from queue with {len(records)} messages")
            lastException = None
            alertErrMsg = None
            for record in records:
                logging.info(f"UpdateAndCloseForBatchLambdarecord={record}")
                try:
                    sbody = record.get('body')
                    if isinstance(sbody, str):
                        body = json.loads(sbody)
                    else:
                        body = sbody
                    messageId = record.get('messageId')
                    messageReceiptHandle = record.get('receiptHandle')
                    self._handleOneMessage(body)
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except LambdaValidationException as lve:
                    alertErrMsg = f"LambdaValidationException trying to process : {lve}"
                    # Raise alert but do not retry request
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except Exception as e:
                    alertErrMsg = f"Unexpected exception trying to process : {e}"
                    traceback.print_tb(sys.exc_info()[2])
                    # Raise alert and retry request (i.e. don't delete message from queue)
                    lastException = e
                # Continue on to next record regardless of failure of one message
                
            if lastException is not None:
                # Tells lambda to retry, also raises alert from LambdaBase
                raise lastException
            elif alertErrMsg is not None:
                # No retry but raise alert anyway
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=alertErrMsg)
        

    def _createServices(self):
        if self.service is None:
            self.service = UpdateAndCloseApiService(UpdateAndCloseForBatchLambda.dbConn)
        if self.lambdaClient is None:
            self.lambdaClient = boto3.client('lambda', region_name=self.requestContext.environDict[envVblNames.ENV_LAMBDA_REGION], config=createClientConfiguration(self.requestContext.environDict))
        if self.lambdaClientForUpdateAndTCA is None:
            # config is None to stop retries from happening on invoked lambdas
            self.lambdaClientForUpdateAndTCA = boto3.client('lambda', region_name=self.requestContext.environDict[envVblNames.ENV_LAMBDA_REGION], config=None)
        if self.fileTrackingDao is None:
            self.fileTrackingDao = FileTrackingDao()
        if self.loginSessionDao is None:
            self.loginSessionDao = LoginSessionDao()
        if self.cloudServicesHelper is None:
            self.cloudServicesHelper = CloudServicesHelper()

        
    def _handleOneMessage(self, body):
        recordRequestContext = createRequestContext(body, LambdaBase.environDict, self.requestContext.lambdaContext, self, isBodyJson=self.isBodyJson())
        fileTrackingId = recordRequestContext.body.get(apiFields.UAC_FLD_TRACKING_ID)
        stpPartnerDeliveryFile = self.fileTrackingDao.queryPartnerFileByTrackingId(self.dbConn, fileTrackingId)
        self.cloudServicesHelper.establishSessionForIncomingStpUser(self.dbConn, recordRequestContext, stpPartnerDeliveryFile.apiApplicationEntitlement, self.loginSessionDao, self.lambdaClient)
        logging.info("After establishSessionForIncomingStpUser")
        logRequest(recordRequestContext)
        self.authorizeRequest(recordRequestContext)
        self.service.processUpdateAndCloseRequest(recordRequestContext, recordRequestContext.body, self.lambdaClientForUpdateAndTCA)


    def needsDbConn(self):
        return True
    
    
    def authorizeRequest(self, recordRequestContext):
        if (checkIfUserHasAnyRoles(recordRequestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER ]) == False):
            logging.error('UpdateAndCloseForBatchLambda - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
        
        
    def _markMessageComplete(self, messageId, messageReceiptHandle):
        '''
        Deletes a message from the queue because we successfully processed it
        '''
        if isBlank(messageId) or isBlank(messageReceiptHandle):
            logging.warning("Not deleting message from queue because no messageId or messageReceiptHandle")
            return
        uacQueueUrl = self.requestContext.environDict[envVblNames.ENV_UPDATEANDCLOSE_QUEUE_URL]
        if self.sqsHelper is None:
            regionName = self.requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
            self.sqsHelper = SqsHelper(uacQueueUrl, regionName=regionName)
        logging.info(f"Delete message from queue {uacQueueUrl}: messageId={messageId} messageReceiptHandle={messageReceiptHandle}")
        self.sqsHelper.deleteOneMessageFromQueue(messageReceiptHandle)
        logging.info("Back from deleteOneMessageFromQueue")
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = UpdateAndCloseForBatchLambda.get_handler(...)