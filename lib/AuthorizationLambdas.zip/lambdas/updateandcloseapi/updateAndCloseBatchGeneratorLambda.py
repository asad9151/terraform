'''
Created on Apr 23, 2020

@author: VanCampK
'''
import logging

from lambdas.lambdaBase import LambdaBase
from lambdas.updateandcloseapi.updateAndCloseBatchGeneratorService import UpdateAndCloseBatchGeneratorService


class UpdateAndCloseBatchGeneratorLambda(LambdaBase):
    '''
    Handler class for UpdateAndCloseBatchGenerator service.
    Responsible for checking to see if any UpdateAndClose batches have completed (all records reported in ptnr_detl table)
    and generating an outgoing response file, and pushing it to the StpOutboundDelivery service for partner delivery.
    Handler: lambdas.updateandcloseapi.updateAndCloseBatchGeneratorLambda.handler
    '''
    
    
    def __init__(self):
        super().__init__()
        LambdaBase.raiseAlertWhenRequestFails = True
        self.service = None
    
    
    def needsDbConn(self):
        return True
    
    
    def handleRequest(self):
        logging.info(f"UpdateAndCloseBatchGeneratorLambda got event {self.requestContext.event}")
        if self.service is None:
            self.service = UpdateAndCloseBatchGeneratorService(UpdateAndCloseBatchGeneratorLambda.dbConn, LambdaBase.alert)
        self.service.processAllUpdateAndClose(self.requestContext)


    def initializeKeepWarm(self):
        pass


    def exitOnTimerEvent(self):
        return False
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = UpdateAndCloseBatchGeneratorLambda.get_handler(...)