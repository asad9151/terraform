'''
Created on Apr 23, 2020

@author: VanCampK
'''
import boto3
import logging
import json
import sys
import traceback

from common import envVblNames
from common.util.awsUtils import createClientConfiguration
from common.util.stringUtils import isBlank
from common.util.sqsHelper import SqsHelper
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaValidationException
from lambdas.lambdaBase import LambdaBase
from lambdas.updateandcloseapi.updateAndCloseBatchParserService import UpdateAndCloseBatchParserService


class UpdateAndCloseBatchParserLambda(LambdaBase):
    '''
    Handler class for UpdateAndCloseApi service.
    Responsible for parsing an UpdateAndClose request file and forwarding all requests to the UpdateAndClose service.
    Handler: lambdas.updateandcloseapi.updateAndCloseBatchParserLambda.handler
    '''
    
    def __init__(self):
        super().__init__()
        LambdaBase.raiseAlertWhenRequestFails = True
        self.service = None
        self.batchParserSqsHelper = None
        self.lambdaClientForUpdateAndTCA = None   # Used to invoke both UpdateResearchResults and TakeCaseAction
    
    
    def needsDbConn(self):
        return True
    
    
    def handleRequest(self):
        incomingEvent = self.requestContext.event
        if self.lambdaClientForUpdateAndTCA is None:
            # config is None to stop retries from happening on invoked lambdas
            self.lambdaClientForUpdateAndTCA = boto3.client('lambda', region_name=self.requestContext.environDict[envVblNames.ENV_LAMBDA_REGION], config=None)
        if self.service is None:
            self.service = UpdateAndCloseBatchParserService(self.dbConn, self.lambdaClientForUpdateAndTCA)
        logging.info(f"UpdateAndCloseBatchParserLambda got incomingEvent {incomingEvent}")
        if 'Records' in incomingEvent:
            # Invoked via queue with batch size 1
            records = incomingEvent['Records']
            logging.info(f"Got multi-event request from queue with {len(records)} messages")
            lastException = None
            alertErrMsg = None
            fileTrackingId = None
            for record in records:
                logging.info(f"UpdateAndCloseBatchParserLambda record={record}")
                try:
                    sbody = record.get('body')
                    if isinstance(sbody, str):
                        body = json.loads(sbody)
                    else:
                        body = sbody
                    messageId = record.get('messageId')
                    messageReceiptHandle = record.get('receiptHandle')
                    fileTrackingId = body.get('fileTrackingId')
                    startingRecordNumber = body.get('startingRecordNumber')
                    self.service.processBatchParseRequest(self.requestContext, fileTrackingId, startingRecordNumber)
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except LambdaValidationException as lve:
                    alertErrMsg = f"LambdaValidationException trying to process fileTrackingId={fileTrackingId}: {lve}"
                    # Raise alert but do not retry batch
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except Exception as e:
                    alertErrMsg = f"Unexpected exception trying to process fileTrackingId={fileTrackingId}: {e}"
                    traceback.print_tb(sys.exc_info()[2])
                    # Raise alert and retry batch (i.e. don't delete message from queue)
                    lastException = e
                # Continue on to next record regardless of failure of one message
                
            if lastException is not None:
                # Tells lambda to retry, also raises alert from LambdaBase
                raise lastException
            elif alertErrMsg is not None:
                # No retry but raise alert anyway
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=alertErrMsg)
        
        
    def _markMessageComplete(self, messageId, messageReceiptHandle):
        '''
        Deletes a message from the queue because we successfully processed it
        '''
        if isBlank(messageId) or isBlank(messageReceiptHandle):
            logging.warning("Not deleting message from queue because no messageId or messageReceiptHandle")
            return
        batchSubmitterQueueUrl = UpdateAndCloseBatchParserLambda.environDict[envVblNames.ENV_UPDATEANDCLOSEBATCHPARSER_QUEUE_URL]
        if self.batchParserSqsHelper is None:
            regionName = UpdateAndCloseBatchParserLambda.environDict.get(envVblNames.ENV_SQS_REGION)
            self.batchParserSqsHelper = SqsHelper(batchSubmitterQueueUrl, regionName=regionName)
        logging.info(f"Delete message from queue {batchSubmitterQueueUrl}: messageId={messageId} messageReceiptHandle={messageReceiptHandle}")
        self.batchParserSqsHelper.deleteOneMessageFromQueue(messageReceiptHandle)
        logging.info("Back from deleteOneMessageFromQueue")
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = UpdateAndCloseBatchParserLambda.get_handler(...)