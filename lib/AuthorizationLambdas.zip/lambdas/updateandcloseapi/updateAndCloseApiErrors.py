'''
Created on Feb 14, 2020

@author: VanCampK
'''

FAILREC_INVALID_COUNTRY_CODE = "Expected an ISO 2-Alpha country code"
FAILREC_INVALID_TYPE_CODE = "Not a valid type code for this element"
FAILREC_INVALID_RESEARCH_SUBTYPE = "The provided research subtype does not match any of the case original research subtypes"
FAILREC_INVALID_SUBRESOLUTION_CODE = "Not a valid subresolution code for the supplied resolution code"
FAILREC_INVALID_SUBRESOLUTION_CODE_FOR_RSCHSUBTYPE = "Not a valid subresolution code for the research subtype"
FAILREC_INVALID_RESOLUTION_CODE_FOR_RSCHSUBTYPE = "Not a valid resolution code for the research subtype"
