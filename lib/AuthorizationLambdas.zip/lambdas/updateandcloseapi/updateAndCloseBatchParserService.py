'''
Created on Apr 24, 2020

@author: VanCampK
'''
import json
import logging
import os
import pymysql
from zipfile import ZipFile

from common import envVblNames
from common.batchStatusCodes import BatchStatusCode
from common import updateEventConstants
from common.dao.fileTrackingDao import FileTrackingDao
from common.dao.updateEventDao import UpdateEventDao
from common.dao.partnerDetailDao import PartnerDetailDao
from common.model.partnerDetail import PartnerDetail
from common.encoders import DecimalAsFloatEncoder
from common.partnerFileType import PartnerFileType
from common.processResultCodes import ProcessResultCode
from common.processStatusCodes import ProcessStatusCode
from common.rejectionReasonCodes import RejectionReasonCode
from common.updateActionCodes import UpdateActionCode
from common.util.s3Helper import S3Helper
from common.util.sqsHelper import SqsHelper
from common.util.stringUtils import isBlank
from lambdas import errorMessages
from lambdas.exceptions import LambdaValidationException, LambdaProcessingException, LambdaAuthenticationException
from lambdas.lambdaCommon import buildLambdaSecureInvokeEvent
from lambdas.loginSessionDao import LoginSessionDao
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.updateandcloseapi.batchRecord import BatchRecord
from lambdas.updateandcloseapi.requestRecord import RequestRecord
import lambdas.updateandcloseapi.updateAndCloseApiFields as apiFields
from lambdas.util.cloudServicesHelper import CloudServicesHelper


class UpdateAndCloseBatchParserService(object):
    '''
    Service to parse and distribute an incoming UpdateAndClose batch request file.
    '''
    MODULE_NAME = "UpdateAndCloseBatchParser"
    LOCAL_DIRECTORY = '/tmp/'
    EXIT_WHEN_MILLISECS_LEFT = 10000
    REQUEST_JSON_FILE = "records.json"


    def __init__(self, dbConn, lambdaClient):
        self.dbConn = dbConn
        self.s3Helper = None
        self.fileTrackingDao = None
        self.updateEventDao = None
        self.updateAndCloseSqsHelper = None
        self.updateAndCloseBatchParserSqsHelper = None
        self.cloudServicesHelper = None
        self.loginSessionDao = None
        self.lambdaClient = lambdaClient
        self.partnerDetailDao = None
        
        
    def processBatchParseRequest(self, requestContext, fileTrackingId, startingRecordNumber):
        self._createServices()
        stpPartnerDeliveryFile = self.fileTrackingDao.queryPartnerFileByTrackingId(self.dbConn, fileTrackingId)
        if stpPartnerDeliveryFile is None:
            errmsg = f"Cannot process message on unknown fileTrackingId={fileTrackingId}"
            logging.error(errmsg)
            raise LambdaProcessingException(errmsg)

        batchRecord = BatchRecord()
        batchRecord.stpPartnerDeliveryFile = stpPartnerDeliveryFile
        batchRecord.startingRecordNumber = startingRecordNumber
        try:
            self._processBatchParseRequestImpl(requestContext, batchRecord)
        except LambdaValidationException as lve:
            # Non-retryable validation error, mark batch as rejected so sender is notified in response file
            logging.error(f"Reject batch due to validation error {lve}")
            batchRecord.stpPartnerDeliveryFile.rejectErrorText = lve.errmsg
            batchRecord.stpPartnerDeliveryFile.batchProcessStatusCode = BatchStatusCode.REJECTED.value
            self._updateBatchStatus(requestContext, batchRecord)
        except LambdaAuthenticationException as lae:
            # Non-retryable validation error, mark batch as rejected so sender is notified in response file
            logging.error(f"Reject batch due to authentication error {lae}")
            batchRecord.stpPartnerDeliveryFile.rejectErrorText = lae.errmsg
            batchRecord.stpPartnerDeliveryFile.batchProcessStatusCode = BatchStatusCode.REJECTED.value
            self._updateBatchStatus(requestContext, batchRecord)
        # Any other exception type propagates out so batch is retried
            

    def _processBatchParseRequestImpl(self, requestContext, batchRecord):
        stpPartnerDeliveryFile = batchRecord.stpPartnerDeliveryFile
        self._checkForValidDeliveryFile(stpPartnerDeliveryFile)
        self.cloudServicesHelper.establishSessionForIncomingStpUser(self.dbConn, requestContext, stpPartnerDeliveryFile.apiApplicationEntitlement, self.loginSessionDao, self.lambdaClient)
        
        self._unpackRequestFile(requestContext, batchRecord)
        stpPartnerDeliveryFile.recordCount = 0
        stpPartnerDeliveryFile.rejectRecordCount = 0
        nSkipped = 0
        with open(batchRecord.localFileName) as fp:
            try:
                line = fp.readline()
                while line:
                    if isBlank(line):
                        logging.warning(f"Skipping blank line after record {stpPartnerDeliveryFile.recordCount}")
                        nSkipped += 1
                    else:
                        stpPartnerDeliveryFile.recordCount += 1
                        requestRecord = self._createRequestRecord(line, stpPartnerDeliveryFile)
                        if requestRecord.isRejected():
                            stpPartnerDeliveryFile.rejectRecordCount += 1
                        batchRecord.requestRecords.append(requestRecord)
                    line = fp.readline()
            except Exception as e:
                # Should only happen if error reading file
                errmsg = f"processBatchParseRequest: Caught exception processing file at recCnt={stpPartnerDeliveryFile.recordCount} (after skipping {nSkipped}): {e}"
                logging.error(errmsg)
                raise LambdaProcessingException(errmsg)
            
        logging.info(f"processBatchParseRequest: of {stpPartnerDeliveryFile.recordCount} records, {stpPartnerDeliveryFile.rejectRecordCount} rejected and {nSkipped} skipped.")
        logging.info(f"processBatchParseRequest: remove local file {batchRecord.localFileName}")
        try:
            os.remove(batchRecord.localFileName)
            logging.info("processBatchParseRequest: Back from removeing local file")
        except Exception as e:
            logging.warning("processBatchParseRequest: Failed to remove local file")
            
        if stpPartnerDeliveryFile.recordCount == 0:
            logging.error(f"processBatchParseRequest: {errorMessages.ERR_FILE_HAS_NO_RECORDS}")
            raise LambdaValidationException(errorMessages.ERR_FILE_HAS_NO_RECORDS)
        else:
            self._submitBatch(requestContext, batchRecord)
                
        
    def _createServices(self):
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
        if self.fileTrackingDao is None:
            self.fileTrackingDao = FileTrackingDao()
        if self.updateEventDao is None:
            self.updateEventDao = UpdateEventDao()
        if self.cloudServicesHelper is None:
            self.cloudServicesHelper = CloudServicesHelper()
        if self.loginSessionDao is None:
            self.loginSessionDao = LoginSessionDao()
            
            
            
    def _checkForValidDeliveryFile(self, stpPartnerDeliveryFile):
        '''
        Checks for a valid UAC request file and raises a LambdaProcessingException if an internal error, or a LambdaValidationException if the error should be reported to the sender.
        '''
        if stpPartnerDeliveryFile.processStatusCode != ProcessStatusCode.PROCESSING_COMPLETE.value \
                or stpPartnerDeliveryFile.processResultCode != ProcessResultCode.FILE_AVAILABLE.value \
                or stpPartnerDeliveryFile.batchProcessStatusCode != BatchStatusCode.RECEIVED.value:
            errmsg = f"UpdateAndClose partner delivery file is not in correct status to be processed: \
                        Expected processStatusCode={ProcessStatusCode.PROCESSING_COMPLETE.value} \
                        processResultCode={ProcessResultCode.FILE_AVAILABLE.value} \
                        batchProcessStatusCode={BatchStatusCode.RECEIVED.value} \
                        actual: {stpPartnerDeliveryFile}"
            logging.error(errmsg)
            raise LambdaProcessingException(errmsg)
        fileName = stpPartnerDeliveryFile.s3Object.fileName
        uacFileType = PartnerFileType.UPDATE_AND_CLOSE_REQUEST.value["fileTypeCode"]
        #uacFilePrefix = PartnerFileType.UPDATE_AND_CLOSE_REQUEST.value["fileNamePrefix"]
        if stpPartnerDeliveryFile.fileTypeCode != uacFileType or not fileName.lower().endswith(".zip"):
            errmsg = f"{errorMessages.ERR_FILE_NAME_INCONSISTENT} Filename={fileName} does not have expected suffix .zip"
            logging.error(errmsg)
            raise LambdaValidationException(errmsg)
            
            
    def _unpackRequestFile(self, requestContext, batchRecord):
        zipLocalFileName = UpdateAndCloseBatchParserService.LOCAL_DIRECTORY + batchRecord.stpPartnerDeliveryFile.s3Object.fileName
        logging.info(f"processBatchParseRequest: Ready to process {batchRecord.stpPartnerDeliveryFile}, copy from S3 to localFileName={zipLocalFileName} ...")
        self.s3Helper.copyFromS3ToLocal(batchRecord.stpPartnerDeliveryFile.s3Object, zipLocalFileName)
        #batchRecord.localFileName = UpdateAndCloseBatchParserService.LOCAL_DIRECTORY + UpdateAndCloseBatchParserService.REQUEST_JSON_FILE
        with ZipFile(zipLocalFileName, 'r') as zipfl: 
            zipInfoList = zipfl.infolist()
            hasRequestJson = False
            logging.info(f"File {zipLocalFileName} contains:")
            for fi in zipInfoList:
                logging.info(f"  filename={fi.filename} date_time={fi.date_time} file_size={fi.file_size} compress_size={fi.compress_size}")
                if fi.filename == UpdateAndCloseBatchParserService.REQUEST_JSON_FILE:
                    hasRequestJson = True
            if not hasRequestJson:
                errmsg = f"{errorMessages.ERR_ZIPFILE_MISSING_REQUEST_JSON} Filename={batchRecord.stpPartnerDeliveryFile.s3Object.fileName}"
                logging.error(errmsg)
                raise LambdaValidationException(errmsg)
            logging.info(f"Extraction {UpdateAndCloseBatchParserService.REQUEST_JSON_FILE} from {zipLocalFileName} into path={UpdateAndCloseBatchParserService.LOCAL_DIRECTORY}")
            batchRecord.localFileName = zipfl.extract(UpdateAndCloseBatchParserService.REQUEST_JSON_FILE, path=UpdateAndCloseBatchParserService.LOCAL_DIRECTORY)
            logging.info(f"Extracted into {batchRecord.localFileName}")
        
            
    def _createRequestRecord(self, line, stpPartnerDeliveryFile):
        requestRecord = RequestRecord()
        try:
            requestRecord.recordNumber = stpPartnerDeliveryFile.recordCount
            requestRecord.partnerFileTrackingId = stpPartnerDeliveryFile.partnerFileTrackingId
            requestRecord.updateAndCloseRequest = json.loads(line)
        except Exception as e:
            logging.error(f"{errorMessages.ERR_INVALID_JSON} Error parsing record # {stpPartnerDeliveryFile.recordCount} e={e} line={line}")
            reqRejErrObj = RequestRejectionError(None, errorMessages.ERR_INVALID_JSON, line)
            requestRecord.updateAndCloseRequest = line
            requestRecord.addRejection(reqRejErrObj, RejectionReasonCode.VALIDATION_ERROR)
        return requestRecord
            
            
    def _submitBatch(self, requestContext, batchRecord):
        nSubmitted = 0
        nError = 0
        nRemaining = len(batchRecord.requestRecords)
        nSkipped = 0
        updateAndCloseQueueUrl = requestContext.environDict.get(envVblNames.ENV_UPDATEANDCLOSE_QUEUE_URL)
        for requestRecord in batchRecord.requestRecords:
            if batchRecord.startingRecordNumber is not None and requestRecord.recordNumber < batchRecord.startingRecordNumber:
                logging.info(f"Skipping over record {requestRecord.recordNumber} because startingRecordNumber={batchRecord.startingRecordNumber}")
                nSkipped += 1
                nRemaining -= 1
                continue
            timeLeft = requestContext.lambdaContext.get_remaining_time_in_millis()
            logging.info(f"_submitBatch: Time left {timeLeft} milliseconds with {nRemaining} records remaining to be submitted.")
            if timeLeft < UpdateAndCloseBatchParserService.EXIT_WHEN_MILLISECS_LEFT:
                logging.warning(f"_submitBatch: Out of time, pushing message to queue to resume at record {requestRecord.recordNumber}")
                self._abortBatchSubmission(requestContext, batchRecord, requestRecord.recordNumber)
                logging.warning(f"_submitBatch INCOMPLETE: {nSubmitted} requests submitted to UpdateAndClose, {nSkipped} skipped and {nError} errors, and {nRemaining} remaining to be submitted.")
                return
            nRemaining -= 1
            isOk = False
            if requestRecord.isRejected():
                # Directly insert the partner detail reject record
                self._storeRejectDetail(requestContext, requestRecord)
            else:
                isOk = self._submitOneRequest(requestContext, requestRecord, updateAndCloseQueueUrl, batchRecord)
            if isOk:
                nSubmitted += 1
            else:
                nError += 1
                
        logging.info(f"_submitBatch complete: {nSubmitted} requests submitted to UpdateAndClose, {nSkipped} skipped, and {nError} errors, and {nRemaining} remaining to be submitted.")
        batchRecord.stpPartnerDeliveryFile.batchProcessStatusCode = BatchStatusCode.PARSED.value
        self._updateBatchStatus(requestContext, batchRecord)
        
        
    def _submitOneRequest(self, requestContext, requestRecord, updateAndCloseQueueUrl, batchRecord):
        try:
            if self.updateAndCloseSqsHelper is None:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                self.updateAndCloseSqsHelper = SqsHelper(updateAndCloseQueueUrl, regionName=regionName)
                
            uacMessage = self._createOutgoingUpdateAndCloseRequest(requestRecord, batchRecord)
            eventSecureInvokeMsg = buildLambdaSecureInvokeEvent(requestContext.userSession.principalId, 'POST', '/updateandcloseapi', uacMessage)
            outgoingBody = json.dumps(eventSecureInvokeMsg)
            logging.info(f"_submitOneRequest posting msg to queue {updateAndCloseQueueUrl} for recordNumber {requestRecord.recordNumber}: outgoingBody startswith {outgoingBody[0:100]}")
            logging.debug(f"  full outgoingBody={outgoingBody}")
            queueResp = self.updateAndCloseSqsHelper.sendMessageToQueue(outgoingBody)
            messageId = queueResp.get('MessageId')
            logging.info(f"_submitOneRequest: messageId={messageId} queueResp={queueResp}")
            if messageId is not None:
                return True
        except Exception as e:
            logging.error('Failed to _submitOneRequest: e=' + str(e))
            # TODO abort or retry?
            
        return False


    def _createOutgoingUpdateAndCloseRequest(self, requestRecord, batchRecord):
        uacMessage = requestRecord.updateAndCloseRequest
        # Add a couple of extra fields for batch processing
        uacMessage[apiFields.UAC_FLD_TRACKING_ID] = batchRecord.stpPartnerDeliveryFile.fileTrackingId
        uacMessage[apiFields.UAC_FLD_PARTNER_TRACKING_ID] = batchRecord.stpPartnerDeliveryFile.partnerFileTrackingId
        uacMessage[apiFields.UAC_FLD_RECORD_NUMBER] = requestRecord.recordNumber
        return uacMessage
        

    def _abortBatchSubmission(self, requestContext, batchRecord, startingRecordNumber):
        '''
        Batch was partially submitted due to ran out of time. We send a message back to self to continue where we left off.
        '''
        batchContinuationMessage = {
            "fileTrackingId": batchRecord.stpPartnerDeliveryFile.fileTrackingId,
            "startingRecordNumber": startingRecordNumber,
            "source": "UpdateAndCloseBatchParser"
        }
        try:
            updateAndCloseBatchParserQueueUrl = requestContext.environDict.get(envVblNames.ENV_UPDATEANDCLOSEBATCHPARSER_QUEUE_URL)
            if self.updateAndCloseBatchParserSqsHelper is None:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                self.updateAndCloseBatchParserSqsHelper = SqsHelper(updateAndCloseBatchParserQueueUrl, regionName=regionName)
                 
            outgoingBody = json.dumps(batchContinuationMessage, cls=DecimalAsFloatEncoder)
            logging.info(f"_abortBatchSubmission posting msg to queue {updateAndCloseBatchParserQueueUrl}: outgoingBody={outgoingBody}")
            queueResp = self.updateAndCloseBatchParserSqsHelper.sendMessageToQueue(outgoingBody)
            messageId = queueResp.get('MessageId')
            logging.info(f"_abortBatchSubmission: messageId={messageId} queueResp={queueResp}")
        except Exception as e:
            logging.error(f"Failed to _abortBatchSubmission: e={e}")
            # Propagate exception so alert is raised and AWS retries
            raise e


    def _updateBatchStatus(self, requestContext, batchRecord):
        self.fileTrackingDao.updatePartnerFileTracking(self.dbConn, batchRecord.stpPartnerDeliveryFile, UpdateAndCloseBatchParserService.MODULE_NAME)
        self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_FILE_TRACKING_TABLE,
                                        batchRecord.stpPartnerDeliveryFile.partnerFileTrackingId, updateEventConstants.AUDIT_ELEMENT_PARTNER_FILE_TRACKING_STATUS,
                                        batchRecord.stpPartnerDeliveryFile.batchProcessStatusCode, batchRecord.stpPartnerDeliveryFile.batchProcessStatusCode, UpdateActionCode.MODIFY.value, None,
                                        None, None, UpdateAndCloseBatchParserService.MODULE_NAME)


    def _storeRejectDetail(self, requestContext, requestRecord):
        if self.partnerDetailDao is None:
            self.partnerDetailDao = PartnerDetailDao()
        partnerDetail = self._createRejectPartnerDetail(requestContext, requestRecord)
        try:
            self.partnerDetailDao.insertPartnerDetail(self.dbConn, partnerDetail, UpdateAndCloseBatchParserService.MODULE_NAME)
        except pymysql.err.IntegrityError as e:
            if e.args[0] == 1062:    # (1062, "Duplicate entry '14-1' for key 'ptnr_detl_ie1'")
                logging.warning(f"_storeDetail failed on duplicate entry (ignoring as duplicate message processing partnerFileTrackingId={partnerDetail.partnerFileTrackingId} recordNumber={partnerDetail.recordNumber})")
            else:
                # Anything else gets raised and alerted on
                logging.error(f"_storeDetail failed: {e}")
                raise
        
        
    def _createRejectPartnerDetail(self, requestContext, requestRecord):
        pd = PartnerDetail()
        pd.partnerFileTrackingId = requestRecord.partnerFileTrackingId
        pd.recordNumber = requestRecord.recordNumber
        pd.rawDataObject = requestRecord.updateAndCloseRequest
        pd.subjectResearchId = requestRecord.subjectResearchId
        pd.rejectionIndicator = 1
        pd.partnerRequestRejectionObject = requestRecord.requestRejectionErrorsToDict()
        return pd
