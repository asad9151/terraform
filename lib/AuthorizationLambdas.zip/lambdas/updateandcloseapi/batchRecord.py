'''
Created on Jun 8, 2019

@author: VanCampK
'''

class BatchRecord(object):
    '''
    Holds information about one UpdateAndClose batch
    '''


    def __init__(self):
        self.stpPartnerDeliveryFile = None      # Incoming partner file
        self.sessionToken = None                # user session token, aka dnb_jti_val
        self.authPrinIdObj = None               # user session auth_prin_id_obj
        self.userId = None                      # user who submitted the batch
        self.localFileName = None               # Locally stored name of the request or response file
        self.requestRecords = []                # Array of RequestRecord
        self.startingRecordNumber = None        # Optional record# to start processing (if continuing from a previous incomplete run)
        self.isParseInProgress = False          # Used internally to track current state of parsing
        self.outgoingStpPartnerDeliveryFile = None  # Outgoing partner file
        self.localDirectoryName = None          # Directory of locally stored temporary files
        self.localRecordsFileName = None        # Locally stored path to records.json file
        