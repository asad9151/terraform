'''
Created on Feb 13, 2020
Field name constants for UpdateAndClose API

@author: VanCampK
'''

# Common fields in all requests
ALL_FLD_SUBJECT_RESEARCH_ID = "subjectResearchId"
ALL_FLD_RESEARCH_TYPE_CODE = "researchTypeCode"
ALL_FLD_RESEARCH_SUBTYPE_CODE = "researchSubTypeCode"

# Common fields in both UpdateAndClose and UpdateResearchResults schemas
BOTH_UAC_URR_FLD_RESEARCH_RESULT = "researchResult"
BOTH_UAC_URR_FLD_CONTACT_ENTRY = "contactEntry"

# Common fields in both UpdateAndClose and TakeCaseAction schemas
BOTH_UAC_TCA_FLD_RESEARCH_COMMENT = "researchComment"
BOTH_UAC_TCA_FLD_RESOLUTION_CODE = "resolutionCode"
BOTH_UAC_TCA_FLD_SUB_RESOLUTION_CODE = "subResolutionCode"

# Fields only in the incoming UpdateAndClose schema
UAC_FLD_RESEARCH_RESULT_RESEARCH_ID = "subjectResearchId"   # Special: do not pass thru even if provided
UAC_FLD_RESOLUTIONS = "researchResolutions"
UAC_FLD_IS_VALIDATION_ONLY = "isValidationOnly"
UAC_FLD_TRACKING_ID = "fileTrackingId"
UAC_FLD_PARTNER_TRACKING_ID = "partnerFileTrackingId"
UAC_FLD_RECORD_NUMBER = "recordNumber"

# Fields only in the outgoing UpdateResearchResults schema
#URR_FLD_

# Fields only in the outgoing TakeCaseAction schema
TCA_FLD_ACTION_TYPE_CODE = "actionTypeCode"
TCA_FLD_RES_TYPE_IDENTIFIER = "researchTypesEntryIdentifier"
TCA_FLD_RESOLUTIONS = "resolutions"

# Fields from database record
DB_FLD_SUBJECT_RESEARCH = "subj_rsch_obj"
DB_FLD_RESEARCH_TYPES = "researchTypes"
DB_FLD_SUBMITTED_DATA = "submittedData"
