'''
Created on April 1, 2020

@author: MorganB
'''

from lambdas.lambdaBase import LambdaBase
from lambdas.missingEventMonitor.missingSTPEventMonitor import missingSTPEventMonitor
from lambdas.missingEventMonitor.missingEventMonitorDao import missingEventMonitorDao
from lambdas.missingEventMonitor.missingEventMonitorSendMsg import missingEventSendMsg 
from lambdas.missingEventMonitor.stuckBatchAndRequestsMonitor import StuckBatchOrRequestMonitor
from lambdas.missingEventMonitor.stuckPartnerCasesMonitor import StuckPartnerCasesMonitor
import logging


class missingEventMonitoringServiceLambda(LambdaBase):
    
    def __init__(self):
        super().__init__()
        self.stuckPartnerCaseService = None
        self.stuckInReceivedBatchorRequestService = None
            
    def exitOnTimerEvent(self):
        logging.debug("*********exitTimerEvent**********")
        return False
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return True
    
    def handleRequest(self):
        LambdaBase.raiseAlertWhenRequestFails = True
        try:
            dbObj = missingEventMonitorDao(self.dbConn, self.environDict) 
        except Exception as e:
            logging.error ('missingEventMonitorLambda - unable to connecting to database.  Error = %s', e)
            raise
        if self.stuckPartnerCaseService is None:
            self.stuckPartnerCaseService = StuckPartnerCasesMonitor(dbObj, self.environDict)
        if self.stuckInReceivedBatchorRequestService is None:
            self.stuckInReceivedBatchorRequestService = StuckBatchOrRequestMonitor(dbObj, self.environDict)
        
        ### checking for problems coming back from STP
        try:
            stpMonitor = missingSTPEventMonitor(dbObj,self.environDict) 
            errorMsgList = stpMonitor.processingMissingResponses()
            if errorMsgList == None:
                logging.info('missingEventMonitorLambda... no STP events to present')
            else:
                missingEventSendMsg(errorMsgList, self.environDict)
                stpMonitor.markEventsAsProcessed()
        except Exception as e:
            logging.error('missingEventMonitorLambda: processing aborted in STP processing.  Error = %s', e)
            raise

        ### Check for stuck (stuck in URL ISSUED attachment status) partner cases
        try:
            self.stuckPartnerCaseService.processStuckPartnerCases()
        except Exception as e:
            logging.error('Error occurred while trying to check for stuck Partner Cases.  Error = %s' % e)
            raise
        
        ### Check for stuck in RECEIVED (batch and request status)
        try:
            self.stuckInReceivedBatchorRequestService.processStuckBatchesAndRequests()
        except Exception as e:
            logging.error('Error occurred while trying to check for batches and requests stuck in RECEIVED status.  Error = %s' % e)
            raise
        
        ## go onto the next Event-checking service
        
handler = missingEventMonitoringServiceLambda.get_handler(...)
        