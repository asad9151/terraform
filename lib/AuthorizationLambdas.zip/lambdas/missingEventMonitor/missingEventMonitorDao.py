'''
Created on Oct 11, 2019

@author: MorganB
'''
import logging
import constants
from common.alertTypes import AlertTypeCode
from common.batchStatusCodes import BatchStatusCode
from common.externalStatusCode import ExternalStatusCode
from common.internalStatusCode import InternalStatusCode
from common.processStatusCodes import ProcessStatusCode
from common.encoders import IResearchEncoder
import json

class missingEventMonitorDao(object):
    '''
    classdocs
    '''
    def __init__(self, dbConn, environDict):
        self.dbConn = dbConn
        self.environDict = environDict  
    
    
    def getListOfUnreturnedSTPFiles(self):
        getAllUnreturnedFileSQL = 'select * from attm where DATE_SUB(NOW(),INTERVAL 7 DAY) <= ROW_CRE_TMST AND prcs_stat_cd = %s ;'
        logging.info ('missingEventMonitorDao - DB select for unreturned files sent to STP.  Query is: %s, value: %s', getAllUnreturnedFileSQL, constants.FILE_SUBMITTED_TO_VIRUS_SCAN)
        self.dbConn.cursor.execute(getAllUnreturnedFileSQL,constants.FILE_SUBMITTED_TO_VIRUS_SCAN)
        logging.info ('missingEventMonitorDao - DB call returned from select for unreturned files sent to STP.')
        res = self.dbConn.cursor.fetchall()
        return res
    
    
    def checkForNewEvents(self, eventType,checkIfMsgSentList):
        checkIfMsgIssuedSQL = 'SELECT * FROM alrt_evnt WHERE alrt_typ = %s AND alrt_typ_unq_id = %s ;'
        newEventList = []
        for entry in checkIfMsgSentList:
            parmList = []
            parmList.append(eventType)
            parmList.append(entry)
            logging.info ('missingEventMonitorDao - DB select to see if missing event had been processed.  Query is: %s, value: %s', checkIfMsgIssuedSQL, parmList)
            self.dbConn.cursor.execute(checkIfMsgIssuedSQL,parmList)
            logging.info ('missingEventMonitorDao - DB call returned from the select to see if missing event had been processed.') 
            res = self.dbConn.cursor.fetchall()
            if len(res) == 0:
                newEventList.append(entry)
        return newEventList

    
    def markFilesAsProcessed(self,SqlStatement,valuesList):
        for entry in valuesList:
            try:
                logging.info ('missingEventMonitorDao - DB mark event as processed.  Query is: %s, value: %s', SqlStatement, entry)
                self.dbConn.cursor.execute(SqlStatement,entry)
                logging.info ('missingEventMonitorDao - DB call returned from marking events as processed') 
            except Exception as e:
                logging.error ('missingEventMonitorDao: error inserting record into database.  Error = %s', e)
                logging.error ('missingEventMonitorDao: SQL statement = %s', SqlStatement)
                logging.error ('missingEventMonitorDao: data to be entered = %s', entry)
                raise
            
    def getStuckPartnerCases(self, partnerTeamIdList, timeoutMins):
        query = '''
            select distinct sr.subj_rsch_id, sr.curr_rsch_team_id from subj_rsch sr
            join attm at
            on sr.subj_rsch_id = at.subj_rsch_id or sr.rsch_reqs_id = at.rsch_reqs_id
            where sr.curr_rsch_intrl_stat_cd = %s 
            AND sr.curr_rsch_team_id in (''' + ','.join(map(str, partnerTeamIdList)) + ''')
            and TIMESTAMPDIFF(MINUTE, sr.curr_intrl_stat_tmst, NOW()) >= %s
            and at.prcs_stat_cd = %s
        '''
        params = (InternalStatusCode.RECEIVED.value,
                  timeoutMins,
              ProcessStatusCode.URL_ISSUED.value)
        
        
        self.dbConn.cursor.execute(query, params)
        rv = self.dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)

        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        
        return dict_arry
    
    def getStuckBatches(self, timeoutMins, maxTime):
        '''
        Query will find batch requests stuck in received status for more than 10 minutes but less than 24 hours.  Then,
        the identified stuck batches will be cross-referenced with the the alrt_evnt table to ensure that an alert has
        not already been generated for the stuck batch.  Only batches that have not already had an alert generated will
        be returned in the result set for this query.
        '''
        query = '''
            SELECT BR.btch_reqs_id FROM btch_reqs BR
            WHERE BR.btch_reqs_id NOT IN (SELECT AE.alrt_typ_unq_id FROM alrt_evnt AE WHERE AE.alrt_typ = %s AND alrt_stat_cd = 1)
            AND BR.prcs_stat_cd = %s
            and BR.btch_typ not in ('CFP_INV_BATCH','CFP_LOOKUP_INV_BATCH','CFP_LOOKUP_BATCH','CAMPAIGN_BATCH')
            AND DATE_SUB(NOW(),INTERVAL %s minute) >= BR.stat_tmst
            AND DATE_SUB(NOW(),INTERVAL %s minute) <= BR.stat_tmst;
        '''
        params = (AlertTypeCode.BATCH_STUCK_IN_RECEIVED.value,
                  BatchStatusCode.RECEIVED.value,
                  timeoutMins, maxTime)
        
        
        self.dbConn.cursor.execute(query, params)
        logging.info(f"DB select for batches stuck in received. Query is: %s, value: %s", query, params)
        rv = self.dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)

        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        
        return dict_arry
    
    def getStuckResearchRequests(self, timeoutMins, maxTime):
        '''
        Query will find research requests stuck in received status for more than 30 minutes but less than 24 hours.  Then,
        the identified research requests will be cross-referenced with the the alrt_evnt table to ensure that an alert has
        not already been generated for the stuck request.  Only requests that have not already had an alert generated will
        be returned in the result set for this query.
        '''
        query = '''
            SELECT DISTINCT SR.rsch_reqs_id FROM subj_rsch SR
            WHERE SR.rsch_reqs_id NOT IN (SELECT AE.alrt_typ_unq_id FROM alrt_evnt AE WHERE AE.alrt_typ = %s AND alrt_stat_cd = 1)
            AND SR.curr_rsch_intrl_stat_cd = %s
            AND DATE_SUB(NOW(),INTERVAL %s minute) >= SR.curr_intrl_stat_tmst
            AND DATE_SUB(NOW(),INTERVAL %s minute) <= SR.curr_intrl_stat_tmst;
        '''
        params = (AlertTypeCode.REQUEST_STUCK_IN_RECEIVED.value, 
                  InternalStatusCode.RECEIVED.value,
                  timeoutMins, maxTime)
        
        
        self.dbConn.cursor.execute(query, params)
        logging.info(f"DB select for requests stuck in received. Query is: %s, value: %s", query, params)
        rv = self.dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)

        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        
        return dict_arry
    
    
if __name__ == '__main__':    
    pass