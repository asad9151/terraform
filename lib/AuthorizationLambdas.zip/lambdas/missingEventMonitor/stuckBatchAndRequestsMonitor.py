'''
Created on Aug 14, 2020

@author: GuardiolaR

Event Monitor to generate email alerts for batches or research requests that have been stuck in 
received status for more than 10 minutes.
'''
import logging
from common import envVblNames
from common.alert import Alert
from common.util.applicationConfigHelper import ApplicationConfigHelper
import lambdas.errorMessages as errmsg

class StuckBatchOrRequestMonitor(object):
    alert = None
    applicationConfigHelper = None
    
    MAX_MINUTES_TO_CHECK_STUCKBATCHORREQUESTS = 1440
    
    def __init__(self, dbObj, environDict):
        self.environDict = environDict
        self.dbObj = dbObj
        if self.applicationConfigHelper is None:
            self.applicationConfigHelper = ApplicationConfigHelper(self.environDict)
        if self.alert is None:
            self.alert = Alert(self.environDict)
        self.batchList = []
        self.requestList = []
    
    
    # Used to Determine which Batches and Requests are stuck in RECEIVED status for greater than 10 minutes
    def processStuckBatchesAndRequests(self):
        stuckBatches = self.dbObj.getStuckBatches(self.environDict.get(envVblNames.ENV_STUCK_BATCH_TIMEOUT_MINS), StuckBatchOrRequestMonitor.MAX_MINUTES_TO_CHECK_STUCKBATCHORREQUESTS)
        stuckRequests = self.dbObj.getStuckResearchRequests(self.environDict.get(envVblNames.ENV_STUCK_REQUEST_TIMEOUT_MINS), StuckBatchOrRequestMonitor.MAX_MINUTES_TO_CHECK_STUCKBATCHORREQUESTS)
        if len(stuckBatches) == 0:
            logging.info("No stuck in Received status batches found.")
        elif len(stuckBatches) > 0:
            detailedErrMsg = self._createStuckBatchOrRequestMessageBody(stuckBatches, None)
            self.alert.raiseAlert("missingEventMonitoringServiceLambda", errmsg.ERR_BATCH_STUCK_IN_RECEIVED, detailedErrMsg)
            self.markEventsAsProcessed(stuckBatch=True, stuckRequest=None)
        if len(stuckRequests) == 0:
            logging.info("No stuck in Received status requests found.")
        elif len(stuckRequests) > 0:
            detailedErrMsg = self._createStuckBatchOrRequestMessageBody(None, stuckRequests)
            self.alert.raiseAlert("missingEventMonitoringServiceLambda", errmsg.ERR_REQUEST_STUCK_IN_RECEIVED, detailedErrMsg)
            self.markEventsAsProcessed(stuckBatch=None, stuckRequest=True)
                
                
    def _createStuckBatchOrRequestMessageBody(self, stuckBatches, stuckRequests):
        stuckBatchMessage = None
        stuckRequestMessage = None
        
        if stuckBatches is not None:
            stuckBatchMessage = 'The following batch ids have been stuck in received status for more than 10 minutes:\n\n'
            for batch in stuckBatches:
                stuckBatchMessage += str(batch.get('btch_reqs_id')) + '\n'
                self.batchList.append(batch)
                #logging.info("Stuck Batch: %s" % batch)
            return stuckBatchMessage
        
        if stuckRequests is not None:
            stuckRequestMessage = 'The following request ids have been stuck in received status for more than 30 minutes:\n\n'
            for request in stuckRequests:
                stuckRequestMessage += str(request.get('rsch_reqs_id')) + '\n'
                self.requestList.append(request)
                #logging.info("Stuck Request: %s" % request)
            return stuckRequestMessage
        
    
    def markEventsAsProcessed(self, stuckBatch, stuckRequest):
        trackingRecordSqlStatement = '''INSERT INTO alrt_evnt 
                                        (alrt_tmst,
                                        alrt_typ,  
                                        alrt_typ_unq_id,
                                        alrt_stat_cd, 
                                        alrt_sent_cnt, 
                                        alrt_summ_txt,
                                        alrt_detl_txt,  
                                        row_cre_id,  
                                        row_mod_id) 
                                        VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s)'''
        fullListOfValuesToBePassed = []
        
        if stuckBatch == True:
            self.msgList = self.batchList
        if stuckRequest == True:
            self.msgList = self.requestList
        
        for entry in self.msgList:
            individualUpdateValueList = []
            if stuckBatch == True:
                individualUpdateValueList.append('Stuck Batch')
                individualUpdateValueList.append(entry['btch_reqs_id'])
                individualUpdateValueList.append(1)
                individualUpdateValueList.append(1)
                individualUpdateValueList.append(errmsg.ERR_BATCH_STUCK_IN_RECEIVED)
                individualUpdateValueList.append('batchRequestID: ' + str(entry['btch_reqs_id']) + ' has been stuck in received status for more than 10 minutes.')
                individualUpdateValueList.append('stuckBatchMon')
                individualUpdateValueList.append('stuckBatchMon')
            if stuckRequest == True:
                individualUpdateValueList.append('Stuck Request')
                individualUpdateValueList.append(entry['rsch_reqs_id'])
                individualUpdateValueList.append(1)
                individualUpdateValueList.append(1)
                individualUpdateValueList.append(errmsg.ERR_REQUEST_STUCK_IN_RECEIVED)
                individualUpdateValueList.append('researchRequestId: ' + str(entry['rsch_reqs_id']) + ' has been stuck in received status for more than 10 minutes.')
                individualUpdateValueList.append('stuckRequestMon')
                individualUpdateValueList.append('stuckRequestMon')
            fullListOfValuesToBePassed.append(individualUpdateValueList)
        
        self.dbObj.markFilesAsProcessed(trackingRecordSqlStatement,fullListOfValuesToBePassed)