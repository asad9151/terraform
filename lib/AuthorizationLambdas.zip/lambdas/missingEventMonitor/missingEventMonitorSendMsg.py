'''
Created on Apr 3, 2020

@author: MorganB
'''
from common.SendEmail import SendEmail
import logging

def missingEventSendMsg(msgList, environDict):
    ## the msgList expects a message subject in msgList[0] followed by messages 
    ## the messages will be included in a single email on separate lines
    try:
        emailObj = SendEmail(environDict['smtp_host'], 'iResearchMissingEventReporting@dnb.com')
    except Exception as e:
        logging.error('missingEventMonitorSendEmail - unable to instantiate email class.  Error = %s ',e)
        raise 
    sendList = environDict['stp_mail_list'].split(',')
    
    emailBody = '\n\n'.join(msgList[1:])
    emailObj.send(sendList, msgList[0], emailBody,'plain')
    
    #for msg in msgDict:
    #    emailObj.send(sendList, msgList[0], msg['msgBody'],'plain')


if __name__ == '__main__':
    pass