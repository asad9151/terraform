'''
Created on Oct 1, 2019

@author: MorganB
'''
import logging
import copy
from datetime import datetime
from datetime import timedelta
from irschGUIAuthenticationLambda import environDict

class missingSTPEventMonitor(object):
    '''
    classdocs  
    '''

    def __init__(self,dbObj, environDict ):
        
        self.environDict = environDict
        self.dbObj = dbObj
        self.msgList = []
        
    
    def structureNotifications(self,eventsToReportList): 
        msgSubject = 'Response from STP is beyond the acceptable threshold - ' + self.environDict['environment_name']
        msgList = []
        emailList = []
        errorDict = {}
        emailList.append(msgSubject)
        for event in eventsToReportList:
            errorMsg = f"STP Response overdue.  Attachment with ID: {event['attm_id']}, file name: {event['fle_nme']}, and folder key: {event['fldr_key']} was sent at {event['attm_tmst']} "
            errorDict['msgSubject'] = msgSubject 
            errorDict['msgBody'] = errorMsg
            errorDict['attm_id'] = event['attm_id']
            msgList.append(copy.deepcopy(errorDict))
            emailList.append(copy.deepcopy(errorMsg))
        return msgList, emailList 

    
    def processingMissingResponses(self):
        ## get list of all outstanding attachment files with STP for virus scanning
        missingRespList = self.dbObj.getListOfUnreturnedSTPFiles()
        if len(missingRespList) == 0:
            logging.info('missingSTPEventMonitor: currently no files out to STP for virus scanning')
            return None
        logging.info('missingSTPEventMonitor: count of outstanding files with STP = %s', len(missingRespList))
        
        ## check if the file has been with STP beyond the timeout period 
        checkIfMsgSentList = []
        timeCheck = datetime.now() - timedelta(minutes = int(self.environDict['stp_return_timeout_minutes']))
        for record in missingRespList:
            if record['attm_tmst'] < timeCheck:
                checkIfMsgSentList.append(record['attm_id'])
        if len(checkIfMsgSentList) == 0:
            logging.info('missingSTPEventMonitor: no old files out to STP for virus scanning')
            return None
        logging.info('missingSTPEventMonitor: count of files count with STP where the wait time has expired = %s', len(checkIfMsgSentList))
        
        ## find out if we have already sent a message on this file - get a list of only new events
        newEventList = self.dbObj.checkForNewEvents('Expired Attm Virus Scan',checkIfMsgSentList)
        if len(newEventList) == 0:
            logging.info('missingSTPEventMonitor: no unreported outstanding file out to STP for virus scanning')
            return None
        
        ## hone the list of entries in missing RespList to only those that have not been reported 
        eventsToReportList = []
        for entry in missingRespList:
            if entry['attm_id'] in newEventList:
                eventsToReportList.append(entry)
        if len(eventsToReportList) == 0:
            logging.error('missingSTPEventMonitor: uh-oh... there should always be duplicates between the 2 lists')
            return None
        
        ##generate a list of messages for these missing events that can be processed by common message-send routine    
        self.msgList, emailList = self.structureNotifications(eventsToReportList)
        if len(self.msgList) == 0:
            logging.error('missingSTPEventMonitor: uh-oh... there should always be messages generated if we got this far')
            return None
        
        return emailList
    
    
    
    def markEventsAsProcessed(self):
        trackingRecordSqlStatement = '''INSERT INTO alrt_evnt 
                                        (alrt_tmst,
                                        alrt_typ,  
                                        alrt_typ_unq_id,
                                        alrt_stat_cd, 
                                        alrt_sent_cnt, 
                                        alrt_summ_txt,
                                        alrt_detl_txt,  
                                        row_cre_id,  
                                        row_mod_id) 
                                        VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s)'''
        fullListOfValuesToBePassed = []
        
        for entry in self.msgList:
            individualUpdateValueList = []
            individualUpdateValueList.append('Expired Attm Virus Scan')
            individualUpdateValueList.append(entry['attm_id'])
            individualUpdateValueList.append(1)
            individualUpdateValueList.append(1)
            individualUpdateValueList.append(entry['msgSubject'])
            individualUpdateValueList.append(entry['msgBody'])
            individualUpdateValueList.append('missingSTPEventMon')
            individualUpdateValueList.append('missingSTPEventMon')
            fullListOfValuesToBePassed.append(individualUpdateValueList)
        
        self.dbObj.markFilesAsProcessed(trackingRecordSqlStatement,fullListOfValuesToBePassed)
            
        

        
