'''
Created on June 11, 2020
Mapper function for training media data
Updated: June 16, 2020
@author: GuardiolaR
'''

def mapTrainingMediaSummaryDataResultToSchema(qryResult, trainingMediaId):
    return _transformToSchema(qryResult, trainingMediaId)

def _transformToSchema(qryResult, trainingMediaId):
    '''
    If no trainingMediaId, then request is for trainingMediaData.  
    If there is a trainingMediaId, then request is for specific trainingMediaRecord.
    '''
    if trainingMediaId is None:
        trainingMediaData = []
        for media in qryResult:
            trainingMedia = _transformTrainingMediaDataToSchema(media)
            trainingMediaData.append(trainingMedia)
        data = {}
        data["trainingMediaData"] = trainingMediaData
        return data
    else:
        trainingMediaRecord = {}
        if (len(qryResult) > 0):
            trainingMediaRecord = _transformTrainingMediaDataToSchema(qryResult[0])
        data = {}
        data["trainingMediaRecord"] = trainingMediaRecord
        return data


def _transformTrainingMediaDataToSchema(rec):
    result = {}
    result["trainingMediaId"] = rec.get("trng_mdia_id")
    result["mediaType"] = rec.get("mdia_typ")
    result["mediaTitle"] = rec.get("mdia_nme")
    result["mediaDescription"] = rec.get("mdia_desc_txt")
    result["mediaCategory"] = rec.get("mdia_ctgy_typ")
    result["mediaFileName"] = rec.get("fle_nme")
    result["mediaOrderNumber"] = rec.get("mdia_ordr_nbr")
    result["mediaKeywords"] = rec.get("mdia_kywd_txt")
    result["mediaViewsCount"] = rec.get("mdia_vws_cnt")
    result["mediaVoteRating"] = rec.get("mdia_vte_cnt")
    result["mediaTotalVotes"] = rec.get("mdia_vte_tot_nbr")
    result["lastModifiedTimestamp"] = rec.get("mod_timestamp")
    
    researchUser = _transformResearchUserToSchema(rec)
    if researchUser["researchUserId"]:
        result["researchUser"] = researchUser
    
    return result


def _transformResearchUserToSchema(rec):
    '''
    Returns one researchUser from the record
    '''
    result = {}
    result["researchUserId"] = rec["rsch_usr_id"]
    result["userFirstName"] = rec.get("usr_firs_nme")
    result["userLastName"] = rec.get("usr_lst_nme")
    result["userEmailAddress"] = rec["usr_eml_adr"]
    return result
