'''
Created on Jan 26, 2020

@author: JafferS
'''
from itertools import groupby
import json

def mapBatchRawDataResultToSchema(qryResult):
    return _transformRawDataToSchema(qryResult)

def _transformRawDataToSchema(qryResult):
    batchRawDataRecs = []
    for row in qryResult:
        batchRawData = _transformRow(row)
        batchRawDataRecs.append(batchRawData)
    result = {}
    result["batchRawDataRecs"] = batchRawDataRecs
    return result

def _transformRow(rec):
    details = {}
    rawData = json.loads(rec.get("raw_data_obj"))
    details["recNo"] = rec.get("rec_nbr")
    details["rejectInd"]= rec.get("rej_indc")
    details["rejectDesc"] = rec.get("btch_rsch_reqs_rej_obj")
    data = dict(list(details.items()) + list(rawData.items()))
    
    return data
