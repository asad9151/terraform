'''
Created on Mar 7, 2019

@author: JafferS
'''
import logging
import json
import boto3
from botocore.client import Config
from lambdas.secureLambdaBase import SecureLambdaBase
from buildUIResponse import buildUIResponse
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.retrieveadmindata.service import Service
from common.irschRoles import IResearchRole
from common.irschAdministeredRoles import IResearchAdministeredRole
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaAuthorizationException
import lambdas.errorMessages as errmsg
from common.util.awsUtils import createClientConfiguration


class SvcLambda(SecureLambdaBase):
    '''
    Handler class for RetrieveAdminData service.
    Implementation of a Lambda handler as a class for a specific Lambda function.
    Handler: lambdas.retrieveadmindata.svclambda.handler
    '''

    def __init__(self):
        super().__init__()
        self.service = None
        self.s3Client = None
        self.sqsHelper = None
    
    def handleSecureRequest(self):
        if self.service is None:
            self.service = Service(SvcLambda.dbConn)
        if self.s3Client is None:
            try:
                logging.info('Initializing s3...')
                #self.s3Client = boto3.client('s3', config=Config(signature_version='s3v4'))
                self.s3Client = boto3.client('s3', config=createClientConfiguration(SvcLambda.environDict, mergeConfig=Config(signature_version='s3v4')))
            except Exception as e:
                raise RuntimeError('S3 not configured')
            
        userData = self.service.retrieveUserData(self.requestContext)
        submitterTeamsData = self.service.retrieveSubmitterTeamsData(self.requestContext)
        researchTeamsForSuperAdmin = self.service.retrieveTeamsForSuperAdmin(self.requestContext)
        researchTeamsForLocalAdmin = self.service.retrieveTeamsForLocalAdmin(self.requestContext)
        researchAdminData = self.service.retrieveResearchAdminUser(self.requestContext)
        iResearchAdministeredRoles = self.service.retrieveIResearchAdministeredRoles(self.requestContext)
        IDaaSAdministeredRoles = self.service.retrieveIDaaSAdministeredRoles(self.requestContext)
        batchSummaryData = self.service.retrieveBatchSummary(self.requestContext)
        batchDetailData = self.service.retrieveBatchDetails(self.requestContext)
        batchRawDataURL = self.service.retrieveBatchRawData(self.requestContext, self.s3Client)
        batchPartnerData = self.service.retrieveBatchPartnerData(self.requestContext)
        teamGroupData = self.service.retrieveTeamGroupData(self.requestContext)        
        countryGroupData = self.service.retrieveCountryGroupData(self.requestContext)
        apiEntitlementData = self.service.retrieveApiEntitlementData(self.requestContext)
        apiEntitlementDetail = self.service.retrieveApiEntitlementDetail(self.requestContext)
        userOrganizationData = self.service.retrieveUserOrgsRefData(self.requestContext)
        trainingMediaData = self.service.retrieveTrainingMediaData(self.requestContext)
        trainingMediaRecord = self.service.retriveTrainingMediaRecord(self.requestContext)
        batchPartnerGeneratedRequests = self.service.retrieveBatchPartnerGeneratedRequests(self.requestContext)
        #bannerMessagesData = self.service.retrieveBannerMessagesData(self.requestContext)
        #bannerMessageRecord = self.service.retrieveBannerMessageRecord(self.requestContext)
        maintenanceOutagesData = self.service.retrieveMaintenanceOutagesData(self.requestContext)
        maintenanceOutageRecord = self.service.retrieveMaintenanceOutageRecord(self.requestContext)
                
        combinedData = self.service.combineAdminData(self.requestContext, userData, submitterTeamsData, researchTeamsForSuperAdmin, 
                                                     researchTeamsForLocalAdmin, researchAdminData, iResearchAdministeredRoles, 
                                                     batchSummaryData, batchRawDataURL, batchPartnerData, batchDetailData, IDaaSAdministeredRoles,
                                                     teamGroupData, countryGroupData, apiEntitlementData, apiEntitlementDetail,
                                                     userOrganizationData, trainingMediaData, trainingMediaRecord, batchPartnerGeneratedRequests,
                                                     maintenanceOutagesData, maintenanceOutageRecord)

        responseBody = json.dumps(combinedData)
        return buildUIResponse(LambdaStatusCodes.OK.value, responseBody, 'application/json')


    def authorizeRequest(self):
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_BATCH_SUMMARY, 'false')
        if getUsersOpt.lower() == 'true' and  (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_REVIEWER ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_BATCH_PARTNER_DATA, 'false')
        if getUsersOpt.lower() == 'true' and  (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_REVIEWER ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_BATCH_PARTNER_GENERATED_REQUESTS, 'false')
        if getUsersOpt.lower() == 'true' and  (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_REVIEWER ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_BATCH_RAW_DATA, 'false')
        if getUsersOpt.lower() == 'true' and  (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_REVIEWER ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_BATCH_DETAILS, 'false')
        if getUsersOpt.lower() == 'true' and  (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_ADMIN, IResearchAdministeredRole.IRESEARCH_BATCH_REVIEWER ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_USERS, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_SUBMITTER_TEAMS, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_TEAMS_FOR_LOCAL_ADMIN, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_TEAMS_FOR_SUPER_ADMIN, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN  ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_USER_ADMIN_JSON, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_IRESEARCH_ADMIN_ROLES, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN  ]) == False):
            logging.error('retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_IDAAS_ROLES, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN  ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles for option {Service.QUERY_PARAM_RETRIEVE_IDAAS_ROLES}')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_TEAM_GROUPS, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_COUNTRY_GROUPS, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_API_ENTITLEMENTS, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_API_ENTITLEMENT_DETAIL, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_USER_ORGS, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_TRAINING_MEDIA, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_RETRIEVE_TRAINING_MEDIA_RECORD, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_MAINTENANCE_OUTAGES, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        getUsersOpt = self.requestContext.getLambdaQueryParameter(Service.QUERY_PARAM_MAINTENANCE_OUTAGE_RECORD, 'false')
        if  (getUsersOpt.lower() == 'true' and  checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error(f'retrieveadmindata - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
                                               
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SvcLambda.get_handler(...)