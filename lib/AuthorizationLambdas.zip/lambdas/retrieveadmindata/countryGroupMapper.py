'''
Created on Apr 11, 2019

@author: JafferS
'''
from itertools import groupby

def mapCountryGroupQueryResultToSchema(qryResult):
    groupByCountryGroupDict = _groupByCountryGroup(qryResult)
    return _transformCountryGroupItemsToSchema(groupByCountryGroupDict)

def _groupByCountryGroup(qryResult):
    groups = groupby(qryResult, lambda qryResult: qryResult['rsch_ref_data_id'])
    return groups

def _transformCountryGroupItemsToSchema(groupByCountryGroupDict):
    countryGroupData = []
    for group, Countrys in groupByCountryGroupDict:
        countryGroup = None
        countryList = []
        for Country in Countrys:
            if countryGroup == None:
                countryGroup = _transformCountryGroupToSchema(Country)

            teanData = _transformCountrysToSchema(Country)
            if bool(teanData) is True:
                countryList.append(teanData)
        countryGroupEntry = {
            "countryGroup": countryGroup,
            "countryCodes": countryList
        }
        countryGroupData.append(countryGroupEntry)  
         
    result = {}
    result["countryGroupData"] = countryGroupData
    return result

def _transformCountryGroupToSchema(rec):

    result = {}
    result["countryGroupId"] = rec.get("rsch_ref_data_id")
    result["countryGroupName"] = rec.get("data_nme")
    result["modifiedTimestamp"] = rec.get("mod_timestamp")

    return result

def _transformCountrysToSchema(rec):
    result = {}
    if rec.get("rsch_ref_data_chld_id", None) is not None:
        result["countryCode"] = rec.get("val")
        result["countryName"] = rec.get("geo_nme")
    return result