'''
Created on Jan 27, 2020

@author: JafferS
'''
from itertools import groupby

def mapBatchPartnerGeneratedRequestsToSchema(qryResult):
    groupByPartnerDict = _groupByPartner(qryResult)
    return _transformPartnersToSchema(groupByPartnerDict)

def _groupByPartner(qryResult):
    groups = groupby(qryResult, lambda qryResult: qryResult['partnerName'])
    return groups

def _transformPartnersToSchema(groupByPartnerDict):
    partners = []

    for partner, details in groupByPartnerDict:
        countryGroup = groupby(details, lambda details: details['ctry_code'])
        partnerObj = {}
        partners.append(partnerObj)
        partnerObj["partnerName"] = partner
        countries = []
        partnerObj["countries"] = countries
        for country, itemDataList in countryGroup:
            countryObj = {}
            countries.append(countryObj)
            countryObj["country"] = country
            detailRecs = []
            countryObj["detailRecs"] = detailRecs  

            for detailData in itemDataList:
                if 'hasMarkets' not in partnerObj:
                    if detailData["part_nme"] == None:
                        partnerObj["hasMarkets"] = False
                    else:
                        partnerObj["hasMarkets"] = True
                detailRec = _transformItemDataToSchema(detailData)
                detailRecs.append(detailRec)
    results = {}
    results["batchPartnerGeneratedRequests"] = partners
    return results
                

def _transformItemDataToSchema(rec):

    result = {}
    if rec.get("extl_stat_cd") is not None:
        result["statusCode"] = rec.get("extl_stat_cd", None)
    result["researchRequestId"] = rec.get("rsch_reqs_id", None)
    return result
