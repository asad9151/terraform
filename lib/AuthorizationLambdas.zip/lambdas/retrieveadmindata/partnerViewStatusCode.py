'''
Created on Jan 29, 2020

@author: JafferS
'''
from enum import Enum

class PartnerViewStatusCode(Enum):
    NEW = 0       
    REJECTED = 1
    #The rest of the statuses are the scots batch status codes - BatchStatusCode