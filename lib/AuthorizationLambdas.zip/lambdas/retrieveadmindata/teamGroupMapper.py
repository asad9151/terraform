'''
Created on Apr 11, 2019

@author: JafferS
'''
from itertools import groupby

def mapTeamGroupQueryResultToSchema(qryResult):
    groupByTeamGroupDict = _groupByTeamGroup(qryResult)
    return _transformTeamGroupItemsToSchema(groupByTeamGroupDict)

def _groupByTeamGroup(qryResult):
    groups = groupby(qryResult, lambda qryResult: qryResult['rsch_ref_data_id'])
    return groups

def _transformTeamGroupItemsToSchema(groupByTeamGroupDict):
    teamGroupData = []
    for group, teams in groupByTeamGroupDict:
        teamGroup = None
        teamList = []
        for team in teams:
            if teamGroup == None:
                teamGroup = _transformTeamGroupToSchema(team)

            teanData = _transformTeamsToSchema(team)
            if bool(teanData) is True:
                teamList.append(teanData)
        teamGroupEntry = {
            "teamGroup": teamGroup,
            "teams": teamList
        }
        teamGroupData.append(teamGroupEntry)  
         
    result = {}
    result["teamGroupData"] = teamGroupData
    return result

def _transformTeamGroupToSchema(rec):

    result = {}
    result["teamGroupId"] = rec.get("rsch_ref_data_id")
    result["teamGroupName"] = rec.get("data_nme")
    result["modifiedTimestamp"] = rec.get("mod_timestamp")

    return result

def _transformTeamsToSchema(rec):
    result = {}
    if rec.get("rsch_team_id", None) is not None:
        result["researchTeamId"] = rec.get("rsch_team_id")
        result["researchTeamName"] = rec.get("rsch_team_nme")
        result["researchTeamDisplayName"] = rec.get("rsch_team_dspl_nme")
        result["researchTeamOrganizationName"] = rec.get("rsch_team_org_nme")
    return result