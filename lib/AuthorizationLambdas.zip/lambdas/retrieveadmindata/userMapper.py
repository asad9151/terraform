'''
Created on Mar 10, 2019
Mapper function for list of users

@author: JafferS
'''

def mapUserQueryResultToSchema(qryResult):
    return _transformToSchema(qryResult)

def _transformToSchema(qryResult):
    users = []
    for user in qryResult:
        researchUser = _transformUserToSchema(user, 'RU_')
        users.append(researchUser)
    result = {}
    result["users"] = users
    return result


def _transformUserToSchema(rec, prefix):
    result = {}
    result["researchUserId"] = rec[prefix+"rsch_usr_id"]
    result["userFirstName"] = rec.get(prefix+"usr_firs_nme")
    result["userLastName"] = rec.get(prefix+"usr_lst_nme")
    '''
    result["userEmailAddress"] = rec[prefix+"usr_eml_adr"]
    result["submitterOrganizationName"] = rec.get(prefix+"sbmt_org_nme")
    result["submitterCountryCode"] = rec.get(prefix+"sbmt_ctry_code")
    if rec[prefix+"acte_indc"] == 1:
        result["isActive"] = True
    else:
        result["isActive"] = False
    result["activeIndicatorTimestamp"] = rec.get(prefix+"acte_indc_tmst")
    '''
    result["loginKey"] = rec.get(prefix+"lgin_key")
    return result
