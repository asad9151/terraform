'''
Created on Mar 10, 2019
Mapper function for converting team member data from flat rows into team hierarchy for retrieveInitialData service

@author: VanCampK
'''
from itertools import groupby

def mapTeamQueryResultToSchema(qryResult, fieldName):
    groupByTeamDict = _groupByTeam(qryResult)
    return _transformGroupsToSchema(groupByTeamDict, fieldName)

def _groupByTeam(qryResult):
    '''
    Takes a sorted flat array of team+member and groups it by team#
    '''
    groups = groupby(qryResult, lambda qryResult: qryResult['RT_rsch_team_id'])
    return groups

def _transformGroupsToSchema(groupByTeamDict, fieldName):
    # Transform into final schema names
    teams = []
    for team, members in groupByTeamDict:
        researchTeam = None
        memberList = []
        for member in members:
            # Get the team from the first member
            if researchTeam == None:
                researchTeam = _transformTeamToSchema(member, 'RT_')
                #print('researchTeam:' + str(researchTeam))

            researchUser = _transformMemberToSchema(member, 'RU_')
            if researchUser["researchUserId"]:
                userEntry = {
                    "researchUser": researchUser
                }
                #print('  userEntry:' + str(userEntry))
                memberList.append(userEntry)
        teamEntry = {
            "researchTeam": researchTeam,
            "teamMembers": memberList
        }
        teams.append(teamEntry)
            
    result = {}
    result[fieldName] = teams
    return result

def _transformTeamToSchema(rec, prefix):
    '''
    Returns one researchTeam from the record
    '''
    result = {}
    result["researchTeamId"] = rec[prefix+"rsch_team_id"]
    result["researchTeamOrganizationName"] = rec.get(prefix+"rsch_team_org_nme")
    result["countryCode"] = rec.get(prefix+"ctry_code")
    result["researchTeamName"] = rec[prefix+"rsch_team_nme"]
    result["researchTeamDisplayName"] = rec.get(prefix+"rsch_team_dspl_nme")
    result["modifiedTimestamp"] = rec.get(prefix+"mod_timestamp")
    return result

def _transformMemberToSchema(rec, prefix):
    '''
    Returns one researchUser from the record
    '''
    result = {}
    result["researchUserId"] = rec[prefix+"rsch_usr_id"]
    result["userFirstName"] = rec.get(prefix+"usr_firs_nme")
    result["userLastName"] = rec.get(prefix+"usr_lst_nme")
    result["userEmailAddress"] = rec[prefix+"usr_eml_adr"]
    '''
    result["submitterOrganizationName"] = rec.get(prefix+"sbmt_org_nme")
    result["submitterCountryCode"] = rec.get(prefix+"sbmt_ctry_code")
    if rec[prefix+"acte_indc"] == 1:
        result["isActive"] = True
    else:
        result["isActive"] = False
    result["activeIndicatorTimestamp"] = rec.get(prefix+"acte_indc_tmst")
    '''
    result["loginKey"] = rec.get(prefix+"lgin_key")
    return result
