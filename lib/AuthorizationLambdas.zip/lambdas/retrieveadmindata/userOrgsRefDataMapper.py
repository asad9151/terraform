'''
Created on Apr 11, 2019

@author: JafferS
'''
from itertools import groupby

def mapUserOrgsQueryResultToSchema(qryResult):
    return _transformQueryResultToSchema(qryResult)


def _transformQueryResultToSchema(qryResult):
    userOrganizationData = []
    for rec in qryResult:
        userOrgEntry = _transformResultToSchema(rec)

        userOrganizationData.append(userOrgEntry)  
         
    result = {}
    result["userOrganizationData"] = userOrganizationData
    return result

def _transformResultToSchema(rec):

    result = {}
    result["userOrganizationId"] = rec.get("rsch_ref_data_id")
    result["userOrganization"] = rec.get("data_nme")
    result["modifiedTimestamp"] = rec.get("mod_timestamp")   
    
    return result
