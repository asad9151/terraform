'''
Created on Jan 27, 2020

@author: JafferS
'''
import json

from common.batchType import BatchType
from common.util.stringUtils import isNotBlank

def mapBatchDetailResultToSchema(qryResult):
    return _transformToSchema(qryResult)

def _transformToSchema(qryResult):

    batchDetail = {}
    if (len(qryResult) > 0):
        batchDetail = _transformBatchDetailToSchema(qryResult[0])
    data = {}
    data["batchDetailData"] = batchDetail
    return data


def _transformBatchDetailToSchema(rec):
    result = {}
    result["batchRequestId"] = rec.get("btch_reqs_id")
    result["batchType"] = rec.get("btch_typ")
    if result["batchType"] == BatchType.CAMPAIGN_BATCH.name:
        result["campaignPriority"] = rec.get("cmpgn_prty_cd")
        result["campaignRouting"] = rec.get("cmpgn_rt_cd")
    result["submittedTimestamp"] = rec.get("row_cre_tmst")
    result["totalCount"] = rec["tot_detl_cnt"]
    result["dueTimestamp"] = rec.get("due_date")
    result["batchStatusCode"] = rec.get("prcs_stat_cd")
    result["statusTimestamp"] = rec.get("stat_tmst")
    result["batchRejectReason"] = rec.get("btch_rej_err_txt")
    result["batchRejectReasonComment"] = rec.get("btch_rej_reas_cmnt")
    btch_reqs_obj = rec.get("btch_reqs_obj")
    if isNotBlank(btch_reqs_obj):
        batchAttributes = json.loads(btch_reqs_obj)
        lookupRules = batchAttributes.get("lookupRules")
        if lookupRules is not None and len(lookupRules) > 0:
            result["lookupRule"] = lookupRules[0].get("lookupRule")
        if batchAttributes.get("cfpProjectId") is not None:
            result["cfpProjectId"] = batchAttributes.get("cfpProjectId")
        if batchAttributes.get("cfpTrackingId") is not None:
            result["cfpTrackingId"] = batchAttributes.get("cfpTrackingId")
            
    customerName = rec.get("cust_nme")
    
    researchUser = _transformResearchUserToSchema(rec, 'RU_')
    if researchUser["researchUserId"]:
        result["researchUser"] = researchUser
        if customerName is None:
            customerName = researchUser.get("submitterOrganizationName")
            
    if customerName is not None:
        result["customerName"] = customerName
    
    return result


def _transformResearchUserToSchema(rec, prefix):
    '''
    Returns one researchUser from the record
    '''
    result = {}
    result["researchUserId"] = rec[prefix+"rsch_usr_id"]
    result["userFirstName"] = rec.get(prefix+"usr_firs_nme")
    result["userLastName"] = rec.get(prefix+"usr_lst_nme")
    result["userEmailAddress"] = rec[prefix+"usr_eml_adr"]
    result["submitterOrganizationName"] = rec.get(prefix+"sbmt_org_nme")
    result["loginKey"] = rec.get(prefix+"lgin_key")
    return result