'''
Created on Apr 11, 2019

@author: JafferS
'''
from itertools import groupby

def mapSubmitterTeamQueryResultToSchema(qryResult):
    groupBySubmitterTeamDict = _groupByTeam(qryResult)
    return _transformGroupsToSchema(groupBySubmitterTeamDict)

def _groupByTeam(qryResult):
    '''
    Takes a sorted flat array of submitterteam+member and groups it by submitterteam#
    '''
    groups = groupby(qryResult, lambda qryResult: qryResult['SG_sbms_grp_id'])
    return groups

def _transformGroupsToSchema(groupBySubmitterTeamDict):
    teams = []
    for team, members in groupBySubmitterTeamDict:
        submitterTeam = None
        memberList = []
        for member in members:
            # Get the team from the first member
            if submitterTeam == None:
                submitterTeam = _transformSubmitterTeamToSchema(member, 'SG_')

            researchUser = _transformMemberToSchema(member, 'RU_')
            if researchUser["researchUserId"]:
                userEntry = {
                    "researchUser": researchUser
                }
                memberList.append(userEntry)
        teamEntry = {
            "submitterTeam": submitterTeam,
            "teamMembers": memberList
        }
        teams.append(teamEntry)  
         
    result = {}
    result["submitterTeams"] = teams
    return result

def _transformSubmitterTeamToSchema(rec, prefix):
    '''
    Returns one submitterTeam from the record
    '''
    result = {}
    result["submissionGroupId"] = rec[prefix+"sbms_grp_id"]
    result["submissionGroupName"] = rec.get(prefix+"sbms_grp_nme")
    result["modifiedTimestamp"] = rec.get(prefix+"mod_timestamp")

    return result

def _transformMemberToSchema(rec, prefix):
    '''
    Returns one researchUser from the record
    '''
    result = {}
    result["researchUserId"] = rec[prefix+"rsch_usr_id"]
    result["userFirstName"] = rec.get(prefix+"usr_firs_nme")
    result["userLastName"] = rec.get(prefix+"usr_lst_nme")
    result["userEmailAddress"] = rec[prefix+"usr_eml_adr"]
    '''
    result["submitterOrganizationName"] = rec.get(prefix+"sbmt_org_nme")
    result["submitterCountryCode"] = rec.get(prefix+"sbmt_ctry_code")
    if rec[prefix+"acte_indc"] == 1:
        result["isActive"] = True
    else:
        result["isActive"] = False
    result["activeIndicatorTimestamp"] = rec.get(prefix+"acte_indc_tmst")
    '''
    result["loginKey"] = rec.get(prefix+"lgin_key")
    return result