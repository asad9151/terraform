'''
Created on APr 11, 2019
DAO for RetrieveAdminData service

@author: JafferS
'''
import json
import csv
import logging
from common.encoders import IResearchEncoder
from common.researchRefDataTypeCode import ResearchRefDataTypeCode
from common.util.stringUtils import isNotBlank


class RetrieveAdminDataDao(object):
    
    def getSubmitterTeams(self, dbConn):
        query = '''
            select SG.sbms_grp_id as SG_sbms_grp_id, SG.sbms_grp_nme as SG_sbms_grp_nme, UNIX_TIMESTAMP(SG.row_mod_tmst) as SG_mod_timestamp,
            RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme, RU.sbmt_ctry_code as RU_sbmt_ctry_code, RU.acte_indc as RU_acte_indc, RU.acte_indc_tmst as RU_acte_indc_tmst
            from sbms_grp SG
            left join sbmt_sbms_grp SSG
            on SG.sbms_grp_id = SSG.sbms_grp_id
            left join rsch_usr RU
            on SSG.rsch_usr_id = RU.rsch_usr_id
            order by SG.sbms_grp_id, RU.rsch_usr_id
        '''
    
        dbConn.cursor.execute(query)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)
        return dict_arry

    def getUsers(self, dbConn):
        query = '''
            select RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme, RU.sbmt_ctry_code as RU_sbmt_ctry_code, RU.acte_indc as RU_acte_indc, RU.acte_indc_tmst as RU_acte_indc_tmst
            from rsch_usr RU
            where acte_indc=1
        '''
        
        dbConn.cursor.execute(query)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)
        return dict_arry
    
    def getResearchTeamsForSuperAdmin(self, dbConn):
        #Return all teams with only local admins
        query = '''
            select RT.rsch_team_id as RT_rsch_team_id, RT.rsch_team_org_nme as RT_rsch_team_org_nme, RT.ctry_code as RT_ctry_code, RT.rsch_team_nme as RT_rsch_team_nme, RT.rsch_team_dspl_nme as RT_rsch_team_dspl_nme, UNIX_TIMESTAMP(RT.row_mod_tmst) as RT_mod_timestamp, 
            RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme, RU.sbmt_ctry_code as RU_sbmt_ctry_code, RU.acte_indc as RU_acte_indc, RU.acte_indc_tmst as RU_acte_indc_tmst  
            from rsch_team RT
            left join rsch_team_mbr TM 
            on TM.rsch_team_id = RT.rsch_team_id
            and TM.team_admr_indc = 1  
            left join rsch_usr RU 
            on RU.rsch_usr_id = TM.rsch_usr_id
            order by RT.rsch_team_id, RU.rsch_usr_id            
            '''
    
        dbConn.cursor.execute(query)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)
        return dict_arry
    
    def getResearchTeamsForLocalAdmin(self, dbConn, teamNmeList):
        #Return only teams this user is a local admin on and only researchers for those teams
        paramList = []
        query = '''
            select RT.rsch_team_id as RT_rsch_team_id, RT.rsch_team_org_nme as RT_rsch_team_org_nme, RT.ctry_code as RT_ctry_code, RT.rsch_team_nme as RT_rsch_team_nme, RT.rsch_team_dspl_nme as RT_rsch_team_dspl_nme, UNIX_TIMESTAMP(RT.row_mod_tmst) as RT_mod_timestamp, 
            RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme, RU.sbmt_ctry_code as RU_sbmt_ctry_code, RU.acte_indc as RU_acte_indc, RU.acte_indc_tmst as RU_acte_indc_tmst  
            from rsch_team RT
            left join rsch_team_mbr TM 
            on TM.rsch_team_id = RT.rsch_team_id
            and TM.team_admr_indc = 0 
            left join rsch_usr RU 
            on RU.rsch_usr_id = TM.rsch_usr_id  
            where RT.rsch_team_nme in (
            '''
    
        first = True
        for teamNme in teamNmeList:
            paramList.append(teamNme)
            if (first == False):
                query += ','
            query += '%s'
            first = False
                
        query += '''
                )
            order by RT.rsch_team_id, RU.rsch_usr_id
                '''    
        params = tuple(paramList)
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)
        return dict_arry
    
    
    def getBatchDetails(self, dbConn, batchRequestId):
        paramList = []
        query = '''
            select BR.btch_reqs_id, BR.btch_typ, BR.row_cre_tmst, BR.tot_detl_cnt, BR.due_date, BR.prcs_stat_cd, BR.stat_tmst, BR.btch_rej_err_txt, BR.btch_rej_reas_cmnt, BR.cust_nme, BR.cmpgn_prty_cd, BR.cmpgn_rt_cd, BR.btch_reqs_obj,
            RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme 
            from btch_reqs BR
            join rsch_usr RU
            on BR.rsch_usr_id = RU.rsch_usr_id
            where btch_reqs_id = %s
            '''
        paramList.append(batchRequestId)
        params = tuple(paramList)
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)

        return dict_arry
    
    
    def getBatchSummary(self, dbConn, batchStatusList, pageSize, lastIdForPage, batchType, searchString):
        query, paramList = self._getBaseQuery(batchStatusList, pageSize, lastIdForPage, batchType, searchString)
        fullQuery = '''
            select BR.btch_reqs_id, BR.btch_typ, BR.row_cre_tmst, BR.tot_detl_cnt, BR.due_date, BR.prcs_stat_cd, BR.stat_tmst, BR.btch_rej_err_txt, BR.btch_rej_reas_cmnt, BR.cust_nme, BR.cmpgn_prty_cd, BR.cmpgn_rt_cd, BR.btch_reqs_obj,
            RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme 
            '''
        fullQuery += query 
        
        fullQuery += '''
              limit %s
              '''
         
        if pageSize != None:
            paramList.append(pageSize + 1)    
        else:
            paramList.append(200)
#         if batchType != None:
#             paramList.append(batchType)
        
        params = tuple(paramList)
        logging.info(f"getBatchSummary query={fullQuery} params={params}")
        dbConn.cursor.execute(fullQuery, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)
        logging.info(f"getBatchSummary got back {len(dict_arry)} results")

        return dict_arry
    
    
    def getBatchSummaryCount(self, dbConn, batchStatusList, batchType, searchString):
        query, paramList = self._getBaseQuery(batchStatusList, None, None, batchType, searchString)
        countQuery = 'select count(*) as totalRecsAvailable ' + query
        
        params = tuple(paramList)
        logging.info(f"getBatchSummaryCount query={countQuery} params={params}")
        dbConn.cursor.execute(countQuery, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        logging.info(f"getBatchSummaryCount got back {len(dict_arry)} results")
        #self._dumpcsv(dict_arry)
        if len(dict_arry) > 0:
            return dict_arry[0]
        else:
            return None


    def _getBaseQuery(self, batchStatusList, pageSize, lastIdForPage, batchType, searchString):
        paramList = []
        query = '''
            from btch_reqs BR
            join rsch_usr RU
            on BR.rsch_usr_id = RU.rsch_usr_id
            where BR.prcs_stat_cd in (
            '''
    
        first = True
        for batchStatus in batchStatusList:
            paramList.append(batchStatus)
            if (first == False):
                query += ','
            query += '%s'
            first = False
                
        query += ')'
        
        if pageSize != None and lastIdForPage != 0:
            query += ' and BR.btch_reqs_id < %s '
            paramList.append(lastIdForPage)
            
        if batchType != None:
            query += ' and BR.btch_typ = %s'
            paramList.append(batchType)
        
        if isNotBlank(searchString):
            query += ' and MATCH(kywd_txt) AGAINST (%s IN NATURAL LANGUAGE MODE)'
            paramList.append(searchString)
        
        query += '''
              order by BR.btch_reqs_id desc 
              '''
        return query, paramList
    
    
    def getBatchRawData(self, dbConn, batchRequestId):
        paramList = []
        query = '''
            select bd.btch_detl_id, bd.rec_nbr, rec_nbr, raw_data_obj, rej_indc, brr.btch_rsch_reqs_rej_obj
            from btch_detl bd
            left join btch_rsch_reqs_rej brr
            on bd.btch_rsch_reqs_rej_id = brr.btch_rsch_reqs_rej_id
            where bd.btch_reqs_id = %s
            '''
        paramList.append(batchRequestId)
        
        params = tuple(paramList)
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)

        return dict_arry
    
    
    def getBatchPartnerData(self, dbConn, batchRequestId):
        paramList = []
        query = '''
            select bd.btch_detl_id, bd.ctry_code, COALESCE(bd.part_nme, bd.ctry_code) as partnerName, bd.part_nme, bd.rsch_reqs_id,  bd.btch_rsch_reqs_rej_id, rr.extl_stat_cd
            from btch_detl bd
            left join rsch_reqs rr
            on bd.rsch_reqs_id = rr. rsch_reqs_id
            where bd.btch_reqs_id = %s
            order by partnerName, bd.ctry_code
            '''

        paramList.append(batchRequestId)
        
        params = tuple(paramList)
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)

        return dict_arry


    def _dumpcsv(self, dict_arry):
        # Dumps the data to a CSV file for testing/verification
        dict0 = dict_arry[0]
        with open('scotsData.csv', 'w', newline='') as f:
            w = csv.DictWriter(f, dict0.keys())
            w.writeheader()
            w.writerows(dict_arry)
    
            
    def getTeamGroupData(self, dbConn):

        query = '''
            select RD.rsch_ref_data_id, RD.data_nme, RD.data_type, UNIX_TIMESTAMP(RD.row_mod_tmst) as mod_timestamp ,
            RDC.rsch_ref_data_chld_id, RDC.val,
            RT.rsch_team_id, RT.rsch_team_org_nme, RT.rsch_team_nme, RT.rsch_team_dspl_nme 
            from rsch_ref_data RD
            left join rsch_ref_data_chld RDC
            on RD.rsch_ref_data_id = RDC.rsch_ref_data_id
            left join rsch_team RT
            on RDC.val = RT.rsch_team_id
            where RD.data_type = %s;
        '''
        
        params = (ResearchRefDataTypeCode.TEAM_GROUP.value)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry
    
    
    def getCountryGroupData(self, dbConn):

        query = '''
            select RD.rsch_ref_data_id, RD.data_nme, RD.data_type, UNIX_TIMESTAMP(RD.row_mod_tmst) as mod_timestamp ,
            RDC.rsch_ref_data_chld_id, RDC.val,
            gq.geo_nme
            from rsch_ref_data RD
            left join rsch_ref_data_chld RDC
            on RD.rsch_ref_data_id = RDC.rsch_ref_data_id
            left join (
            select GUPN.geo_nme , GUPC.geo_code 
            from geo_unit_code GUPC 
            join geo_unit GUP 
            on GUP.geo_unit_id = GUPC.geo_unit_id
            join geo_unit_nme GUPN on 
            GUPN.geo_unit_id = GUP.geo_unit_id 
            and GUP.expn_dt is null
            and GUP.expd_by_dt is null
            and GUPC.expn_dt is null
            and GUPC.expd_by_dt is null
            and GUPN.expn_dt is null
            and GUPN.expd_by_dt is null
            and GUPN.lang_cd in (331)
            and GUP.geo_unit_typ_cd in (128)
            and GUPC.geo_code_typ_cd in (23416)
            and GUPN.geo_nme_typ_cd in (32) ) as gq
            on gq.geo_code = RDC.val
            where RD.data_type = %s
        '''
        
        params = (ResearchRefDataTypeCode.COUNTRY_GROUP.value)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry
    
    
    def getUserOrgsRefData(self, dbConn):

        query = '''
            select rsch_ref_data_id, data_nme, data_type, UNIX_TIMESTAMP(row_mod_tmst) as mod_timestamp
            from rsch_ref_data
            where data_type = %s
        '''
        
        params = (ResearchRefDataTypeCode.USER_ORGANIZATION.value)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry


    def getTrainingMediaData(self, dbConn, trainingMediaId, mediaCategory):
        paramList = []
        query = '''
            select trng_mdia_id, mdia_typ, mdia_nme, mdia_desc_txt, mdia_ctgy_typ, mdia_ordr_nbr, mdia_kywd_txt, 
            attm.fle_nme, mdia_vte_cnt, mdia_vte_tot_nbr, mdia_vws_cnt, rsch_usr.rsch_usr_id, 
            rsch_usr.usr_eml_adr, rsch_usr.usr_firs_nme, rsch_usr.usr_lst_nme, 
            UNIX_TIMESTAMP(attm.row_mod_tmst) as mod_timestamp from trng_mdia
            inner join attm on trng_mdia.attm_id = attm.attm_id 
            inner join rsch_usr on attm.rsch_usr_id = rsch_usr.rsch_usr_id
        '''
        if trainingMediaId is None and mediaCategory is None:
            query += ';'
            dbConn.cursor.execute(query)
        elif trainingMediaId is not None and mediaCategory is not None:
            query += ' where trng_mdia_id = %s and mdia_ctgy_typ like %s;' 
            paramList.append(trainingMediaId, mediaCategory)
            params = tuple(paramList)
            dbConn.cursor.execute(query, params)
        else:
            if trainingMediaId is not None:
                query += ' where trng_mdia_id = %s'
                paramList.append(trainingMediaId)
            if mediaCategory is not None:
                query += 'where mdia_ctgy_typ like %s'
                paramList.append(mediaCategory)
            query += ';'
            params = tuple(paramList)
            dbConn.cursor.execute(query, params)
        
        
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry
    
    def getBatchPartnerGeneratedRequests(self, dbConn, batchRequestId):
        paramList = []
        query = '''
            select rr.rsch_reqs_id, coalesce(sr.v_dnb_ctry_cd, sr.v_subm_ctry_cd) as ctry_code, extl_stat_cd from rsch_reqs rr
            join subj_rsch sr
            on rr.rsch_reqs_id = sr.rsch_reqs_id
            where rr.btch_reqs_id = %s
            and lnk_typ = 2
            order by ctry_code
        '''
        paramList.append(batchRequestId)
        
        params = tuple(paramList)
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)

        return dict_arry