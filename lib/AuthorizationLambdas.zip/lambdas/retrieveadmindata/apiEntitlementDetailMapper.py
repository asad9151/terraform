'''
Created on Apr 11, 2019

@author: JafferS
'''
from itertools import groupby
import json

def mapApiEntitlementDetailQueryResultToSchema(qryResult):
    detail = {}
    if qryResult is not None:
        detail = _transformResultToSchema(qryResult)
    data = {}
    data["apiEntitlementDetail"] = detail
    return data

def _transformResultToSchema(detail):

    result = {}
    result["apiAppEntitlementId"] = detail.get("api_app_entl_id")
    result["dnbAppId"] = detail.get("dnb_app_id")
    result["appName"] = detail.get("app_nme")
    if detail['api_entl_obj'] is None:
        detail['api_entl_obj']= json.dumps({})
    result["apiEntitlementObj"] = json.loads(detail.get("api_entl_obj"))
    result["requestMethodCode"] = detail.get("reqs_meth_cd")
    result["partnerFolderName"] = detail.get("ptnr_fldr_nme")    
    result["userLoginKey"] = detail.get("rsch_usr_lgin_key")    
    if detail['prcs_optns_obj'] is None:
        detail['prcs_optns_obj']= json.dumps({})
    result["processOptionsObject"] = json.loads( detail.get("prcs_optns_obj") ) 
    result["modifiedTimestamp"] = detail.get("mod_timestamp")
    
    return result
