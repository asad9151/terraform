'''
Created on Mar 30, 2020

@author: JafferS
'''
from common.resolutionTypeCode import ResolutionTypeCode
from common.subResolutionTypeCode import SubResolutionTypeCode
from common.externalStatusCode import ExternalStatusCode
from common.util.dateUtils import isoFormatToDateTime
from common.dao.scotsDao import ScotsDao
from common.scotsTables import ScotsTable
from common.commentTypeCodes import CommentTypeCode
from common.requestMethodCodes import RequestMethodCode

class UpdateSFDCHelper(object):
        
    resolutionMap = None
    subResolutionMap = None
    scotsDao = None
    scots_dict = None
    MINI_INVESTIGATION_TYPE_CODE = 13755
    
    def __init__(self, dbConn):

        if self.scotsDao is None:
            self.scotsDao = ScotsDao()
        if self.scots_dict is None:
            self.scots_dict = self.scotsDao.queryTypeCodesToDescriptions(dbConn)
            
        if self.resolutionMap is None:
            self.resolutionMap = {}
            self.resolutionMap[ResolutionTypeCode.DUNS_ALREADY_EXISTS.value] = 'DUNS Existed'
            self.resolutionMap[ResolutionTypeCode.DUNS_COULD_NOT_BE_CREATED.value] = 'Denied'
            self.resolutionMap[ResolutionTypeCode.DUNS_CREATED.value] = 'DUNS Created'
            self.resolutionMap[ResolutionTypeCode.DATA_WAS_CHANGED_OR_ADDED.value] = 'Updated Multiple Fields of Different Types'
            self.resolutionMap[ResolutionTypeCode.DATA_WAS_CORRECT_SO_NOT_CHANGED.value] = 'No updates made, exact match found'
        if self.subResolutionMap is None:
            self.subResolutionMap = {}
            self.subResolutionMap[SubResolutionTypeCode.REQUIRED_DOCUMENTS_NOT_PROVIDED.value] = 'Insufficient Documentation Provided'
            self.subResolutionMap[SubResolutionTypeCode.INQUIRY_COULD_NOT_BE_COMPLETED.value] = 'Incomplete/Incorrect Info'
            self.subResolutionMap[SubResolutionTypeCode.SUBMITTER_CANCELLED_REQUEST.value] = 'Cancelled'
            self.subResolutionMap[SubResolutionTypeCode.SUBJECT_IS_AN_INDIVIDUAL_NOT_A_BUSINESS.value] = 'Missing Required Data'
            self.subResolutionMap[SubResolutionTypeCode.BUSINESS_HAS_NOT_STARTED_OPERATIONS.value] = 'Missing Required Data'
            self.subResolutionMap[SubResolutionTypeCode.INSUFFICIENT_INFO_PROVIDED.value] = 'Missing Required Data'
            self.subResolutionMap[SubResolutionTypeCode.ADDRESS_IS_OF_AGENT_NOT_OF_SUBJECT.value] = 'Missing Required Data'
            self.subResolutionMap[SubResolutionTypeCode.OUTSIDE_SOURCES_COULD_NOT_CONFIRM_ATTEMPTS_UNSUCCESSFUL.value] = 'Max Attempt'            
            self.subResolutionMap[SubResolutionTypeCode.EXPLANATION_PROVIDED_IN_RESOLUTION_COMMENT.value] = 'Complete'  
                       
    def getResolutionData(self, usageRecord):
        resolutionData = {}
        resolutionData['Resolution_Sub_Area__c'] = ''
        resolutionData['Case_Resolution__c'] = ''
        resolutionData['Subject_Company_Name__c'] = ''
        resolutionData['DBA__c'] = ''
        resolutionData['Physical_Address__c'] = ''  
        resolutionData['Physical_City__c'] = ''
        resolutionData['Physical_State__c'] = ''
        resolutionData['Physical_Zip__c'] = ''
        resolutionData['Subject_Phone__c'] = ''
        resolutionData['Legal_Structure__c'] = ''
        if 'request' in usageRecord:
            request = usageRecord['request']
            if 'cases' in request:
                cases = request['cases']
                for case in cases:
                    if ('researchTypes' in case):
                        researchTypes = case['researchTypes']
                        for researchType in researchTypes:
                            if 'resolutionCode' in researchType and 'subResolutionCode' in researchType:
                                resolutionCode = researchType['resolutionCode']
                                subResolutionCode = researchType['subResolutionCode']
                                if resolutionCode in self.resolutionMap:
                                    resolutionData['Case_Resolution__c'] = self.resolutionMap[resolutionCode]
                                if subResolutionCode in self.subResolutionMap:
                                    resolutionData['Resolution_Sub_Area__c'] = self.subResolutionMap[subResolutionCode]
                    if ('researchResult' in case):
                        result = case['researchResult']
                        if 'organizationName' in result:
                            resolutionData['Subject_Company_Name__c'] = result['organizationName']
                        if 'tradeStyleName' in result:
                            resolutionData['DBA__c'] =  result['tradeStyleName']
                        if 'addresses' in result:
                            addresses = result['addresses']
                            for address in addresses:
                                if 'addressUsageTypeCode' in address and address['addressUsageTypeCode'] == 1114:
                                    if 'streetAddress' in address:
                                        resolutionData['Physical_Address__c'] = address['streetAddress']  
                                    if 'town' in address:
                                        resolutionData['Physical_City__c'] =  address['town']      
                                    if 'territory' in address:
                                        resolutionData['Physical_State__c'] =  address['territory']       
                                    if 'postalCode' in address:
                                        resolutionData['Physical_Zip__c'] =  address['postalCode']
                        if 'organizationPhones' in result and len(result['organizationPhones']) > 0:
                            telephone = result['organizationPhones'][0]
                            isdCode = ''
                            if 'isdCode' in telephone:
                                isdCode = telephone['isdCode']
                            if 'telephone' in telephone:
                                resolutionData['Subject_Phone__c'] =  isdCode + ' ' + telephone['telephone']
                        if 'legalFormDescription' in result:
                            resolutionData['Legal_Structure__c'] = result['legalFormDescription']
                                
        resolutionData['Resolution_Description__c'] = self.getLastResolutionComment(usageRecord)
        return resolutionData
    
    
    def getStatus(self, usageRecord):
        status = None
        if 'request' in usageRecord:
            request = usageRecord['request']
            if 'currentResearchStatusCode' in request:
                currentStatus = request['currentResearchStatusCode']
                if currentStatus == ExternalStatusCode.CLOSED.value:
                    status = 'Completed'
            usage = usageRecord['usage']
            if 'investigationTypeCode' in usage:
                investigationTypeCode = usage['investigationTypeCode']
                if investigationTypeCode == self.MINI_INVESTIGATION_TYPE_CODE:
                    status = 'Returned'
            if 'requestMethodCode' in request:
                requestMethodCode = request['requestMethodCode']
                if requestMethodCode == RequestMethodCode.SFDC_ENTERPRISE.value:
                    status = 'Returned'
        if status is None:
            status = ''
            
        return status
    
    def getResolutionDuns(self, usageRecord):
        resolutionDuns = None
        if 'subject' in usageRecord:
            subject = usageRecord['subject']
            if 'answeredDuns' in subject:
                resolutionDuns = subject['answeredDuns']

        if resolutionDuns is None:
            resolutionDuns = ''
            
        return resolutionDuns
    
    def getCompleteTime(self, usageRecord):
        completionTime = None
        if 'request' in usageRecord:
            request = usageRecord['request']
            if 'researchCompletionTimestamp' in request:
                completionTime = request['researchCompletionTimestamp']
        if completionTime is None:
            completionTime = ''
            
        return completionTime
    
    def composeMainComment(self, usageRecord):
        comment = ''
        scotsDesc = ''
        duns =  self.getResolutionDuns(usageRecord)
        if (duns != ''):
            comment = comment + 'DUNS: ' + duns + '\n'    
        
        if 'request' in usageRecord:
            request = usageRecord['request']
            if 'currentResearchStatusCode' in request:
                currentStatus = request['currentResearchStatusCode']
                scotsDesc = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.EXTERNAL_STATUS.value, currentStatus , langId=None)
                if scotsDesc is None:
                    scotsDesc = ''
                comment = comment + "Research Results: " + scotsDesc + '\n'
            if 'cases' in request:
                cases = request['cases']
                for case in cases:
                    if 'researchTypes' in case:
                        for researchType in case['researchTypes']:
                            if 'resolutionCode' in researchType and 'subResolutionCode' in researchType:
                                resolutionCode = researchType['resolutionCode']
                                subResolutionCode = researchType['subResolutionCode']
                                scotsDesc = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.RESOLUTION.value, resolutionCode, langId=None)
                                if scotsDesc is None:
                                    scotsDesc = ''
                                comment = comment + 'Resolution: ' + scotsDesc + '\n'
                                scotsDesc = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.SUB_RESOLUTION.value, subResolutionCode, langId=None)
                                if scotsDesc is None:
                                    scotsDesc = ''
                                comment = comment + 'Sub_Resolution: ' + scotsDesc + '\n'
                                comment = comment + 'Completion Time: ' + self.getCompleteTime(usageRecord) + ' UTC' + '\n'     
                    if 'researchTeamName' in case:
                        comment = comment + 'Research Team: ' + case['researchTeamName'] + '\n'
                    if 'researcher' in case:
                        researchPerson = case['researcher']
                        if 'userLastName' in researchPerson and 'userFirstName' in researchPerson:
                            comment = comment + 'Researcher Name: ' + researchPerson['userFirstName'] + ' ' + researchPerson['userLastName'] + '\n'
                        if 'userEmailAddress' in researchPerson:                        
                            comment = comment + 'Researcher Email: ' + researchPerson['userEmailAddress'] + '\n'
                    if ('researchResult' in case):
                        result = case['researchResult']
                        if 'organizationName' in result:
                            comment = comment + 'Name: ' + result['organizationName'] + '\n'
                        if 'countryCode' in result:
                            comment = comment + 'Country: ' + result['countryCode'] + '\n'
                        if 'addresses' in result:
                            addresses = result['addresses']
                            for address in addresses:
                                if 'streetAddress' in address:
                                    comment = comment + 'Address: ' + address['streetAddress'] + '\n'     
                                if 'town' in address:
                                    comment = comment + 'City: ' + address['town'] + '\n'         
                                if 'territory' in address:
                                    comment = comment + 'State: ' + address['territory'] + '\n'           
                                if 'postalCode' in address:
                                    comment = comment + 'Zip: ' + address['postalCode'] + '\n'   
                        if 'organizationPhones' in result:
                            telephones = result['organizationPhones']
                            for telephone in telephones:
                                isdCode = ''
                                if 'isdCode' in telephone:
                                    isdCode = telephone['isdCode']
                                if 'telephone' in telephone:
                                    comment = comment + 'Phone: ' + isdCode + ' ' + telephone['telephone'] + '\n'   
        
        return comment
    
    
    def getComments(self, usageRecord, commentTypeCode):
        comments = []  
        
        if 'request' in usageRecord:
            request = usageRecord['request']
            if 'cases' in request:
                cases = request['cases']
                for case in cases:
                    if 'comments' in case:
                        researchComments = case['comments']
                        for comment in researchComments:
                            if 'commentTypeCode' in comment:
                                typeCode = comment['commentTypeCode']
                                if typeCode == commentTypeCode:     
                                    newComment = {}                  
                                    newComment['commentTypeCode'] = typeCode    
                                    if 'researchUser' in comment:
                                        researchPerson = comment['researchUser']
                                        if 'userLastName' in researchPerson and 'userFirstName' in researchPerson:
                                            newComment['name'] = researchPerson['userFirstName'] + ' ' + researchPerson['userLastName']
                                        if 'userEmailAddress' in researchPerson:
                                            newComment['email'] = researchPerson['userEmailAddress']
                                    if 'commentTimestamp' in comment:
                                        newComment['dateTime'] = comment['commentTimestamp']
                                    if 'researchComment' in comment:
                                        newComment['comment'] = comment['researchComment']
                                    newCommentString = self.generateCommentString(newComment)
                                    logEntry = {}
                                    if 'dateTime' in newComment:
                                        commentDateTime = isoFormatToDateTime(newComment['dateTime'])
                                        logEntry['dateTime'] = commentDateTime
                                        logEntry['logEntry'] = newCommentString
                                        comments.append(logEntry)
        return comments
    
    
    def generateCommentString(self, comment):
        scotsDesc = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.COMMENT_TYPE.value, comment['commentTypeCode'], langId=None)
        if scotsDesc is None:
            scotsDesc = ''
        newCommentString = scotsDesc + '\n'
        if 'dateTime' in comment:
            newCommentString = newCommentString + comment['dateTime'] + ' UTC' + '\n' 
        if 'name' in comment:
            newCommentString = newCommentString + 'Researcher Name: ' + comment['name'] + '\n'
        if 'email' in comment: 
            newCommentString = newCommentString + 'Researcher Email: ' + comment['email'] + '\n'
        if 'comment' in comment:
            newCommentString = newCommentString + 'Comment: ' + comment['comment']
            
        return newCommentString
    
    def getSFDCCaseId(self, usageRecord):
        sfdcCaseId = None
        if ('requestor' in usageRecord):
            requestor = usageRecord['requestor']
            if ('requestorOwnRequestKey' in requestor):
                sfdcCaseId = requestor['requestorOwnRequestKey'].strip()
        return sfdcCaseId
    
    def getResearchRequestId(self, usageRecord):
        researchRequestId = None
        if ('request' in usageRecord):
            request = usageRecord['request']
            if ('researchRequestId' in request):
                researchRequestId = request['researchRequestId']
        return researchRequestId
    
    def getConctactLog(self, usageRecord):
        contactLogEntries = []  
        scotsDesc = ''
        
        if 'request' in usageRecord:
            request = usageRecord['request']
            if 'cases' in request:
                cases = request['cases']
                for case in cases:
                    if 'contactEntries' in case:
                        contactLog = case['contactEntries']
                        for contactEntry in contactLog:
                            newContactEntry = {}
                            if 'researchUser' in contactEntry:
                                researchPerson = contactEntry['researchUser']
                                if 'userLastName' in researchPerson and 'userFirstName' in researchPerson:
                                    newContactEntry['name'] = researchPerson['userFirstName'] + ' ' + researchPerson['userLastName']
                                if 'userEmailAddress' in researchPerson:
                                    newContactEntry['email'] = researchPerson['userEmailAddress']
                            if 'contactTimestamp' in contactEntry:
                                newContactEntry['dateTime'] = contactEntry['contactTimestamp']
                            if 'communicationMethodCode' in contactEntry:
                                communicationMethodCode = contactEntry['communicationMethodCode'] 
                                scotsDesc = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.COMMUNICATION_METHOD.value, communicationMethodCode, langId=None)
                                if scotsDesc is None:
                                    scotsDesc = ''         
                                newContactEntry['communicationMethod'] = scotsDesc
                            if 'contactOrganizationName' in contactEntry:
                                newContactEntry['organizationName'] = contactEntry['contactOrganizationName']
                            contactTitle = ''
                            if 'contactTitleText' in contactEntry:
                                contactTitle = contactEntry['contactTitleText']
                            if 'contactName' in contactEntry:
                                newContactEntry['contactName'] = contactTitle + ' '  + contactEntry['contactName']
                            if 'resultCode' in contactEntry:
                                resultCode = contactEntry['resultCode']
                                scotsDesc = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.CONTACT_RESULT.value, resultCode, langId=None)
                                if scotsDesc is None:
                                    scotsDesc = ''         
                                newContactEntry['contactResult'] = scotsDesc
                            newContactLogString = self.generateContactString(newContactEntry)
                            logEntry = {}
                            if 'dateTime' in newContactEntry:
                                logDateTime = isoFormatToDateTime(newContactEntry['dateTime'])
                                logEntry['dateTime'] = logDateTime
                                logEntry['logEntry'] = newContactLogString
                                contactLogEntries.append(logEntry)

        return contactLogEntries
    
    def generateContactString(self, contactEntry):
        contactEntryString = 'Contact Entry: ' + '\n'
        if 'dateTime' in contactEntry:
            contactEntryString = contactEntryString + contactEntry['dateTime'] + ' UTC' + '\n' 
        if 'name' in contactEntry:
            contactEntryString = contactEntryString + 'Researcher Name: ' + contactEntry['name'] + '\n'
        if 'email' in contactEntry: 
            contactEntryString = contactEntryString + 'Researcher Email: ' + contactEntry['email'] + '\n'
        if 'communicationMethod' in contactEntry:
            contactEntryString = contactEntryString + 'Communication Method: ' + contactEntry['communicationMethod'] + '\n' 
        if 'organizationName' in contactEntry:
            contactEntryString = contactEntryString + 'Organization Name: ' + contactEntry['organizationName'] + '\n' 
        if 'contactName' in contactEntry:
            contactEntryString = contactEntryString + 'Contact Name: ' + contactEntry['contactName'] + '\n' 
        if 'contactResult' in contactEntry:
            contactEntryString = contactEntryString + 'Contact Result: ' + contactEntry['contactResult'] + '\n' 
            
        return contactEntryString
    
    def getLastResolutionComment(self, usageRecord):
        resolutionComments = []
        resolutionComment = ''
        
        if 'request' in usageRecord:
            request = usageRecord['request']
            if 'cases' in request:
                cases = request['cases']
                for case in cases:
                    if 'comments' in case:
                        researchComments = case['comments']
                        for comment in researchComments:
                            if 'commentTypeCode' in comment:
                                typeCode = comment['commentTypeCode']
                                if typeCode == CommentTypeCode.RESOLUTION_COMMENT.value and comment['researchIteration'] == 0: 
                                    commentObj = {}
                                    if 'commentTimestamp' in comment:
                                        commentDateTime = isoFormatToDateTime(comment['commentTimestamp'])
                                        commentObj['dateTime'] = commentDateTime
                                    if 'researchComment' in comment:
                                        commentObj['comment']  = comment['researchComment']
                                    resolutionComments.append(commentObj)

        if len(resolutionComments) > 0:
            sortedList = sorted(resolutionComments, key=lambda k: k['dateTime']) 
            resolutionComment = sortedList[len(sortedList) - 1].get('comment')

        return resolutionComment
        