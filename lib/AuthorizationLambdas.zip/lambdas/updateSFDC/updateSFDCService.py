import logging
import json
import requests
from common.externalStatusCode import ExternalStatusCode
from decimal import Decimal
from common import envVblNames
from requests.exceptions import RequestException
from lambdas.updateSFDC.updateSFDCHelper import UpdateSFDCHelper
from common.commentTypeCodes import CommentTypeCode


EXIT_WHEN_MILLISECS_LEFT = 10000
SFDC_UPDATE_CASE_ACTION = '/services/data/v48.0/sobjects/Case/'
SFDC_INSERT_COMMENT_ACTION = '/services/data/v48.0/sobjects/CaseComment/'
METHOD_TYPE_POST = 'POST'
METHOD_TYPE_PATCH = 'PATCH'
    
class UpdateSFDCService(object):
    sqsHelper = None
    requestContext = None
    sfdcToken = None
    timeoutSecs = None
    sfdcTokenUrl = None
    authData = None
    ownerId = None
    updateSFDCHelper = None
    scotsDao = None
    scots_dict = None
    
    def __init__(self, sqsHelper, requestContext, dbConn):
        self.sqsHelper = sqsHelper
        self.requestContext = requestContext
        if self.updateSFDCHelper is None:
            self.updateSFDCHelper = UpdateSFDCHelper(dbConn)

        self.initSFDCVariables()
          
              
    def updateSFDCCase(self):
        logging.info("in UpdateSFDCService, updateSFDCCase")
        timeLeft = self.requestContext.lambdaContext.get_remaining_time_in_millis()
        logging.info("Time left %s" % timeLeft)
        lastException = None
        while(True and timeLeft > EXIT_WHEN_MILLISECS_LEFT):
            message = self.sqsHelper.getOneMessageFromQueue()
            receipt_handle = None
            if message is not None:
                try:
                    if 'MessageId' in message:
                        logging.info('messageId is: %s ' % message['MessageId'])

                    if 'ReceiptHandle' in message and 'Body' in message:
                        receipt_handle = message['ReceiptHandle']
                        logging.info('current receipt handle is %s' %  receipt_handle)
                        self.handleMessage(message)
                        logging.info('Deleting msg with handle %s' % receipt_handle)
                        self.sqsHelper.deleteOneMessageFromQueue(receipt_handle)
                except Exception as err:
                    if isinstance(err, RequestException):
                        logging.error('Request Exception while trying to update SFDC. Error = %s' % err)
                    else:
                        logging.error('Error updating SFDC. Error = %s' % err)
                        if receipt_handle is not None:
                            logging.info('Deleting msg with handle %s' % receipt_handle)
                            self.sqsHelper.deleteOneMessageFromQueue(receipt_handle)
                    lastException = err
            else:
                break
            timeLeft = self.requestContext.lambdaContext.get_remaining_time_in_millis()
            logging.info("Time left %s" % timeLeft)
        if lastException is not None:
            raise lastException
        
        
    def handleMessage(self, message):
        messageBody = json.loads(message['Body'])
        logging.info ('bodyDict = %s' % messageBody)
        # messageBody is the SNS Message. Usage record is contained inside 'Message'
        if 'Message' in messageBody:
            usageRecord = json.loads(messageBody['Message'])
            researchRequestId = self.updateSFDCHelper.getResearchRequestId(usageRecord)
            logging.info('researchRequestId is %s ' % researchRequestId)
            sfdcCaseId = self.updateSFDCHelper.getSFDCCaseId(usageRecord)
            logging.info('sfdcCaseId is %s ' % sfdcCaseId)
            if sfdcCaseId is not None:
                if self.shouldSendRec(usageRecord):
                    updateRec = self.generateUpdateRec(usageRecord, sfdcCaseId)
                    self.updateSFDC(updateRec, METHOD_TYPE_PATCH, sfdcCaseId, researchRequestId)
                    self.handleComments(usageRecord, sfdcCaseId, researchRequestId)
            else:
                raise Exception('Cannot update SFDC case. SFDC Case id not available.')
            
            
    def shouldSendRec(self, usageRecord):
        if (usageRecord['request']['previousResearchStatusCode'] == ExternalStatusCode.CHALLENGED.value):
            logging.info('Previous status is challenged')
            return False
        return True
            

    def updateSFDC(self, sfdcUpdateRec, method, sfdcCaseId, researchRequestId):
        if self.sfdcToken is None:
            self.sfdcToken = self.getToken()
            
        sfdcUpdateRecJson = json.dumps(sfdcUpdateRec)
        logging.info('SFDC Update json %s' % sfdcUpdateRecJson)
        
        response = self.tryUpdatingSFDC(sfdcUpdateRecJson, method, sfdcCaseId)                        

        if response.status_code == 401:
            response = self.tryUpdatingSFDC(sfdcUpdateRecJson, method, sfdcCaseId)                        
            if response.status_code == 401:
                logging.info("Error message in response is %s:" % response.text)
                raise RequestException('Got back status code %s while trying to get token from SFDC for the second time. ResearchRequestId is %s' % (response.status_code, researchRequestId))
        elif response.status_code == 404 or response.status_code == 400:
            logging.info("Error message in response is %s:" % response.text)
            raise Exception('Got back status code %s while trying to update SFDC. ResearchRequestId is %s' % (response.status_code, researchRequestId))
        elif response.status_code not in [200, 201, 202, 203, 204, 205, 206]:
            logging.info("Error message in response is %s:" % response.text)
            raise RequestException('Got back status code %s while trying to update SFDC. ResearchRequestId is %s' % (response.status_code, researchRequestId))

    def tryUpdatingSFDC(self, sfdcUpdateRecJson, method, sfdcCaseId):
        headers = {}
        headers['Content-type'] = 'application/json'
        headers['Authorization'] = 'OAuth ' + self.sfdcToken['access_token']
        if method == METHOD_TYPE_PATCH:
            requestURL = self.sfdcToken['instance_url'] + SFDC_UPDATE_CASE_ACTION + sfdcCaseId
        elif method == METHOD_TYPE_POST:
            requestURL = self.sfdcToken['instance_url'] + SFDC_INSERT_COMMENT_ACTION
        logging.info('requestURL: %s ' % requestURL)
        
        logging.info('UpdateSFDC: Before request. Method is %s ' % method)
        response = requests.request(method = method, url = requestURL, data = sfdcUpdateRecJson, headers = headers, auth=False, timeout=self.timeoutSecs, verify=False)
        logging.info('UpdateSFDC After request')
                        
        logging.info('Response status is %s ' % response.status_code)
        return response

        
    def getToken(self):
        headers = {}
        headers['Content-type'] = 'application/x-www-form-urlencoded'
        
        logging.info('Before request')
        response = requests.post(self.sfdcTokenUrl, params=self.authData, headers=headers, auth=False, timeout=self.timeoutSecs, verify=False)
        logging.info('After request')
                
        logging.info("Token status is %s " % response.status_code)
        if response.status_code not in [200, 201, 202, 203, 204, 205, 206]:
            logging.info("Error message in response is %s:" % response.text)
            raise RequestException('Got back status code %s while trying to get token from SFDC.' % response.status_code)
        else:
            if 'access_token' in response.json() and 'instance_url' in response.json():
                return response.json()
            else:
                logging.info("Error message in response is %s: " % response.text)
                logging.info("JSON in response is %s: " % str(response.json))
                raise RequestException('No access token returned for status %s while trying to get token from IDaaS.' % response.status_code)
     
        
    def generateUpdateRec(self, usageRecord, sfdcCaseId):
        rec = {}
        resolutionData = self.updateSFDCHelper.getResolutionData(usageRecord)
        rec['Case_Resolution__c'] = resolutionData['Case_Resolution__c']
        rec['Resolution_Sub_Area__c'] = resolutionData['Resolution_Sub_Area__c']
        rec['Status'] = self.updateSFDCHelper.getStatus(usageRecord)
        rec['Customer_DUNS__c'] = self.updateSFDCHelper.getResolutionDuns(usageRecord)
        rec['Research_Complete_Time__c'] = self.updateSFDCHelper.getCompleteTime(usageRecord)
        rec['OwnerId'] = self.ownerId
        rec['Resolution_Description__c'] = resolutionData['Resolution_Description__c']
        rec['Subject_DUNS__c'] = self.updateSFDCHelper.getResolutionDuns(usageRecord)
        rec['Subject_Company_Name__c'] = resolutionData['Subject_Company_Name__c']
        rec['DBA__c'] = resolutionData['DBA__c']
        rec['Physical_Address__c'] = resolutionData['Physical_Address__c']
        rec['Physical_City__c'] = resolutionData['Physical_City__c']
        rec['Physical_State__c'] = resolutionData['Physical_State__c']
        rec['Physical_Zip__c'] = resolutionData['Physical_Zip__c']
        rec['Subject_Phone__c'] = resolutionData['Subject_Phone__c']
        rec['Legal_Structure__c'] = resolutionData['Legal_Structure__c']
        return rec
    
    
    def handleComments(self, usageRecord, sfdcCaseId, researchRequestId):
        #process comments and contact logs
        logEntries = self.updateSFDCHelper.getComments(usageRecord, CommentTypeCode.INTERNAL_RESEARCHER_COMMENT.value)
        resolutionComments = self.updateSFDCHelper.getComments(usageRecord, CommentTypeCode.RESOLUTION_COMMENT.value)
        contactLogEntries = self.updateSFDCHelper.getConctactLog(usageRecord)
        logEntries.extend(resolutionComments)
        logEntries.extend(contactLogEntries)
        
        if len(logEntries) > 0:
            sortedList = sorted(logEntries, key=lambda k: k['dateTime']) 
            for logEntry in sortedList:
                rec = {}
                rec['ParentId'] = sfdcCaseId
                rec['CommentBody'] = logEntry['logEntry']
                #logging.info('comment is %s ' % logEntry['logEntry'])
                self.updateSFDC(rec, METHOD_TYPE_POST, sfdcCaseId, researchRequestId)   
        
        #process main comment
        commentBody = self.updateSFDCHelper.composeMainComment(usageRecord)
        rec = {}
        rec['ParentId'] = sfdcCaseId
        rec['CommentBody'] = commentBody
        #logging.info('Main comment is %s ' % commentBody)
        self.updateSFDC(rec, METHOD_TYPE_POST, sfdcCaseId, researchRequestId)             
    
    
    def initSFDCVariables(self):

        if self.sfdcTokenUrl is None:
            if self.requestContext.environDict[envVblNames.ENV_SFDC_TOKEN_URL] is not None:
                self.sfdcTokenUrl = self.requestContext.environDict[envVblNames.ENV_SFDC_TOKEN_URL]
            else:
                logging.error ('sfdcTokenUrl is missing')
                raise ValueError("sfdcTokenUrl is missing")
            
        if self.ownerId is None:
            if self.requestContext.environDict[envVblNames.ENV_SFDC_OWNER_ID] is not None:
                self.ownerId = self.requestContext.environDict[envVblNames.ENV_SFDC_OWNER_ID]
            else:
                logging.error ('sfdcOwnerId is missing')
                raise ValueError("sfdcOwnerId is missing")
        
        if self.timeoutSecs is None:
            if self.requestContext.environDict[envVblNames.ENV_SFDC_TIMEOUT_SECS] is not None:
                self.timeoutSecs = Decimal(self.requestContext.environDict[envVblNames.ENV_SFDC_TIMEOUT_SECS])
            else:
                logging.error ('sfdcTimeoutSecs is missing')
                raise ValueError("sfdcTimeoutSecs is missing")
        
        if self.authData is None:
            self.authData = {}
            if 'password' not in self.authData:
                if envVblNames.ENV_SFDC_TOKEN_PASSWORD in self.requestContext.environDict:
                    self.authData['password'] = self.requestContext.environDict[envVblNames.ENV_SFDC_TOKEN_PASSWORD]
                else:
                    logging.error ('sfdcTokenPassword is missing')
                    raise ValueError("sfdcTokenPassword is missing")
        
            if 'username' not in self.authData:
                if envVblNames.ENV_SFDC_TOKEN_USERNAME in self.requestContext.environDict:
                    self.authData['username'] = self.requestContext.environDict[envVblNames.ENV_SFDC_TOKEN_USERNAME]
                else:
                    logging.error ('sfdcTokenUsername is missing')
                    raise ValueError("sfdcTokenUsername is missing")
                
            if 'client_id' not in self.authData:
                if envVblNames.ENV_SFDC_TOKEN_CLIENT_ID in self.requestContext.environDict:
                    self.authData['client_id'] = self.requestContext.environDict[envVblNames.ENV_SFDC_TOKEN_CLIENT_ID]
                else:
                    logging.error ('sfdcTokenClient is missing')
                    raise ValueError("sfdcTokenClient is missing")
                
            if 'client_secret' not in self.authData:
                if envVblNames.ENV_SFDC_TOKEN_CLIENT_SECRET in self.requestContext.environDict:
                    self.authData['client_secret'] = self.requestContext.environDict[envVblNames.ENV_SFDC_TOKEN_CLIENT_SECRET]
                else:
                    logging.error ('sfdcTokenClientSecret is missing')
                    raise ValueError("sfdcTokenClientSecret is missing")
        
            if 'grant_type' not in self.authData:
                self.authData['grant_type'] = 'password'