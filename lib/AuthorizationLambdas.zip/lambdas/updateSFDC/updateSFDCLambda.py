'''
Created on Nov 25, 2019

@author: JafferS
'''
from lambdas.lambdaBase import LambdaBase
from lambdas.updateSFDC.updateSFDCService import UpdateSFDCService
from common import envVblNames
import logging
from common.util.sqsHelper import SqsHelper

class UpdateSFDCLambda(LambdaBase):
    sqsHelper = None
    lambdaClient = None
    service = None
    s3Client = None
        
    def exitOnTimerEvent(self):
        logging.debug("*********exitTimerEvent**********")
        return False
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return True
    
    def handleRequest(self):
        logging.debug("*******handleRequest******")
        LambdaBase.raiseAlertWhenRequestFails = True
        if self.service is None:
            self.service = UpdateSFDCService(UpdateSFDCLambda.sqsHelper,  self.requestContext, UpdateSFDCLambda.dbConn)
        logging.info("in UpdateSFDCLambda, handle request")
        self.service.updateSFDCCase()
       
        
    def initializeKeepWarm(self):
        logging.debug("*******initializeKeepWarm******")
        if UpdateSFDCLambda.sqsHelper is None:
            try:
                if UpdateSFDCLambda.environDict.get(envVblNames.ENV_SFDC_USAGE_QUEUE_URL) is not None:
                    regionName = UpdateSFDCLambda.environDict.get(envVblNames.ENV_SQS_REGION)
                    UpdateSFDCLambda.sqsHelper = SqsHelper(queueUrl=UpdateSFDCLambda.environDict.get(envVblNames.ENV_SFDC_USAGE_QUEUE_URL), regionName=regionName)
            except:
                raise RuntimeError("SQS not configured")
                

#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = UpdateSFDCLambda.get_handler(...)