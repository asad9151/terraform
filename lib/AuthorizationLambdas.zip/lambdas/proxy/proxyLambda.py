'''
@author: VanCampK
'''
import logging
import sys
import traceback
from decimal import Decimal
from buildUIResponse import buildUIResponse
from common.envVblNames import getEnvironAsBool
from lambdas.lambdaBase import LambdaBase
from lambdas.lambdaStatusCodes import LambdaStatusCodes
import lambdas.errorMessages as errmsg
from lambdas.proxy.proxyService import ProxyService
from lambdas.lambdaCommon import logResponse
from lambdas.exceptions import LambdaProcessingException


class ProxyLambda(LambdaBase):
    '''
    Handler class for Proxy (AWS generic proxy lambda)
    Handler: lambdas.proxy.proxyLambda.handler
    
    Environment variables supported (all are required unless noted as optional):
    irsch_proxyUrl - name of the destination host to proxy to
    irsch_proxyVerifyHost - (Optional) if set to "false" then the host SSL certificate does not need to match the hostname (do not use in production)
    irsch_proxyContentType - content type of the response, e.g. application/json or text/xml
    irsch_proxyMaxRetries - maximum number of times to retry connecting to the destination host if it fails
    irsch_proxyTimeoutSecs - timeout for connection to destination host
    irsch_proxyDelayRetriesSecs - time (in seconds) to delay between retries
    '''
    
    
    def __init__(self):
        super().__init__()
        self.service = None
    
    
    def handleRequest(self):
        proxyUrl = ProxyLambda.environDict["PROXYURL"]
        contentType = ProxyLambda.environDict["PROXYCONTENTTYPE"]
        maxRetries = int(ProxyLambda.environDict["PROXYMAXRETRIES"])
        timeoutSecs = Decimal(ProxyLambda.environDict["PROXYTIMEOUTSECS"])
        delayBetweenRetriesSecs = Decimal(ProxyLambda.environDict["PROXYDELAYRETRIESSECS"])
        verifyHostTxt = ProxyLambda.environDict.get("PROXYVERIFYHOST")
        verifyHost = getEnvironAsBool(verifyHostTxt) if verifyHostTxt is not None else True
        if self.service is None:
            self.service = ProxyService(proxyUrl, contentType, maxRetries, timeoutSecs, delayBetweenRetriesSecs, verifyHost=verifyHost)
        responseBody = None
        try:
            self.supplementRequest()
            statusCode, responseBody = self.service.makeRequest(self.requestContext)
            logResponse (self.requestContext, responseBody)
            return buildUIResponse(statusCode, responseBody, contentType = contentType)
        except Exception as e:
            logging.error('error invoking makeRequest.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            errorMessage = errmsg.ERR_INTERNAL_REQUEST
            if isinstance(e, LambdaProcessingException):
                errorMessage = e.errmsg
            return buildUIResponse(LambdaStatusCodes.INTERNAL_SERVER_ERROR.value, errorMessage) 


    def supplementRequest(self):
        '''
        Placeholder - subclass can override to add special behavior, e.g. set SERVICE_DICT_SUPPLEMENTAL_QUERY_PARAMETERS
        '''
    

    def initializeKeepWarm(self):
        pass
        
        
    def isBodyJson(self):
        '''
        Overridden because we will specify the content type dynamically
        '''
        return False
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = ProxyLambda.get_handler(...)