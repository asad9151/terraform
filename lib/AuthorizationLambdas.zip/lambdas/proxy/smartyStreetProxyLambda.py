'''
Created on Feb 26, 2020

@author: VanCampK
'''
from common import envVblNames
from common.util.stringUtils import isNotBlank
from lambdas.proxy.proxyLambda import ProxyLambda
from lambdas.proxy.proxyService import ProxyService

class SmartyStreetProxyLambda(ProxyLambda):
    '''
    Handler class for SmartyStreetProxy
    Handler: lambdas.proxy.smartyStreetProxyLambda.handler

    Examples:
    https://us-street.api.smartystreets.com/street-address?street=3501 Corporate Parkway&city=Center Valley&state=PA&zipcode=18034&auth-id=XXX&auth-token=YYY
    https://us-autocomplete.api.smartystreets.com/suggest?prefix=892 King Way Breinigsville&auth-id=XXX&auth-token=YYY
    '''
    SS_LAMBDA_PATH_PREFIX = "/smartystreetproxy"
    

    def supplementRequest(self):
        # Add smarty street authid/token from environment
        self.requestContext.serviceDict[ProxyService.SERVICE_DICT_SUPPLEMENTAL_QUERY_PARAMETERS] = {
            # auth-id=b0bce285-48a5-eb18-2c12-87bd2aec0fec
            # auth-token=KGRoSzN7FvdOw3QnmNRl
            "auth-id": self.requestContext.environDict.get(envVblNames.ENV_SMARTYSTREET_AUTH_ID),
            "auth-token": self.requestContext.environDict.get(envVblNames.ENV_SMARTYSTREET_AUTH_TOKEN)
        }
        # Append resource path to URL
        #resourcePathAppend = self.requestContext.path.replace(SmartyStreetProxyLambda.SS_LAMBDA_PATH_PREFIX, "")
        #if isNotBlank(resourcePathAppend):
        #    self.requestContext.serviceDict[ProxyService.APPEND_TO_RESOURCE_PATH] = resourcePathAppend


#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SmartyStreetProxyLambda.get_handler(...)