'''
Created on Nov 6, 2019

@author: VanCampK
'''
import logging
import requests
import sys
import time
import traceback
from common.util.dictUtils import mergeDictionaries, copyDictWithoutSecureElements
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaProcessingException, LambdaConflictException
from lambdas.lambdaStatusCodes import LambdaStatusCodes


class ProxyService(object):
    '''
    Service to proxy to any backend http/https service.
    '''
    SERVICE_DICT_SUPPLEMENTAL_QUERY_PARAMETERS = "supplementalQueryParams"
    APPEND_TO_RESOURCE_PATH = "appendToResourcePath"


    def __init__(self, proxyUrl, contentType, maxRetries, timeoutSecs, delayBetweenRetriesSecs, verifyHost=True):
        self.proxyUrl = proxyUrl
        self.proxyHeaders = {"Content-Type": contentType}
        self.maxRetries = maxRetries
        self.timeoutSecs = timeoutSecs
        self.delayBetweenRetriesSecs = delayBetweenRetriesSecs
        self.verifyHost = verifyHost

        
    def makeRequest(self, requestContext):
        for retry in range(0, self.maxRetries+1):
            try:
                statusCode, responseBody = self._tryRequest(requestContext, retry)
                if statusCode == LambdaStatusCodes.OK.value:
                    return statusCode, responseBody
                logging.error(f"makeRequest got non-OK response on retry#{retry} statusCode={statusCode} and responseBody={responseBody}")
            except Exception as e:
                logging.error(f"makeRequest exception on retry#{retry} error = {e}")
                traceback.print_tb(sys.exc_info()[2])
                
            # Delay between retries
            logging.info(f"makeRequest sleep between retries for {self.delayBetweenRetriesSecs} seconds...")
            time.sleep(self.delayBetweenRetriesSecs)
                
        # All retries exhausted, unrecoverable error
        logging.error("All retries exhausted in ProxyService.makeRequest - giving up.")
        raise LambdaProcessingException(errmsg.ERR_CONNECT_FAILURE)
    
    
    def _tryRequest(self, requestContext, retry):
        queryParams = requestContext.queryParameters
        supplementalQueryParams = requestContext.serviceDict.get(ProxyService.SERVICE_DICT_SUPPLEMENTAL_QUERY_PARAMETERS)
        if supplementalQueryParams is not None:
            mergeDictionaries(queryParams, supplementalQueryParams)
        fullUrl = self.proxyUrl
        appendToResourcePath = requestContext.serviceDict.get(ProxyService.APPEND_TO_RESOURCE_PATH)
        if appendToResourcePath is not None:
            fullUrl += appendToResourcePath
        logging.info(f"make {requestContext.method} Request({fullUrl}) with headers={self.proxyHeaders} params={copyDictWithoutSecureElements(queryParams)} timeoutSecs={self.timeoutSecs} verify={self.verifyHost}: retry#{retry}")
        if requestContext.method.lower() == "post":
            response = requests.post(url = fullUrl, data = requestContext.body, headers = self.proxyHeaders, params = queryParams, timeout=self.timeoutSecs, verify=self.verifyHost)
        elif requestContext.method.lower() == "get":
            response = requests.get(url = fullUrl, headers = self.proxyHeaders, params = queryParams, timeout=self.timeoutSecs, verify=self.verifyHost)
        else:
            logging.error(f"Unsupported method: {requestContext.method}")
            raise LambdaConflictException(f"Unsupported method: {requestContext.method}")

        logging.debug(f"_tryRequest: response={response}")
        return response.status_code, response.text
