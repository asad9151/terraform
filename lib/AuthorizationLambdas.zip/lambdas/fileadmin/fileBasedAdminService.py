'''
Created on Aug 3, 2020

@author: VanCampK
'''
import logging
import tempfile
import os
import sys
import traceback

from common.dao.updateEventDao import UpdateEventDao
from common.excelReader import ExcelReader
from common.util.stringUtils import isNotBlank
from lambdas.exceptions import LambdaValidationException
from lambdas.fileadmin.adminRecord import AdminRecord
from lambdas.fileadmin.adminRequestRecord import AdminRequestRecord
from lambdas.fileadmin.fileBasedAdminDao import FileBasedAdminDao
from lambdas.fileadmin.fileTypes import FileType
from lambdas.fileadmin.statusChangePlugin import StatusChangePlugin


class FileBasedAdminService(object):
    '''
    Services for processing file-based admin requests
    '''
    APP_MODULE_NM = "FileBasedAdminService"


    def __init__(self, s3Helper, dbConn, environDict, alert):
        self.s3Helper = s3Helper
        self.dbConn = dbConn
        self.environDict = environDict
        self.alert = alert
        self.excelReader = None
        self.fileBasedAdminDao = None
        self.updateEventDao = None
        
        
    def processAdminRequestFile(self, requestContext, s3Object):
        self._createServices(requestContext)
        adminRecord = AdminRecord(s3Object)
        try:
            self._processAdminRequestFileImpl(requestContext, adminRecord)
        except Exception as e:
            logging.error(f"processAdminRequestFile caught exception {e}")
            traceback.print_tb(sys.exc_info()[2])
            adminRecord.lastException = e
            
        ##################### TODO insert into fle_tkg table (what about usage event?) ###########################################
        self._generateReport(requestContext, adminRecord)
        
        
    def _processAdminRequestFileImpl(self, requestContext, adminRecord):
        logging.info(f"Input file is {adminRecord.s3Object.fileName}")
        adminRecord.fileType = self._getFileType(adminRecord.s3Object)
        self._mapFileTypeToPlugin(adminRecord)
        adminRecord.localFileName = self._getTempfileName(adminRecord.s3Object.fileName)
        logging.info(f"Copying file of type {adminRecord.fileType.value} to local {adminRecord.localFileName}")
        self.s3Helper.copyFromS3ToLocal(adminRecord.s3Object, adminRecord.localFileName)
        self._processLocalFile(requestContext, adminRecord)
        
        
    def _createServices(self, requestContext):
        self.excelReader = ExcelReader()
        self.fileBasedAdminDao = FileBasedAdminDao()
        self.updateEventDao = UpdateEventDao()
        
        
    def _getFileType(self, s3Object):
        for fileType in FileType.getFileTypes():
            if s3Object.fileName.startswith(fileType.value):
                return fileType
        # No file type name matched
        raise LambdaValidationException(f"File name {s3Object.fileName} does not start with any known file prefix")
        
        
    def _mapFileTypeToPlugin(self, adminRecord):
        if adminRecord.fileType == FileType.STATUS_CHANGE:
            adminRecord.plugin = StatusChangePlugin(self.dbConn, self.environDict, self.fileBasedAdminDao, self.updateEventDao)
        else:
            raise LambdaValidationException(f"Unknown fileType {adminRecord.fileType.value}")
        
        
    def _getTempfileName(self, appendName):
        return os.path.join(tempfile.gettempdir(), next(tempfile._get_candidate_names()) + "_" + appendName)
    
    
    def _processLocalFile(self, requestContext, adminRecord):
        origRequests = self.excelReader.readCsvAsJson(adminRecord.localFileName)
        recNum = 0
        for origRequest in origRequests:
            keyValue = adminRecord.plugin.getPrintableKey(origRequest)
            if isNotBlank(keyValue):
                recNum += 1
                adminRecord.requests.append(AdminRequestRecord(origRequest, recNum))
            else:
                # Stop at first invalid record
                logging.warning(f"Stopping after record {recNum} because not a valid record")
                break
            
        self._deleteLocalFile(adminRecord.localFileName)
                
        adminRecord.plugin.validateAllRequests(requestContext, adminRecord)
        if adminRecord.isRejected():
            # Don't proceed if any requests failed validation
            adminRecord.nRemaining = len(adminRecord.requests)
            for request in adminRecord.requests:
                if request.isRejected():
                    adminRecord.nError += 1
            return
            
        adminRecord.plugin.processAllRequests(requestContext, adminRecord)
        # Optionally delete file from S3 in the future - for now keep it around to track


    def _deleteLocalFile(self, localFileName):
        os.remove(localFileName)
        
        
    def _generateReport(self, requestContext, adminRecord):
        UNORDERED_LIST_START_TAG = "<ul>"
        UNORDERED_LIST_END_TAG = "</ul>"
        LIST_ITEM_START_TAG = "<li>"
        LIST_ITEM_END_TAG = "</li>"
        MAX_SUCCESS_RECORDS = 100
        
        numRecs = len(adminRecord.requests)
        if adminRecord.isRejected():
            if adminRecord.nProcessed > 0:
                status = "PARTLY PROCESSED"
            else:
                status = "REJECTED"
        else:
            status = "FULLY PROCESSED"
        summary = f"Admin Request File {adminRecord.s3Object.fileName} is {status}"
        topLine = f"{summary}: nProcessed={adminRecord.nProcessed} nError={adminRecord.nError} nRemaining={adminRecord.nRemaining}\n"
        body = []
        body.append(topLine)
        body.append(UNORDERED_LIST_START_TAG)
        if adminRecord.lastException is not None:
            #logging.error(f"lastException={adminRecord.lastException}")
            body.append(f"{LIST_ITEM_START_TAG}lastException={adminRecord.lastException}{LIST_ITEM_END_TAG}")
        for request in adminRecord.requests:
            keyValue = adminRecord.plugin.getPrintableKey(request.originalRecord)
            if request.isRejected():
                body.append(f"{LIST_ITEM_START_TAG}Record#{request.recordNumber} Key={keyValue} - ERROR: {request.requestRejectionErrorsToString()}{LIST_ITEM_END_TAG}")
            elif numRecs <= MAX_SUCCESS_RECORDS:
                # Only display success records if the batch is small
                body.append(f"{LIST_ITEM_START_TAG}Record#{request.recordNumber} Key={keyValue} - VALID: wasProcessed={request.wasProcessed}{LIST_ITEM_END_TAG}")
            else:
                logging.info(f"Suppressed from email due to large batch: {LIST_ITEM_START_TAG}Record#{request.recordNumber} Key={keyValue} - VALID: wasProcessed={request.wasProcessed}{LIST_ITEM_END_TAG}")
                
        if numRecs > MAX_SUCCESS_RECORDS:
            body.append("(success records suppressed since batch is large, see logs for details)")
        body.append(UNORDERED_LIST_END_TAG)
        self.alert.sendNonAlertMessage(FileBasedAdminService.APP_MODULE_NM, summary, "\n".join(body))
        