'''
Created on Aug 3, 2020

@author: VanCampK
'''
import logging

from common.util.s3Helper import S3Helper
from determineStartType import determineStartType
from lambdas.fileadmin.fileBasedAdminService import FileBasedAdminService
from lambdas.lambdaBase import LambdaBase
import lambdas.lambdaConstants as consts


class FileBasedAdminLambda(LambdaBase):
    '''
    Handler class for FileBasedAdmin service.
    Handler: lambdas.fileadmin.fileBasedAdminLambda.handler
    
    Deployment configuration notes:
    This lambda needs the layer irsch_*_ApiLibraries
    Must create S3 event rule to fire this lambda whenever a file is dropped in irsch-*-datastores bucket under the file-admin-request folder.
    '''
    s3Helper = None
    service = None
    
        
    def exitOnTimerEvent(self):
        return True
    
    
    def needsDbConn(self):
        return True
    
    
    def handleRequest(self):
        LambdaBase.raiseAlertWhenRequestFails = True
        startType = determineStartType(self.requestContext.event)
        logging.info(f"FileBasedAdminLambda: startType={startType} event={self.requestContext.event}")
        try:
            if startType == consts.LAMBDA_START_TYPE_S3:
                # S3 event mode
                s3list = FileBasedAdminLambda.s3Helper.parseS3ObjectsFromEvent(self.requestContext.event)
                if s3list is not None and len(s3list) > 0:
                    self._createService()
                    for s3Object in s3list:
                        FileBasedAdminLambda.service.processAdminRequestFile(self.requestContext, s3Object)
                        
        except Exception as e:
            logging.error(f"FileBasedAdminLambda: Uncaught exception {e}")
            raise


    def _createService(self):
        FileBasedAdminLambda.service = FileBasedAdminService(FileBasedAdminLambda.s3Helper, FileBasedAdminLambda.dbConn, FileBasedAdminLambda.environDict, FileBasedAdminLambda.alert)
    

    def initializeKeepWarm(self):
        if FileBasedAdminLambda.s3Helper is None:
            FileBasedAdminLambda.s3Helper = S3Helper()
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = FileBasedAdminLambda.get_handler(...)