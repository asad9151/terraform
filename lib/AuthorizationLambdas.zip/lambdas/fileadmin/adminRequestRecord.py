'''
Created on Jun 8, 2019

@author: VanCampK
'''


class AdminRequestRecord(object):
    '''
    Holds attributes about one Admin request record
    '''

    def __init__(self, originalRecord, recordNumber):
        self.originalRecord = originalRecord  # original record transformed into json
        self.queryResult = None             # results of querying the database
        self.requestRejectionErrors = []    # list of RequestRejectionError, if any
        self.rejectionReasonCode = None     # reason for rejection, if any
        self.recordNumber = recordNumber    # sequential record number in the batch
        self.wasProcessed = False           # was this request processed?
        
        
    def isRejected(self):
        if self.requestRejectionErrors:
            if len(self.requestRejectionErrors) > 0:
                return True
        return False
    
    
    def addRejection(self, requestRejectionError, rejectionReasonCode):
        self.requestRejectionErrors.append(requestRejectionError)
        self.rejectionReasonCode = rejectionReasonCode
            
            
    def requestRejectionErrorsToString(self):
        errmsg = '['
        for err in self.requestRejectionErrors:
            if len(errmsg) > 1:
                errmsg += ','
            errmsg += str(err)
        errmsg += ']'
        return errmsg


    def requestRejectionErrorsToDict(self):
        errs = []
        for err in self.requestRejectionErrors:
            errs.append(err.toDict())
        return errs
