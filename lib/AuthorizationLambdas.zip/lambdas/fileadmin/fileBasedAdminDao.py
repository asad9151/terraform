'''
Created on Aug 3, 2020

@author: VanCampK
'''
import logging


class FileBasedAdminDao(object):
    '''
    Database access object for File-Base Admin service
    '''
    RESEARCH_REQUESTS_BATCH_SIZE = 1000
     

    def queryResearchRequests(self, dbConn, researchRequestIds):
        '''
        Queries a list of research requests.
        Returns a dictionary mapping each rsch_reqs_id to a list of cases along with its fields needed for validation and updating:
            v_reqs_meth_cd
            extl_stat_cd
            v_reqr_own_reqs_key
            subj_rsch_id
            curr_rsch_intrl_stat_cd
            curr_rsch_extl_stat_cd
            lgin_key
        Splits the request into multiple batches if the list of request ids is too long, to avoid an.
        '''
        rschReqsBatches = self._splitListIntoBatches(researchRequestIds)
        rschReqsResults = {}
        for rschReqsBatch in rschReqsBatches:
            currBatchResults = self._queryResearchRequestsOneBatch(dbConn, rschReqsBatch)
            for k, v in currBatchResults.items():
                rschReqsResults[k] = v
        return rschReqsResults
        
        
    def _splitListIntoBatches(self, researchRequestIds):
        rschReqsBatches = []
        currRschReqsBatch = []
        for researchRequestId in researchRequestIds:
            currRschReqsBatch.append(researchRequestId)
            if len(currRschReqsBatch) >= FileBasedAdminDao.RESEARCH_REQUESTS_BATCH_SIZE:
                rschReqsBatches.append(currRschReqsBatch)
                currRschReqsBatch = []
                
        if len(currRschReqsBatch) > 0:
            rschReqsBatches.append(currRschReqsBatch)
        return rschReqsBatches
    
    
    def _queryResearchRequestsOneBatch(self, dbConn, rschReqsBatch):
        query = '''
        select RR.rsch_reqs_id, RR.v_reqs_meth_cd, RR.extl_stat_cd, RR.v_reqr_own_reqs_key, SR.subj_rsch_id, SR.curr_rsch_intrl_stat_cd, SR.curr_rsch_extl_stat_cd, RU.lgin_key
        from rsch_reqs RR
        join subj_rsch SR on SR.rsch_reqs_id = RR.rsch_reqs_id
        join rsch_usr RU on RU.rsch_usr_id = RR.rsch_usr_id
        where RR.rsch_reqs_id in (
        '''
        query_p2 = '''
        )
        order by RR.rsch_reqs_id, SR.subj_rsch_id asc
        '''
        paramsList = []
        isFirst = True
        for rsch_reqs_id in rschReqsBatch:
            if not isFirst:
                query += ","
            isFirst = False
            query += "%s"
            paramsList.append(rsch_reqs_id)
        query += query_p2
        params = tuple(paramsList)
    
        logging.info(f"_queryResearchRequestsOneBatch: query={query} params={params}")
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        logging.info(f"_queryResearchRequestsOneBatch: back with {len(rv)} rows")
        
        dict_data={}
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            rsch_reqs_id = result['rsch_reqs_id']
            dd = dict_data.get(rsch_reqs_id)
            if dd is None:
                dict_data[rsch_reqs_id] = []
                dict_data[rsch_reqs_id].append(result)
            else:
                dd.append(result)
    
        return dict_data


    def updateResearchRequestStatus(self, dbConn, rschReqsId, externalStatusCodeValue, moduleNm):
        query = '''
        update rsch_reqs set extl_stat_cd=%s, extl_stat_tmst=NOW(), row_modr_id_txt = %s where rsch_reqs_id = %s
        '''
        
        params = (externalStatusCodeValue, moduleNm, rschReqsId)
        logging.info(f"updateResearchRequestStatus: query={query} params={params}")
        nRowsAffected = dbConn.cursor.execute(query, params)
        #rowCount = dbConn.cursor.rowcount
        logging.info(f"updateResearchRequestStatus: back from update: nRowsAffected={nRowsAffected}")
        return nRowsAffected
        

    def updateSubjectResearchStatus(self, dbConn, subjRschId, internalStatusCodeValue, externalStatusCodeValue, closeDateTime, moduleNm):
        query = "update subj_rsch set curr_rsch_intrl_stat_cd=%s, curr_intrl_stat_tmst=NOW(), row_modr_id_txt = %s"
        paramsList = [internalStatusCodeValue, moduleNm]
        
        if externalStatusCodeValue is not None:
            query += ", curr_rsch_extl_stat_cd=%s, curr_extl_stat_tmst=NOW()"
            paramsList.append(externalStatusCodeValue)
        
        if closeDateTime is not None:
            query += ", subj_rsch_obj = JSON_SET(subj_rsch_obj, '$.researchTypes[0].resolutionTimestamp',%s)"
            paramsList.append(closeDateTime)
            
        query += "where subj_rsch_id = %s"
        paramsList.append(subjRschId)
        params = tuple(paramsList)
        
        logging.info(f"updateSubjectResearchStatus: query={query} params={params}")
        nRowsAffected = dbConn.cursor.execute(query, params)
        logging.info(f"updateSubjectResearchStatus: back from update: nRowsAffected={nRowsAffected}")
        return nRowsAffected
