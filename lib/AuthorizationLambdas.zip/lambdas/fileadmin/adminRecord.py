'''
Created on Aug 5, 2020

@author: VanCampK
'''


class AdminRecord(object):
    '''
    Holds information about a single file based admin request
    '''


    def __init__(self, s3Object):
        self.s3Object = s3Object
        self.fileType = None
        self.plugin = None
        self.localFileName = None
        self.lastException = None
        self.requests = []
        self.nProcessed = 0
        self.nError = 0
        self.nRemaining = 0
        
        
    def isRejected(self):
        if self.lastException is not None or self.nError > 0:
            return True
        for request in self.requests:
            if request.isRejected():
                return True
            