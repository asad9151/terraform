'''
Created on Aug 3, 2020

@author: VanCampK
'''
import logging
import sys
import traceback

from common.internalStatusCode import InternalStatusCode
from common import updateEventConstants
from common.rejectionReasonCodes import RejectionReasonCode
from common.updateActionCodes import UpdateActionCode
from common.util.dateUtils import getCurrentJavaDatetimestamp
from common.util.stateHelper import StateHelper
from common.util.stringUtils import isBlank, isNotBlank
from lambdas import errorMessages
from lambdas.exceptions import LambdaValidationException, LambdaProcessingException
from lambdas.fileadmin.fileBasedAdminPlugin import FileBasedAdminPlugin
from lambdas.requestRejectionError import RequestRejectionError


class StatusChangePlugin(FileBasedAdminPlugin):
    '''
    Processes a list of status change requests
    '''
    MIN_VALIDATION_CHECK_FIELDS = 2     # user must populate at least this number of check fields on each request
    EXIT_WHEN_MILLISECS_LEFT = 10000
    APP_MODULE_NM = "StatusChangePlugin"
    
    
    def __init__(self, dbConn, environDict, fileBasedAdminDao, updateEventDao):
        self.dbConn = dbConn
        self.environDict = environDict
        self.fileBasedAdminDao = fileBasedAdminDao
        self.updateEventDao = updateEventDao


    def getPrintableKey(self, originalRecord):
        rrid = originalRecord.get("rsch_reqs_id")
        if isBlank(rrid):
            return None
        return rrid
    
    
    def validateAllRequests(self, requestContext, adminRecord):
        researchRequestIds = self._getResearchRequestIds(adminRecord.requests)
        if len(researchRequestIds) == 0:
            raise LambdaValidationException(f"File {adminRecord.s3Object.fileName} has no requests")
        queryResults = self.fileBasedAdminDao.queryResearchRequests(self.dbConn, researchRequestIds)
        for request in adminRecord.requests:
            rrid = request.originalRecord.get("rsch_reqs_id")
            request.queryResult = queryResults.get(rrid)
            if request.queryResult is None:
                request.addRejection(RequestRejectionError(jsonPathName="rsch_reqs_id", errorDescription=errorMessages.ERR_KEY_NOT_FOUND, providedValue=rrid), RejectionReasonCode.VALIDATION_ERROR)
            else:
                self._validateOneRequest(request, rrid)
        
            
    def _getResearchRequestIds(self, requests):
        researchRequestIds = []
        for request in requests:
            rrid = request.originalRecord.get("rsch_reqs_id")
            if isBlank(rrid):
                # Stop at first row with no research request id
                break
            researchRequestIds.append(rrid)
        return researchRequestIds
                
    
    def _validateOneRequest(self, request, rrid):
        #logging.info(f"_validateOneRequest: originalRecord={request.originalRecord} queryResult={request.queryResult} on rsch_reqs_id={rrid}")
        req_rsch_intrl_stat_cd = request.originalRecord.get("rsch_intrl_stat_cd")
        exp_curr_rsch_intrl_stat_cd = request.originalRecord.get("curr_rsch_intrl_stat_cd")
        exp_reqs_meth_cd = request.originalRecord.get("reqs_meth_cd")
        exp_reqr_own_reqs_key = request.originalRecord.get("reqr_own_reqs_key")
        exp_sbmt_lgin_key = request.originalRecord.get("sbmt_lgin_key")
        if isBlank(req_rsch_intrl_stat_cd):
            request.addRejection(RequestRejectionError(jsonPathName="rsch_intrl_stat_cd", errorDescription=errorMessages.ERR_REQUIRED_FIELD_MISSING, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
        else:
            if req_rsch_intrl_stat_cd == InternalStatusCode.CHALLENGED.value:
                request.addRejection(RequestRejectionError(jsonPathName="rsch_intrl_stat_cd", errorDescription="Challenge status is not supported", providedValue=req_rsch_intrl_stat_cd), RejectionReasonCode.VALIDATION_ERROR)
            else:
                req_extrl_stat_cd = StateHelper.mapInternalToExternalStatus(req_rsch_intrl_stat_cd)
                if req_extrl_stat_cd is None:
                    request.addRejection(RequestRejectionError(jsonPathName="rsch_intrl_stat_cd", errorDescription="The supplied internal status is not valid", providedValue=req_rsch_intrl_stat_cd), RejectionReasonCode.VALIDATION_ERROR)
        if isBlank(exp_reqs_meth_cd):
            request.addRejection(RequestRejectionError(jsonPathName="reqs_meth_cd", errorDescription=errorMessages.ERR_REQUIRED_FIELD_MISSING, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
        nCheckFlds = 0
        if isNotBlank(exp_curr_rsch_intrl_stat_cd):
            nCheckFlds += 1
        if isNotBlank(exp_reqs_meth_cd):
            nCheckFlds += 1
        if isNotBlank(exp_sbmt_lgin_key):
            nCheckFlds += 1
        if isNotBlank(exp_reqr_own_reqs_key):
            nCheckFlds += 1
        if nCheckFlds < StatusChangePlugin.MIN_VALIDATION_CHECK_FIELDS:
            request.addRejection(RequestRejectionError(jsonPathName="", errorDescription=f"Did not provide at least {StatusChangePlugin.MIN_VALIDATION_CHECK_FIELDS} check field values", providedValue=nCheckFlds), RejectionReasonCode.VALIDATION_ERROR)
        for caseQueryResult in request.queryResult:
            subjRschId = caseQueryResult.get("subj_rsch_id")
            act_curr_rsch_intrl_stat_cd = caseQueryResult.get("curr_rsch_intrl_stat_cd")
            act_reqs_meth_cd = caseQueryResult.get("v_reqs_meth_cd")
            act_reqr_own_reqs_key = caseQueryResult.get("v_reqr_own_reqs_key")
            act_sbmt_lgin_key = caseQueryResult.get("lgin_key")
            if isNotBlank(exp_curr_rsch_intrl_stat_cd) and exp_curr_rsch_intrl_stat_cd != act_curr_rsch_intrl_stat_cd:
                request.addRejection(RequestRejectionError(jsonPathName="curr_rsch_intrl_stat_cd", errorDescription=f"curr_rsch_intrl_stat_cd does not match expected value: actual is {act_curr_rsch_intrl_stat_cd}", providedValue=exp_curr_rsch_intrl_stat_cd), RejectionReasonCode.VALIDATION_ERROR)
            if isNotBlank(exp_reqs_meth_cd) and exp_reqs_meth_cd != act_reqs_meth_cd:
                request.addRejection(RequestRejectionError(jsonPathName="reqs_meth_cd", errorDescription=f"reqs_meth_cd does not match expected value: actual is {act_reqs_meth_cd}", providedValue=exp_reqs_meth_cd), RejectionReasonCode.VALIDATION_ERROR)
            if isNotBlank(exp_sbmt_lgin_key) and exp_sbmt_lgin_key != act_sbmt_lgin_key:
                request.addRejection(RequestRejectionError(jsonPathName="sbmt_lgin_key", errorDescription=f"sbmt_lgin_key does not match expected value: actual is {act_sbmt_lgin_key}", providedValue=exp_sbmt_lgin_key), RejectionReasonCode.VALIDATION_ERROR)
            if isNotBlank(exp_reqr_own_reqs_key) and exp_reqr_own_reqs_key != act_reqr_own_reqs_key:
                request.addRejection(RequestRejectionError(jsonPathName="reqr_own_reqs_key", errorDescription=f"reqr_own_reqs_key does not match expected value: actual is {act_reqr_own_reqs_key}", providedValue=exp_reqr_own_reqs_key), RejectionReasonCode.VALIDATION_ERROR)
    
    
    def processAllRequests(self, requestContext, adminRecord):
        adminRecord.nRemaining = len(adminRecord.requests)
        for request in adminRecord.requests:
            try:
                rrid = request.originalRecord.get("rsch_reqs_id")
                timeLeft = requestContext.lambdaContext.get_remaining_time_in_millis()
                logging.info(f"_processAllRequests: Time left {timeLeft} milliseconds with {adminRecord.nRemaining} records remaining to be submitted.")
                if timeLeft < StatusChangePlugin.EXIT_WHEN_MILLISECS_LEFT:
                    errmsg = f"Ran out of time processing requests, batch incomplete"
                    logging.warning(f"_processAllRequests: {errmsg}")
                    adminRecord.lastException = LambdaProcessingException(errmsg)
                    break
                if request.isRejected():
                    logging.info(f"Skipping rejected record #{request.recordNumber} on rrid={rrid}")
                else:
                    logging.info(f"Processing record #{request.recordNumber} on rrid={rrid}")
                    self._processOneRequest(requestContext, request)
            except Exception as e:
                logging.error(f"processAllRequests Caught exception processing: {e}")
                traceback.print_tb(sys.exc_info()[2])
                request.addRejection(RequestRejectionError(jsonPathName="rsch_reqs_id", errorDescription=f"Caught exception processing: {e}", providedValue=rrid), RejectionReasonCode.INTERNAL_ERROR)
                
            if request.isRejected():
                adminRecord.nError += 1
            adminRecord.nProcessed += 1
            adminRecord.nRemaining -= 1
    
    
    def _processOneRequest(self, requestContext, request):
        rrid = request.originalRecord.get("rsch_reqs_id")
        req_rsch_intrl_stat_cd = request.originalRecord.get("rsch_intrl_stat_cd")
        req_extrl_stat_cd = StateHelper.mapInternalToExternalStatus(req_rsch_intrl_stat_cd)
        upd_extrl_stat_cd = None
        
        # First update the subj_rsch records (may be more than one)
        for caseQueryResult in request.queryResult:
            # Don't update external status codes unless actually changed
            if req_extrl_stat_cd != caseQueryResult.get("curr_rsch_extl_stat_cd"):
                upd_extrl_stat_cd = req_extrl_stat_cd
            # Special update for case close
            if req_rsch_intrl_stat_cd == InternalStatusCode.CLOSED.value:
                closeDateTime = getCurrentJavaDatetimestamp()
            else:
                closeDateTime = None
                
            subjRschId = caseQueryResult.get("subj_rsch_id")
            nRowsAffected = self.fileBasedAdminDao.updateSubjectResearchStatus(self.dbConn, subjRschId, req_rsch_intrl_stat_cd, upd_extrl_stat_cd, closeDateTime, StatusChangePlugin.APP_MODULE_NM)
            if nRowsAffected != 1:
                request.addRejection(RequestRejectionError(jsonPathName="subj_rsch_id", errorDescription=f"Updated {nRowsAffected} rows in subj_rsch", providedValue=subjRschId), RejectionReasonCode.VALIDATION_ERROR)
                # Stop on first error
                return
            else:
                self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_SUBJECT_RESEARCH_TABLE,
                                            subjRschId, updateEventConstants.AUDIT_ELEMENT_INTERNAL_STATUS,
                                            req_rsch_intrl_stat_cd, req_rsch_intrl_stat_cd, UpdateActionCode.MODIFY.value, None,
                                            None, None, StatusChangePlugin.APP_MODULE_NM)
        
        # Next update the rsch_reqs
        # Don't update external status code unless actually changed
        if upd_extrl_stat_cd is not None:
            nRowsAffected = self.fileBasedAdminDao.updateResearchRequestStatus(self.dbConn, rrid, upd_extrl_stat_cd, StatusChangePlugin.APP_MODULE_NM)
            if nRowsAffected != 1:
                request.addRejection(RequestRejectionError(jsonPathName="rsch_reqs_id", errorDescription=f"Updated {nRowsAffected} rows: rsch_reqs", providedValue=rrid), RejectionReasonCode.VALIDATION_ERROR)
            else:
                self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_RESEARCH_REQUESTS_TABLE,
                                            rrid, updateEventConstants.AUDIT_ELEMENT_REQ_EXTERNAL_STATUS,
                                            req_extrl_stat_cd, req_extrl_stat_cd, UpdateActionCode.MODIFY.value, None,
                                            None, None, StatusChangePlugin.APP_MODULE_NM)
        request.wasProcessed = True
