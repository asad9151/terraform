'''
Created on Aug 5, 2020

@author: VanCampK
'''

class FileBasedAdminPlugin(object):
    '''
    Defines the interface for a plugin for this service
    '''


    def getPrintableKey(self, originalRecord):
        '''
        Return the printable key from the original record, if present.
        If key not present, return None; this implies an empty record so parsing of the file stops.
        '''
        raise NotImplementedError


    def validateAllRequests(self, requestContext, adminRecord):
        '''
        Validates each request
        '''
        raise NotImplementedError


    def processAllRequests(self, requestContext, adminRecord):
        '''
        Processes each request
        '''
        raise NotImplementedError
