'''
Created on Feb 25, 2021
Service for login session management to logout of an active session or to keepalive an active session.
Secondary function of service is to return list of upcoming maintenance outages.
@author: GuardiolaR
'''

import logging
from common.dao.mntnWndwOutageDao import queryMntnWndwOutagesData
from common.mappers.mntnWindowBannerMessageDataMapper import mapMaintenanceOutageDataResultToSchema
from lambdas.keepaliveservice.dao import updateLogoutTimestamp
from lambdas.exceptions import LambdaValidationException
import lambdas.errorMessages as errmsg

class KeepaliveService(object):
    NUMBER_OF_DAYS_SINCE_LAST_OUTAGE = 0
    
    def __init__(self, dbConn):
        self.dbConn = dbConn
        
    def retrieveMntnWindowOutagesData(self, requestContext):
    #Builds cache of current mtnn window outages that have been created by super admins.
        logging.info('retrieveMntnWindowOutagesData cache')
        qryResult = queryMntnWndwOutagesData(self.dbConn, None, KeepaliveService.NUMBER_OF_DAYS_SINCE_LAST_OUTAGE)
        mappedResult = mapMaintenanceOutageDataResultToSchema(qryResult, mntnWindowId=None)
        return mappedResult
    
        
    def logoff(self, requestContext):
        userId = int(requestContext.userSession.userId)
        dnbJtiVal = requestContext.userSession.sessionToken
        
        if dnbJtiVal is None or userId is None:
            logging.error('Unable to get userSession')
            raise LambdaValidationException(errmsg.ERR_USER_SESSION_INVALID)
        
        logging.info(f'Before running query to updateLogoutTimestamp for user id: {userId} and userSession{dnbJtiVal}')
        rowsUpdated = updateLogoutTimestamp(self.dbConn, userId, dnbJtiVal)
        if rowsUpdated is None:
            logging.error("Exception occurred while updating a row in lgin_ses table")
            raise LambdaValidationException(errmsg.ERR_USER_SESSION_INVALID)
            
        logging.info(f'After running query, lgn_sess rows updated: {rowsUpdated}')