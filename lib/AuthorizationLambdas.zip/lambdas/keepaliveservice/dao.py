'''
Created on Mar 1, 2021
DAO for keepalive service user session management.
@author: GuardiolaR
'''
import logging

def updateLogoutTimestamp(dbConn, userId, userSession):
    '''
    * Updates the logout timestamp on the session.
     * @param userSession
     * @return number of rows updated (usually 1 on success, 0 if failed to find session)
    '''
    updateQuery = '''
        UPDATE lgin_ses 
        SET lg_out_tmst=NOW()
        WHERE rsch_usr_id= %s
        and dnb_jti_val = %s;
    '''
    
    params = (userId, userSession)
    logging.info(f'updateLogoutTimestamp query={updateQuery} userId={userId} dnbJtiVal={userSession}');
    dbConn.cursor.execute(updateQuery, params)
    dbConn.dbconn.commit()
    return dbConn.cursor.rowcount