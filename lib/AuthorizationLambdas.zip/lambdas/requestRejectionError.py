'''
Created on Jun 8, 2019

@author: VanCampK
'''
import logging
import re
import lambdas.errorMessages as errmsg

class RequestRejectionError(object):
    '''
    Holds one research request record rejection error
    '''
    schemaErrIsTooLongRegex = re.compile(r" is too long$")

    def __init__(self, jsonPathName=None, errorDescription=None, providedValue=None):
        self.jsonPathName = jsonPathName
        # Special case schema validation errors
        if providedValue is None and errorDescription is not None:
            matched = RequestRejectionError.schemaErrIsTooLongRegex.search(errorDescription)
            if matched is not None:
                logging.info(f"Changing schema validation error '{errorDescription}' to {errmsg.ERR_VALUE_TOO_LONG} with providedValue='{providedValue}'")
                #print(str(matched.span(0)[0]) + " -> " + str(matched.span(0)[1]))
                providedValue = errorDescription[0:matched.span(0)[0]]
                # remove outer quotes if schema validator had put them there
                if providedValue[0] == "'" and providedValue[-1] == "'":
                    providedValue = providedValue[1:-1]
                errorDescription = errmsg.ERR_VALUE_TOO_LONG
                
        self.errorDescription = None if errorDescription is None else errorDescription[0:399]
        self.providedValue = None
        if providedValue:
            try:
                self.providedValue = str(providedValue)[0:3999]
            except:
                logging.error('RequestRejectionError: Can\'t record providedValue because it can\'t be stringified: jsonPathName=' + jsonPathName + ' errorDescription=' + errorDescription)
        
        
    def __str__(self):
        return f"RequestRejectionError(jsonPathName={self.jsonPathName} errorDescription={self.errorDescription} providedValue={self.providedValue})"

        
    def toDict(self):
        return {
            "jsonPathName": self.jsonPathName,
            "errorDescription": self.errorDescription,
            "providedValue": self.providedValue
        }
        
        
    @classmethod
    def fromDict(cls, srcDict):
        rre = RequestRejectionError(jsonPathName=srcDict.get("jsonPathName"), errorDescription=srcDict.get("errorDescription"), providedValue=srcDict.get("providedValue"))
        return rre
        
    
    def __eq__(self, other):
        return type(self) == type(other) and str(self) == str(other)
        
        
    def __lt__(self, other):
        return str(self) < str(other)
    
        
    def __hash__(self):
        return hash(str(self))
    