'''
Created on Mar 2, 2019
Module for lambda functions
@author: VanCampK
'''
