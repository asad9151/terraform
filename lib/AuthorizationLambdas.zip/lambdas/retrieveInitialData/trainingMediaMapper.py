'''
Created on July 27, 2020
Mapper function to query trainingMedia table and return all rows to be used as placeholders for actual trainingMedia
that is viewable in the Help Section Dropdown of the iResearch UI.

@author: GuardiolaR
'''

def mapTrainingMediaSummaryDataResultToSchema(qryResult):
    return _transformToSchema(qryResult)

def _transformToSchema(qryResult):
    '''
    Maps the trainingMediaData into an array that can be consumed by the UI during the retrieveInitialData call.
    '''
    trainingMediaData = []
    for media in qryResult:
        trainingMedia = _transformTrainingMediaDataToSchema(media)
        trainingMediaData.append(trainingMedia)
    data = {}
    data["trainingMediaData"] = trainingMediaData
    return data


def _transformTrainingMediaDataToSchema(rec):
    result = {}
    result["trainingMediaId"] = rec.get("trng_mdia_id")
    result["mediaType"] = rec.get("mdia_typ")
    result["mediaTitle"] = rec.get("mdia_nme")
    result["mediaDescription"] = rec.get("mdia_desc_txt")
    result["mediaCategory"] = rec.get("mdia_ctgy_typ")
    result["mediaFileName"] = rec.get("fle_nme")
    result["mediaOrderNumber"] = rec.get("mdia_ordr_nbr")
    result["mediaViewsCount"] = rec.get("mdia_vws_cnt")
    result["mediaVoteRating"] = rec.get("mdia_vte_cnt")
    result["mediaTotalVotes"] = rec.get("mdia_vte_tot_nbr")
    result["lastModifiedTimestamp"] = rec.get("mod_timestamp")
    
    return result