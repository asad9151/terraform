'''
Created on Mar 10, 2019
Mapper function for converting team member data from flat rows into team hierarchy for retrieveInitialData service

@author: VanCampK
'''
from itertools import groupby
from common.mappers.userMapper import mapToUserSchema
from common.mappers.teamMapper import mapToTeamSchema

def mapTeamQueryResultToSchema(qryResult):
    groupByTeamDict = _groupByTeam(qryResult)
    return _transformGroupsToSchema(groupByTeamDict)

def _groupByTeam(qryResult):
    '''
    Takes a sorted flat array of team+member and groups it by team#
    '''
    groups = groupby(qryResult, lambda qryResult: qryResult['RT_rsch_team_id'])
    return groups

def _transformGroupsToSchema(groupByTeamDict):
    # Transform into final schema names
    teams = []
    for team, members in groupByTeamDict:
        researchTeam = None
        memberList = []
        for member in members:
            # Get the team from the first member
            if researchTeam == None:
                researchTeam = mapToTeamSchema(member, 'RT_')
                #print('researchTeam:' + str(researchTeam))
                # Remove elements the UI doesn't need
                del researchTeam['researchTeamOrganizationName']
                del researchTeam['countryCode']

            researchUser = mapToUserSchema(member, 'RU_')

            if researchUser["researchUserId"]:
                del researchUser['userEmailAddress']
                del researchUser['submitterOrganizationName']
                del researchUser['submitterCountryCode']
                del researchUser['isActive']
                del researchUser['activeIndicatorTimestamp']
                del researchUser['user']
                userEntry = {
                    "researchUser": researchUser
                }
                #print('  userEntry:' + str(userEntry))
                memberList.append(userEntry)
        teamEntry = {
            "researchTeam": researchTeam,
            "teamMembers": memberList
        }
        teams.append(teamEntry)
            
    result = {}
    result["teams"] = teams
    return result
