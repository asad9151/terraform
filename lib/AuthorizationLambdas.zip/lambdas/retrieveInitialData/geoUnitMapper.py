'''
Created on Mar 24, 2019
Mapper functions for GeoUnit data

@author: VanCampK
'''
import logging
from itertools import groupby
from operator import itemgetter
from lambdas.retrieveInitialData.geoCodeTypeCodes import GeoCodeTypeCode
from lambdas.exceptions import LambdaConflictException
from lambdas.retrieveInitialData.geoNameTypeCodes import GeoNameTypeCode

def mapCountriesToSchema(countriesResult, countriesTerritoriesResult, langCd1, langCd2):
    groupByGeoUnitDict = _groupByCountry(countriesResult, langCd1, langCd2)
    _mergeTerritoriesIntoCountries(groupByGeoUnitDict, countriesTerritoriesResult, langCd1, langCd2)
    return _transformGeoUnitsToSchema(groupByGeoUnitDict)


def _groupByCountry(qryResult, langCd1, langCd2):
    '''
    Group all results by geo_unit_id: This takes multiple rows from the database query and groups them into a single record per country.
    Example input:
    {"geo_unit_id": 859, "geo_unit_typ_cd": 128, "geo_code_typ_cd": 23413, "geo_code": "93", "lang_cd": 39, "geo_nme_typ_cd": 32, "geo_nme": "Afghanistan"},
    {"geo_unit_id": 859, "geo_unit_typ_cd": 128, "geo_code_typ_cd": 23413, "geo_code": "93", "lang_cd": 331, "geo_nme_typ_cd": 32, "geo_nme": "AFGHANISTAN"},
    {"geo_unit_id": 859, "geo_unit_typ_cd": 128, "geo_code_typ_cd": 23416, "geo_code": "AF", "lang_cd": 39, "geo_nme_typ_cd": 32, "geo_nme": "Afghanistan"},
    {"geo_unit_id": 859, "geo_unit_typ_cd": 128, "geo_code_typ_cd": 23416, "geo_code": "AF", "lang_cd": 331, "geo_nme_typ_cd": 32, "geo_nme": "AFGHANISTAN"},
    {"geo_unit_id": 859, "geo_unit_typ_cd": 128, "geo_code_typ_cd": 23417, "geo_code": "004", "lang_cd": 39, "geo_nme_typ_cd": 32, "geo_nme": "Afghanistan"},
    {"geo_unit_id": 859, "geo_unit_typ_cd": 128, "geo_code_typ_cd": 23417, "geo_code": "004", "lang_cd": 331, "geo_nme_typ_cd": 32, "geo_nme": "AFGHANISTAN"},
    
    Example output:
    { 859: { "iso2Alpha": "AF", "iso3Numeric": 93, "internationalDialingCode": "093", "officialName": "AFGHANISTAN" }, ... }
    '''
    
    grouper = itemgetter("geo_unit_id", "geo_code_typ_cd", "lang_cd")
    groupByGeoUnitDict = {}
    for key, grp in groupby(qryResult, grouper):
        key_dict = dict(zip(["geo_unit_id", "geo_code_typ_cd", "lang_cd"], key))
        geoUnitId = key_dict["geo_unit_id"]
        grplist = list(grp)
        #print(str(geoUnitId) + " " + str(key_dict) + " -> " + str(grplist))
            
        # Find or add this geoUnit into the dictionary
        geoUnitElt = groupByGeoUnitDict.get(geoUnitId)
        if geoUnitElt is None:
            # Add new country to dictionary
            geoUnitElt = {}
            groupByGeoUnitDict[geoUnitId] = geoUnitElt
        
        # For now just store record 0 - DO WE NEED GROUPER?
        rec = grplist[0]
        if key_dict["geo_code_typ_cd"] == GeoCodeTypeCode.GEO_CODE_TYPE_CODE_ISO2ALPHA.value:
            geoUnitElt["iso2Alpha"] = rec["geo_code"]
        if key_dict["geo_code_typ_cd"] == GeoCodeTypeCode.GEO_CODE_TYPE_CODE_ISO3NUMERIC.value:
            geoUnitElt["iso3Numeric"] = rec["geo_code"]
        if key_dict["geo_code_typ_cd"] == GeoCodeTypeCode.GEO_CODE_TYPE_CODE_INTLDIALING.value:
            geoUnitElt["internationalDialingCode"] = rec["geo_code"]
        langCd = rec["lang_cd"]
        if geoUnitElt.get("officialName"):
            # Override officialName if first-choice langCd
            if langCd == langCd1:
                geoUnitElt["officialName"] = rec["geo_nme"]
        else:
            # Assuming we only get back records on langCd1 or langCd2, any officialName is better than no officialName
            geoUnitElt["officialName"] = rec["geo_nme"]
        
    return groupByGeoUnitDict


def _mergeTerritoriesIntoCountries(groupByGeoUnitDict, countriesTerritoriesResult, langCd1, langCd2):
    '''
    Groups the results by parent country, and merges the territories array into each country
    Example input:
    {"P_geo_unit_id": 868, "P_geo_unit_typ_cd": 128, "geo_unit_id": 99967788, "geo_unit_typ_cd": 5392, "lang_cd": 39, "geo_nme_typ_cd": 32, "geo_nme": "WEST AUSTRALIA"}, #manually modified data to make it different for US/British English
    {"P_geo_unit_id": 868, "P_geo_unit_typ_cd": 128, "geo_unit_id": 99967788, "geo_unit_typ_cd": 5392, "lang_cd": 331, "geo_nme_typ_cd": 32, "geo_nme": "WESTERN AUSTRALIA"},
    {"P_geo_unit_id": 868, "P_geo_unit_typ_cd": 128, "geo_unit_id": 99967788, "geo_unit_typ_cd": 5392, "lang_cd": 39, "geo_nme_typ_cd": 33, "geo_nme": "WA"},
    {"P_geo_unit_id": 868, "P_geo_unit_typ_cd": 128, "geo_unit_id": 99967788, "geo_unit_typ_cd": 5392, "lang_cd": 331, "geo_nme_typ_cd": 33, "geo_nme": "WA"},
    Example output:
    { 868: { "territories": { 99967788: "officialName": "WESTERN AUSTRALIA", "abbrName": "WA" }, }, ... }
    '''
    grouper = itemgetter("P_geo_unit_id", "geo_unit_id", "geo_nme_typ_cd", "lang_cd")
    for key, grp in groupby(countriesTerritoriesResult, grouper):
        key_dict = dict(zip(["P_geo_unit_id", "geo_unit_id", "geo_nme_typ_cd", "lang_cd"], key))
        parentGeoUnitId = key_dict["P_geo_unit_id"]
        childGeoUnitId = key_dict["geo_unit_id"]
        grplist = list(grp)
        geoUnitElt = groupByGeoUnitDict.get(parentGeoUnitId)
        if not geoUnitElt:
            # Should never be possible but...
            logging.error('_mergeTerritoriesIntoCountries Parent country ' + str(parentGeoUnitId) + ' missing (refered by terr geo_unit_id=' + key_dict["geo_unit_id"] + ")")
            raise LambdaConflictException('Missing country')
        territories = geoUnitElt.get("territories")
        if not territories:
            territories = {}
            geoUnitElt["territories"] = territories
            
        # See if this territory already present
        territory = territories.get(childGeoUnitId)
        if not territory:
            territory = {}
            territories[childGeoUnitId] = territory
        
        # For now just store record 0 - DO WE NEED GROUPER?
        rec = grplist[0]
        langCd = rec["lang_cd"]
        if key_dict["geo_nme_typ_cd"] == GeoNameTypeCode.GEO_NAME_TYPE_CODE_OFFICIAL.value:
            if territory.get("officialName"):
                # Override officialName if first-choice langCd
                if langCd == langCd1:
                    territory["officialName"] = rec["geo_nme"]
            else:
                # Assuming we only get back records on langCd1 or langCd2, any officialName is better than no officialName
                territory["officialName"] = rec["geo_nme"]
        elif key_dict["geo_nme_typ_cd"] == GeoNameTypeCode.GEO_NAME_TYPE_CODE_ABBREVIATED.value:
            if territory.get("abbrName"):
                if langCd == langCd1:
                    territory["abbrName"] = rec["geo_nme"]
            else:
                territory["abbrName"] = rec["geo_nme"]

    return groupByGeoUnitDict
    

def _transformGeoUnitsToSchema(groupByGeoUnitDict):
    result = {}
    countryArray = []
    # Transform countries dictionary into array 
    for country in groupByGeoUnitDict.values():
        territories = country.get("territories")
        if territories:
            # Transform territories dictionary into array
            territoryArray = []
            for territory in territories.values():
                territoryArray.append(territory)
            #country.pop("territories")
            country["territories"] = territoryArray
        countryArray.append(country)
    result["countries"] = countryArray
    return result