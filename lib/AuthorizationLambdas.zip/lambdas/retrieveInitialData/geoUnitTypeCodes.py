'''
Created on Mar 25, 2019

@author: VanCampK
'''
from enum import Enum

class GeoUnitTypeCode(Enum):
    GEO_UNIT_TYPE_CODE_COUNTRY = 128
    GEO_UNIT_TYPE_CODE_TERRITORY = 5392

    @classmethod
    def hasValue(cls, value):
        return any(value == item.value for item in cls)        