'''
Created on Mar 25, 2019

@author: VanCampK
'''
from enum import Enum

class GeoCodeTypeCode(Enum):
    GEO_CODE_TYPE_CODE_ISO2ALPHA = 23416
    GEO_CODE_TYPE_CODE_ISO3NUMERIC = 23417
    GEO_CODE_TYPE_CODE_INTLDIALING = 23413
    GEO_CODE_TYPE_CODE_WORLDBASE = 23414

    @classmethod
    def hasValue(cls, value):
        return any(value == item.value for item in cls)        