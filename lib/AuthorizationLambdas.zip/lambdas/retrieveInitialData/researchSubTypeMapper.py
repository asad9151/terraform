'''
Created on Apr 18, 2019

@author: VanCampK
'''
from itertools import groupby
from operator import itemgetter

def mapResearchSubTypeToResolutionCodesToSchema(qryResult):
    groupByRschSubTypeDict = {}
    grouper = itemgetter("rsch_sub_typ_cd","resl_cd")
    for key, grp in groupby(qryResult, grouper):
        key_dict = dict(zip(["rsch_sub_typ_cd","resl_cd"], key))
        #grplist = list(grp)
        rschSubTyp = key_dict["rsch_sub_typ_cd"]
        #reslCd = key_dict["resl_cd"]
        reslSubTypCds = []
        #for itm in grplist:
        for itm in grp:
            reslSubTypCds.append(itm["sub_resl_cd"])
        resolutionType = {
            "resolutionCode": key_dict["resl_cd"],
            "resolutionSubTypeCodes": reslSubTypCds
        }
        # Add to resolutionTypes list if already there, or create new one
        researchSubTypeCode_resolutionTypes = groupByRschSubTypeDict.get(rschSubTyp)
        if not researchSubTypeCode_resolutionTypes:
            researchSubTypeCode_resolutionTypes = []
            groupByRschSubTypeDict[rschSubTyp] = researchSubTypeCode_resolutionTypes
        researchSubTypeCode_resolutionTypes.append(resolutionType)

    finalResult = _transformToFinalSchema(groupByRschSubTypeDict)
    return finalResult

def _transformToFinalSchema(groupByRschSubTypeDict):
    researchSubTypeToResolutionCodesList = []
    for k,v in groupByRschSubTypeDict.items():
        resolutionTypes = []
        for resType in v:
            resolutionSubTypeCodes = []
            for subResType in resType["resolutionSubTypeCodes"]:
                newSubResType = {
                    "subResolutionCode": subResType
                }
                resolutionSubTypeCodes.append(newSubResType)
                
            newResType = {
                "resolutionCode": resType["resolutionCode"],
                "resolutionSubTypeCodes": resolutionSubTypeCodes
            }
            resolutionTypes.append(newResType)
            
        newItem = {}
        if k:
            newItem["researchSubTypeCode"] = k
        newItem["resolutionTypes"] = resolutionTypes
        
        researchSubTypeToResolutionCodesList.append(newItem)
        
    finalResult = {
        "researchSubTypeToResolutionCodes": researchSubTypeToResolutionCodesList
    }
    return finalResult
