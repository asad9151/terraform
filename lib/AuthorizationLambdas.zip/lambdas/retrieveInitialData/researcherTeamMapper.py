'''
Created on Mar 10, 2019
Mapper function for converting researcher team data into schema for retrieveInitialData service

'''

def mapResearcherTeamQueryResultToSchema(qryResult):
    return _transformResultsToSchema(qryResult)


def _transformResultsToSchema(qryResult):
    # Transform into final schema names
    researcherTeams = []
    for row in qryResult:
        prefix = 'RT_'
        result = {
            "researchTeamId": row.get(prefix+"rsch_team_id"),
            "researchTeamName": row.get(prefix+"rsch_team_nme"),
            "researchTeamDisplayName": row.get(prefix+"rsch_team_dspl_nme"),
            "getNextIndicator" : True if row.get(prefix+"get_nxt_indc") == 1 else False
        }
        researchTeam = result
        researcherTeams.append(researchTeam)
            
    result = {}
    result["researcherTeams"] = researcherTeams
    return result
