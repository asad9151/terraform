'''
Created on Mar 25, 2019

@author: VanCampK
'''
from enum import Enum

class GeoNameTypeCode(Enum):
    #32 = Official, 33 = Abbreviated
    GEO_NAME_TYPE_CODE_OFFICIAL = 32
    GEO_NAME_TYPE_CODE_ABBREVIATED = 33

    @classmethod
    def hasValue(cls, value):
        return any(value == item.value for item in cls)        