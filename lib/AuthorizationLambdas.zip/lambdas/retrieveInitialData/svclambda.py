'''
Created on Mar 7, 2019

@author: VanCampK
'''
import logging
import json

from lambdas.secureLambdaBase import SecureLambdaBase
from buildUIResponse import buildUIResponse
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.retrieveInitialData.service import Service
from common.irschRoles import IResearchRole
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaAuthorizationException
import lambdas.errorMessages as errmsg

class SvcLambda(SecureLambdaBase):
    '''
    Handler class for RetrieveInitialData service.
    Implementation of a Lambda handler as a class for a specific Lambda function.
    Handler: lambdas.retrieveInitialData.svclambda.handler
    '''

    # Class-level variables in the lambda are cached:
    cache_scotsData = None
    cache_geoUnitData = None
    cache_researchSubTypeData = None
    
    def __init__(self):
        self.service = None
    
    def handleSecureRequest(self):
        if self.service is None:
            self.service = Service(SvcLambda.dbConn)
        
        if SvcLambda.cache_scotsData is None:
            logging.info('retrieveInitialData cold start reading scotsData')
            scotsData = self.service.retrieveScotsData(self.requestContext)
            self._logResponseStatistics(scotsData, 'scotsData')
            SvcLambda.cache_scotsData = scotsData
        else:
            logging.info('retrieveInitialData warm start using scotsData from cache')
            
        if (SvcLambda.cache_geoUnitData) is None:
            logging.info('retrieveInitialData cold start reading geoUnitData')
            geoUnitData = self.service.retrieveCountryAndTerritoryData(self.requestContext)
            self._logResponseStatistics(geoUnitData, 'geoUnitData')
            SvcLambda.cache_geoUnitData = geoUnitData
        else:
            logging.info('retrieveInitialData warm start using geoUnitData from cache')

        if (SvcLambda.cache_researchSubTypeData) is None:
            logging.info('retrieveInitialData cold start reading researchSubTypeData')
            researchSubTypeData = self.service.retrieveResearchSubTypeToResolutionCodes(self.requestContext)
            self._logResponseStatistics(researchSubTypeData, 'researchSubTypeData')
            SvcLambda.cache_researchSubTypeData = researchSubTypeData
        else:
            logging.info('retrieveInitialData warm start using geoUnitData from cache')
            
        logging.info('retrieveInitialData reading countryToResearchSubTypeData')
        countryToResearchTypeData = self.service.retrieveCountryToResearchTypeData(self.requestContext)
        self._logResponseStatistics(countryToResearchTypeData, 'countryToResearchTypeData')
            
        logging.info('retrieveInitialData reading TeamMembersData')
        teamMembersData = self.service.retrieveTeamMembersData(self.requestContext)
        self._logResponseStatistics(teamMembersData, 'teamMembersData')
        
        logging.info('retrieveInitialData reading CurrentUserData')
        currentUserData = self.service.retrieveCurrentUserData(self.requestContext)
        self._logResponseStatistics(currentUserData, 'currentUserData')
        
        logging.info('retrieveInitialData reading TrainingMediaData')
        trainingMediaData = self.service.trainingMediaData(self.requestContext)
        self._logResponseStatistics(trainingMediaData, 'trainingMediaData')
        
        logging.info('retrieveInitialData reading ResearcherTeamsData')
        researcherTeamsData = self.service.retrieveResearcherTeams(self.requestContext)
        self._logResponseStatistics(researcherTeamsData, 'researcherTeams')
        
        combinedData = self.service.combineRetrieveInitialData(self.requestContext, SvcLambda.cache_scotsData, teamMembersData, SvcLambda.cache_geoUnitData, SvcLambda.cache_researchSubTypeData, currentUserData, 
                                                               countryToResearchTypeData, trainingMediaData, researcherTeamsData)
        #validateResponse(combinedData, self.environDict)
        responseBody = json.dumps(combinedData)
        return buildUIResponse(LambdaStatusCodes.OK.value, responseBody, 'application/json')

    def _logResponseStatistics(self, datadict, dataName):
        datalen = 0
        if datadict:
            # Have to go down one level to get the total #items
            for k,v in datadict.items():
                datalen += len(v)
                
        logging.info('retrieved ' + dataName + ' len=' + str(datalen))
            

    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN, IResearchRole.IRESEARCH_RESEARCHER, IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7, IResearchRole.IRESEARCH_TECH_SUPPORT, IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_INTERNAL_REVIEWER]) == False):
            logging.error('retrieveInitialData - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)

#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SvcLambda.get_handler(...)