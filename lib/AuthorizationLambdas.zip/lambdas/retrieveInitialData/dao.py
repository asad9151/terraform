'''
Created on Mar 4, 2019
DAO for RetrieveInitialData service

@author: VanCampK
'''
import json
import csv
from common.encoders import IResearchEncoder
from lambdas.retrieveInitialData.geoCodeTypeCodes import GeoCodeTypeCode
from lambdas.retrieveInitialData.geoUnitTypeCodes import GeoUnitTypeCode
from lambdas.retrieveInitialData.geoNameTypeCodes import GeoNameTypeCode
from common.requestMethodCodes import RequestMethodCode
from common.scotsTables import ScotsTable

def queryScotsData(dbConn, langCd):
    '''
    Some notes on the query below per review with Liz Fanning:
    Regarding expired codes:
    -    Any row in cd_val with expn_dt not null is considered expired – no need to actually compare the date.
    -    Any row in cd_val_txt with expn_dt not null can be ignored.
    -    The usage of expired SCOTS codes is that they can be used for display of output, but should never be used as valid input values (for instance on submitting or updating cases).
    -    Any row in cd_val_assn with expn_dt not null is considered expired. Since our use of this table is limited to validating input, we can ignore all expired associations and not load them at all.
    -    All of the above tables have an effv_dt which we can ignore, as it is not being used.
    Regarding the sys_appy table:
    -    Need to left-join because not every table we need is listed in sys_appy, for instance table 759 has no entry
    -    If cd_tbl_appy_indc=1 then cd_val_id will be null, so the entire table applies (first half of above “OR” clause)
    -    If cd_tbl_appy_indc=0 then cd_val_id will not be null, so only the selected cd_val_id’s in the table apply (second half of the above “OR” clause)
    '''
    query = '''
select distinct cv.cd_val_id as cdValId, cv.cd_tbl_id as cdTblId, cvt.lang_cd as langCd, cvt.prod_litr_desc as shrtDescr, cvt.cd_val_desc as descr,
case when cv.expn_dt is null then 0 else 1 end as isExpired,
case when sa.dnb_sys_cd is null then 0 when sa.dnb_sys_cd = 33485 then 1 else 0 end as isApplicableUi,
cv2.cd_val_id as C_cdValId, cv2.cd_tbl_id as C_cdTblId, cvt2.lang_cd as C_langCd, cvt2.prod_litr_desc as C_shrtDescr, cvt2.cd_val_desc as C_descr,
case when cv2.expn_dt is null then 0 else 1 end as C_isExpired,
case when sa2.dnb_sys_cd is null then 0 when sa2.dnb_sys_cd = 33485 then 1 else 0 end as C_isApplicableUi
from cd_val cv
join cd_val_txt cvt on cv.cd_val_id = cvt.cd_val_id 
left join sys_appy sa on (sa.cd_tbl_appy_indc=1 and sa.cd_tbl_id=cv.cd_tbl_id and sa.cd_val_id is null) or (sa.cd_tbl_appy_indc=0 and sa.cd_tbl_id=cv.cd_tbl_id and sa.cd_val_id=cv.cd_val_id)
join cd_val_assn cva on cva.prnt_cd_val_Id=cv.cd_val_id
join cd_val cv2 on cv2.cd_val_id=cva.chld_cd_val_Id
join cd_val_txt cvt2 on cv2.cd_val_id = cvt2.cd_val_id
left join sys_appy sa2 on (sa2.cd_tbl_appy_indc=1 and sa2.cd_tbl_id=cv2.cd_tbl_id and sa2.cd_val_id is null) or (sa2.cd_tbl_appy_indc=0 and sa2.cd_tbl_id=cv2.cd_tbl_id and sa2.cd_val_id=cv2.cd_val_id)
where cvt.expn_dt is null and cvt2.expn_dt is null
and (sa.dnb_sys_cd is null or sa.dnb_sys_cd in (33484,33485))
and cvt.lang_cd = %s
and (sa2.dnb_sys_cd is null or sa2.dnb_sys_cd in (33484,33485))
and cvt2.lang_cd = %s
and cva.expn_dt is null
UNION
select distinct cv.cd_val_id as cdValId, cv.cd_tbl_id as cdTblId, cvt.lang_cd as langCd, cvt.prod_litr_desc as shrtDescr, cvt.cd_val_desc as descr, 
case when cv.expn_dt is null then 0 else 1 end as isExpired,
case when sa.dnb_sys_cd is null then 0 when sa.dnb_sys_cd = 33485 then 1 else 0 end as isApplicableUi,
null as C_cdValId, null as C_cdTblId, null as C_langCd, null as C_shrtDescr, null as C_descr, null as C_isExpired, null as C_isApplicableUi
from cd_val cv
join cd_val_txt cvt on cv.cd_val_id = cvt.cd_val_id 
left join sys_appy sa on (sa.cd_tbl_appy_indc=1 and sa.cd_tbl_id=cv.cd_tbl_id and sa.cd_val_id is null) or (sa.cd_tbl_appy_indc=0 and sa.cd_tbl_id=cv.cd_tbl_id and sa.cd_val_id=cv.cd_val_id)
left join cd_val_assn cva on cva.prnt_cd_val_Id=cv.cd_val_id
where cvt.expn_dt is null
and (sa.dnb_sys_cd is null or sa.dnb_sys_cd in (33484,33485))
and cvt.lang_cd = %s
and (cva.prnt_cd_val_Id is null or cva.expn_dt is not null)
order by 2, 1, 8, 7, 14
    '''
    
    params = (langCd, langCd, langCd)
    dbConn.cursor.execute(query,params)
    rv = dbConn.cursor.fetchall()
    dict_data=[]
    for result in rv:
        #print(json.dumps(result, cls=IResearchEncoder) + ',')
        dict_data.append(result)

    # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
    json_data = json.dumps(dict_data, cls=IResearchEncoder)
    #print('Result of fetchall/zip:')
    #print(json_data)
    dict_arry = json.loads(json_data)
    #self._dumpcsv(dict_arry)
    return dict_arry

def _dumpcsv(self, dict_arry):
    # Dumps the data to a CSV file for testing/verification
    dict0 = dict_arry[0]
    with open('scotsData.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, dict0.keys())
        w.writeheader()
        w.writerows(dict_arry)

def queryAllTeamMembers(dbConn, teamNmeList):
    '''
    Gets the list of all teams, and the list of researchers on the named teams
    '''
    teamQuery = ''
    teamParamList = []
    first = True
    for teamNme in teamNmeList:
        teamParamList.append(teamNme)
        if (first == False):
            teamQuery += ','
        teamQuery += '%s'
        first = False

    paramList = []
    query = ''
    if len(teamNmeList) > 0:
        query = '''
select RT.rsch_team_id as RT_rsch_team_id, RT.rsch_team_org_nme as RT_rsch_team_org_nme, RT.ctry_code as RT_ctry_code, RT.rsch_team_nme as RT_rsch_team_nme, RT.rsch_team_dspl_nme as RT_rsch_team_dspl_nme, RT.get_nxt_indc as RT_get_nxt_indc, RT.mini_lnkg_indc as RT_mini_lnkg_indc,  
RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme, RU.sbmt_ctry_code as RU_sbmt_ctry_code, RU.acte_indc as RU_acte_indc, RU.acte_indc_tmst as RU_acte_indc_tmst  
from rsch_team RT
left join rsch_team_mbr TM on TM.rsch_team_id = RT.rsch_team_id and TM.team_admr_indc = 0
left join rsch_usr RU on RU.rsch_usr_id = TM.rsch_usr_id
        '''
        query += ' where RT.rsch_team_nme in ('
        query += teamQuery
        paramList.extend(teamParamList)
        query += ')'
        query += ' UNION '
    
    query += '''
select RT.rsch_team_id as RT_rsch_team_id, RT.rsch_team_org_nme as RT_rsch_team_org_nme, RT.ctry_code as RT_ctry_code, RT.rsch_team_nme as RT_rsch_team_nme, RT.rsch_team_dspl_nme as RT_rsch_team_dspl_nme, RT.get_nxt_indc as RT_get_nxt_indc, RT.mini_lnkg_indc as RT_mini_lnkg_indc,  
null as RU_rsch_usr_id, null as RU_usr_firs_nme, null as RU_usr_lst_nme, null as RU_usr_eml_adr, null as RU_lgin_key, null as RU_sbmt_org_nme, null as RU_sbmt_ctry_code, null as RU_acte_indc, null as RU_acte_indc_tmst  
from rsch_team RT
    '''
    if len(teamNmeList) > 0:
        query += ' where RT.rsch_team_nme not in ('
        query += teamQuery
        paramList.extend(teamParamList)
        query += ')'

    query += 'order by 1, 6'

    params = tuple(paramList)
    #print('queryAllTeamMembers: query=' + query + ' params=' + str(params))
    dbConn.cursor.execute(query,params)
    #row_headers=[x[0] for x in dbConn.cursor.description]
    rv = dbConn.cursor.fetchall()
    dict_data=[]
    for result in rv:
        #z = zip(row_headers,result)
        #d = dict(z)
        #print(json.dumps(result, cls=IResearchEncoder) + ',')
        #dict_data.append(d)
        dict_data.append(result)

    # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
    json_data = json.dumps(dict_data, cls=IResearchEncoder)
    #print('queryAllTeamMembers:' + str(json_data))
    dict_arry = json.loads(json_data)
    #print('after json.loads:' + str(dict_arry))
    #self._dumpcsv(dict_arry)
    return dict_arry


def queryResearcherTeams(dbConn, teamNmeList):
    '''
    Gets the list of all teams the researcher is part of 
    '''
    teamQuery = ''
    teamParamList = []
    first = True
    for teamNme in teamNmeList:
        teamParamList.append(teamNme)
        if (first == False):
            teamQuery += ','
        teamQuery += '%s'
        first = False

    paramList = []
    query = ''

    dict_arry=[]
    if len(teamNmeList) > 0:
        query = '''
            select RT.rsch_team_id as RT_rsch_team_id,  RT.rsch_team_nme as RT_rsch_team_nme, RT.rsch_team_dspl_nme as RT_rsch_team_dspl_nme, RT.get_nxt_indc as RT_get_nxt_indc
            from rsch_team RT
        '''
        query += ' where RT.rsch_team_nme in ('
        query += teamQuery
        paramList.extend(teamParamList)
        query += ')'

        query += ' order by RT.rsch_team_dspl_nme'

        params = tuple(paramList)
        dbConn.cursor.execute(query,params)

        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
            json_data = json.dumps(dict_data, cls=IResearchEncoder)
            dict_arry = json.loads(json_data)
    return dict_arry

def queryAllCountries(dbConn, langCd1, langCd2):
    # Retrieving the following geo_code_typ_cd: 23416 = ISO 2 Alpha, 23417 = ISO 3 Numeric, 23413 = Intl Dialing Code
    # Retrieving the following geo_nme_typ_cd: 32 = Official
    query = '''
select distinct GUP.geo_unit_id, GUP.geo_unit_typ_cd,
GUPC.geo_code_typ_cd, GUPC.geo_code,
GUPN.lang_cd, GUPN.geo_nme_typ_cd, GUPN.geo_nme
from geo_unit GUP
join geo_unit_code GUPC on GUPC.geo_unit_id = GUP.geo_unit_id
join geo_unit_nme GUPN on GUPN.geo_unit_id = GUP.geo_unit_id 
where 1=1
and GUP.expn_dt is null
and GUP.expd_by_dt is null
and GUPC.expn_dt is null
and GUPC.expd_by_dt is null
and GUPN.expn_dt is null
and GUPN.expd_by_dt is null
and GUPN.lang_cd in (%s,%s)
and GUP.geo_unit_typ_cd in (%s)
and GUPC.geo_code_typ_cd in (%s,%s,%s)
and GUPN.geo_nme_typ_cd in (%s)
order by GUP.geo_unit_id, GUPC.geo_code_typ_cd, GUPN.lang_cd
    '''
    params = (langCd1,
              langCd2,
              GeoUnitTypeCode.GEO_UNIT_TYPE_CODE_COUNTRY.value,
              GeoCodeTypeCode.GEO_CODE_TYPE_CODE_INTLDIALING.value,
              GeoCodeTypeCode.GEO_CODE_TYPE_CODE_ISO2ALPHA.value,
              GeoCodeTypeCode.GEO_CODE_TYPE_CODE_ISO3NUMERIC.value,
              GeoNameTypeCode.GEO_NAME_TYPE_CODE_OFFICIAL.value)
    dbConn.cursor.execute(query, params)
    rv = dbConn.cursor.fetchall()
    dict_data=[]
    for result in rv:
        #print(json.dumps(result, cls=IResearchEncoder) + ',')
        dict_data.append(result)

    #print('Got ' + str(len(dict_data)) + ' GeoUnit rows')
    # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
    json_data = json.dumps(dict_data, cls=IResearchEncoder)
    #print('Result of fetchall/zip:')
    #print(json_data)
    dict_arry = json.loads(json_data)
    #self._dumpcsv(dict_arry)
    return dict_arry
    
def queryCountryTerritories(dbConn, langCd1, langCd2):
    # Queries all the territories in all countries that have territories
    # Retrieving the following geo_nme_typ_cd: 32 = Official, 33 = Abbreviated
    query='''
select distinct GUP.geo_unit_id as P_geo_unit_id, GUP.geo_unit_typ_cd as P_geo_unit_typ_cd,
GUC.geo_unit_id, GUC.geo_unit_typ_cd,
GUCN.lang_cd, GUCN.geo_nme_typ_cd, GUCN.geo_nme
from geo_unit GUP
join geo_unit_assn GUA on GUA.prnt_geo_unit_id = GUP.geo_unit_id
join geo_unit GUC on GUC.geo_unit_id = GUA.chld_geo_unit_id
join geo_unit_nme GUCN on GUCN.geo_unit_id = GUC.geo_unit_id
where 1=1
and GUP.expn_dt is null
and GUP.expd_by_dt is null
and GUA.expn_dt is null
and GUA.expd_by_dt is null
and GUC.expn_dt is null
and GUC.expd_by_dt is null
and GUCN.expn_dt is null
and GUCN.expd_by_dt is null
and GUCN.lang_cd in (%s,%s)
and GUP.geo_unit_typ_cd in (%s)
and GUC.geo_unit_typ_cd in (%s)
and GUCN.geo_nme_typ_cd in (%s,%s)
order by GUP.geo_unit_id, GUC.geo_unit_id, GUCN.geo_nme_typ_cd, GUCN.lang_cd
    '''
    params = (langCd1,
              langCd2,
              GeoUnitTypeCode.GEO_UNIT_TYPE_CODE_COUNTRY.value,
              GeoUnitTypeCode.GEO_UNIT_TYPE_CODE_TERRITORY.value,
              GeoNameTypeCode.GEO_NAME_TYPE_CODE_OFFICIAL.value,
              GeoNameTypeCode.GEO_NAME_TYPE_CODE_ABBREVIATED.value)
    dbConn.cursor.execute(query, params)
    rv = dbConn.cursor.fetchall()
    dict_data=[]
    for result in rv:
        #print(json.dumps(result, cls=IResearchEncoder) + ',')
        dict_data.append(result)

    #print('Got ' + str(len(dict_data)) + ' GeoUnit C-T rows')
    # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
    json_data = json.dumps(dict_data, cls=IResearchEncoder)
    #print('Result of fetchall/zip:')
    #print(json_data)
    dict_arry = json.loads(json_data)
    #self._dumpcsv(dict_arry)
    return dict_arry

def queryResearchSubTypeToResolutionCodes(dbConn):
    query = '''
select rsch_sub_typ_cd,resl_cd,sub_resl_cd
from rsch_typ_resl_cmbo
order by rsch_sub_typ_cd,resl_cd,sub_resl_cd
    '''
    
    dbConn.cursor.execute(query)
    rv = dbConn.cursor.fetchall()
    dict_data=[]
    for result in rv:
        #print(json.dumps(result, cls=IResearchEncoder) + ',')
        dict_data.append(result)

    json_data = json.dumps(dict_data, cls=IResearchEncoder)
    dict_arry = json.loads(json_data)
    return dict_arry

def queryCountryToResearchTypeData(dbConn, subTypeGroups):
    query = '''
select ctry_code, rsch_typ_cd, rsch_sub_typ_cd
from rsch_sub_typ_by_ctry cs
join cd_val_assn cva
on cs.rsch_sub_typ_cd = cva.chld_cd_val_Id
join cd_val cv
on cv.cd_val_id = cva.prnt_cd_val_Id
where cd_tbl_id = %s
and cv.expn_dt is null
and cva.expn_dt is null
and prnt_cd_val_Id in (''' + ','.join(map(str, subTypeGroups)) + ''')
and sub_typ_grp in (''' + ','.join(map(str, subTypeGroups)) + ''')
and reqs_meth_cd = %s
order by ctry_code, rsch_typ_cd, rsch_sub_typ_cd;
    '''
    params = (ScotsTable.RESEARCH_SUBTYPE_GROUPS.value,
              RequestMethodCode.IRESEARCH_UI.value)
    
    dbConn.cursor.execute(query, params)
    rv = dbConn.cursor.fetchall()
    dict_data=[]
    for result in rv:
        #print(json.dumps(result, cls=IResearchEncoder) + ',')
        dict_data.append(result)

    json_data = json.dumps(dict_data, cls=IResearchEncoder)
    dict_arry = json.loads(json_data)
    return dict_arry



def queryAllTrainingMedia(dbConn):
    '''
    Gets the list of all training media in our trng_mdia table.  This list will be used by the UI to display
    all the training media content that is available on the respective training media pages.  Another service
    will be invoked by the UI to get the attachmentLink for a training media artifact when it is clicked by 
    an end user. 
    '''
    query = '''
select trng_mdia_id, mdia_typ, mdia_nme, mdia_desc_txt, mdia_ctgy_typ, mdia_ordr_nbr, 
attm.fle_nme, mdia_vte_cnt, mdia_vte_tot_nbr, mdia_vws_cnt,
UNIX_TIMESTAMP(attm.row_mod_tmst) as mod_timestamp from trng_mdia
inner join attm on trng_mdia.attm_id = attm.attm_id; 
    '''
    
    dbConn.cursor.execute(query)
    rv = dbConn.cursor.fetchall()
    dict_data=[]
    for result in rv:
        dict_data.append(result)

    json_data = json.dumps(dict_data, cls=IResearchEncoder)
    dict_arry = json.loads(json_data)
    return dict_arry