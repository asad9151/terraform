'''
Created on Jul 1, 2019

@author: JafferS
'''

from itertools import groupby
from operator import itemgetter

def mapCountryToResearchTypeToSchema(qryResult):
    groupByCountryDict = _groupByCountry(qryResult)
    return _transformGroupsToSchema(groupByCountryDict)

def _groupByCountry(qryResult):
    grouper = itemgetter("ctry_code")
    groups = groupby(qryResult,  grouper)
    return groups

def _transformGroupsToSchema(groupByCountryDict):
    countries = []
    for countryCd, group in groupByCountryDict:
        researchTypeList = []
        typeGrouper = itemgetter("rsch_typ_cd")
        typeGroups = groupby(group,  typeGrouper)
        for researchType, group1 in typeGroups:
            researchSubTypes = []
            for item in group1:
                researchSubTypes.append(item["rsch_sub_typ_cd"])
            typeEntry = {
                "researchType": researchType,
                "researchSubTypes": researchSubTypes
            }
            researchTypeList.append(typeEntry)
        countryEntry = {
            "countryCd": countryCd,
            "researchTypes": researchTypeList
        }
        countries.append(countryEntry)
        
    result = {}
    result["countryToResearchTypeData"] = countries
    return result
