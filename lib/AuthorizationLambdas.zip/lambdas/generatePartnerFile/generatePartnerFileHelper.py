import logging
import json
import os
import zipfile
from common import envVblNames
from common.dao.fileTrackingDao import FileTrackingDao
from common.dao.updateEventDao import UpdateEventDao
from common.dao.partnerDetailDao import PartnerDetailDao
from common.partnerFileType import PartnerFileType
from common.model.stpDeliveryFile import StpDeliveryFile
from common.model.stpPartnerDeliveryFile import StpPartnerDeliveryFile
from common.model.partnerDetail import PartnerDetail
from common.model.s3Object import S3Object
from common.util.s3Helper import S3Helper
from common.processResultCodes import ProcessResultCode
from common.processStatusCodes import ProcessStatusCode
from urllib.parse import unquote_plus
from common.mappers.apiApplicationEntitlementMapper import mapToApiApplicationEntitlement

STP_OUTBOUND_FOLDER = 'stp-outbound'
MODULE_NAME = 'GeneratePartnerFileService'
LOCAL_DIRECTORY = '/tmp/'    

class GeneratePartnerFileHelper(object):
    
    requestContext = None
    fileTrackingDao = None
    updateEventDao = None
    datastoresBucket = None
    partnerDetailDao = None
    dbConn = None
    s3Helper = None
    
    def __init__(self, requestContext, dbConn):
        self.requestContext = requestContext
        self.dbConn = dbConn
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
        if self.fileTrackingDao is None:
            self.fileTrackingDao = FileTrackingDao()
        if self.updateEventDao is None:
            self.updateEventDao = UpdateEventDao()
        if self.partnerDetailDao is None:
            self.partnerDetailDao = PartnerDetailDao()
        if self.datastoresBucket is None:
            self.datastoresBucket = self.requestContext.environDict[envVblNames.ENV_DATASTORES_BUCKET]

        
    def updateFileTrackingTables(self, fileTrackId, partnerFileTrackingId, apiAppData, count, s3Object, attachmentCount):
        stpDeliveryFile = self.createOutboundStpDeliveryFile(s3Object, apiAppData)
        stpDeliveryFile.fileTrackingId = fileTrackId
        self.fileTrackingDao.updateFileTracking(self.dbConn, stpDeliveryFile, MODULE_NAME)

        stpPartnerDeliveryFile = self.createOutboundStpPartnerDeliveryFile (partnerFileTrackingId, count, apiAppData, attachmentCount)
        stpPartnerDeliveryFile.partnerFileTrackingId = partnerFileTrackingId
        self.fileTrackingDao.updatePartnerFileTracking(self.dbConn, stpPartnerDeliveryFile, MODULE_NAME)

    def insertIntoFileTrackingTable(self, zipFileName, apiAppData):
        s3Object = self.createS3ObjectForPartnerFile(apiAppData, zipFileName, 0)
        stpDeliveryFile = self.createOutboundStpDeliveryFile(s3Object, apiAppData)
        fileTrackId = self.fileTrackingDao.insertFileTracking(self.dbConn, stpDeliveryFile, MODULE_NAME)
        return fileTrackId
            
    def insertIntoPartnerFileTrackingTable(self, fileTrackId, apiAppData):
        stpPartnerDeliveryFile = self.createOutboundStpPartnerDeliveryFile (fileTrackId, 0, apiAppData, 0)
        partnerFileTrackingId = self.fileTrackingDao.insertPartnerFileTracking(self.dbConn, stpPartnerDeliveryFile, MODULE_NAME)
        return partnerFileTrackingId
    
    def insertPartnerDetailTable(self, partnerFileTrackingId, messageBody, count):
        messageDict = json.loads(messageBody)
        partnerDetail = PartnerDetail()
        partnerDetail.partnerFileTrackingId = partnerFileTrackingId
        partnerDetail.rawDataObject = messageBody
        partnerDetail.recordNumber = count
        partnerDetail.rejectionIndicator = 0
        subjRsch = messageDict.get('subjectResearch', None)
        if subjRsch is not None:
            subjectResearchId = subjRsch.get('subjectResearchId', None)
            partnerDetail.subjectResearchId = subjectResearchId
        self.partnerDetailDao.insertPartnerDetail(self.dbConn, partnerDetail, MODULE_NAME)
        
    def handleAttachments(self, messageBody, directoryName):
        attachmentCount = 0
        messageDict = json.loads(messageBody)
        if 'attachments' in messageDict and len(messageDict['attachments']) > 0:
            attachments = messageDict['attachments']
            subjRsch = messageDict.get('subjectResearch', None)
            if subjRsch is not None:
                subjectResearchId = subjRsch.get('subjectResearchId', None)
                if subjectResearchId is not None:
                    attachmentDirectory = directoryName + '/' + str(subjectResearchId)
                    os.mkdir(attachmentDirectory)
                    for attachment in attachments:
                        s3Object = self.createS3ObjectForAttachment(attachment)
                        logging.info("attachment is %s " % attachment['filename'])
                        self.s3Helper.copyFromS3ToLocal(s3Object, attachmentDirectory + '/' + attachment['filename'])
                        attachmentCount = attachmentCount + 1
        return attachmentCount
        
    def createZipFile(self, zipFileName, directoryName):
        zf = zipfile.ZipFile(LOCAL_DIRECTORY + zipFileName, "w")
        for dirname, subdirs, files in os.walk(directoryName):
            for filename in files:
                filePath = os.path.join(dirname, filename)
                pathToUse = filePath.replace(directoryName, "")
                zf.write(filePath, pathToUse)
        zf.close()

    def createOutboundStpDeliveryFile(self, s3Object, apiAppData):
        stpDeliveryFile = StpDeliveryFile()
        stpDeliveryFile.inboundOutboundIndicator = StpDeliveryFile.STP_DELIVERY_OUTBOUND
        stpDeliveryFile.relativeFolder = apiAppData['ptnr_fldr_nme']
        stpDeliveryFile.s3Object = s3Object
        stpDeliveryFile.processStatusCode = ProcessStatusCode.PROCESSING_COMPLETE.value
        stpDeliveryFile.processResultCode = ProcessResultCode.SUCCESSFUL.value
        stpDeliveryFile.deliveryAttemptCount = 1
        
        return stpDeliveryFile
    
    def createOutboundStpPartnerDeliveryFile(self, fileTrackId, count, apiAppData, attachmentCount):
        apiAppEntl = mapToApiApplicationEntitlement(apiAppData, "")
        stpPartnerDeliveryFile = StpPartnerDeliveryFile()
        stpPartnerDeliveryFile.fileTrackingId = fileTrackId
        stpPartnerDeliveryFile.apiApplicationEntitlement = apiAppEntl
        stpPartnerDeliveryFile.fileTypeCode = PartnerFileType.RESEARCH_REQUEST.value['fileTypeCode']
        stpPartnerDeliveryFile.recordCount = count
        stpPartnerDeliveryFile.attachmentCount = attachmentCount
        
        return stpPartnerDeliveryFile

    def createS3ObjectForPartnerFile (self, apiAppData, zipFileName, fileSize):
        s3Object = S3Object()
        s3Object.setS3ObjectKey('s3://' + self.datastoresBucket + '/' + STP_OUTBOUND_FOLDER + '/' + apiAppData['ptnr_fldr_nme'] + '/'  + zipFileName)
        s3Object.fileSize = fileSize
        
        return s3Object
    
    def createS3ObjectForAttachment(self, attachment):
        s3Object = S3Object()
        s3Object.setS3ObjectKey(attachment['s3ObjectKey'])
        s3Object.fileSize = attachment['attachmentSize']
        
        return s3Object
    
    def getS3ObjectForS3Trigger(self, event):
        s3Object = S3Object()
        try:
            incomingS3Bucket = (event['Records'][0]['s3']['bucket']['name'])
        except Exception as e:
            logging.error('getS3Overrides: missing bucket name from event data.  error msg = %s',e)
            raise        
        try: 
            incomingS3Key = (unquote_plus(event['Records'][0]['s3']['object']['key']))
        except Exception as e:
            logging.error('_getS3ObjectForS3Trigger: missing S3Key from event data  error msg = %s',e)
            raise    
        logging.info('_getS3ObjectForS3Trigger:  bucket = %s', incomingS3Bucket)
        logging.info('_getS3ObjectForS3Trigger:  key = %s', incomingS3Key)

        s3Object.setS3ObjectKey('s3://' + incomingS3Bucket + '/' + incomingS3Key)
        return s3Object

        