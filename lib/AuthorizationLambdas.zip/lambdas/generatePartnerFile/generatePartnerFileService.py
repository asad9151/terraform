import logging
import os
import shutil
from common import envVblNames
from common.dao.apiApplicationEntitlementDao import ApiApplicationEntitlementDao
from datetime import datetime
from common.partnerFileType import PartnerFileType
from common.util.s3Helper import S3Helper
import lambdas.errorMessages as errmsg
from lambdas.generatePartnerFile.generatePartnerFileHelper import GeneratePartnerFileHelper

LOCAL_DIRECTORY = '/tmp/'    
DATE_FORMAT = "%Y%m%d%H%M%S%f"
JSON_FILE_NAME = 'records.json'
MODULE_NAME = 'GeneratePartnerFileService'

class GeneratePartnerFileService (object):
    sqsHelper = None
    requestContext = None
    dbConn = None
    apiApplicationEntitlementDao = None
    s3Helper = None
    generatePartnerFileHelper = None
    alert = None
    
    def __init__(self, sqsHelper, requestContext, dbConn, alert):
        self.sqsHelper = sqsHelper
        self.alert = alert
        self.requestContext = requestContext
        self.dbConn = dbConn
        if self.apiApplicationEntitlementDao is None:
            self.apiApplicationEntitlementDao = ApiApplicationEntitlementDao()
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
        if self.generatePartnerFileHelper is None:
            self.generatePartnerFileHelper = GeneratePartnerFileHelper(requestContext, dbConn)
              
    def generateFile(self):
        try:
            apiAppData = self.apiApplicationEntitlementDao.queryApiApplication(self.dbConn,  self.requestContext.environDict[envVblNames.ENV_PARTNER_APP_ID])
            currDateTime = datetime.now()
            dateTimeStr = currDateTime.strftime(DATE_FORMAT)[:-6]
            directoryName = LOCAL_DIRECTORY + dateTimeStr + '/'
            zipFileName = PartnerFileType.RESEARCH_REQUEST.value['fileNamePrefix'] + dateTimeStr + '.zip'
    
            count = 0
            attachmentCount = 0
            lastException = None
            os.mkdir(directoryName)
            with open(directoryName + JSON_FILE_NAME, 'w') as newFile:
                messages = self.sqsHelper.getAllMessagesNoDelete()
                for message in messages:
                    logging.info(message)
                    receipt_handle = None
                    if message is not None:
                        try:
                            if 'MessageId' in message:
                                logging.info('messageId is: %s ' % message['MessageId'])
        
                            if 'ReceiptHandle' in message and 'Body' in message:
                                receipt_handle = message['ReceiptHandle']
                                logging.info('current receipt handle is %s' %  receipt_handle)
                                
                                if count == 0:
                                    if not apiAppData.get('ptnr_fldr_nme', None):
                                        logging.error('Partner folder not configured for dnb_app_id %s ' % str(apiAppData.get('dnb_app_id')))
                                        raise Exception('Partner folder not configured for dnb_app_id %s ' % str(apiAppData.get('dnb_app_id')))

                                    fileTrackId = self.generatePartnerFileHelper.insertIntoFileTrackingTable(zipFileName, apiAppData)
                                    partnerFileTrackingId = self.generatePartnerFileHelper.insertIntoPartnerFileTrackingTable(fileTrackId, apiAppData)
                                messageBody = message['Body']
                                logging.info ('Record is %s' % messageBody)
                                count = count + 1
                                try:
                                    self.generatePartnerFileHelper.insertPartnerDetailTable(partnerFileTrackingId, messageBody, count)
                                except Exception as e:
                                    logging.error('Error while inserting rec into partner detail table. Rec is %s, Error = %s' % (messageBody, e) )
                                    # want to keep processing and not throw exception in case of database error
                                    
                                newFile.write(messageBody + '\n')
                                try:
                                    numAttachments = self.generatePartnerFileHelper.handleAttachments(messageBody, directoryName)
                                    attachmentCount = attachmentCount + numAttachments
                                except Exception as e:
                                    errorMsg ='Error while handling attachments for rec. partnerFileTrackingId is %s, Error = %s' % (str(partnerFileTrackingId), str(e))
                                    logging.error(errorMsg)
                                    self.alert.raiseAlert(MODULE_NAME, errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=errorMsg)                                
                                    # want to keep processing and not throw exception in case of s3 error
        
                                logging.info('Deleting msg with handle %s' % receipt_handle)
                                self.sqsHelper.deleteOneMessageFromQueue(receipt_handle)
                        except Exception as recError:
                            logging.error('Error while processing rec for partner.. Message is %s. Error = %s' % (message, recError))
                            lastException = recError
                            # try to keep going 
    
            if count > 0:
                self.generatePartnerFileHelper.createZipFile(zipFileName, directoryName)
                fileSize = os.path.getsize(LOCAL_DIRECTORY + zipFileName)            
                s3Object = self.generatePartnerFileHelper.createS3ObjectForPartnerFile(apiAppData, zipFileName, fileSize)
                self.generatePartnerFileHelper.updateFileTrackingTables(fileTrackId, partnerFileTrackingId, apiAppData, count, s3Object, attachmentCount)
                self.s3Helper.copyFromLocalToS3(LOCAL_DIRECTORY + zipFileName, s3Object)
                
            # cleanup
            shutil.rmtree(directoryName, ignore_errors=True)
                
        except Exception as e1: 
            logging.error('Error while generating partner file. Error = %s' % e1)
            raise e1
        
        if lastException is not None:
            logging.error('Partner file generated and placed in datastores bucket but individual record failed.')
            raise lastException
        