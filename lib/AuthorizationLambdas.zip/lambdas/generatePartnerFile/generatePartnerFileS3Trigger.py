import logging
import json
import os
import shutil
from common import envVblNames
from common.dao.partnerDetailDao import PartnerDetailDao
from common.dao.apiApplicationEntitlementDao import ApiApplicationEntitlementDao
from datetime import datetime
from common.partnerFileType import PartnerFileType
from common.util.s3Helper import S3Helper
from lambdas.generatePartnerFile.generatePartnerFileHelper import GeneratePartnerFileHelper
from lambdas.generatePartnerFile.retryActionCode import RetryActionCode

LOCAL_DIRECTORY = '/tmp/'    
DATE_FORMAT = "%Y%m%d%H%M%S%f"
JSON_FILE_NAME = 'records.json'

class GeneratePartnerFileS3Trigger (object):
    requestContext = None
    datastoresBucket = None
    partnerDetailDao = None
    dbConn = None
    apiApplicationEntitlementDao = None
    s3Helper = None
    generatePartnerFileHelper = None
    
    def __init__(self, requestContext, dbConn):
        self.requestContext = requestContext
        self.dbConn = dbConn
        if self.partnerDetailDao is None:
            self.partnerDetailDao = PartnerDetailDao()
        if self.apiApplicationEntitlementDao is None:
            self.apiApplicationEntitlementDao = ApiApplicationEntitlementDao()
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
        if self.generatePartnerFileHelper is None:
            self.generatePartnerFileHelper = GeneratePartnerFileHelper(requestContext, dbConn)      
            
    def generateFile(self):
    
        try:
            logging.info("event is %s" % self.requestContext.event)
            s3ObjectForS3Trigger = self.generatePartnerFileHelper.getS3ObjectForS3Trigger(self.requestContext.event)
            self.s3Helper.copyFromS3ToLocal (s3ObjectForS3Trigger, LOCAL_DIRECTORY + 's3TriggerFile.json')
            with open(LOCAL_DIRECTORY + 's3TriggerFile.json', 'r') as triggerFile:
                first_line = triggerFile.readline()
                recDict = json.loads(first_line)
                logging.info('Rerun rec is %s ' % recDict)
                if 'retryActionCode' in recDict:
                    if recDict['retryActionCode'] != RetryActionCode.GENERATE_FROM_PARTNER_DETAIL.value:
                        logging.error('retryActionCode is %s and not %s ' % (recDict['retryActionCode'], RetryActionCode.GENERATE_FROM_PARTNER_DETAIL.value))
                        raise Exception('retryActionCode is %s and not %s ' % (recDict['retryActionCode'], RetryActionCode.GENERATE_FROM_PARTNER_DETAIL.value))
                else:
                    logging.error('retryActionCode missing')
                    raise Exception('retryActionCode missing')
                if 'ptnrFleTkgId' not in recDict:
                    logging.error('ptnrFleTkgId missing')
                    raise Exception('ptnrFleTkgId missing')
                if 'fleTkgId' not in recDict:
                    logging.error('fleTkgId missing')
                    raise Exception('fleTkgId missing')
                    
            apiAppData = self.apiApplicationEntitlementDao.queryApiApplication(self.dbConn,  self.requestContext.environDict[envVblNames.ENV_PARTNER_APP_ID])
            if not apiAppData.get('ptnr_fldr_nme', None):
                logging.error('Partner folder not configured for dnb_app_id %s ' % str(apiAppData.get('dnb_app_id')))
                raise Exception('Partner folder not configured for dnb_app_id %s ' % str(apiAppData.get('dnb_app_id')))
    
            currDateTime = datetime.now()
            dateTimeStr = currDateTime.strftime(DATE_FORMAT)[:-6]
            directoryName = LOCAL_DIRECTORY + dateTimeStr + '/'
            zipFileName = PartnerFileType.RESEARCH_REQUEST.value['fileNamePrefix'] + dateTimeStr + '.zip'
            
            partnerFileTrackingId = recDict['ptnrFleTkgId']
            logging.info("partnerFileTrackingId: %s" % str(partnerFileTrackingId))
            fileTrackId  = recDict['fleTkgId']
            logging.info("partnerFileTrfileTrackIdackingId: %s" % str(fileTrackId))
            
            count = 0
            attachmentCount = 0
            os.mkdir(directoryName)
            with open(directoryName + JSON_FILE_NAME, 'w') as newFile:
                partnerFileRecs = self.partnerDetailDao.queryPartnerDetail(self.dbConn, partnerFileTrackingId)
                for rec in partnerFileRecs:
                    jsonRec = rec.getRawDataObject()
                    logging.info('Detail json rec is %s ' % jsonRec)

                    count = count + 1
                                        
                    newFile.write(jsonRec + '\n')
                    numAttachments = self.generatePartnerFileHelper.handleAttachments(jsonRec, directoryName)
                    attachmentCount = attachmentCount + numAttachments
            if count > 0:
                self.generatePartnerFileHelper.createZipFile(zipFileName, directoryName)
                fileSize = os.path.getsize(LOCAL_DIRECTORY + zipFileName)            
                s3Object = self.generatePartnerFileHelper.createS3ObjectForPartnerFile(apiAppData, zipFileName, fileSize)
                self.generatePartnerFileHelper.updateFileTrackingTables(fileTrackId, partnerFileTrackingId, apiAppData, count, s3Object, attachmentCount)
                self.s3Helper.copyFromLocalToS3(LOCAL_DIRECTORY + zipFileName, s3Object)
                
            # cleanup
            shutil.rmtree(directoryName, ignore_errors=True)
                
        except Exception as e1: 
            logging.error('Error while Re-generating partner file. Error = %s' % e1)
            raise e1
    
         