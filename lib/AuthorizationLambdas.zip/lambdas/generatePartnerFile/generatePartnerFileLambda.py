'''
Created on Nov 25, 2019

@author: JafferS
'''
from lambdas.lambdaBase import LambdaBase
from lambdas.generatePartnerFile.generatePartnerFileService import GeneratePartnerFileService
from lambdas.generatePartnerFile.generatePartnerFileS3Trigger import GeneratePartnerFileS3Trigger
from common import envVblNames
import logging
from common.util.sqsHelper import SqsHelper
from determineStartType import determineStartType
import lambdas.lambdaConstants as consts

class GeneratePartnerFileLambda(LambdaBase):
    sqsHelper = None
    lambdaClient = None
    service = None
    serviceS3Trigger = None
        
    def exitOnTimerEvent(self):
        logging.debug("*********exitTimerEvent**********")
        return False
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return True
    
    def handleRequest(self):
        logging.debug("*******handleRequest******")
        logging.info("in GeneratePartnerFileLambda, handle request")
        LambdaBase.raiseAlertWhenRequestFails = True
        startType = determineStartType(self.requestContext.event)
        if startType == consts.LAMBDA_START_TYPE_TIMER:
            if self.service is None:
                self.service = GeneratePartnerFileService(GeneratePartnerFileLambda.sqsHelper,  self.requestContext, GeneratePartnerFileLambda.dbConn, LambdaBase.alert)
            self.service.generateFile()
        elif startType == consts.LAMBDA_START_TYPE_S3:
            serviceS3Trigger = GeneratePartnerFileS3Trigger(self.requestContext, GeneratePartnerFileLambda.dbConn)
            serviceS3Trigger.generateFile()
        
    def initializeKeepWarm(self):
        logging.debug("*******initializeKeepWarm******")
        if GeneratePartnerFileLambda.sqsHelper is None:
            try:
                if GeneratePartnerFileLambda.environDict.get(envVblNames.ENV_SQS_QUEUE_PREFIX) and GeneratePartnerFileLambda.environDict.get(envVblNames.ENV_PARTNER_QUEUE_NAME) is not None:
                    regionName = GeneratePartnerFileLambda.environDict.get(envVblNames.ENV_SQS_REGION)
                    sqsQueueName = GeneratePartnerFileLambda.environDict.get(envVblNames.ENV_SQS_QUEUE_PREFIX) + GeneratePartnerFileLambda.environDict.get(envVblNames.ENV_PARTNER_QUEUE_NAME)
                    GeneratePartnerFileLambda.sqsHelper = SqsHelper(queueUrl=sqsQueueName, regionName=regionName)
            except:
                raise RuntimeError("SQS not configured")
                

#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = GeneratePartnerFileLambda.get_handler(...)