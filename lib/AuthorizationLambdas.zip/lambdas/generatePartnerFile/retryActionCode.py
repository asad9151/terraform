'''
Created on Nov 25, 2019

@author: JafferS
'''
from enum import Enum

class RetryActionCode(Enum):
    GENERATE_FROM_PARTNER_DETAIL = 1
    