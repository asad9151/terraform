'''
Modified on Apr 19, 2019

@author: VanCampK
'''
import boto3
from botocore.client import Config
import logging
import sys
import traceback
import constants
from databaseClass import databaseClass
from buildUIResponse import buildUIResponse
from attachmentClass import attachment
from common.irschRoles import IResearchRole
from common.util.awsUtils import createClientConfiguration
from lambdas.secureLambdaBase import SecureLambdaBase
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaProcessingException, LambdaAuthorizationException, LambdaValidationException, LambdaConflictException
from common.dao.subjectResearchDao import SubjectResearchDao
from common.dao.researchRequestDao import ResearchRequestDao
from lambdas.attachment.deleteAttachmentService import DeleteAttachmentService
import lambdas.errorMessages as errmsg
from lambdas.attachment.attachmentHelper import AttachmentHelper

class DeleteAttachmentLambda(SecureLambdaBase):
    '''
    Handler class for DeleteAttachment service.
    Handler: lambdas.attachment.deleteAttachmentlambda.handler
    '''
    s3 = None
    subjectResearchDao = None
    researchRequestDao = None
    attachmentHelper = None

    def __init__(self):
        self.service = None
    
    def handleSecureRequest(self):
        if self.service is None:
            self.service = DeleteAttachmentService(DeleteAttachmentLambda.dbConn, DeleteAttachmentLambda.s3)
            
        incomingContent = self.requestContext.incomingContent
        attmId = incomingContent.get(DeleteAttachmentService.REQUEST_ATTM_ID_PARAM)

        if attmId is None:
            logging.error('DeleteAttachmentLambda-E001: missing key value from incoming request.  event-body = %s', incomingContent)
            raise LambdaValidationException('missing key in deleteattachment request')

        attmObj = self.service.loadAttachment(attmId)
        if DeleteAttachmentLambda.attachmentHelper is None:
            DeleteAttachmentLambda.attachmentHelper = AttachmentHelper(self.dbConn)
        self.requestContext.cacheObj = DeleteAttachmentLambda.attachmentHelper.loadCaseOrRequest(attmObj)
        
        self.authorizeDeleteAttachmentFromCaseOrRequest(attmObj)

        self.service.deleteAttachment(self.requestContext)

        msgBody = "{}"
        return buildUIResponse(LambdaStatusCodes.OK.value, msgBody, 'application/json')

    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER, IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error('DeleteAttachmentLambda - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)


    def initializeKeepWarm(self):
        if not DeleteAttachmentLambda.s3:
            try:
                logging.info('Initializing s3...')
                DeleteAttachmentLambda.s3 = boto3.client('s3', config=createClientConfiguration(DeleteAttachmentLambda.environDict, mergeConfig=Config(signature_version='s3v4')))
                #DeleteAttachmentLambda.s3 = boto3.resource('s3')
            except Exception as e:
                logging.error('DeleteAttachmentLambda-E004: problem connecting to s3 client.  error = %s', e)
                return buildUIResponse(LambdaStatusCodes.INTERNAL_SERVER_ERROR.value, 'Internal error in DeleteAttachment')


    def authorizeDeleteAttachmentFromCaseOrRequest(self, attmObj):
        # Can only delete user-uploaded attachments, not BDRS response
        attmType = attmObj.getIncomingType()
        if attmType != constants.SUBMITTER_ATTACHMENT and attmType != constants.CASE_RESOLUTION_ATTACHMENT and attmType != constants.RESEARCHER_INTERNAL_ATTACHMENT and attmType != constants.CHALLENGE_ATTACHMENT:
            logging.error('DeleteAttachmentLambda-E005: attachment type ' + str(attmType) + ' is not a valid attachment type to delete')
            raise LambdaValidationException('not a valid attachment type to delete')
        
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN ]) == True):
            # SuperAdmin can delete any attachment
            return
        
        if attmObj.getResearchRequestId():
            # request level attachment
            rschReqsId = self.requestContext.cacheObj.get('rsch_reqs_id')
            logging.error('User=' + self.requestContext.userSession.emailId + ' is not a superadmin so cant delete submitter attachment for rschReqsId=' + str(rschReqsId))
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
        
        if attmObj.getSubjectResearchId():
            subjRschId = self.requestContext.cacheObj.get('subj_rsch_id')
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER ]) == False):
                logging.error('User does not have researcher role so cant delete case level attachment for subjRschId=' + str(subjRschId))
                raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
            rschEmailId = self.requestContext.cacheObj.get('usr_eml_adr')
            if not rschEmailId or self.requestContext.userSession.emailId != rschEmailId:
                logging.error('User=' + self.requestContext.userSession.emailId + ' is not the assigned researcher=' + str(rschEmailId) + ' for subjRschId=' + str(subjRschId))
                raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)

        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = DeleteAttachmentLambda.get_handler(...)