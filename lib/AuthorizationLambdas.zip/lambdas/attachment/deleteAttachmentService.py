'''
Created on Apr 23, 2019

@author: VanCampK
'''
#from attachmentClass import attachment
import boto3
import logging
import constants
from common import updateEventConstants
from common.mappers.attachmentMapper import mapToAttachmentObj
from common.dao.updateEventDao import UpdateEventDao
from common.updateActionCodes import UpdateActionCode
from lambdas.exceptions import LambdaValidationException
from lambdas.attachment.attachmentDao import AttachmentDao

class DeleteAttachmentService(object):
    REQUEST_ATTM_ID_PARAM = 'attmId'

    def __init__(self, dbConn, s3):
        self.dbConn = dbConn
        self.s3 = s3
        self.attmObj = None
        self.attachmentDao = None
        self.updateEventDao = None

        
    def loadAttachment(self, attmId):
        if self.attachmentDao is None:
            self.attachmentDao = AttachmentDao()
            
        dict_rslt = self.attachmentDao.queryAttachment(self.dbConn, attmId)
        if dict_rslt:
            self.attmObj = mapToAttachmentObj(dict_rslt)
            return self.attmObj
        else:
            logging.error('DeleteAttachmentService: attachment not found: attmId=' + str(self.attmObj.getAttachmentId()))
            raise LambdaValidationException('attachment not found')

    
    def deleteAttachment(self, requestContext):
        if self.attachmentDao is None:
            self.attachmentDao = AttachmentDao()
            
        # First update the database so the attachment is unavailable even if the S3 delete fails
        self.attachmentDao.deleteAttachment(self.dbConn, self.attmObj)
        # Insert into event table
        if self.updateEventDao is None:
            self.updateEventDao = UpdateEventDao()
        self.updateEventDao.insertEvent(self.dbConn, requestContext.userSession.userId, updateEventConstants.AUDIT_ATTACHMENT_TABLE,
                                        self.attmObj.getAttachmentId(), updateEventConstants.AUDIT_ELEMENT_PROCESS_RESULT_CODE,
                                        constants.FILE_DELETED, None, UpdateActionCode.MODIFY.value, None,
                                        requestContext.userSession.sessionToken, constants.FILE_DELETED, 'deleteAttachment')
        
        # Delete the actual S3 object
        s3Obj = self.attmObj.getS3Obj()
        if not s3Obj:
            logging.error('DeleteAttachmentService: attachment not valid to be deleted - missing s3ObjKey: attmId=' + str(self.attmObj.getAttachmentId()))
            raise LambdaValidationException('attachment not valid to be deleted')
        filename = s3Obj.split('/')[5]
        subfolder = s3Obj.split('/')[4]
        topfolder = s3Obj.split('/')[3]
        bucket = s3Obj.split('/')[2]
        s3Key = topfolder + '/' + subfolder + '/' + filename
        logging.info('Deleting attachment from s3: bucket=' + bucket + ' s3Key=' + s3Key)
        try:
            #self.s3.Object(bucket, s3Key).delete()
            self.s3.delete_object(Bucket=bucket, Key=s3Key)
            logging.info('Back from deleting attachment')
        except Exception as e:
            logging.error('deleteAttachmentService: failed to delete object from S3. attmId=' + str(self.attmObj.getAttachmentId()) + ' error = %s', e)
            #TODO propagate error back to user or just send alert? Since database was updated, it can't be tried again...
            raise e
            
        