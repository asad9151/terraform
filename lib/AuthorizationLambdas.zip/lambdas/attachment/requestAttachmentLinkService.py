'''
Created on Mar 10, 2020

@author: VanCampK
'''
import binascii
import logging
import os

# Begin iResearch imports
import constants
from attachmentLimitCheck import attachmentLimitReached
from common.dao.batchRequestDao import BatchRequestDao
from common.requestMethodCodes import RequestMethodCode
from common.util.stringUtils import isBlank
from common.util.stringUtils import isInt
from lambdas.exceptions import LambdaProcessingException, LambdaValidationException, LambdaConflictException
import lambdas.errorMessages as errmsg
from common.batchType import BatchType


class RequestAttachmentLinkService(object):
    '''
    Reusable service for creating attachment links.
    Depends on the following environment variables:
        uploadBucket
        UrlExpiresIn
        researchRequestAttachmentLimit (only required if requesting SUBMITTER_ATTACHMENT)
        subjectResearchAttachmentLimit (only required if requesting CASE_RESOLUTION_ATTACHMENT)
        internalSubjectResearchAttachmentLimit (only required if requesting RESEARCHER_INTERNAL_ATTACHMENT)
    '''
    FILE_TYPE = 'multipart/form-data'
    MAX_ATTM_FILENAME_LENGTH = 194


    def __init__(self, dbObj, s3, dbConn):
        self.dbObj = dbObj
        self.s3 = s3
        self.dbConn = dbConn
        self.batchRequestDao = None
        
        
    def validateAttachmentRequest(self, attmObj, fullValidation=True, requestContext=None):
        if len(attmObj.getIncomingFileName()) > RequestAttachmentLinkService.MAX_ATTM_FILENAME_LENGTH:
            errorMessage=errmsg.ERR_ATTACHMENT_FILENAME_TOO_LONG
            logging.error(f"{errorMessage} incomingFileName={attmObj.getIncomingFileName()}")
            raise LambdaValidationException(errorMessage)
            
        # make sure that the file type is a valid suffix listed in the constants variable
        #fileParts = attmObj.getIncomingFileName().split('.')
        #if len(fileParts) < 2:
        fileSuffix = attmObj.getIncomingFileName().split('.')[-1]
        if attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE:
            if fileSuffix.lower() not in constants.VALID_BATCH_FILE_TYPES:
                errorMessage=errmsg.ERR_BAD_ATTACHMENT_FILENAME + ', '.join([str(v) for v in constants.VALID_BATCH_FILE_TYPES])
                logging.info(f"irschRequestAttachmentLink-W002: {errorMessage} incomingFileName={attmObj.getIncomingFileName()}")
                raise LambdaValidationException(errorMessage)
        elif attmObj.getIncomingType() == constants.CFP_BATCH_FILE:
            if fileSuffix.lower() not in constants.VALID_CFP_FILE_TYPES:
                errorMessage=errmsg.ERR_BAD_ATTACHMENT_FILENAME + ', '.join([str(v) for v in constants.VALID_CFP_FILE_TYPES])
                logging.info(f"irschRequestAttachmentLink-W002: {errorMessage} incomingFileName={attmObj.getIncomingFileName()}")
                raise LambdaValidationException(errorMessage)
        elif attmObj.getIncomingType() == constants.TRAINING_MEDIA_ATTACHMENT:
            if fileSuffix.lower() not in constants.VALID_TRAINING_MEDIA_TYPES:
                errorMessage=errmsg.ERR_BAD_ATTACHMENT_FILENAME + ', '.join([str(v) for v in constants.VALID_TRAINING_MEDIA_TYPES])
                logging.info(f"irschRequestAttachmentLink-W002: {errorMessage} incomingFileName={attmObj.getIncomingFileName()}")
                raise LambdaValidationException(errorMessage)
        else:
            if fileSuffix.lower() not in constants.VALID_FILE_TYPES:
                errorMessage=errmsg.ERR_BAD_ATTACHMENT_FILENAME + ', '.join([str(v) for v in constants.VALID_FILE_TYPES])
                logging.info(f"irschRequestAttachmentLink-W002: {errorMessage} incomingFileName={attmObj.getIncomingFileName()}")
                raise LambdaValidationException(errorMessage)
        
        if attmObj.getIncomingType() != constants.SUBMITTER_ATTACHMENT and \
                attmObj.getIncomingType() != constants.CASE_RESOLUTION_ATTACHMENT and \
                attmObj.getIncomingType() != constants.RESEARCHER_INTERNAL_ATTACHMENT and \
                attmObj.getIncomingType() != constants.CHALLENGE_ATTACHMENT and \
                attmObj.getIncomingType() != constants.SUBMISSION_BATCH_FILE and \
                attmObj.getIncomingType() != constants.CFP_BATCH_FILE and \
                attmObj.getIncomingType() != constants.TRAINING_MEDIA_ATTACHMENT:
            logging.error(f'irschRequestAttachmentLink-E010: {errmsg.ERR_UNSUPPORTED_ATTACHMENT_TYPE}.  value = %s', str(attmObj.getIncomingType()))
            raise LambdaValidationException(errmsg.ERR_UNSUPPORTED_ATTACHMENT_TYPE)
        
        #If batch is campaign, determine if required parameters are present and of correct data type
        if  attmObj.getBatchType() == BatchType.CAMPAIGN_BATCH.name:
            campaignPriority = attmObj.getCampaignPriority()
            campaignRouting = attmObj.getCampaignRouting()
            if campaignPriority is None or campaignRouting is None:
                logging.error(f'For incoming request {errmsg.ERR_CAMPAIGN_PARAMETERS} campaignPriority value = %s; campaignRouting value = %s', str(campaignPriority), str(campaignRouting))
                raise LambdaValidationException(f'For upload-attachment URL request {errmsg.ERR_CAMPAIGN_PARAMETERS}')
            if isInt(campaignPriority) != True or isInt(campaignRouting) != True:
                logging.error(f'{errmsg.ERR_CAMPAIGN_PARAMETERS_DATATYPE} in incoming request.  campaignPriority value = %s; campaignRouting value = %s', str(campaignPriority), str(campaignRouting))
                raise LambdaValidationException(f'{errmsg.ERR_CAMPAIGN_PARAMETERS_DATATYPE} in upload-attachment URL request')
        
        if fullValidation and attmObj.getIncomingType() != constants.TRAINING_MEDIA_ATTACHMENT:
            # These validations may not be ready to perform until after the case is assigned
            if isinstance(attmObj.getIncomingAttachmentKey(), int):
                pass
            else:
                logging.error('irschRequestAttachmentLink-E009: invalid key; must be numeric  key = %s', str(attmObj.getIncomingAttachmentKey()))
                raise LambdaValidationException('invalid key; it must be numeric')
            if requestContext is not None:
                if attachmentLimitReached(attmObj,self.dbObj,requestContext.environDict):
                    logging.info('irschRequestAttachmentLink-W001: attachment limit reached.  attachment key = %s', str(attmObj.getIncomingAttachmentKey()))
                    raise LambdaValidationException(errmsg.ERR_ATTACHMENT_LIMIT)
        
        
    def processAttachmentRequest(self, requestContext, attmObj):
        if self.batchRequestDao is None:
            self.batchRequestDao = BatchRequestDao()
        
        if attmObj.getIncomingType() == constants.SUBMITTER_ATTACHMENT:
            attmObj.setIncomingFolder('R' + str(attmObj.getIncomingAttachmentKey()))
        elif attmObj.getIncomingType() == constants.CASE_RESOLUTION_ATTACHMENT or attmObj.getIncomingType() == constants.RESEARCHER_INTERNAL_ATTACHMENT or attmObj.getIncomingType() == constants.CHALLENGE_ATTACHMENT:
            attmObj.setIncomingFolder('C' + str(attmObj.getIncomingAttachmentKey()))
        elif attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE or attmObj.getIncomingType() == constants.CFP_BATCH_FILE:
            attmObj.setIncomingFolder('U' + str(attmObj.getIncomingAttachmentKey()))
        elif attmObj.getIncomingType() == constants.TRAINING_MEDIA_ATTACHMENT:
            attmObj.setIncomingFolder('M' + str(attmObj.getIncomingAttachmentKey()))

        if attachmentLimitReached(attmObj,self.dbObj,requestContext.environDict):
            logging.info('irschRequestAttachmentLink-W001: attachment limit reached.  attachment key = %s', str(attmObj.getIncomingAttachmentKey()))
            raise LambdaValidationException(errmsg.ERR_ATTACHMENT_LIMIT)
        
        adjustedName = self.randomValue() + '_' + attmObj.getIncomingFileName()
        attmObj.setAdjustedFileName(adjustedName)
        putkey = constants.UPLOAD_FOLDER + '/' + attmObj.getIncomingFolder() + '/' + attmObj.getAdjustedFileName()
        logging.info('bucket=' + str(requestContext.environDict.get('uploadBucket')) + ' putkey=' + putkey + ' UrlExpiresIn=' + str(requestContext.environDict.get('UrlExpiresIn')) + ' seconds')
            
        if attmObj.getIncomingType() == constants.TRAINING_MEDIA_ATTACHMENT:
            signedURL = self.s3.generate_presigned_post(
                Bucket= requestContext.environDict['uploadBucket'],
                Key=putkey,
                Fields = {"acl": "public-read", "Content-Type": RequestAttachmentLinkService.FILE_TYPE},
                ExpiresIn = int(requestContext.environDict['UrlExpiresIn']),
                Conditions = [
                    {"acl": "public-read"},
                    # {"Content-Type": FILE_TYPE},
                    ["content-length-range", 1, constants.TRAINING_MEDIA_MAX_ATTACHMENT_SIZE]
                    ]
                )
        elif attmObj.getIncomingType() != constants.TRAINING_MEDIA_ATTACHMENT:
            signedURL = self.s3.generate_presigned_post(
                Bucket= requestContext.environDict['uploadBucket'],
                Key=putkey,
                Fields = {"acl": "public-read", "Content-Type": RequestAttachmentLinkService.FILE_TYPE},
                ExpiresIn = int(requestContext.environDict['UrlExpiresIn']),
                Conditions = [
                    {"acl": "public-read"},
                    # {"Content-Type": FILE_TYPE},
                    ["content-length-range", 1, constants.MAX_ATTACHMENT_SIZE]
                    ]
                )
        logging.info ('irschRequestAttachmentLink-I003: The returned signed URL information = %s', signedURL)

        responseBody = {}
        responseBody["signed_URL"] = signedURL
        # Checking if the type is `SUBMISSION_BATCH_FILE`
        # Creating batch record and sending `batchRequestId` in response body for user
        if attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE or attmObj.getIncomingType() == constants.CFP_BATCH_FILE:
            batch_status = self.dbObj.batchRecordHandle(attmObj, RequestMethodCode.IRESEARCH_UI.value,'irschRequestAttachmentLink', requestContext.userSession)
            if batch_status[0] == 'success':
                responseBody['batchRequestId'] = batch_status[1]
                logging.info(f"processAttachmentRequest Inserted batchRequestId={responseBody['batchRequestId']} - calling updateKeywords...")
                self.batchRequestDao.updateKeywords(self.dbConn, responseBody['batchRequestId'])
                logging.info(f"_updateBatchRecord Updated keywords for batchRequestId={responseBody['batchRequestId']}")
            elif batch_status[0] == 'duplicate-on-insert':
                logging.info('irschRequestAttachmentLink-I004: received "duplicate" return code from dbObj')
                raise LambdaConflictException('Duplicate entries received for attachment upload URL')
            elif batch_status[0] == 'error':
                logging.error('irschRequestAttachmentLink-E014: received "error" return code from dbObj')
                raise LambdaProcessingException('Internal error in upload URL generation process')
            else:
                logging.error('irschRequestAttachmentLink-E015: received unknown return code - %s - from dbObj', batch_status[0])
                raise LambdaProcessingException('Internal error in upload URL generation process')
        
        status = self.dbObj.signedURLIssued(attmObj,'irschRequestAttachmentLink', requestContext.userSession)
        if status == 'success':
            pass
        elif status == 'duplicate-on-insert':
            logging.info('irschRequestAttachmentLink-I004: received "duplicate" return code from dbObj')
            raise LambdaConflictException('Duplicate entries received for attachment upload URL')
        elif status == 'error':
            logging.error('irschRequestAttachmentLink-E014: received "error" return code from dbObj')
            raise LambdaProcessingException('Internal error in upload URL generation process')
        else:
            logging.error('irschRequestAttachmentLink-E015: received unknown return code - %s - from dbObj', status)
            raise LambdaProcessingException('Internal error in upload URL generation process') 
        
        logging.info(f"processAttachmentRequest: attmId={attmObj.getAttachmentId()}")
        responseBody["attm_id"] = attmObj.getAttachmentId()

        return responseBody
            

    def randomValue(self):
        return binascii.b2a_hex(os.urandom(4)).upper().decode("UTF-8")
    