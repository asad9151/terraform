'''
Common functions for attachment processing
Created on Apr 23, 2019

@author: VanCampK
'''
import boto3
from botocore.client import Config
import logging
import constants
import time

from common import envVblNames
from common.dao.fileTrackingDao import FileTrackingDao
from common.dao.subjectResearchDao import SubjectResearchDao
from common.dao.researchRequestDao import ResearchRequestDao
from common.dao.updateEventDao import UpdateEventDao
from common.model.s3Object import S3Object
from common.model.stpDeliveryFile import StpDeliveryFile
from common.processResultCodes import ProcessResultCode
from common.processStatusCodes import ProcessStatusCode
from common.updateActionCodes import UpdateActionCode
from common import updateEventConstants
from common.util.awsUtils import createClientConfiguration
from common.util.s3Helper import S3Helper
from common.util.stringUtils import isNotBlank
from lambdas.exceptions import LambdaValidationException
import lambdas.errorMessages as errmsg


class AttachmentHelper(object):
    STP_OUTBOUND_FOLDER = "stp-outbound"
    subjectResearchDao = None
    researchRequestDao = None
    fileTrackingDao = None
    updateEventDao = None
    s3Client = None
    s3Helper = None
    
    def __init__(self, dbConn):
        self.dbConn = dbConn

    def loadCaseOrRequest(self, attmObj):
        # Loads the case or request object
        if attmObj.getIncomingType() == constants.SUBMITTER_ATTACHMENT:
            if not AttachmentHelper.researchRequestDao:
                AttachmentHelper.researchRequestDao = ResearchRequestDao()
            rschReqObj = AttachmentHelper.researchRequestDao.queryResearchRequest(self.dbConn, attmObj.getIncomingAttachmentKey())
            if not rschReqObj:
                logging.error('RschReqsId ' + str(attmObj.getIncomingAttachmentKey()) + ' does not exist')
                raise LambdaValidationException(errmsg.ERR_KEY_NOT_FOUND)
            return rschReqObj
        elif attmObj.getIncomingType() == constants.CASE_RESOLUTION_ATTACHMENT or attmObj.getIncomingType() == constants.RESEARCHER_INTERNAL_ATTACHMENT  or attmObj.getIncomingType() == constants.CHALLENGE_ATTACHMENT:
            if not AttachmentHelper.subjectResearchDao:
                AttachmentHelper.subjectResearchDao = SubjectResearchDao()
            subjRschObj = AttachmentHelper.subjectResearchDao.querySubjResearch(self.dbConn, attmObj.getIncomingAttachmentKey())
            if not subjRschObj:
                logging.error('SubjRschId ' + str(attmObj.getIncomingAttachmentKey()) + ' does not exist')
                raise LambdaValidationException(errmsg.ERR_KEY_NOT_FOUND)
            return subjRschObj
        
        return None


    def sendFileToMockSTP(self, attmObj, environDict):
        mockStpBucket = environDict.get(envVblNames.ENV_MOCKSTP_BUCKET)
        if isNotBlank(mockStpBucket):
            if AttachmentHelper.s3Client is None:
                logging.info('Initializing s3...')
                AttachmentHelper.s3Client = boto3.client('s3', config=createClientConfiguration(environDict, mergeConfig=Config(signature_version='s3v4')))
                
            delaySecs = environDict.get(envVblNames.ENV_MOCKSTP_DELAYSECS)
            if isNotBlank(delaySecs):
                logging.info(f"MockSTP: sleeping for {delaySecs} seconds")
                time.sleep(int(delaySecs))
            fileToSend = attmObj.getLocalFileName()
            remoteFileName = "bderet/" + fileToSend.split('/')[-1]
            logging.info(f"MockSTP: Uploading {fileToSend} to bucket {mockStpBucket} remote file {remoteFileName}")
            self.s3Client.upload_file(fileToSend, mockStpBucket, remoteFileName)


    def sendFileToStpOutboundDeliveryService(self, attmObj, environDict, moduleNm):
        isProcessUploadedAttmThruStpDelivery = envVblNames.getEnvironAsBool(environDict.get(envVblNames.ENV_PROCESS_UPLOADED_ATTM_THRU_STPDELIVERY))
        if isProcessUploadedAttmThruStpDelivery == True:
            if AttachmentHelper.s3Helper is None:
                logging.info('Initializing s3...')
                AttachmentHelper.s3Helper = S3Helper()
            if AttachmentHelper.fileTrackingDao is None:
                AttachmentHelper.fileTrackingDao = FileTrackingDao()
            if AttachmentHelper.updateEventDao is None:
                AttachmentHelper.updateEventDao = UpdateEventDao()

            # Add record to fle_tkg table
            sdf = self._createStpDeliveryFile(attmObj, environDict)
            logging.info(f"sendFileToStpOutboundDeliveryService: insertting StpDeliveryFile={sdf}")
            AttachmentHelper.fileTrackingDao.insertFileTracking(self.dbConn, sdf, moduleNm)
            logging.info(f"sendFileToStpOutboundDeliveryService: Inserted fileTrackingId={sdf.fileTrackingId}")
            AttachmentHelper.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_FILE_TRACKING_TABLE,
                                            sdf.fileTrackingId, updateEventConstants.AUDIT_ELEMENT_FILE_TRACKING_ID,
                                            sdf.s3Object.fileName, sdf.processStatusCode, UpdateActionCode.ADD.value, None,
                                            None, None, moduleNm)
            logging.info(f"sendFileToStpOutboundDeliveryService: Copying {attmObj.getLocalFileName()} to {sdf.s3Object}")
            AttachmentHelper.s3Helper.copyFromLocalToS3(attmObj.getLocalFileName(), sdf.s3Object)


    def _createStpDeliveryFile(self, attmObj, environDict):
        sdf = StpDeliveryFile()
        sdf.inboundOutboundIndicator = StpDeliveryFile.STP_DELIVERY_OUTBOUND
        sdf.s3Object = S3Object()
        sdf.stpFileName = attmObj.getIncomingFolder() + "_" + attmObj.getIncomingFileName()
        s3ObjKey = f"s3://{environDict.get(envVblNames.ENV_DATASTORES_BUCKET)}/{AttachmentHelper.STP_OUTBOUND_FOLDER}/{environDict.get(envVblNames.ENV_STP_USERID)}/{sdf.stpFileName}"
        sdf.s3Object.setS3ObjectKey(s3ObjKey)
        sdf.relativeFolder = environDict.get(envVblNames.ENV_STP_USERID)
        sdf.s3Object.fileSize = attmObj.getIncomingSize()
        sdf.deliveryAttemptCount = 1
        sdf.processStatusCode = ProcessStatusCode.FILE_RECEIVED.value
        sdf.processResultCode = ProcessResultCode.SUCCESSFUL.value
        return sdf