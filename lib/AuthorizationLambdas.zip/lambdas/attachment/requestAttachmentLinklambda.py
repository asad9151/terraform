'''
Modified on Apr 18, 2019

@author: MorganB, VanCampK
'''
import boto3
from botocore.client import Config
import logging
import json

# Begin iresearch imports
from attachmentClass import attachment
from buildUIResponse import buildUIResponse
from common.batchType import BatchType
from common.dao.subjectResearchDao import SubjectResearchDao
from common.dao.researchRequestDao import ResearchRequestDao
from common.irschRoles import IResearchRole
from common.irschAdministeredRoles import IResearchAdministeredRole
from common.util.awsUtils import createClientConfiguration
import constants
from databaseClass import databaseClass
from lambdas.attachment.attachmentHelper import AttachmentHelper
from lambdas.attachment.requestAttachmentLinkService import RequestAttachmentLinkService
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaAuthorizationException, LambdaValidationException
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.secureLambdaBase import SecureLambdaBase


class RequestAttachmentLinkLambda(SecureLambdaBase):
    '''
    Handler class for RequestAttachmentLink service.
    Handler: lambdas.attachment.requestAttachmentLinklambda.handler
    '''
    dbObj = type('',(object,),{})()
    s3 = None
    subjectResearchDao = None
    researchRequestDao = None
    service = None
    attachmentHelper = None
    
    
    def handleSecureRequest(self):
        incomingContent = self.requestContext.incomingContent
        if incomingContent.get('attachmentType', None) == constants.SUBMISSION_BATCH_FILE or incomingContent.get('attachmentType', None) == constants.CFP_BATCH_FILE:
            if 'attachmentName' not in incomingContent or 'attachmentType' not in incomingContent:
                logging.error('irschRequestAttachmentLink-E007: missing values from incoming request.  event-body = %s', incomingContent)
                raise LambdaValidationException('missing parameters in upload-attachment URL request')
        elif incomingContent.get('attachmentType', None) == constants.TRAINING_MEDIA_ATTACHMENT:
            if 'attachmentName' not in incomingContent:
                logging.error('irschRequestAttachmentLink-E007: missing values from incoming request.  event-body = %s', incomingContent)
                raise LambdaValidationException('missing parameters in upload-attachment URL request') 
        else:
            if 'attachmentName' not in incomingContent or 'attachmentKey' not in incomingContent or 'attachmentType' not in incomingContent:
                logging.error('irschRequestAttachmentLink-E007: missing values from incoming request.  event-body = %s', incomingContent)
                #return buildUIResponse(400, 'missing parameters in upload-attachment URL request')
                raise LambdaValidationException('missing parameters in upload-attachment URL request')                        
        # attachmentProcessingDict = {key:value for (key,value) in incomingContent.items()}
        attmObj = attachment() 
        attmObj.loadRequestAttributes(incomingContent) 
        
        # Checking if the incoming type if its `SUBMISSION_BATCH_FILE`
        if attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE or attmObj.getIncomingType() == constants.CFP_BATCH_FILE:
            if isinstance(self.requestContext.userSession.userId, str):
                attmObj.setIncomingAttachmentKey(int(self.requestContext.userSession.userId))
            else:
                attmObj.setIncomingAttachmentKey(self.requestContext.userSession.userId)
            if attmObj.getBatchType() == "":
                attmObj.setBatchType(BatchType.GENERIC_BATCH.name)
            else:
                if (BatchType.hasValue(attmObj.getBatchType()) == False):
                    logging.error('Invalid batch type %s ', attmObj.getBatchType())
                    raise LambdaValidationException('Invalid batch type')                        
                    
        RequestAttachmentLinkLambda.service.validateAttachmentRequest(attmObj, requestContext=self.requestContext)
        
        if RequestAttachmentLinkLambda.attachmentHelper is None:
            RequestAttachmentLinkLambda.attachmentHelper = AttachmentHelper(self.dbConn)
            
        self.requestContext.cacheObj = RequestAttachmentLinkLambda.attachmentHelper.loadCaseOrRequest(attmObj)

        self.authorizeCaseOrRequest(attmObj)

        responseBody = RequestAttachmentLinkLambda.service.processAttachmentRequest(self.requestContext, attmObj)                    
        
        msgBody = json.dumps(responseBody)
        return buildUIResponse(LambdaStatusCodes.OK.value, msgBody, 'application/json')


    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER, IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7, IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN, IResearchRole.IRESEARCH_SUPER_ADMIN ]) == False):
            logging.error('RequestAttachmentLinkLambda - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)


    def initializeKeepWarm(self):
        if not isinstance(RequestAttachmentLinkLambda.dbObj, databaseClass):
            logging.info('Initializing databaseClass...')
            try:
                RequestAttachmentLinkLambda.dbObj = databaseClass(RequestAttachmentLinkLambda.environDict)
            except Exception as e:
                logging.error('RequestAttachmentLinkLambda-E012: error building database object.  error msg = %s', e)
                #LambdaBase.alert.raiseAlert("RequestAttachmentLinkLambda", "Database Object was not created", str(e))
                return    
        else:
            # warm start
            try:
                logging.info('RequestAttachmentLinkLambda warm start - testing database connection...')
                RequestAttachmentLinkLambda.dbObj.checkConnection()
                logging.info('RequestAttachmentLinkLambda continuing after database connection tested')
            except Exception as e:
                logging.error('RequestAttachmentLinkLambda - error testing database connection.  error = %s', e)
                #LambdaBase.alert.raiseAlert("RequestAttachmentLinkLambda", "error testing database connection", str(e))
                return

        if not RequestAttachmentLinkLambda.s3:
            logging.info('Initializing s3...')
            #RequestAttachmentLinkLambda.s3 = boto3.client('s3', config=Config(signature_version='s3v4'))
            RequestAttachmentLinkLambda.s3 = boto3.client('s3', config=createClientConfiguration(RequestAttachmentLinkLambda.environDict, mergeConfig=Config(signature_version='s3v4')))

        if not RequestAttachmentLinkLambda.service:
            RequestAttachmentLinkLambda.service = RequestAttachmentLinkService(RequestAttachmentLinkLambda.dbObj, RequestAttachmentLinkLambda.s3, self.dbConn)

        
    def authorizeCaseOrRequest(self, attmObj):
        if attmObj.getIncomingType() == constants.SUBMITTER_ATTACHMENT:
            self._authorizeSubmitterAttachment(attmObj)
        elif attmObj.getIncomingType() == constants.CASE_RESOLUTION_ATTACHMENT or attmObj.getIncomingType() == constants.RESEARCHER_INTERNAL_ATTACHMENT:
            self._authorizeResolutionAttachment(attmObj)
        elif attmObj.getIncomingType() == constants.CHALLENGE_ATTACHMENT:
            self._authorizeChallengeAttachment(attmObj)
        elif attmObj.getIncomingType() == constants.TRAINING_MEDIA_ATTACHMENT:
            self._authorizeTrainingMediaAttachment()
        elif attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7 ]) == False):
                logging.error('User does not have submitter role')
                raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)            
            # Must have role specific to batch type
            if attmObj.getBatchType() == BatchType.GENERIC_BATCH.name:
                if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchAdministeredRole.IRESEARCH_MINIBATCH_SUBMITTER ]) == False):
                    logging.error('User does not have minibatch submitter role')
                    raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
            elif attmObj.getBatchType() == BatchType.NEW_DUNS_MINI_BATCH.name:
                if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchAdministeredRole.IRESEARCH_DRSBATCH_SUBMITTER ]) == False):
                    logging.error('User does not have drsbatch submitter role')
                    raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
            elif attmObj.getBatchType() == BatchType.CAMPAIGN_BATCH.name:
                if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchAdministeredRole.IRESEARCH_CAMPAIGNBATCH_SUBMITTER ]) == False):
                    logging.error('User does not have campaignbatch submitter role')
                    raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)    
            else:
                raise LambdaValidationException(errmsg.ERR_UNSUPPORTED_BATCH_TYPE)
        else:
            raise LambdaValidationException(errmsg.ERR_UNSUPPORTED_ATTACHMENT_TYPE)
        '''
        elif attmObj.getIncomingType() == constants.CFP_BATCH_FILE:
            # TODO decide whether to use attachment type or batch type for CFP
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [IResearchAdministeredRole.IRESEARCH_CFPBATCH_SUBMITTER]) == False):
                logging.error('User does not have cfpbatch submitter role')
                raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7]) == False):
                logging.error('User does not have submitter role')
                raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
        '''


    def _authorizeSubmitterAttachment(self, attmObj):
        # Must be the original submitter, or a member of the original submitter's team, or a local admin of the assigned team
        rschReqs = self.requestContext.cacheObj
        reqsLoginKey = rschReqs.get('lgin_key')
        if not RequestAttachmentLinkLambda.researchRequestDao:
            RequestAttachmentLinkLambda.researchRequestDao = ResearchRequestDao()
        # Is user original submitter?
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7 ]) == True):
            if self.requestContext.userSession.loginKey.lower() == reqsLoginKey.lower():
                logging.info(f"_authorizeSubmitterAttachment: user {self.requestContext.userSession.loginKey} is the original submitter ({reqsLoginKey})")
                return
            logging.info(f"_authorizeSubmitterAttachment: user {self.requestContext.userSession.loginKey} is not the original submitter ({reqsLoginKey})")
            # Is user in same submitter group as original submitter?
            rschReqs = RequestAttachmentLinkLambda.researchRequestDao.queryResearchRequest(self.dbConn, attmObj.getIncomingAttachmentKey(), submitterUserId=self.requestContext.userSession.userId)
            if rschReqs is not None and len(rschReqs) > 0:
                logging.info(f"_authorizeSubmitterAttachment: user {self.requestContext.userSession.loginKey} is on the submitter team")
                return
            logging.info(f"_authorizeSubmitterAttachment: user {self.requestContext.userSession.loginKey} is not on the submitter team")

        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN]) == True):
            # Is user localadmin of any of the assigned teams?
            rschTeams = RequestAttachmentLinkLambda.researchRequestDao.queryResearchRequestTeams(self.dbConn, attmObj.getIncomingAttachmentKey(), localAdminUserId=self.requestContext.userSession.userId)
            if len(rschTeams) > 0:
                logging.info(f"_authorizeSubmitterAttachment: user {self.requestContext.userSession.loginKey} is local admin on the assigned research team")
                return
            logging.info(f"_authorizeSubmitterAttachment: user {self.requestContext.userSession.loginKey} is not local admin on the assigned research team")

        logging.error(f'User={self.requestContext.userSession.loginKey} is not authorized submitter for this request')
        raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)


    def _authorizeResolutionAttachment(self, attmObj):
        if RequestAttachmentLinkLambda.subjectResearchDao is None:
            RequestAttachmentLinkLambda.subjectResearchDao = SubjectResearchDao()
        # Must be local admin of the assigned team, or the assigned researcher
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER ]) == True):
            # Is user current assigned researcher?
            subjRsch = self.requestContext.cacheObj
            rschLoginKey = subjRsch.get('lgin_key')
            if self.requestContext.userSession.loginKey.lower() == rschLoginKey.lower():
                return

        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN]) == True):
            # Is user localadmin of the assigned team?
            rschTeams = RequestAttachmentLinkLambda.subjectResearchDao.querySubjResearchTeams(self.dbConn, attmObj.getIncomingAttachmentKey(), localAdminUserId=self.requestContext.userSession.userId)
            if len(rschTeams) > 0:
                logging.info(f"_authorizeResolutionAttachment: user {self.requestContext.userSession.loginKey} is local admin on the assigned research team")
                return
            logging.info(f"_authorizeResolutionAttachment: user {self.requestContext.userSession.loginKey} is not local admin on the assigned research team")

        logging.error(f'User={self.requestContext.userSession.loginKey} is not authorized researcher for this case')
        raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
    
    def _authorizeChallengeAttachment(self, attmObj):
        # Must be the original submitter, or a member of the original submitter's team, or a local admin of the assigned team
        if not RequestAttachmentLinkLambda.researchRequestDao:
            RequestAttachmentLinkLambda.researchRequestDao = ResearchRequestDao()
        if RequestAttachmentLinkLambda.subjectResearchDao is None:
            RequestAttachmentLinkLambda.subjectResearchDao = SubjectResearchDao()
            
        # Is user in same submitter group as original submitter?
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7 ]) == True):
            subjRsch = self.requestContext.cacheObj
            rschReqId = subjRsch.get('rsch_reqs_id')
            rschReqs = RequestAttachmentLinkLambda.researchRequestDao.queryResearchRequest(self.dbConn, rschReqId, submitterUserId=self.requestContext.userSession.userId)
            if rschReqs is not None and len(rschReqs) > 0:
                logging.info(f"_authorizeSubmitterAttachment: user self.requestContext.userSession.userId is on the submitter team ({self.requestContext.userSession.userId})")
                return
            logging.info(f"_authorizeSubmitterAttachment: user {self.requestContext.userSession.userId} is not on the submitter team")

        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN]) == True):
            # Is user localadmin of the assigned team?
            rschTeams = RequestAttachmentLinkLambda.subjectResearchDao.querySubjResearchTeams(self.dbConn, attmObj.getIncomingAttachmentKey(), localAdminUserId=self.requestContext.userSession.userId)
            if len(rschTeams) > 0:
                logging.info(f"_authorizeResolutionAttachment: user {self.requestContext.userSession.userId} is local admin on the assigned research team")
                return
            logging.info(f"_authorizeResolutionAttachment: user {self.requestContext.userSession.userId} is not local admin on the assigned research team")

        logging.error(f'User={self.requestContext.userSession.userId} is not authorized for this case')
        raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
    
    
    def _authorizeTrainingMediaAttachment(self):
        # Must be a super admin to upload training media artifact
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [IResearchRole.IRESEARCH_SUPER_ADMIN]) == True):
            # Is user a super admin
            logging.info(f"_authorizeTrainingMediaAttachment: user {self.requestContext.userSession.userId} is a super admin and entitled to upload training media attachment")
            return
        logging.error(f'User={self.requestContext.userSession.userId} is not a super admin and is thus not authorized to upload a training media attachment')
        raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = RequestAttachmentLinkLambda.get_handler(...)