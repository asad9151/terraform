'''
DAO for deleteAttachment service
'''
import logging
import json
import constants
from common.encoders import IResearchEncoder

class AttachmentDao(object):


    def queryAttachment(self, dbConn, attmId):
        # Sample returned:
        # {"attm_id": 872, "subj_rsch_id": null, "s3_obj_key": "s3://irsch-d1-datastores/attachments/U1/MiniBatch_FileSample_04.xlsx", "attm_typ_cd": 33994, "attm_tmst": "2019-06-04T18:55:55+00:00", "attm_sz_msmt": 18743, "rsch_usr_id": 1, "row_cre_tmst": "2019-06-04T18:55:55+00:00", "row_crer_id_txt": "kvc", "row_mod_tmst": "2019-06-04T18:55:55+00:00", "row_modr_id_txt": "kvc", "rsch_reqs_id": null, "fldr_key": "U1", "fle_nme": "MiniBatch_FileSample_04.xlsx", "prcs_stat_cd": 29169, "prcs_rslt_cd": 33806, "btch_reqs_id": 1000, "BR_btch_frmt_cd": 5187, "BR_btch_src_cd": 33585, "BR_prcs_stat_cd": 33598, "BR_btch_rej_reas_cmnt": null, "BR_btch_rej_err_txt": null, "BR_tot_entr_cnt": null, "BR_rej_entr_cnt": null, "BR_dnb_jti_val": "9E68E937415143FC862B9B931A5AB001", "auth_prin_id_obj": "{\"exp\": 1556802475, \"iat\": 1556737675, \"iss\": \"iResearchUILogonValidation\", \"jti\": \"9E68E937415143FC862B9B931A5AB001\", \"sub\": \"vancampk@dnb.com\", \"email\": \"vancampk@dnb.com\", \"groups\": [\"JIRA_ACCESS\", \"CONFLUENCE_ACCESS\", \"IRESEARCH_ACCESS\", \"DIRECTPLUS_MONITORING_DEFAULT\", \"IRESEARCH_TEAM_US_PC\", \"IRESEARCH_TEAM_US_NCR\", \"IRESEARCH_TEAM_US_HIRISK\", \"IRESEARCH_TEAM_US_SUPER7\", \"IRESEARCH_TEAM_US_L5\", \"IRESEARCH_RESEARCHER_LOCALADMIN\", \"IRESEARCH_RESEARCHER\", \"IRESEARCH_SUBMITTER_US_SUPER7\", \"IRESEARCH_TECH_SUPPORT\", \"BITBUCKET_ACCESS\", \"IDM_CONSOLE_IRESEARCH_ADM\", \"IRESEARCH_TEAM_US_SUPER_7_L5\", \"IRESEARCH_TEAM_US_ENHANCED\", \"IRESEARCH_TEAM_UK_ENHANCED\", \"IRESEARCH_TEAM_IE_ENHANCED\", \"IRESEARCH_TEAM_HK_ENHANCED\", \"IRESEARCH_TEAM_TW_ENHANCED\", \"IRESEARCH_TEAM_IN_ENHANCED\", \"IRESEARCH_TEAM_CA_ENHANCED\", \"IRESEARCH_TEAM_CH_ENHANCED\", \"IRESEARCH_TEAM_US_SALESUP\", \"IRESEARCH_TEAM_US_MA\", \"IRESEARCH_TEAM_US_LINKAGE\", \"IRESEARCH_SUPER_ADMIN\"], \"company\": \"DNB\", \"user_type\": \"UI\", \"given_name\": \"Kenneth\", \"family_name\": \"Van Camp\"}"}
        query = '''
SELECT AT.*, BR.btch_frmt_cd as BR_btch_frmt_cd, BR.btch_src_cd as BR_btch_src_cd, BR.prcs_stat_cd as BR_prcs_stat_cd, BR.btch_rej_reas_cmnt as BR_btch_rej_reas_cmnt, BR.btch_rej_err_txt as BR_btch_rej_err_txt, BR.tot_entr_cnt as BR_tot_entr_cnt, BR.rej_entr_cnt as BR_rej_entr_cnt, BR.dnb_jti_val as BR_dnb_jti_val, BR.btch_typ as BR_btch_typ, LS.auth_prin_id_obj
from attm AT 
left join btch_reqs BR on BR.btch_reqs_id = AT.btch_reqs_id
left join lgin_ses LS on LS.dnb_jti_val = BR.dnb_jti_val
WHERE AT.attm_id = %s
        '''
        dbConn.cursor.execute(query, attmId)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            return dict_rslt
        
        return None


    def deleteAttachment(self, dbConn, attmObj):
        query = 'UPDATE attm SET row_modr_id_txt = %s, prcs_rslt_cd = %s WHERE attm_id = %s'
        params = ('deleteAttachment', constants.FILE_DELETED, attmObj.getAttachmentId())
        logging.info('insertEvent: ' + query + " params=" + str(params))
        dbConn.cursor.execute(query,params)
        #dbConn.commit();
