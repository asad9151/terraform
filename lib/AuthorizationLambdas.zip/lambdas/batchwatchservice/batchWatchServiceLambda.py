'''
@author: Dilip Teja
'''
import boto3
from lambdas.lambdaBase import LambdaBase
from lambdas.batchwatchservice.batchWatchService import BatchWatchService
from botocore.client import Config
from databaseClass import databaseClass
from common import envVblNames
import logging
from common.util.awsUtils import createClientConfiguration
from common.util.sqsHelper import SqsHelper


class BatchWatchServiceLambda(LambdaBase):
    
    sqsHelper = None
    lambdaClient = None
    service = None
    dbObj = dbObj = type('',(object,),{})()
    s3Client = None
    snsClient = None
    notificationTopicARN = None
    submitCaseBatchSubmitterSqsHelper = None
    cfpResponseGeneratorSqsHelper = None
    
        
    def exitOnTimerEvent(self):
        logging.debug("*********exitTimerEvent**********")
        return True
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return True
    
    def handleRequest(self):
        logging.debug("*******handleRequest******")
        LambdaBase.raiseAlertWhenRequestFails = True
        if self.service is None:
            self.service = BatchWatchService(BatchWatchServiceLambda.s3Client, BatchWatchServiceLambda.dbObj,
                                              BatchWatchServiceLambda.lambdaClient, BatchWatchServiceLambda.sqsHelper,
                                              BatchWatchServiceLambda.snsClient, BatchWatchServiceLambda.notificationTopicARN,
                                              BatchWatchServiceLambda.dbConn, self.requestContext, LambdaBase.alert,
                                              BatchWatchServiceLambda.submitCaseBatchSubmitterSqsHelper,
                                              BatchWatchServiceLambda.cfpResponseGeneratorSqsHelper)
            
        self.service.getQueueDetails(self.requestContext.event)
        self.service.processBatchMapper()
       
        
    def initializeKeepWarm(self):
        logging.debug("*******initializeKeepWarm******")
        if isinstance(BatchWatchServiceLambda.dbObj, databaseClass):
            # warm start
            try:
                logging.info('batchWatchServiceLambda warm start - testing database connection...')
                BatchWatchServiceLambda.dbObj.checkConnection()
                logging.info('batchWatchServiceLambda continuing after database connection tested')
            except Exception as e:
                logging.error('batchWatchServiceLambda - error testing database connection.  error = %s', e)
                LambdaBase.alert.raiseAlert("batchWatchServiceLambda", "error testing database connection", str(e))
                raise
        else:
            try:
                logging.info('Initializing databaseClass...')
                print(BatchWatchServiceLambda.environDict)
                BatchWatchServiceLambda.dbObj = databaseClass(BatchWatchServiceLambda.environDict)
            except Exception as e:
                logging.error('batchWatchServiceLambda-E002: error building database object.  error = %s', e)
                raise
        if BatchWatchServiceLambda.s3Client is None:
            try:
                logging.info('Initializing s3...')
                BatchWatchServiceLambda.s3Client = boto3.client('s3', config=createClientConfiguration(BatchWatchServiceLambda.environDict, mergeConfig=Config(signature_version='s3v4')))
            except:
                raise RuntimeError('S3 not configured')
        if BatchWatchServiceLambda.snsClient is None:
            try:
                logging.info('Initializing databaseClass...')
                BatchWatchServiceLambda.snsClient = boto3.client('sns', region_name=BatchWatchServiceLambda.environDict.get(envVblNames.ENV_SNS_REGION), config=createClientConfiguration(BatchWatchServiceLambda.environDict))
            except:
                raise RuntimeError('SNS not configured')
        if BatchWatchServiceLambda.notificationTopicARN is None:
            try:
                BatchWatchServiceLambda.notificationTopicARN = BatchWatchServiceLambda.environDict.get(envVblNames.ENV_NOTIFICATION_TOPIC_ARN)
            except:
                raise RuntimeError('notification service not configured')
        if BatchWatchServiceLambda.sqsHelper is None:
            try:
                if BatchWatchServiceLambda.environDict.get(envVblNames.ENV_BATCH_WATCH_CONDENSED_QUEUE_URL) is not None:
                    regionName = BatchWatchServiceLambda.environDict.get(envVblNames.ENV_SQS_REGION)
                    BatchWatchServiceLambda.sqsHelper = SqsHelper(queueUrl=BatchWatchServiceLambda.environDict.get(envVblNames.ENV_BATCH_WATCH_CONDENSED_QUEUE_URL), regionName=regionName)
            except:
                raise RuntimeError("SQS not configured")
        if BatchWatchServiceLambda.submitCaseBatchSubmitterSqsHelper is None:
            try:
                if BatchWatchServiceLambda.environDict.get(envVblNames.ENV_SUBMITCASEBATCHSUBMITTER_QUEUE_URL) is not None:
                    regionName = BatchWatchServiceLambda.environDict.get(envVblNames.ENV_SQS_REGION)
                    BatchWatchServiceLambda.submitCaseBatchSubmitterSqsHelper = SqsHelper(queueUrl=BatchWatchServiceLambda.environDict.get(envVblNames.ENV_SUBMITCASEBATCHSUBMITTER_QUEUE_URL), regionName=regionName)
            except:
                raise RuntimeError("SUBMITCASEBATCHSUBMITTERQUEUEURL not configured")
        if BatchWatchServiceLambda.cfpResponseGeneratorSqsHelper is None:
            try:
                if BatchWatchServiceLambda.environDict.get(envVblNames.ENV_CFPRESPONSEGENERATOR_QUEUE_URL) is not None:
                    regionName = BatchWatchServiceLambda.environDict.get(envVblNames.ENV_SQS_REGION)
                    BatchWatchServiceLambda.cfpResponseGeneratorSqsHelper = SqsHelper(queueUrl=BatchWatchServiceLambda.environDict.get(envVblNames.ENV_CFPRESPONSEGENERATOR_QUEUE_URL), regionName=regionName)
            except:
                raise RuntimeError("CFPRESPONSEGENERATOR_QUEUE_URL not configured")
            
                

#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = BatchWatchServiceLambda.get_handler(...)