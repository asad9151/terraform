'''
@author: vancampk
'''
from lambdas.lambdaBase import LambdaBase
from common import envVblNames
import logging

from common.util.sqsHelper import SqsHelper
from lambdas.batchwatchservice.batchWatchCondenserService import BatchWatchCondenserService


class BatchWatchCondenserLambda(LambdaBase):
    '''
    Handler class for BatchWatchCondenser service.
    Responsible for reading the BatchWatchPreQueue, condensing down messages on a single batchId/batchWatchTypeCode,
    and sending out messages to the sendToBatchWatchService queue.
    Handler: lambdas.batchwatchservice.batchWatchCondenserLambda.handler
    '''
    
    def __init__(self):
        super().__init__()
        LambdaBase.raiseAlertWhenRequestFails = True
        self.service = None
        self.batchWatchPreQueueSqsHelper = None
        self.sendToBatchWatchServiceSqsHelper = None

    
    def handleRequest(self):
        if self.batchWatchPreQueueSqsHelper is None:
            regionName = BatchWatchCondenserLambda.environDict.get(envVblNames.ENV_SQS_REGION)
            self.batchWatchPreQueueSqsHelper = SqsHelper(queueUrl=BatchWatchCondenserLambda.environDict.get(envVblNames.ENV_BATCH_WATCH_QUEUE_URL), regionName=regionName)
        if self.sendToBatchWatchServiceSqsHelper is None:
            regionName = BatchWatchCondenserLambda.environDict.get(envVblNames.ENV_SQS_REGION)
            self.sendToBatchWatchServiceSqsHelper = SqsHelper(queueUrl=BatchWatchCondenserLambda.environDict.get(envVblNames.ENV_BATCH_WATCH_CONDENSED_QUEUE_URL), regionName=regionName)
        if self.service is None:
            self.service = BatchWatchCondenserService(LambdaBase.dbConn, self.batchWatchPreQueueSqsHelper, self.sendToBatchWatchServiceSqsHelper, LambdaBase.alert)
            
        incomingEvent = self.requestContext.event
        if 'Records' in incomingEvent:
            # Invoked via queue with batch size 10K
            records = incomingEvent['Records']
            self.service.processQueue(self.requestContext, records)
        else:
            logging.warning(f"Got non-queue event, ignoring")
            
    
    def needsDbConn(self):
        return True
                

#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = BatchWatchCondenserLambda.get_handler(...)