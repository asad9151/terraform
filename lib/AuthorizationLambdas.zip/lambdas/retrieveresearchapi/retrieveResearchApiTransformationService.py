'''
Created on Aug 30, 2019

@author: VanCampK
'''
import copy
import jmespath

from common.rejectionReasonCodes import RejectionReasonCode
from common.util.stringUtils import isNotBlank, isInt
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaNotFoundException
from lambdas.requestRejection import RequestRejection
import lambdas.retrieveresearchapi.retrieveResearchApiFields as apiFields
from lambdas.util.cloudServicesHelper import CloudServicesHelper
from common.requestMethodCodes import RequestMethodCode

class RetrieveResearchApiTransformationService(object):
    '''
    Responsible for transforming responses from RetrieveCase/RetrieveCaseSummary schema into RetrieveResearch/RetrieveResearchSummary schema
    '''


    def mapRetrieveCaseResponse(self, requestContext, requestRecord):
        rc = requestRecord.retrieveCaseResponse
        rcResponseBody = rc[apiFields.IRSCH_FLD_RESPONSE_BODY]
        if requestRecord.isPartnerView:
            if requestRecord.isSummaryLevel:
                self._mapPartnerSummary(rcResponseBody, requestRecord)
            else:
                self._mapPartnerDetail(rcResponseBody, requestRecord)
        else:
            if requestRecord.isSummaryLevel:
                self._mapSummary(rcResponseBody, requestRecord)
            else:
                self._mapDetail(rcResponseBody, requestRecord)


    def _mapDetail(self, rcResponseBody, requestRecord):
        rcRequests = rcResponseBody.get(apiFields.IRSCH_FLD_REQUESTS)
        if rcRequests is not None and len(rcRequests) > 0:
            requestRecord.responseRecord = self._mapRequest(rcRequests[0], requestRecord.isSummaryLevel)
        else:
            # Case not found
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrorMessage=errmsg.ERR_KEY_NOT_FOUND)
            raise LambdaNotFoundException(errmsg.ERR_KEY_NOT_FOUND, requestRejection=requestRejection)
        
        
    def _mapSummary(self, rcResponseBody, requestRecord):
        rcRequests = rcResponseBody.get(apiFields.IRSCH_FLD_REQUESTS)
        requests = []
        for rcReq in rcRequests:
            requests.append(self._mapRequest(rcReq, requestRecord.isSummaryLevel))
        reqCt = rcResponseBody.get(apiFields.IRSCH_FLD_REQUESTS_CT) if rcResponseBody.get(apiFields.IRSCH_FLD_REQUESTS_CT) is not None else len(requests)
        requestRecord.responseRecord = {
            apiFields.API_FLD_REQUESTS_CT: reqCt,
            apiFields.API_FLD_SUMMARY_REQUESTS: requests
        }
        if rcResponseBody.get(apiFields.BOTH_FLD_LAST_ID_FOR_PAGE) is not None:
            requestRecord.responseRecord[apiFields.BOTH_FLD_LAST_ID_FOR_PAGE] = rcResponseBody.get(apiFields.BOTH_FLD_LAST_ID_FOR_PAGE)
        if rcResponseBody.get(apiFields.BOTH_FLD_HAS_NEXT_PAGE) is not None:
            requestRecord.responseRecord[apiFields.BOTH_FLD_HAS_NEXT_PAGE] = rcResponseBody.get(apiFields.BOTH_FLD_HAS_NEXT_PAGE)
        else:
            requestRecord.responseRecord[apiFields.BOTH_FLD_HAS_NEXT_PAGE] = False
        
        
    def _mapRequest(self, rcRequest, isSummaryLevel):
        rr = rcRequest[apiFields.IRSCH_FLD_RESEARCH_REQUEST]
        cases = self._mapCases(rcRequest[apiFields.IRSCH_FLD_CASES], isSummaryLevel)
        casesFldNm = apiFields.API_FLD_SUMMARIZED_CASES if isSummaryLevel else apiFields.API_FLD_CASES
        responseRecord = {
            apiFields.BOTH_FLD_RESEARCH_REQUEST_ID: rr.get(apiFields.BOTH_FLD_RESEARCH_REQUEST_ID),
            apiFields.BOTH_FLD_SUBMISSION_TS: rr.get(apiFields.BOTH_FLD_SUBMISSION_TS),
            apiFields.BOTH_FLD_EXT_STATUS_CD: rcRequest.get(apiFields.BOTH_FLD_EXT_STATUS_CD),
            apiFields.BOTH_FLD_EXT_STATUS_TS: rcRequest.get(apiFields.BOTH_FLD_EXT_STATUS_TS),
            casesFldNm: cases
        }
        if rr.get(apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_KEY) is not None:
            responseRecord[apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_KEY] = rr.get(apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_KEY)
        if isSummaryLevel == False and rr.get(apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_DESCR) is not None:
            responseRecord[apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_DESCR] = rr.get(apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_DESCR)
        if rr.get(apiFields.BOTH_FLD_EXTERNAL_INVS_ID) is not None:
            responseRecord[apiFields.BOTH_FLD_EXTERNAL_INVS_ID] = rr.get(apiFields.BOTH_FLD_EXTERNAL_INVS_ID)
        if rr.get(apiFields.BOTH_FLD_CUSTOMER_REF_NAME) is not None:
            responseRecord[apiFields.BOTH_FLD_CUSTOMER_REF_NAME] = rr.get(apiFields.BOTH_FLD_CUSTOMER_REF_NAME)
        if rr.get(apiFields.BOTH_FLD_PRIORITY) is not None:
            responseRecord[apiFields.BOTH_FLD_PRIORITY] = rr.get(apiFields.BOTH_FLD_PRIORITY)
        if rr.get(apiFields.BOTH_FLD_REQUESTOR_PREF_LANG_CODE) is not None:
            responseRecord[apiFields.BOTH_FLD_REQUESTOR_PREF_LANG_CODE] = rr.get(apiFields.BOTH_FLD_REQUESTOR_PREF_LANG_CODE)
        rcSubmitterUser = rr.get(apiFields.IRSCH_FLD_USER)
        rcSubmitterLoginKey = rcSubmitterUser.get(apiFields.BOTH_FLD_LOGIN_KEY) if rcSubmitterUser is not None else None
        if rcSubmitterLoginKey is not None:
            responseRecord[apiFields.BOTH_FLD_LOGIN_KEY] = rcSubmitterLoginKey
        rcSubmitterEmail = rcSubmitterUser.get(apiFields.BOTH_FLD_EMAIL_ADDRESS) if rcSubmitterUser is not None else None
        if rcSubmitterEmail is not None:
            responseRecord[apiFields.BOTH_FLD_EMAIL_ADDRESS] = rcSubmitterEmail
        rcSubmitterFirstName = rcSubmitterUser.get(apiFields.BOTH_FLD_FIRST_NAME) if rcSubmitterUser is not None else None
        if rcSubmitterFirstName is not None:
            responseRecord[apiFields.BOTH_FLD_FIRST_NAME] = rcSubmitterFirstName
        rcSubmitterLastName = rcSubmitterUser.get(apiFields.BOTH_FLD_LAST_NAME) if rcSubmitterUser is not None else None
        if rcSubmitterLastName is not None:
            responseRecord[apiFields.BOTH_FLD_LAST_NAME] = rcSubmitterLastName
        if rr.get(apiFields.BOTH_FLD_ORG_NAME) is not None:
            responseRecord[apiFields.BOTH_FLD_ORG_NAME] = rr.get(apiFields.BOTH_FLD_ORG_NAME)
        return responseRecord
        
        
    def _mapCases(self, rcCases, isSummaryLevel):
        cases = []
        for rcCase in rcCases:
            subjRsch = rcCase.get(apiFields.IRSCH_FLD_SUBJ_RSCH)
            case = {
                apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID: subjRsch.get(apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID),
                apiFields.BOTH_FLD_EXT_STATUS_CD: subjRsch.get(apiFields.BOTH_FLD_EXT_STATUS_CD),
                apiFields.BOTH_FLD_EXT_STATUS_TS: subjRsch.get(apiFields.BOTH_FLD_EXT_STATUS_TS),
                apiFields.BOTH_FLD_RESEARCH_TYPES: subjRsch.get(apiFields.BOTH_FLD_RESEARCH_TYPES)
            }
            if rcCase.get(apiFields.IRSCH_FLD_SUBJECT_DATA) is not None:
                case[apiFields.API_FLD_SUBJECT_DATA] = rcCase.get(apiFields.IRSCH_FLD_SUBJECT_DATA)
            if rcCase.get(apiFields.BOTH_FLD_ISCHALLENGEABLE) is not None:
                case[apiFields.BOTH_FLD_ISCHALLENGEABLE] = self._getIsChallengeable(rcCase)
                
            if not isSummaryLevel:
                if subjRsch.get(apiFields.BOTH_FLD_SUBMITTED_DATA) is not None:
                    case[apiFields.BOTH_FLD_SUBMITTED_DATA] = subjRsch.get(apiFields.BOTH_FLD_SUBMITTED_DATA)
                rschRslt = self._mapResearchResult(rcCase.get(apiFields.IRSCH_FLD_RESEARCH_RESULT))
                if len(rschRslt) > 0:
                    case[apiFields.API_FLD_RESEARCH_RESULT] = rschRslt
                comments = self._mapComments(rcCase.get(apiFields.IRSCH_FLD_COMMENTS))
                if len(comments) > 0:
                    case[apiFields.API_FLD_COMMENTS] = comments
                attachments = self._mapAttachments(rcCase.get(apiFields.BOTH_FLD_ATTACHMENTS))
                if len(attachments) > 0:
                    case[apiFields.BOTH_FLD_ATTACHMENTS] = attachments
                if rcCase.get(apiFields.IRSCH_FLD_DUE_DATE) is not None:
                    case[apiFields.API_FLD_DUE_DATE] = rcCase.get(apiFields.IRSCH_FLD_DUE_DATE)
                rschChallenges = subjRsch.get(apiFields.BOTH_FLD_RESEARCH_CHALLENGES)
                if rschChallenges is not None and len(rschChallenges) > 0:
                    case[apiFields.API_FLD_CHALLENGE_DUE_DATE] = self._getLastChallengeDueDate(rschChallenges)
                    case[apiFields.BOTH_FLD_RESEARCH_CHALLENGES] = rschChallenges
                previousResearches = self._getPreviousResearches(rcCase)
                if previousResearches is not None:
                    case[apiFields.API_FLD_PREV_RESEARCHES] = previousResearches
            cases.append(case)
        return cases
    
    
    def _mapComments(self, rcComments):
        comments = []
        for rcComment in rcComments:
            typeCd = rcComment.get(apiFields.BOTH_FLD_COMMENT_TYPE_CD)
            cmnt = rcComment.get(apiFields.BOTH_FLD_COMMENT_TXT)
            if isNotBlank(cmnt) and isInt(typeCd) and typeCd > 0:
                comment = {
                    apiFields.BOTH_FLD_COMMENT_TYPE_CD: typeCd,
                    apiFields.BOTH_FLD_COMMENT_TXT: cmnt
                }
                comments.append(comment)
        return comments
    
    def _mapAttachments(self, rcAttachments):
        attachments = []
        for rcAttachment in rcAttachments:
            url = rcAttachment.get(apiFields.BOTH_FLD_ATTACHMENT_URL)

            if isNotBlank(url):
                attachment = {
                    apiFields.BOTH_FLD_ATTACHMENT_URL: url,
                    apiFields.API_FLD_ATTACHMENT_NAME: rcAttachment.get(apiFields.IRSCH_FLD_ATTACHMENT_FILENAME),
                    apiFields.BOTH_FLD_ATTACHMENT_TYPE_CODE: rcAttachment.get(apiFields.BOTH_FLD_ATTACHMENT_TYPE_CODE),
                    apiFields.BOTH_FLD_ATTACHMENT_TIMESTAMP: rcAttachment.get(apiFields.BOTH_FLD_ATTACHMENT_TIMESTAMP),
                    apiFields.BOTH_FLD_ATTACHMENT_SIZE: rcAttachment.get(apiFields.BOTH_FLD_ATTACHMENT_SIZE)
                }
                attachments.append(attachment)
        return attachments
    
    
    def _mapResearchResult(self, rcRr):
        rr = {}
        if rcRr is not None:
            for fld in apiFields.BOTH_RESEARCH_RESULT_FIELDS:
                v = rcRr.get(fld)
                if v is not None:
                    rr[fld] = v
        return rr
    
    
    def _getLastChallengeDueDate(self, rschChallenges):
        if len(rschChallenges) > 0:
            lastRschChal = rschChallenges[-1]
            dueDtTmst = lastRschChal.get(apiFields.IRSCH_FLD_CHALLENGE_DUE_DATE)
            if dueDtTmst is not None:
                return dueDtTmst


    def _getPreviousResearches(self, rcCase):
        subjRsch = rcCase.get(apiFields.IRSCH_FLD_SUBJ_RSCH)
        rschRsltHist = rcCase.get(apiFields.IRSCH_FLD_RSCH_RESULT_HIST)
        prevRschIter = subjRsch.get(apiFields.IRSCH_FLD_PREV_RESEARCH_ITERS)
        if rschRsltHist is not None or prevRschIter is not None:
            maxHist = 0
            if rschRsltHist is not None:
                maxHist = len(rschRsltHist)
            if prevRschIter is not None:
                maxHist = max(maxHist, len(prevRschIter))
            if maxHist == 0:
                return None
            previousResearches = []
            for i in range(maxHist):
                rschRslt = rschRsltHist[i] if rschRsltHist is not None and len(rschRsltHist) > i else None
                prevRsch = prevRschIter[i] if prevRschIter is not None and len(prevRschIter) > i else None
                previousResearch = {}
                if rschRslt is not None:
                    previousResearch[apiFields.API_FLD_RESEARCH_RESULT] = self._mapResearchResult(rschRslt)
                if prevRsch is not None:
                    previousResearch[apiFields.BOTH_FLD_RESEARCH_TYPES] = prevRsch.get(apiFields.IRSCH_FLD_PREV_RESEARCH_TYPES)
                previousResearches.append(previousResearch)
            return previousResearches
        return None
    
    def _getIsChallengeable(self, rcCase):
        isChallengeable = rcCase.get(apiFields.BOTH_FLD_ISCHALLENGEABLE)
        apiSpecificValidation = None
        if isChallengeable == False:
            return isChallengeable
        
        countryCode = None
        subjRsch = rcCase.get(apiFields.IRSCH_FLD_SUBJ_RSCH)
        if subjRsch is not None:
            researchTypes = subjRsch.get(apiFields.BOTH_FLD_RESEARCH_TYPES)
        subjData = rcCase.get(apiFields.IRSCH_FLD_SUBJECT_DATA)
        if subjData is not None:
            countryCode = subjData['countryCode']
            
        if researchTypes is not None and countryCode is not None:
            apiSpecificValidation = CloudServicesHelper.isChallengeable(self, researchTypes, countryCode)
        
        if apiSpecificValidation is not None and apiSpecificValidation == False:
            isChallengeable = apiSpecificValidation
        
        return isChallengeable


    def _mapPartnerDetail(self, rcResponseBody, requestRecord):
        rcRequests = rcResponseBody.get(apiFields.IRSCH_FLD_REQUESTS)
        if rcRequests is not None and len(rcRequests) > 0:
            requestRecord.responseRecord = {
                apiFields.PTNR_FLD_CASE: self._mapPartnerRequest(rcRequests[0], requestRecord.isSummaryLevel)
            }
        else:
            # Case not found
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrorMessage=errmsg.ERR_KEY_NOT_FOUND)
            raise LambdaNotFoundException(errmsg.ERR_KEY_NOT_FOUND, requestRejection=requestRejection)


    def _mapPartnerSummary(self, rcResponseBody, requestRecord):
        rcRequests = rcResponseBody.get(apiFields.IRSCH_FLD_REQUESTS)
        requests = []
        for rcReq in rcRequests:
            requests.extend(self._mapPartnerRequest(rcReq, requestRecord.isSummaryLevel))
        reqCt = rcResponseBody.get(apiFields.IRSCH_FLD_REQUESTS_CT) if rcResponseBody.get(apiFields.IRSCH_FLD_REQUESTS_CT) is not None else len(requests)
        requestRecord.responseRecord = {
            apiFields.PTNR_FLD_SUMMARY_REQUESTS_CT: reqCt,
            apiFields.PTNR_FLD_SUMMARIZED_CASES: requests
        }
        if rcResponseBody.get(apiFields.BOTH_FLD_LAST_ID_FOR_PAGE) is not None:
            requestRecord.responseRecord[apiFields.BOTH_FLD_LAST_ID_FOR_PAGE] = rcResponseBody.get(apiFields.BOTH_FLD_LAST_ID_FOR_PAGE)
        if rcResponseBody.get(apiFields.BOTH_FLD_HAS_NEXT_PAGE) is not None:
            requestRecord.responseRecord[apiFields.BOTH_FLD_HAS_NEXT_PAGE] = rcResponseBody.get(apiFields.BOTH_FLD_HAS_NEXT_PAGE)
        else:
            requestRecord.responseRecord[apiFields.BOTH_FLD_HAS_NEXT_PAGE] = False
            
        
    def _mapPartnerRequest(self, rcRequest, isSummaryLevel):
        responseRecords = []
        for subjectResearchResults in rcRequest[apiFields.IRSCH_FLD_CASES]:
            subjectResearch = subjectResearchResults[apiFields.IRSCH_FLD_SUBJ_RSCH]
            responseRecord = {
                apiFields.PTNR_FLD_RESEARCH_REQUEST: self._mapPartnerResearchRequest(rcRequest[apiFields.IRSCH_FLD_RESEARCH_REQUEST], rcRequest[apiFields.BOTH_FLD_REQS_METH_CD], subjectResearchResults, isSummaryLevel),
                apiFields.PTNR_FLD_SUBJ_RSCH: self._mapPartnerSubjectResearch(subjectResearch, rcRequest[apiFields.IRSCH_FLD_RESEARCH_REQUEST], subjectResearchResults, isSummaryLevel)
            }
            if isSummaryLevel == False:
                if subjectResearchResults.get(apiFields.IRSCH_FLD_RESEARCH_RESULT) is not None:
                    responseRecord[apiFields.PTNR_FLD_RESEARCH_RESULT] = self._mapPartnerResearchResult(subjectResearchResults.get(apiFields.IRSCH_FLD_RESEARCH_RESULT), isSummaryLevel)
                if subjectResearchResults.get(apiFields.IRSCH_FLD_RSCH_RESULT_HIST) is not None:
                    responseRecord[apiFields.PTNR_FLD_RSCH_RESULT_HIST] = self._mapPartnerResearchResultHist(subjectResearchResults.get(apiFields.IRSCH_FLD_RSCH_RESULT_HIST), isSummaryLevel)
                if subjectResearchResults.get(apiFields.IRSCH_FLD_CHALLENGE_ITER) is not None:
                    responseRecord[apiFields.PTNR_FLD_CHALLENGE_ITER] = subjectResearchResults.get(apiFields.IRSCH_FLD_CHALLENGE_ITER)
                responseRecord[apiFields.PTNR_FLD_COMMENTS] = self._mapPartnerComments(subjectResearchResults.get(apiFields.IRSCH_FLD_COMMENTS))
                if subjectResearchResults.get(apiFields.IRSCH_FLD_FIRMOGRAPHICS) is not None:
                    responseRecord[apiFields.PTNR_FLD_FIRMOGRAPHICS] = self._mapPartnerFirmographics(subjectResearchResults.get(apiFields.IRSCH_FLD_FIRMOGRAPHICS))
            else:
                responseRecord[apiFields.PTNR_FLD_RESEARCH_REQUEST][apiFields.BOTH_FLD_REQS_METH_CD] = rcRequest.get(apiFields.BOTH_FLD_REQS_METH_CD)
                
            if subjectResearchResults.get(apiFields.BOTH_FLD_ATTACHMENTS) is not None and isSummaryLevel == False:
                responseRecord[apiFields.BOTH_FLD_ATTACHMENTS] = self._mapPartnerAttachments(subjectResearchResults.get(apiFields.BOTH_FLD_ATTACHMENTS))
            responseRecords.append(responseRecord)
            
        if isSummaryLevel == False:
            return responseRecords[0]
        else:
            return responseRecords
    
    
    def _mapPartnerResearchRequest(self, rr, requestMethodCode, subjectResearchResults, isSummaryLevel):
        responseRecord = {
            apiFields.BOTH_FLD_USER_ID: rr[apiFields.IRSCH_FLD_USER].get(apiFields.BOTH_FLD_USER_ID),
            apiFields.BOTH_FLD_RESEARCH_REQUEST_ID: rr.get(apiFields.BOTH_FLD_RESEARCH_REQUEST_ID),
            apiFields.BOTH_FLD_RESEARCH_REQUEST_ID: rr.get(apiFields.BOTH_FLD_RESEARCH_REQUEST_ID),
            apiFields.BOTH_FLD_SUBMISSION_TS: rr.get(apiFields.BOTH_FLD_SUBMISSION_TS)
        }
        if rr.get(apiFields.BOTH_FLD_SUB_NUM) is not None:
            responseRecord[apiFields.BOTH_FLD_SUB_NUM] = rr.get(apiFields.BOTH_FLD_SUB_NUM) 
        if rr.get(apiFields.BOTH_FLD_ORG_NAME) is not None:
            responseRecord[apiFields.BOTH_FLD_ORG_NAME] = rr.get(apiFields.BOTH_FLD_ORG_NAME)
        if rr.get(apiFields.BOTH_FLD_REQS_CNTRY_CD) is not None:
            responseRecord[apiFields.BOTH_FLD_REQS_CNTRY_CD] = rr.get(apiFields.BOTH_FLD_REQS_CNTRY_CD)
        if rr.get(apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_KEY) is not None:
            responseRecord[apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_KEY] = rr.get(apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_KEY)
        if isSummaryLevel == False and rr.get(apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_DESCR) is not None:
            responseRecord[apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_DESCR] = rr.get(apiFields.BOTH_FLD_REQUESTOR_OWN_REQUEST_DESCR)
        #if rr.get(apiFields.BOTH_FLD_EXTERNAL_INVS_ID) is not None:
        #    responseRecord[apiFields.BOTH_FLD_EXTERNAL_INVS_ID] = rr.get(apiFields.BOTH_FLD_EXTERNAL_INVS_ID)
        if rr.get(apiFields.BOTH_FLD_REQUESTOR_PREF_LANG_CODE) is not None:
            responseRecord[apiFields.BOTH_FLD_REQUESTOR_PREF_LANG_CODE] = rr.get(apiFields.BOTH_FLD_REQUESTOR_PREF_LANG_CODE)
        if rr.get(apiFields.BOTH_FLD_PRIORITY) is not None:
            responseRecord[apiFields.BOTH_FLD_PRIORITY] = rr.get(apiFields.BOTH_FLD_PRIORITY)
        if rr.get(apiFields.BOTH_FLD_CUSTOMER_REF_NAME) is not None:
            responseRecord[apiFields.BOTH_FLD_CUSTOMER_REF_NAME] = rr.get(apiFields.BOTH_FLD_CUSTOMER_REF_NAME)
        if subjectResearchResults.get(apiFields.IRSCH_FLD_DUE_DATE) is not None:
            responseRecord[apiFields.API_FLD_DUE_DATE] = subjectResearchResults.get(apiFields.IRSCH_FLD_DUE_DATE)
        if isSummaryLevel == False:
            responseRecord[apiFields.BOTH_FLD_REQS_METH_CD] = rr.get(apiFields.BOTH_FLD_REQS_METH_CD)
            if rr.get(apiFields.BOTH_FLD_CUSTOMER_REF_NAME) is not None:
                responseRecord[apiFields.BOTH_FLD_CUSTOMER_REF_NAME] = rr.get(apiFields.BOTH_FLD_CUSTOMER_REF_NAME)
            if rr.get(apiFields.BOTH_FLD_NOTIF_CNTCS) is not None:
                responseRecord[apiFields.BOTH_FLD_NOTIF_CNTCS] = rr.get(apiFields.BOTH_FLD_NOTIF_CNTCS)
        if requestMethodCode == RequestMethodCode.IRESEARCH_UI.value and rr[apiFields.IRSCH_FLD_USER].get(apiFields.BOTH_FLD_SUBMITTER_ORG_NAME) is not None:
            responseRecord[apiFields.BOTH_FLD_SUBMITTER_ORG_NAME] = rr[apiFields.IRSCH_FLD_USER].get(apiFields.BOTH_FLD_SUBMITTER_ORG_NAME)
        return responseRecord
            
    
    def _mapPartnerSubjectResearch(self, subjRsch, rr, subjectResearchResults, isSummaryLevel):
        case = {
            apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID: subjRsch.get(apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID),
            apiFields.BOTH_FLD_RESEARCH_TYPES: subjRsch.get(apiFields.BOTH_FLD_RESEARCH_TYPES),
            apiFields.BOTH_FLD_INT_STAT_CD: subjRsch.get(apiFields.BOTH_FLD_INT_STAT_CD),
            apiFields.BOTH_FLD_INT_STATUS_TS: subjRsch.get(apiFields.BOTH_FLD_INT_STATUS_TS)
        }
        rschTeamName = jmespath.search(apiFields.IRSCH_PATH_RSCH_TEAM, subjRsch)
        if rschTeamName is not None:
            case[apiFields.BOTH_FLD_RSCH_TEAM_NM] = rschTeamName
        if isSummaryLevel == False:
            case[apiFields.BOTH_FLD_RESEARCH_REQUEST_ID] = rr.get(apiFields.BOTH_FLD_RESEARCH_REQUEST_ID)
            case[apiFields.BOTH_FLD_SUBMITTED_DATA] = subjRsch.get(apiFields.BOTH_FLD_SUBMITTED_DATA)
            if subjRsch.get(apiFields.BOTH_FLD_ROUTING_REAS_CD) is not None:
                case[apiFields.BOTH_FLD_ROUTING_REAS_CD] = subjRsch.get(apiFields.BOTH_FLD_ROUTING_REAS_CD)
            if subjRsch.get(apiFields.BOTH_FLD_RSCH_ASSGN_TS) is not None:
                case[apiFields.BOTH_FLD_RSCH_ASSGN_TS] = subjRsch.get(apiFields.BOTH_FLD_RSCH_ASSGN_TS)
            if subjRsch.get(apiFields.BOTH_FLD_TRNF_REAS_CD) is not None:
                case[apiFields.BOTH_FLD_TRNF_REAS_CD] = subjRsch.get(apiFields.BOTH_FLD_TRNF_REAS_CD)
            rschChallenges = subjRsch.get(apiFields.BOTH_FLD_RESEARCH_CHALLENGES)
            if rschChallenges is not None and len(rschChallenges) > 0:
                case[apiFields.BOTH_FLD_RESEARCH_CHALLENGES] = rschChallenges
            prevRschIter = subjRsch.get(apiFields.IRSCH_FLD_PREV_RESEARCH_ITERS)
            if prevRschIter is not None and len(prevRschIter) > 0:
                case[apiFields.IRSCH_FLD_PREV_RESEARCH_ITERS] = prevRschIter
            case[apiFields.BOTH_FLD_SUBMISSION_TS] = subjRsch.get(apiFields.BOTH_FLD_SUBMISSION_TS)
        else:
            case[apiFields.PTNR_FLD_SUMMARIZED_SBMT] = self._mapPartnerSummarizedSubmittedData(subjRsch.get(apiFields.BOTH_FLD_SUBMITTED_DATA))
            case[apiFields.BOTH_FLD_SUBMISSION_TS] = rr.get(apiFields.BOTH_FLD_SUBMISSION_TS)
            if subjectResearchResults.get(apiFields.IRSCH_FLD_SUBJECT_DATA) is not None:
                case[apiFields.PTNR_FLD_SUBJECT_DATA] = subjectResearchResults.get(apiFields.IRSCH_FLD_SUBJECT_DATA)

        return case
    
    
    def _mapPartnerSummarizedSubmittedData(self, submittedData):
        sbmtData = {
        }
        if submittedData.get(apiFields.BOTH_FLD_DUNS) is not None:
            sbmtData[apiFields.BOTH_FLD_DUNS] = submittedData.get(apiFields.BOTH_FLD_DUNS)
        if submittedData.get(apiFields.BOTH_FLD_SBMT_ORG_NAME) is not None:
            sbmtData[apiFields.BOTH_FLD_SBMT_ORG_NAME] = submittedData.get(apiFields.BOTH_FLD_SBMT_ORG_NAME)
        if submittedData.get(apiFields.BOTH_FLD_SBMT_CNTRY_CD) is not None:
            sbmtData[apiFields.BOTH_FLD_SBMT_CNTRY_CD] = submittedData.get(apiFields.BOTH_FLD_SBMT_CNTRY_CD)
        return sbmtData
    
    
    def _mapPartnerFirmographics(self, firmographics):
        fg = {
            apiFields.BOTH_FLD_FIRMO_UI_VSN: firmographics.get(apiFields.BOTH_FLD_FIRMO_UI_VSN)
        }
        return fg
    
    
    def _mapPartnerResearchResult(self, researchResult, isSummaryLevel):
        # Since we want almost everything, we start with the full researchResult and then subtract some unwanted elements
        rr = copy.deepcopy(researchResult)
        rr.pop(apiFields.IRSCH_FLD_RSCH_DISC_MRG, None)
        rr.pop(apiFields.IRSCH_FLD_RSCH_DISC_ACQ, None)
        rr.pop(apiFields.IRSCH_FLD_BDRS_USBLTY, None)
        rr.pop(apiFields.IRSCH_FLD_ISDEL_BDRS_DUP, None)
        rr.pop(apiFields.IRSCH_FLD_SRC_DATA_ITMS, None)
        rr.pop(apiFields.IRSCH_FLD_LINKAGE_NODES, None)
        rr.pop(apiFields.IRSCH_FLD_CURR_LINKAGE_DUNS, None)
        rr.pop(apiFields.IRSCH_FLD_CURR_LINKAGE_ORG_NM, None)
        rr.pop(apiFields.IRSCH_FLD_CURR_LINKAGE_CNTRY_CD, None)
        rr.pop(apiFields.IRSCH_FLD_CURR_LINKAGE_ADDR, None)

        return rr
    
    
    def _mapPartnerResearchResultHist(self, researchResultHist, isSummaryLevel):
        rrh = []
        for rr in researchResultHist:
            rrt = self._mapPartnerResearchResult(rr, isSummaryLevel)
            rrh.append(rrt)
        return rrh
    
    
    def _mapPartnerComments(self, comments):
        cmnts = []
        for comment in comments:
            # Since we need most of the comment elements, just copy the whole thing and remove what's unneeded
            cmnt = copy.deepcopy(comment)
            rschUser = cmnt.get(apiFields.IRSCH_FLD_USER)
            if rschUser is not None:
                cmnt[apiFields.BOTH_FLD_USER_ID] = rschUser.get(apiFields.BOTH_FLD_USER_ID)
            cmnt.pop(apiFields.IRSCH_FLD_USER, None)
            cmnt.pop(apiFields.IRSCH_FLD_COMMENT_ID, None)
            cmnts.append(cmnt)
        return cmnts
    
    
    def _mapPartnerAttachments(self, attachments):
        attms = []
        for attachment in attachments:
            attm = {
                apiFields.BOTH_FLD_ATTACHMENT_S3OBJ_KEY: attachment.get(apiFields.BOTH_FLD_ATTACHMENT_S3OBJ_KEY),
                apiFields.BOTH_FLD_ATTACHMENT_URL: attachment.get(apiFields.BOTH_FLD_ATTACHMENT_URL),
                apiFields.BOTH_FLD_ATTACHMENT_TYPE_CODE: attachment.get(apiFields.BOTH_FLD_ATTACHMENT_TYPE_CODE),
                apiFields.BOTH_FLD_ATTACHMENT_TIMESTAMP: attachment.get(apiFields.BOTH_FLD_ATTACHMENT_TIMESTAMP),
                apiFields.BOTH_FLD_ATTACHMENT_SIZE: attachment.get(apiFields.BOTH_FLD_ATTACHMENT_SIZE),
                apiFields.BOTH_FLD_ATTACHMENT_FILENAME: attachment.get(apiFields.BOTH_FLD_ATTACHMENT_FILENAME),
            }
            attms.append(attm)
        return attms