'''
Created on Sep 11, 2019
RetrieveCase/RetrieveCaseSummary query parameter names

@author: VanCampK
'''
from enum import Enum

class RetrieveCaseParameterType(Enum):
    IS_SUMMARY_LEVEL = 'isSummaryLevelOnly'
    RESEARCH_REQUEST_ID = 'researchRequestId'
    SUBJECT_RESEARCH_ID = 'subjectResearchId'
    EXTERNAL_STATUS_CODE = 'researchExternalStatusCode'
    VIEW_TYPE = 'viewType'
    MAX_CASES = 'maxCases'
    LAST_ID_FOR_PAGE = 'lastIdForPage'
    PAGE_SIZE = 'pageSize'
    SORT_ORDER = 'sortOrder'
    SEARCH_STRING = 'searchString'
    TEAM_NAME = 'teamName'
    SUBMITTER_VIEW_TYPE = 'submitterViewType'
    RESEARCHER_USER_ID = 'researcherId'
    START_DATE = 'startReportingPeriodDate'
    END_DATE = 'endReportingPeriodDate'
    CLOSED_START_DATE = 'closedPeriodStartingDate'
    CLOSED_END_DATE = 'closedPeriodEndingDate'
    REQUESTOR_REQUEST_KEY = 'requestorOwnRequestKey'
    CUSTOMER_REF_NAME = 'customerReferenceName'
    