'''
Created on Aug 28, 2019

@author: VanCampK
'''
import json
import logging
from common.rejectionReasonCodes import RejectionReasonCode
import lambdas.errorMessages as errmsg
from lambdas.exceptions import createException, LambdaAuthorizationException, LambdaNotFoundException
import lambdas.lambdaConstants as lambdaConstants 
from lambdas.lambdaCommon import buildLambdaSecureInvokeEvent, invokeLambdaFunction, parsePayloadFromInvokeResponse, parseHTTPStatusCodeFromInvokeResponse, parseStatusCodeFromPayload, parseStatusCodeFromInvokeResponse
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.requestRejection import RequestRejection
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.retrieveresearchapi.apiParameterTypes import RetrieveResearchDetailsApiParameterType
from lambdas.retrieveresearchapi.requestRecord import RequestRecord


class RetrieveResearchApiSubmissionService(object):
    '''
    Response for interfacing to the RetrieveCase/RetrieveCaseSummary back-end services
    '''
    # Elements of the submitOneRequest response dictionary:
    RESULT_STATUS_CODE = "statusCode"
    RESULT_ERR_MSG = "errmsg"
    RESULT_BODY = "responseBody"
    RESULT_ERR_RESPONSE = "errorResponse"
    ERROR_MESSAGE = "errorMessage"
    ERROR_TYPE = "errorType"


    def __init__(self, lambdaClient):
        self.lambdaClient = lambdaClient


    def submitOneRequest(self, requestContext, retrieveCaseArn, requestRecord):
        logging.info('Invoking RetrieveCase: outgoingQueryParams=' + str(requestRecord.outgoingQueryParams))
        #print('outgoingBody=' + outgoingBody)
        event = buildLambdaSecureInvokeEvent(requestContext.userSession.principalId, 'GET', '/retrievecase', queryParams=requestRecord.outgoingQueryParams)
        response = invokeLambdaFunction(self.lambdaClient, event, retrieveCaseArn, lambdaConstants.INVOKE_LAMBDA_REQUEST_RESPONSE)
        
        resultDict = {
            RetrieveResearchApiSubmissionService.RESULT_STATUS_CODE: None,
            RetrieveResearchApiSubmissionService.RESULT_ERR_MSG: None,
            RetrieveResearchApiSubmissionService.RESULT_BODY: None
        }
        isSuccess = True
        httpStatusCode = parseHTTPStatusCodeFromInvokeResponse(response)
        resultDict[RetrieveResearchApiSubmissionService.RESULT_STATUS_CODE] = httpStatusCode
        if httpStatusCode != LambdaStatusCodes.OK.value and httpStatusCode != LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
            isSuccess = False
            resultDict[RetrieveResearchApiSubmissionService.RESULT_ERR_MSG] = 'Failed to submitOneRequest: response=' + str(response)
            errmsg = 'httpStatusCode=' + str(httpStatusCode)
            logging.error('Failed to submitOneRequest #1: errmsg=' + errmsg + ' response=' + str(response))
        #elif invokeType == lambdaConstants.INVOKE_LAMBDA_ASYNC:
        else:
            responsePayload = parsePayloadFromInvokeResponse(response)
            if responsePayload:
                logging.info('Response payload from RetrieveCase:' + str(responsePayload))
                #print('Response payload from RetrieveCase:' + str(responsePayload))
                statusCode = parseStatusCodeFromPayload(responsePayload)
                resultDict[RetrieveResearchApiSubmissionService.RESULT_STATUS_CODE] = statusCode
                responseBody = responsePayload.get('body')
                if responseBody is not None:
                    resultDict[RetrieveResearchApiSubmissionService.RESULT_BODY] = json.loads(responseBody)
                if statusCode != LambdaStatusCodes.OK.value:
                    isSuccess = False
                    resultDict[RetrieveResearchApiSubmissionService.RESULT_ERR_MSG] = 'Failed to submitOneRequest #3: response payload=' + str(responsePayload)
                    errmsg = 'statusCode=' + str(statusCode)
                    logging.error('Failed to submitOneRequest: errmsg=' + errmsg + ' response=' + str(response))
                    self._raiseSubmitException(statusCode, resultDict, requestRecord)
            
                
        logging.info('RetrieveCaseApiSubmissionService invoked RetrieveCase: success=' + str(isSuccess))
        return resultDict
   

    def _raiseSubmitException(self, statusCode, resultDict, requestRecord):
        resultErrDict = resultDict[RetrieveResearchApiSubmissionService.RESULT_BODY]
        errorMessage = errmsg.ERR_INTERNAL_REQUEST
        if resultErrDict is not None:
            errorResponse = resultErrDict.get(RetrieveResearchApiSubmissionService.RESULT_ERR_RESPONSE)
            if errorResponse is not None:
                errorMessage = errorResponse.get(RetrieveResearchApiSubmissionService.ERROR_MESSAGE)
        # Special cases to handle are NOT_FOUND(404) and FORBIDDEN(403)
        if statusCode == LambdaStatusCodes.FORBIDDEN.value:
            requestRejection = self._createRequestRejection(requestRecord, errmsg.ERR_NOT_AUTHORIZED)
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.NOT_FOUND.value:
            requestRejection = self._createRequestRejection(requestRecord, errmsg.ERR_NO_RECORD_FOUND, showDetails=False)
            raise LambdaNotFoundException(errmsg.ERR_NO_RECORD_FOUND, requestRejection=requestRejection)
        else:
            raise createException(statusCode, errorMessage, isCloudServices=True)
    
    
    def _createRequestRejection(self, requestRecord, errorMessage, showDetails=True):
        rejectionErrors = []
        subjectResearchId = requestRecord.outgoingQueryParams.get(RetrieveResearchDetailsApiParameterType.SUBJECT_RESEARCH_ID.value)
        researchRequestId = requestRecord.outgoingQueryParams.get(RetrieveResearchDetailsApiParameterType.RESEARCH_REQUEST_ID.value)
        if subjectResearchId is not None:
            if showDetails == True:
                rejectionError = RequestRejectionError(jsonPathName=RetrieveResearchDetailsApiParameterType.SUBJECT_RESEARCH_ID.value, errorDescription=errorMessage, providedValue=subjectResearchId)
            else:
                rejectionError = RequestRejectionError(errorDescription=errorMessage)
        else:
            if showDetails == True:
                rejectionError = RequestRejectionError(jsonPathName=RetrieveResearchDetailsApiParameterType.RESEARCH_REQUEST_ID.value, errorDescription=errorMessage, providedValue=researchRequestId)
            else:
                rejectionError = RequestRejectionError(errorDescription=errorMessage)
                
        rejectionErrors.append(rejectionError)
        return RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrors=rejectionErrors, rejectionErrorMessage=errorMessage)
        