'''
Created on Aug 28, 2019

@author: VanCampK
'''

class RequestRecord(object):
    '''
    Holds attributes about one RetrieveRequestApi request
    '''

    def __init__(self):
        self.isSummaryLevel = True          # False if a single case is requested, True otherwise
        self.isPartnerView = False          # True if a partner (researcher) view, False if submitter view
        self.outgoingQueryParams = {}       # query parameters to be send to RetrieveCase service
        self.requestRejectionErrors = []    # list of RequestRejectionError, if any
        self.rejectionReasonCode = None     # reason for rejection, if any
        self.retrieveCaseResponse = None    # untransformed response from RetrieveCase/RetrieveCaseSummary
        self.responseRecord = None          # fully transformed response to this request
        
        
    def isRejected(self):
        if self.requestRejectionErrors:
            if len(self.requestRejectionErrors) > 0:
                return True
        return False
    
    
    def addRejection(self, requestRejectionError, rejectionReasonCode):
        self.requestRejectionErrors.append(requestRejectionError)
        self.rejectionReasonCode = rejectionReasonCode
