'''
@author: VanCampK
'''
import logging
import json
from common.irschRoles import IResearchRole
from buildUIResponse import buildUIResponse
from lambdas.secureLambdaBase import SecureLambdaBase
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.lambdaStatusCodes import LambdaStatusCodes
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaAuthorizationException, LambdaValidationException
from lambdas.requestRejection import RequestRejection
from lambdas.retrieveresearchapi.retrieveResearchApiService import RetrieveResearchApiService
from lambdas.retrieveresearchapi.requestRecord import RequestRecord


class PartnerRetrieveCaseSummaryApiLambda(SecureLambdaBase):
    '''
    Handler class for PartnerRetrieveCaseApi service.
    Responsible for handling incoming requests from customers via Direct+ APIs.
    Handler: lambdas.retrieveresearchapi.partnerRetrieveCaseSummaryApiLambda.handler
    '''
    
    
    def __init__(self):
        super().__init__()
        self.service = None

    
    def handleSecureRequest(self):
        if self.service is None:
            self.service = RetrieveResearchApiService(PartnerRetrieveCaseSummaryApiLambda.dbConn, PartnerRetrieveCaseSummaryApiLambda.lambdaClient)

        requestRecord = RequestRecord()
        isSummaryLevel = True
        
        self.service.convertQueryParameters(self.requestContext, requestRecord, isSummaryLevel, isPartnerView=True)
            
        if requestRecord.isRejected():
            requestRejection = RequestRejection(requestRecord.rejectionReasonCode, rejectionErrors=requestRecord.requestRejectionErrors)
            raise LambdaValidationException(errmsg.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        
        responseBody = self.service.processRetrieveResearchRequest(self.requestContext, requestRecord)
        
        logging.info('PartnerRetrieveCaseSummaryApiLambda response=' + str(responseBody))
        msgBody = json.dumps(responseBody)
        return buildUIResponse(LambdaStatusCodes.OK.value, msgBody, 'application/json')


    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER ]) == False):
            logging.error('PartnerRetrieveCaseSummaryApiLambda - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)


    def initializeKeepWarm(self):
        pass
        

    def getResponseSchema(self):
        return "iResearchPartnerRetrieveCaseSummaryResponse.json"

    
    def isApi(self):
        '''
        By default we are behaving as there is a browser on the other side.
        Subclass can override this if they want API-type behavior.
        '''
        return True

        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = PartnerRetrieveCaseSummaryApiLambda.get_handler(...)