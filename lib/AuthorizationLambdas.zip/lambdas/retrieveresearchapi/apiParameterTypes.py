'''
Created on Aug 28, 2019
Direct+ API incoming query parameter names for RetrieveResearchApi

@author: VanCampK
'''
from enum import Enum

class RetrieveResearchDetailsApiParameterType(Enum):
    # Parameters accepted for RETRIEVE_RESEARCH_DETAILS_REQUEST 
    SUBJECT_RESEARCH_ID = 'subjectResearchId'
    RESEARCH_REQUEST_ID = 'researchRequestId'
    

class RetrieveResearchSummaryApiParameterType(Enum):
    # Parameters accepted for RETRIEVE_RESEARCH_SUMMARY_REQUEST 
    START_DATE = 'startReportingPeriodDate'
    END_DATE = 'endReportingPeriodDate'
    EXTERNAL_STATUS_CODE = 'requestedStatusTypeCode'
    REQUESTOR_REQUEST_KEY = 'requestorOwnRequestKey'
    RESEARCH_REQUEST_ID = 'researchRequestId'
    PAGE_SIZE = 'pageSize'
    LAST_ID_FOR_PAGE = 'lastIdForPage'
    IS_ASCENDING_SORT = 'isAscendingSortOrder'
    IS_MY_REQUESTS_ONLY = 'isMyRequestsOnly'
    CLOSED_START_DATE = 'closedPeriodStartingDate'
    CLOSED_END_DATE = 'closedPeriodEndingDate'
    CUSTOMER_REF_NAME = 'customerReferenceName'


class PartnerRetrieveCaseDetailsApiParameterType(Enum):
    SUBJECT_RESEARCH_ID = 'subjectResearchId'


class PartnerRetrieveCaseSummaryApiParameterType(Enum):
    START_TS = 'startReportingPeriodTimestamp'
    END_TS = 'endReportingPeriodTimestamp'
    INTERNAL_STATUS_CODE = 'researchInternalStatusCode'
    TEAM_NAME = 'teamName'
    PAGE_SIZE = 'pageSize'
    LAST_ID_FOR_PAGE = 'lastIdForPage'
    IS_ASCENDING_SORT = 'isAscendingSortOrder'
