'''
Created on Mar 11, 2019

@author: VanCampK
'''
import logging
import datetime

class StatsLogger(object):
    '''
    Logs statistics on lambda usage and keep-warm events
    '''

    def __init__(self):
        self.timeOfColdStart = datetime.datetime.now()
        self.numKeepWarmCalls = 0
        self.numAPICalls = 0

    def logStats(self, isKeepWarmCall, isAPICall):
        logMessage = "Time of Cold Start: " + str(self.timeOfColdStart)
        if isKeepWarmCall == True:
            self.numKeepWarmCalls += 1
            logMessage += " isKeepWarmCall"
        if isAPICall == True:
            self.numAPICalls += 1
            logMessage += " isAPICall"
        logMessage += " Number of KeepWarmCalls: " + str(self.numKeepWarmCalls)
        logMessage += " Number of API Calls: " + str(self.numAPICalls)
        #logMessage.append("Total Memory: " + Runtime.getRuntime().totalMemory()).append(" ");
        #logMessage.append("Free Memory: " + Runtime.getRuntime().freeMemory()).append("\n");
        logging.info(logMessage);