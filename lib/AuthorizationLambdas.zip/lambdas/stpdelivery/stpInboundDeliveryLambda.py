'''
Modified on Apr 10, 2020

@author: VanCampK
'''
import logging

from common import envVblNames
from common.util.sftpHelper import SftpHelper
from common.util.sftpMockHelper import SftpMockHelper
from lambdas.lambdaBase import LambdaBase
from lambdas.stpdelivery.sftpDeliveryType import SftpDeliveryType
from lambdas.stpdelivery.stpInboundDeliveryService import StpInboundDeliveryService
from lambdas.stpdelivery.stpUtil import getSftpDeliveryType, SFTP_USERS_INBOUND_FOLDER
from lambdas.exceptions import LambdaConflictException


class StpInboundDeliveryLambda(LambdaBase):
    '''
    Handler class for StpInboundDelivery and SftpInboundDelivery service.
     - which one is controlled by the environment variable "SFTPDELIVERYTYPE" (value can be "SFTP_S3" or "STP")
    Handler: lambdas.stpdelivery.stpInboundDeliveryLambda.handler
    
    Deployment configuration notes:
    This lambda must be created with Python 3.7 for compatibility with the paramiko SFTP library.
    This lambda needs the layer irsch_d1_SFTPLibraries_PY37
    For StpInboundDelivery, must set up a Cloudwatch timer rule irsch_*_InvokeStpInboundDelivery to invoke this lambda every 5 minutes.
    For SftpInboundDelivery, must set up a Cloudwatch timer rule irsch_*_InvokeSftpInboundDelivery to invoke this lambda every 5 minutes (for recovery mode only).
    For SftpInboundDelivery, must create S3 event rule to fire this lambda whenever a file is dropped in irsch-*-datastores bucket under the sftp-users folder.
    '''
    MOCK_STP_SERVER = "MOCK-STP"
    MOCK_STP_ROOT_FOLDER = "mock-stp"
    MOCK_STP_OUTBOUND_FOLDER = "outbound"
    MOCK_STP_INBOUND_FOLDER = "inbound"

        
    def exitOnTimerEvent(self):
        return False
    
    
    def needsDbConn(self):
        return True
    
    
    def handleRequest(self):
        LambdaBase.raiseAlertWhenRequestFails = True
            
        service = self._createService()
        logging.info(f"StpInboundDeliveryLambda: event={self.requestContext.event}")
        try:
            service.processInboundFiles(self.requestContext)
            service.closeConnection()
        except Exception as e:
            logging.error(f"StpInboundDeliveryLambda: Uncaught exception {e}, closing STP connections...")
            service.closeConnection()
            raise


    def _createService(self):
        sftpServer = self.requestContext.environDict.get(envVblNames.ENV_STP_SERVER)
        sftpUserId = self.requestContext.environDict.get(envVblNames.ENV_STP_USERID)
        sftpPassword = self.requestContext.environDict.get(envVblNames.ENV_STP_PASSWORD)
        datastoresBucket = self.requestContext.environDict.get(envVblNames.ENV_DATASTORES_BUCKET)
        sftpHelper = None
        if sftpServer == StpInboundDeliveryLambda.MOCK_STP_SERVER:
            sftpHelper = SftpMockHelper(datastoresBucket, StpInboundDeliveryLambda.MOCK_STP_ROOT_FOLDER,
                                             StpInboundDeliveryLambda.MOCK_STP_OUTBOUND_FOLDER,
                                             StpInboundDeliveryLambda.MOCK_STP_INBOUND_FOLDER)
        else:
            sftpDeliveryType = getSftpDeliveryType(self.requestContext)
            if sftpDeliveryType == SftpDeliveryType.STP.value:
                # STP mode
                sftpHelper = SftpHelper(sftpServer, sftpUserId, sftpPassword)
            elif sftpDeliveryType == SftpDeliveryType.CFP.value:
                logging.error("Unsupported CFP delivery type on inbound service")
                raise LambdaConflictException("Unsupported CFP delivery type on inbound service")
            else:
                # SFTP_S3 mode
                sftpHelper = SftpMockHelper(datastoresBucket, SFTP_USERS_INBOUND_FOLDER, "", "")
            
        if sftpHelper is not None:
            try:
                logging.info("Trying to connect to STP...")
                sftpHelper.connect()
                logging.info("Successfully connected to STP")
            except Exception as e:
                logging.error(f"StpInboundDeliveryLambda: Caught exception {e}, closing STP connections and exiting...")
                sftpHelper.quit()
                raise
        service = StpInboundDeliveryService(StpInboundDeliveryLambda.dbConn, StpInboundDeliveryLambda.environDict, StpInboundDeliveryLambda.alert, sftpHelper, self.getModuleName())
        return service


    def initializeKeepWarm(self):
        pass
        
        
    def getModuleName(self):
        sftpDeliveryType = getSftpDeliveryType(self.requestContext)
        if sftpDeliveryType == SftpDeliveryType.STP.value:
            return "StpInboundDeliveryLambda"
        else:
            return "SftpInboundDeliveryLambda"
    
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = StpInboundDeliveryLambda.get_handler(...)