'''
Created on Aug 14, 2020

@author: VanCampK
'''
from enum import Enum


class StpDeliveryIndicator(Enum):
    SFTP_S3 = 0     # For delivery to/from our SFTP S3 server
    STP = 1         # For delivery to/from STP
    CFP = 2         # For delivery of STAT files to CFP's SFTP server (no inbound supported)
    