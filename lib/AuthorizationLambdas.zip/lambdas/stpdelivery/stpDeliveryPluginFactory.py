'''
Created on Apr 14, 2020

@author: VanCampK
'''
from lambdas.stpdelivery.cfpDeliveryPlugin import CfpDeliveryPlugin
from lambdas.stpdelivery.sftpDeliveryType import SftpDeliveryType
from lambdas.stpdelivery.stpPartnerDeliveryPlugin import StpPartnerDeliveryPlugin
from lambdas.stpdelivery.stpVirusScanDeliveryPlugin import StpVirusScanDeliveryPlugin
from lambdas.stpdelivery.stpUtil import getSftpDeliveryType


def stpDeliveryPluginFactory(dbConn, requestContext):
    '''
    Factory method to instantiate and return a list of all needed plugins.
    TODO consider replacing this with configuration.
    '''
    sftpDeliveryType = getSftpDeliveryType(requestContext)
    pluginList = []
    # Order matters! More well-defined plugin by getS3OutboundFolder() and getS3InboundFolder() should go first, in case namespaces overlap.
    if sftpDeliveryType in [SftpDeliveryType.SFTP_S3.value, SftpDeliveryType.CFP.value]:
        cfpDeliveryPlugin = CfpDeliveryPlugin(dbConn, requestContext)
        pluginList.append(cfpDeliveryPlugin)
    else:
        stpVirusScanDeliveryPlugin = StpVirusScanDeliveryPlugin(dbConn, requestContext)
        pluginList.append(stpVirusScanDeliveryPlugin)
        stpPartnerDeliveryPlugin = StpPartnerDeliveryPlugin(dbConn, requestContext)
        pluginList.append(stpPartnerDeliveryPlugin)
        
    return pluginList
    