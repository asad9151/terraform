'''
Created on Apr 13, 2020

@author: VanCampK
'''
import logging
import time

from common import envVblNames
from common.model.s3Object import S3Object
from common.util.s3Helper import S3Helper
from common.util.sftpHelper import SftpHelper
from common.util.sftpMockHelper import SftpMockHelper
from common.util.stringUtils import isNotBlank
from lambdas.stpdelivery.stpDeliveryPlugin import StpDeliveryPlugin


class StpVirusScanDeliveryPlugin(StpDeliveryPlugin):
    '''
    Plugin to handle specifics for files being sent to STP for virus scanning
    '''
    MODULE_NAME = "StpVirusScanDeliveryPlugin"
    MOCK_STP_SERVER = "MOCK-STP"
    MOCK_STP_ROOT_FOLDER = ""
    MOCK_STP_OUTBOUND_FOLDER = "bderet"
    MOCK_STP_INBOUND_FOLDER = "unused"

    
    def __init__(self, dbConn, requestContext):
        super().__init__(dbConn, requestContext)
        self.myStpUserId = self.requestContext.environDict.get(envVblNames.ENV_STP_USERID)
        self.s3Bucket = self.requestContext.environDict.get(envVblNames.ENV_DATASTORES_BUCKET)


    def getPluginName(self):
        return StpVirusScanDeliveryPlugin.MODULE_NAME
        

    def getS3Bucket(self):
        return self.s3Bucket


    def getS3OutboundFolder(self):
        # Set this to stp-outbound if using the existing ProcessUploadedAttachment lambda, or to attachment-upload if replacing it.
        return "stp-outbound/" + self.myStpUserId


    def nameOutboundRelativeFolder(self, s3Folder):
        return s3Folder.replace("stp-outbound/", "")


    def getStpOutboundFolder(self):
        return "bderet"


    def getS3InboundFolder(self):
        # Set this to bderet to use the existing ProcessVirusScannedAttachment lambda, or to attachments if replacing it.
        return "bderet"


    def getSTPInboundFolder(self):
        return "other"


    def nameSTPOutboundFile(self, stpDeliveryFile):
        return f"{self.myStpUserId}.0.{stpDeliveryFile.s3Object.fileName}"


    def decodeSTPInboundFile(self, stpDeliveryFile):
        # Sample inbound file: iResearchQA.D39TMEL5.virusScanTest2.zip
        # Sample inbound file: iResearchDEV.CLPAGJEV.R286865_5836310F_MiniBatch_ManyValidationFailures.xlsx
        s3Object = S3Object()
        s3Object.bucket = self.s3Bucket
        flnmParts = stpDeliveryFile.stpFileName.split(".")
        stpDeliveryFile.relativeFolder = flnmParts[0]
        s3Object.folder = self.getS3InboundFolder()
        s3Object.fileName = ".".join(flnmParts[2:])
        stpDeliveryFile.s3Object = s3Object
    
    
    def isValidInboundFileNameForThisPlugin(self, stpFileName):
        flnmParts = stpFileName.split(".")
        if len(flnmParts) > 1:
            if flnmParts[0] == self.myStpUserId:
                return True
        return False
        
        
    def recordOutboundDetails(self, stpDeliveryFile):
        '''
        Need to override this if we are replacing ProcessUploadedAttachment, to set attm status to FILE_RECEIVED.
        '''


    def postOutboundSuccessAction(self, stpDeliveryFile):
        '''
        Need to add more functionality to this if we are replacing ProcessUploadedAttachment, to set attm status to FILE_SUBMITTED_TO_VIRUS_SCAN.
        '''
        # In mock mode, pause and then copy file to /bderet folder in S3 bucket so it comes back immediately to ProcessVirusScannedAttachment
        # (This bypasses the StpInboundDelivery service.)
        sftpServer = self.requestContext.environDict.get(envVblNames.ENV_STP_SERVER)
        if sftpServer == StpVirusScanDeliveryPlugin.MOCK_STP_SERVER:
            delaySecs = self.requestContext.environDict.get(envVblNames.ENV_MOCKSTP_DELAYSECS)
            if isNotBlank(delaySecs):
                logging.info(f"postOutboundSuccessAction in MOCK mode: sleeping for {delaySecs} seconds")
                time.sleep(int(delaySecs))
            localFileName = SftpHelper.LOCAL_DIRECTORY + stpDeliveryFile.s3Object.fileName
            s3Helper = S3Helper()
            s3Object = S3Object()
            s3Object.bucket = self.s3Bucket
            flnmParts = stpDeliveryFile.stpFileName.split(".")
            s3Object.fileName = ".".join(flnmParts[2:])
            s3Object.folder = StpVirusScanDeliveryPlugin.MOCK_STP_OUTBOUND_FOLDER
            s3Object.fileSize = stpDeliveryFile.s3Object.fileSize
            logging.info(f"postOutboundSuccessAction in MOCK mode: posting file {localFileName} to {s3Object}")
            s3Helper.copyFromLocalToS3(localFileName, s3Object)
        
        
    def recordInboundDetails(self, stpDeliveryFile):
        '''
        Need to override this if we are replacing ProcessVirusScannedAttachment, to set attm status to FILE_RETURNED_FROM_VIRUS_SCAN
        '''


    def postInboundSuccessAction(self, stpDeliveryFile):
        '''
        Need to override this if we are replacing ProcessVirusScannedAttachment, to:
        Set attm status to PROCESSING_COMPLETE and result code to FILE_AVAILABLE.
        '''
