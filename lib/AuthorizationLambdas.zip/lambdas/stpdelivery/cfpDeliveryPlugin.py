'''
Created on Aug 14, 2020

@author: VanCampK
'''
import logging

from common import envVblNames
from common.model.s3Object import S3Object
from common.partnerFileType import PartnerFileType
from common.util.stringUtils import isBlank
from lambdas.stpdelivery.sftpDeliveryType import SftpDeliveryType
from lambdas.stpdelivery.stpPartnerDeliveryPlugin import StpPartnerDeliveryPlugin
from lambdas.stpdelivery.stpUtil import getSftpDeliveryType


class CfpDeliveryPlugin(StpPartnerDeliveryPlugin):
    '''
    STP delivery plugin for CFP
    '''


    def getPluginName(self):
        return "CfpDeliveryPlugin"
    
    
    def _getBaseDirectoryName(self):
        sftpDeliveryType = getSftpDeliveryType(self.requestContext)
        if sftpDeliveryType == SftpDeliveryType.CFP.value:
            return "cfp-sftp-outbound"
        else:
            return "sftp-outbound"


    def getS3OutboundFolder(self):
        sftpDeliveryType = getSftpDeliveryType(self.requestContext)
        if sftpDeliveryType == SftpDeliveryType.CFP.value:
            return self._getBaseDirectoryName() + self.requestContext.environDict.get(envVblNames.ENV_CFP_SFTP_DIRECTORY)
        else:
            return self._getBaseDirectoryName()


    def nameOutboundRelativeFolder(self, s3Folder):
        baseFolder = self._getBaseDirectoryName() + "/"
        return s3Folder.replace(baseFolder, "")


    def nameSTPOutboundFile(self, stpDeliveryFile):
        return f"{stpDeliveryFile.relativeFolder}/{stpDeliveryFile.s3Object.fileName}"


    def getStpOutboundFolder(self):
        sftpDeliveryType = getSftpDeliveryType(self.requestContext)
        if sftpDeliveryType == SftpDeliveryType.CFP.value:
            #return self.getS3OutboundFolder()
            return ""
        else:
            return "sftp-users"


    def getS3InboundFolder(self):
        return "sftp-inbound"


    def getSTPInboundFolder(self):
        return "sftp-users"
    
    
    def getPartnerFolderSplitChar(self):
        # From SFTP we get partner's name from folder name
        return "/"
    
    
    def isValidInboundFileNameForThisPlugin(self, stpFileName):
        partnerFolderName = self._getPartnerFolderName(stpFileName)
        if partnerFolderName is None:
            return False
        else:
            fileType = self._getPartnerFileType(stpFileName)
            if fileType == PartnerFileType.CFP_REQUEST:
                return True
            else:
                #logging.warning(f"Filename {stpFileName} is from a recognized partner {partnerFolderName} but does not conform to any known inbound partner file type")
                return False
    
    
    def _getPartnerFileType(self, stpFileName):
        # Sample inbound filename from SFTP-S3 CFP: CFPDev/global/FPC.KEN.CFP_LOOKUP_INV_BATCH_20200807_1.TR458I.IRD1.HDX
        # Returns CFP_REQUEST file type
        if isBlank(stpFileName):
            return None
        flnmParts = stpFileName.split(self.getPartnerFolderSplitChar())
        if len(flnmParts) < 3:
            logging.warning(f"_getPartnerFileType: stpFileName={stpFileName} has less than 3 parts so can't be matched")
            return None
        fileNameMinusPartner = flnmParts[2]
        logging.info(f"_getPartnerFileType: fileNameMinusPartner={fileNameMinusPartner}")
        for pft in PartnerFileType:
            prefix = pft.value["fileNamePrefix"]
            suffixes = pft.value["fileNameSuffixes"]
            fileTypeCode = pft.value["fileTypeCode"]
            if prefix is not None and fileNameMinusPartner.lower().startswith(prefix.lower()):
                for suffix in suffixes:
                    if fileNameMinusPartner.lower().endswith(suffix.lower()):
                        return pft
                logging.info(f"cfpDeliveryPlugin._getPartnerFileType ({fileTypeCode}): fileNamePrefix {prefix} matches but ignoring because does not match any known fileNameSuffixes {','.join(suffixes)}")
        return None


    def decodeSTPInboundFile(self, stpDeliveryFile):
        # Sample inbound filename from SFTP-S3 CFP: CFPDev/global/FPC.KEN.CFP_LOOKUP_INV_BATCH_20200807_1.TR458I.IRD1.HDX
        s3Object = S3Object()
        s3Object.bucket = self.requestContext.environDict.get(envVblNames.ENV_DATASTORES_BUCKET)
        flnmParts = stpDeliveryFile.stpFileName.split(self.getPartnerFolderSplitChar())
        stpDeliveryFile.relativeFolder = flnmParts[0] + "/" + flnmParts[1]
        s3Object.folder = self.getS3InboundFolder() + "/" + stpDeliveryFile.relativeFolder
        s3Object.fileName = flnmParts[2]
        stpDeliveryFile.s3Object = s3Object
