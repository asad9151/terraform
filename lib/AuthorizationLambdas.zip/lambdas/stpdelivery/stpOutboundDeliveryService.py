'''
Created on Apr 10, 2020

@author: VanCampK
'''
import logging
import sys
import traceback

from common import updateEventConstants
from common.dao.fileTrackingDao import FileTrackingDao
from common.dao.updateEventDao import UpdateEventDao
from common.model.stpDeliveryFile import StpDeliveryFile
from common.processResultCodes import ProcessResultCode
from common.processStatusCodes import ProcessStatusCode
from common.updateActionCodes import UpdateActionCode
from common.util.sftpHelper import SftpHelper
import lambdas.errorMessages as errmsgs
from lambdas.exceptions import LambdaConflictException
from lambdas.stpdelivery.sftpDeliveryType import SftpDeliveryType
from lambdas.stpdelivery.stpDeliveryPluginFactory import stpDeliveryPluginFactory
from lambdas.stpdelivery.stpUtil import getStpDeliveryIndicator, getSftpDeliveryType
from common.util.stringUtils import isNotBlank


class StpOutboundDeliveryService(object):
    '''
    Services to support incoming and outgoing file delivery
    '''
    EXIT_WHEN_MILLISECS_LEFT = 10000
    SFTP_USERS_OUTBOUND_FOLDER = "sftp-users"
    STOP_AFTER_DELIVERY_ATTEMPT = 576  # Retries every 5 minutes for 48 hours
    RECOVER_MINIMUM_FILE_AGE_MINUTES = 6    # Wait at least 6 minutes before trying to recover since the lambda runs every 5 minutes


    def __init__(self, s3Helper, dbConn, environDict, alert, sftpHelper, moduleName):
        self.s3Helper = s3Helper
        self.dbConn = dbConn
        self.environDict = environDict
        self.stpDeliveryPlugins = None
        self.sftpHelper = sftpHelper
        self.fileTrackingDao = None
        self.updateEventDao = None
        self.alert = alert
        self.moduleName = moduleName
        
        
    def _createServices(self, requestContext):
        if self.stpDeliveryPlugins is None:
            self.stpDeliveryPlugins = stpDeliveryPluginFactory(self.dbConn, requestContext)
        if self.fileTrackingDao is None:
            self.fileTrackingDao = FileTrackingDao()
        if self.updateEventDao is None:
            self.updateEventDao = UpdateEventDao()
        
        
    def processOutboundFile(self, requestContext, s3Object):
        self._createServices(requestContext)
        stpDeliveryIndicator = getStpDeliveryIndicator(requestContext)
        foundPlugin = False
        # Find the first plugin that will service this file
        for plugin in self.stpDeliveryPlugins:
            pluginS3RootFolder = plugin.getS3OutboundFolder()
            if s3Object.bucket == plugin.getS3Bucket() and s3Object.folder.startswith(pluginS3RootFolder):
                logging.info(f"Plugin {plugin.getPluginName()}: process s3Object {s3Object}: bucket {plugin.getS3Bucket()} and folder startswith {pluginS3RootFolder}")
                foundPlugin = True
                try:
                    relativeFolder = plugin.nameOutboundRelativeFolder(s3Object.folder)
                    stpDeliveryFile = self.fileTrackingDao.queryPartnerFileTracking(self.dbConn, StpDeliveryFile.STP_DELIVERY_OUTBOUND, relativeFolder, s3Object.fileName, stpDeliveryIndicator)
                    if stpDeliveryFile is None:
                        logging.error(errmsgs.ERR_S3_FILE_NOT_FOUND + f": {s3Object}")
                        self.alert.raiseAlert(self.moduleName, errmsgs.ERR_S3_FILE_NOT_FOUND, detailedErrMsg=str(s3Object))
                        break
                    self._processOutboundFileImpl(requestContext, plugin, stpDeliveryFile)
                except Exception as e:
                    logging.error(f"processOutboundFile: Caught exception {e}, aborting delivery of {stpDeliveryFile.s3Object}")
                    traceback.print_tb(sys.exc_info()[2])
                    self._markOutboundFileFailure(requestContext, plugin, stpDeliveryFile)
                    # Do not raise exception, it will be processed on next retry
                break
            else:
                logging.info(f"Plugin {plugin.getPluginName()}: do not process s3Object {s3Object}: bucket not {plugin.getS3Bucket()} or folder not startswith {pluginS3RootFolder}")
        if foundPlugin == False:
            logging.warning("processOutboundFile: No plugin matches")
        
        
    def closeConnection(self):
        if self.sftpHelper is not None:
            self.sftpHelper.quit()
            
            
    def findFilesToRecover(self, requestContext):
        self._createServices(requestContext)
        stpDeliveryIndicator = getStpDeliveryIndicator(requestContext)
        stpDeliveryFiles = self.fileTrackingDao.queryFailedPartnerFileTracking(self.dbConn, StpDeliveryFile.STP_DELIVERY_OUTBOUND, stpDeliveryIndicator, StpOutboundDeliveryService.RECOVER_MINIMUM_FILE_AGE_MINUTES)
        logging.info(f"findFilesToRecover found {len(stpDeliveryFiles)} files to recover...")
        return stpDeliveryFiles
            
            
    def processRecoveryFiles(self, requestContext, stpDeliveryFiles):
        nSuccess = 0
        nFailure = 0
        nRemaining = len(stpDeliveryFiles)
        outOfTime = False
        first = True
        for stpDeliveryFile in stpDeliveryFiles:
            if outOfTime:
                break
            logging.info(f"processRecoveryFiles attempting to recover {stpDeliveryFile} ...")
            foundPlugin = False
            # Find the first plugin that will service this file
            for plugin in self.stpDeliveryPlugins:
                pluginS3RootFolder = plugin.getS3OutboundFolder()
                if stpDeliveryFile.s3Object.bucket == plugin.getS3Bucket() and stpDeliveryFile.s3Object.folder.startswith(pluginS3RootFolder):
                    logging.info(f"Plugin {plugin.getPluginName()}: process stpDeliveryFile {stpDeliveryFile}")
                    foundPlugin = True
                    try:
                        self._processOutboundFileImpl(requestContext, plugin, stpDeliveryFile, first=first)
                        logging.info(f"processRecoveryFiles recovery successful")
                        nSuccess += 1
                        nRemaining -= 1
                        timeLeft = requestContext.lambdaContext.get_remaining_time_in_millis()
                        logging.info(f"processInboundFiles: Time left {timeLeft} milliseconds with {nRemaining} records remaining to be submitted.")
                        if timeLeft < StpOutboundDeliveryService.EXIT_WHEN_MILLISECS_LEFT:
                            logging.warning(f"processInboundFiles: Out of time with {nRemaining} files left to process, will resume on next invoke")
                            outOfTime = True
                    except Exception as e:
                        logging.error(f"processRecoveryFiles: Caught exception {e}, aborting delivery of {stpDeliveryFile}")
                        stpDeliveryFile.deliveryAttemptCount += 1
                        traceback.print_tb(sys.exc_info()[2])
                        isAborted = False
                        if stpDeliveryFile.deliveryAttemptCount >= StpOutboundDeliveryService.STOP_AFTER_DELIVERY_ATTEMPT:
                            self.alert.raiseAlert(self.moduleName, f"Failed to deliver to STP after {stpDeliveryFile.deliveryAttemptCount} attempts (WILL NOT TRY AGAIN)", detailedErrMsg=str(stpDeliveryFile))
                            isAborted = True
                        self._markOutboundFileFailure(requestContext, plugin, stpDeliveryFile, isAborted=isAborted)
                        nFailure += 1
                        nRemaining -= 1
                            
                    first = False
                    break
                else:
                    logging.info(f"Plugin {plugin.getPluginName()}: do not process stpDeliveryFile {stpDeliveryFile}: bucket not {plugin.getS3Bucket()} or folder not startswith {pluginS3RootFolder}")
            if foundPlugin == False:
                logging.warning("processRecoveryFiles: No plugin matches")
                
        logging.info(f"processRecoveryFiles completed with nSuccess={nSuccess} nFailure={nFailure} nRemaining={nRemaining}")

    
    def _processOutboundFileImpl(self, requestContext, plugin, stpDeliveryFile, first=True):
        # First set the file to failed status in case anything goes wrong...
        self._markOutboundFileFailure(requestContext, plugin, stpDeliveryFile)
        stpDeliveryFile.stpFileName = plugin.nameSTPOutboundFile(stpDeliveryFile)
        #localFileName = SftpHelper.LOCAL_DIRECTORY + stpDeliveryFile.stpFileName
        localFileName = SftpHelper.LOCAL_DIRECTORY + stpDeliveryFile.s3Object.fileName
        plugin.recordOutboundDetails(stpDeliveryFile)
        self.s3Helper.copyFromS3ToLocal(stpDeliveryFile.s3Object, localFileName)
        outboundFileName = stpDeliveryFile.stpFileName
        outboundFolder = plugin.getStpOutboundFolder()
        sftpDeliveryType = getSftpDeliveryType(requestContext)
        if sftpDeliveryType == SftpDeliveryType.CFP.value:
            # Break up filename into directory and filename
            fileparts = outboundFileName.split('/')
            if len(fileparts) > 1:
                outboundFolder += "/" + "/".join(fileparts[0:-1])
                outboundFileName = fileparts[-1]
                
        if first == True and isNotBlank(outboundFolder):
            self.sftpHelper.chdir(outboundFolder)
        self.sftpHelper.putFile(localFileName, outboundFileName)
        if sftpDeliveryType == SftpDeliveryType.CFP.value:
            logging.info("_testForSuccessfulPut disabled for CFP because the file is immediately moved out")
        else:
            self._testForSuccessfulPut(outboundFileName)
        
        stpDeliveryFile.processStatusCode = ProcessStatusCode.PROCESSING_COMPLETE.value
        stpDeliveryFile.processResultCode = ProcessResultCode.FILE_AVAILABLE.value
        self.fileTrackingDao.updateFileTracking(self.dbConn, stpDeliveryFile, self.moduleName)
        self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_FILE_TRACKING_TABLE,
                                        stpDeliveryFile.fileTrackingId, updateEventConstants.AUDIT_ELEMENT_FILE_TRACKING_ID,
                                        stpDeliveryFile.stpFileName, stpDeliveryFile.processStatusCode, UpdateActionCode.MODIFY.value, None,
                                        None, None, self.moduleName)
        logging.info("_processOutboundFileImpl success: Invoking plugin postOutboundSuccessAction")
        plugin.postOutboundSuccessAction(stpDeliveryFile)
        logging.info(f"_processOutboundFileImpl completed for {stpDeliveryFile}")


    def _markOutboundFileFailure(self, requestContext, plugin, stpDeliveryFile, isAborted=False):
        stpDeliveryFile.processStatusCode = ProcessStatusCode.FILE_SUBMITTED_TO_VIRUS_SCAN.value
        stpDeliveryFile.processResultCode = ProcessResultCode.UNSUCCESSFUL.value if isAborted == False else ProcessResultCode.FILE_ABORTED.value 
        self.fileTrackingDao.updateFileTracking(self.dbConn, stpDeliveryFile, self.moduleName)
        self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_FILE_TRACKING_TABLE,
                                        stpDeliveryFile.fileTrackingId, updateEventConstants.AUDIT_ELEMENT_FILE_TRACKING_RESULT_CODE,
                                        str(stpDeliveryFile.processResultCode), stpDeliveryFile.processStatusCode, UpdateActionCode.MODIFY.value, None,
                                        None, None, self.moduleName)


    def _testForSuccessfulPut(self, stpFileName):
        if self.sftpHelper.isProductionMode():
            # Validate that the file was successfully put by doing a directory listing...
            fileNames = [stpFileName, f"{stpFileName}.antivirus.scanning"]
            foundFile = self.sftpHelper.doesAnyFileExist(fileNames)
            if foundFile == False:
                logging.error(f"_testForSuccessfulPut: failed to find {fileNames} in directory")
                raise LambdaConflictException(f"Failed on put of file {stpFileName} - need to retry")
