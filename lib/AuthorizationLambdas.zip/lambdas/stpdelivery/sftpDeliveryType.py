'''
Created on Aug 14, 2020

@author: VanCampK
'''
from enum import Enum


class SftpDeliveryType(Enum):
    STP = "STP"         # For delivery to/from STP
    SFTP_S3 = "SFTP_S3" # For delivery to/from our SFTP S3 server
    CFP = "CFP"         # For delivery of STAT files to CFP's SFTP server (no inbound supported)
    