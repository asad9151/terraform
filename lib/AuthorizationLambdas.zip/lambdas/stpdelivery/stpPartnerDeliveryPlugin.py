'''
Created on Apr 13, 2020

@author: VanCampK
'''
import json
import logging

from common import envVblNames
from common import updateEventConstants
from common.dao.apiApplicationEntitlementDao import ApiApplicationEntitlementDao
from common.dao.fileTrackingDao import FileTrackingDao
from common.dao.updateEventDao import UpdateEventDao
from common.model.stpPartnerDeliveryFile import StpPartnerDeliveryFile
from common.partnerFileType import PartnerFileType
from common.processStatusCodes import ProcessStatusCode
from common.updateActionCodes import UpdateActionCode
from common.util.stringUtils import isBlank, isNotBlank
from common.util.sqsHelper import SqsHelper
from common.model.s3Object import S3Object
from lambdas.stpdelivery.stpDeliveryPlugin import StpDeliveryPlugin
from lambdas.exceptions import LambdaConflictException,\
    LambdaProcessingException

class StpPartnerDeliveryPlugin(StpDeliveryPlugin):
    '''
    Plugin to handle specifics for partner delivery files
    '''
    MODULE_NAME = "StpPartnerDeliveryPlugin"
    

    def __init__(self, dbConn, requestContext):
        super().__init__(dbConn, requestContext)
        self._partnerApiAppEntlList = None
        self._apiApplicationEntitlementDao = None
        self.fileTrackingDao = None
        self.updateEventDao = None
        self.sqsHelper = None


    def getPluginName(self):
        return "StpPartnerDeliveryPlugin"
    

    def getS3Bucket(self):
        return self.requestContext.environDict.get(envVblNames.ENV_DATASTORES_BUCKET)


    def getS3OutboundFolder(self):
        return "stp-outbound"


    def nameOutboundRelativeFolder(self, s3Folder):
        return s3Folder.replace("stp-outbound/", "")


    def getStpOutboundFolder(self):
        return "bderet"


    def getS3InboundFolder(self):
        return "stp-inbound"


    def getSTPInboundFolder(self):
        return "other"


    def nameSTPOutboundFile(self, stpDeliveryFile):
        return f"{stpDeliveryFile.relativeFolder}.0.{stpDeliveryFile.s3Object.fileName}"


    def decodeSTPInboundFile(self, stpDeliveryFile):
        # Sample inbound filename from STP: china.12345678.filename.ext
        s3Object = S3Object()
        s3Object.bucket = self.requestContext.environDict.get(envVblNames.ENV_DATASTORES_BUCKET)
        flnmParts = stpDeliveryFile.stpFileName.split(".")
        stpDeliveryFile.relativeFolder = flnmParts[0]
        s3Object.folder = self.getS3InboundFolder() + "/" + stpDeliveryFile.relativeFolder
        s3Object.fileName = ".".join(flnmParts[2:])
        stpDeliveryFile.s3Object = s3Object
    
    
    def isValidInboundFileNameForThisPlugin(self, stpFileName):
        partnerFolderName = self._getPartnerFolderName(stpFileName)
        if partnerFolderName is None:
            return False
        else:
            fileType = self._getPartnerFileType(stpFileName)
            if fileType is None:
                logging.error(f"Filename {stpFileName} is from a recognized partner {partnerFolderName} but does not conform to any known partner file type")
                return False
            else:
                return True
        
        
    def _getPartnerFolderName(self, stpFileName):
        apiAppEntl = self._getPartnerApiAppEntl(stpFileName)
        if apiAppEntl is not None:
            return apiAppEntl.partnerFolderName
        else:
            return None
        
        
    def _getPartnerApiAppEntl(self, stpFileName):
        # Sample inbound filename from STP: china.CN2KTGFE.iResearchDEV.0.UpdateAndCloseRequest_20200420120000.zip
        # Returns: ApiEntl object for partnerName='china'
        self._loadPartnerApiEntlList()
        flnmParts = stpFileName.split(self.getPartnerFolderSplitChar())
        theApiAppEntl = None
        hasApiAppEntl = False
        if len(flnmParts) > 1:
            partnerName = flnmParts[0]
            for apiAppEntl in self._partnerApiAppEntlList:
                if partnerName == apiAppEntl.partnerFolderName:
                    if theApiAppEntl is None and hasApiAppEntl == False:
                        theApiAppEntl = apiAppEntl
                        hasApiAppEntl = True
                    else:
                        logging.error(f"More than one API is configured for same partnerFolderName={partnerName}, latest is {apiAppEntl}")
                        theApiAppEntl = None
                        
        return theApiAppEntl
    
    
    def getPartnerFolderSplitChar(self):
        # From STP we get partner's name from dot-separated name
        return "."
    
    
    def _getPartnerFileType(self, stpFileName):
        # Sample inbound filename from STP: china.CN2KTGFE.iResearchDEV.0.UpdateAndCloseRequest_20200420120000.zip
        # Returns UpdateAndCloseRequest file type
        if isBlank(stpFileName):
            return None
        flnmParts = stpFileName.split(".")
        if len(flnmParts) < 5:
            logging.warning(f"_getPartnerFileType: stpFileName={stpFileName} has less than 5 parts so can't be matched")
            return None
        fileNameMinusPartner = ".".join(flnmParts[4:])
        logging.info(f"_getPartnerFileType: fileNameMinusPartner={fileNameMinusPartner}")
        for pft in PartnerFileType:
            prefix = pft.value["fileNamePrefix"]
            if prefix is not None and fileNameMinusPartner.lower().startswith(prefix.lower()):
                return pft
        return None
    
        
    def recordInboundDetails(self, stpDeliveryFile):
        '''
        insert row into ptnr_fle_tkg
        '''
        if self.fileTrackingDao is None:
            self.fileTrackingDao = FileTrackingDao()
        if self.updateEventDao is None:
            self.updateEventDao = UpdateEventDao()
        stpPartnerDeliveryFile = StpPartnerDeliveryFile(stpDeliveryFile)
        partnerFileType = self._getPartnerFileType(stpPartnerDeliveryFile.stpFileName)
        if partnerFileType is None:
            # should not happen
            partnerFileType = partnerFileType.UNKNOWN_FILE_TYPE
        stpPartnerDeliveryFile.fileTypeCode = partnerFileType.value["fileTypeCode"]
        stpPartnerDeliveryFile.apiApplicationEntitlement = self._getPartnerApiAppEntl(stpPartnerDeliveryFile.stpFileName)
        if stpPartnerDeliveryFile.apiApplicationEntitlement is None:
            errmsg = f"StpPartnerDeliveryPlugin.recordInboundDetails failed to getPartnerApiAppEntl for stpFileName={stpPartnerDeliveryFile.stpFileName}"
            logging.error(errmsg)
            raise LambdaConflictException(errmsg)
        partnerFileTrackingId = self.fileTrackingDao.insertPartnerFileTracking(self.dbConn, stpPartnerDeliveryFile, StpPartnerDeliveryPlugin.MODULE_NAME)
        logging.info(f"StpPartnerDeliveryPlugin.recordInboundDetails: created partnerFileTrackingId={partnerFileTrackingId}")
        stpPartnerDeliveryFile.partnerFileTrackingId = partnerFileTrackingId
        self.updateEventDao.insertEvent(self.dbConn, None, updateEventConstants.AUDIT_PARTNER_FILE_TRACKING_TABLE,
                                        stpPartnerDeliveryFile.partnerFileTrackingId, updateEventConstants.AUDIT_ELEMENT_PARTNER_FILE_TRACKING_ID,
                                        stpPartnerDeliveryFile.stpFileName, stpPartnerDeliveryFile.processStatusCode, UpdateActionCode.ADD.value, None,
                                        None, None, StpPartnerDeliveryPlugin.MODULE_NAME)


    def _loadPartnerApiEntlList(self):
        #if self._partnerApiAppEntlList is not None and len(self._partnerApiAppEntlList) > 0:
        #    return
        if self._apiApplicationEntitlementDao is None:
            self._apiApplicationEntitlementDao = ApiApplicationEntitlementDao()
        allApiAppEntlList = self._apiApplicationEntitlementDao.queryAllApiApplications(self.dbConn)
        self._partnerApiAppEntlList = []
        for apiAppEntl in allApiAppEntlList:
            if isNotBlank(apiAppEntl.partnerFolderName):
                logging.info(f"StpPartnerDeliveryPlugin: Loaded partnerFolderName {apiAppEntl.partnerFolderName} for apiApp {apiAppEntl}")
                self._partnerApiAppEntlList.append(apiAppEntl)
        if len(self._partnerApiAppEntlList) == 0:
            logging.error("StpPartnerDeliveryPlugin: empty partner list!")
            
            
    def postInboundSuccessAction(self, stpDeliveryFile):
        # Put a message on the appropriate queue depending on batch file type
        stpPartnerDeliveryFile = StpPartnerDeliveryFile(stpDeliveryFile)
        partnerFileType = self._getPartnerFileType(stpPartnerDeliveryFile.stpFileName)
        if partnerFileType is None or partnerFileType.value["queueEnvVbl"] is None:
            logging.info("postInboundSuccessAction: No queue configured for file type")
            return
        regionName = self.requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
        sqsUrl = self.requestContext.environDict.get(partnerFileType.value["queueEnvVbl"])
        if self.sqsHelper is None:
            self.sqsHelper = SqsHelper(queueUrl=sqsUrl, regionName=regionName)
        messageBody = { "fileTrackingId": stpPartnerDeliveryFile.fileTrackingId, "source": StpPartnerDeliveryPlugin.MODULE_NAME }
        message = json.dumps(messageBody)
        logging.info(f"postInboundSuccessAction posting message to queue {sqsUrl}: {message}")
        queueResp = self.sqsHelper.sendMessageToQueue(message)
        messageId = queueResp.get('MessageId')
        logging.info(f'postInboundSuccessAction: messageId={messageId} queueResp={queueResp}')
        if messageId is None:
            logging.error("postInboundSuccessAction: Failure posting message to queue")
            raise LambdaProcessingException("postInboundSuccessAction: Failure posting message to queue")
        # TODO consider setting batch status READY_TO_PARSE?
        