'''
Modified on Apr 10, 2020

@author: VanCampK
'''
import logging

from common.util.s3Helper import S3Helper
from common import envVblNames
from common.util.sftpMockHelper import SftpMockHelper
from common.util.sftpHelper import SftpHelper
from determineStartType import determineStartType
from lambdas.lambdaBase import LambdaBase
import lambdas.lambdaConstants as consts
from lambdas.stpdelivery.sftpDeliveryType import SftpDeliveryType
from lambdas.stpdelivery.stpOutboundDeliveryService import StpOutboundDeliveryService
from lambdas.stpdelivery.stpUtil import getSftpDeliveryType


class StpOutboundDeliveryLambda(LambdaBase):
    '''
    Handler class for StpOutboundDelivery and SftpOutboundDelivery and CfpSftpOutboundDelivery service.
     - which one is controlled by the environment variable "SFTPDELIVERYTYPE" (value can be "SFTP_S3" or "STP" or "CFP")
    Handler: lambdas.stpdelivery.stpOutboundDeliveryLambda.handler
    
    Deployment configuration notes:
    This lambda must be created with Python 3.7 for compatibility with the paramiko SFTP library.
    This lambda needs the layer irsch_d1_SFTPLibraries_PY37
    For StpOutboundDelivery, must create S3 event rule to fire this lambda whenever a file is dropped in irsch-*-datastores bucket under the stp-outbound folder.
    For SftpOutboundDelivery, must create S3 event rule to fire this lambda whenever a file is dropped in irsch-*-datastores bucket under the sftp-outbound folder.
    For StpOutboundDelivery, must also set up a Cloudwatch timer rule irsch_*_InvokeStpOutboundDelivery to invoke this lambda every 5 minutes (used for recovery mode only).
    For SftpOutboundDelivery, must also set up a Cloudwatch timer rule irsch_*_InvokeSftpOutboundDelivery to invoke this lambda every 5 minutes (used for recovery mode only).
    Future phase: Disable irsch_*_ProcessUploadedFile from attachment-upload S3 event enable this lambda is enabled for this event (will also want to disable irsch_*_ProcessSTPFailureQueue lambda and queue at same time).
    '''
    MOCK_STP_SERVER = "MOCK-STP"
    MOCK_STP_ROOT_FOLDER = "mock-stp"
    MOCK_STP_OUTBOUND_FOLDER = "outbound"
    MOCK_STP_INBOUND_FOLDER = "inbound"
    MOCK_CFP_SERVER = "MOCK-CFP"
    MOCK_CFP_ROOT_FOLDER = "mock-cfp"
    MOCK_CFP_OUTBOUND_FOLDER = "outbound"
    MOCK_CFP_INBOUND_FOLDER = "inbound-unused"
    
    s3Helper = None
        
    def exitOnTimerEvent(self):
        return False
    
    
    def needsDbConn(self):
        return True
    
    
    def handleRequest(self):
        LambdaBase.raiseAlertWhenRequestFails = True
        startType = determineStartType(self.requestContext.event)
        logging.info(f"StpOutboundDeliveryLambda: startType={startType} event={self.requestContext.event}")
        service = None
        try:
            if startType == consts.LAMBDA_START_TYPE_S3:
                # S3 event mode
                s3list = StpOutboundDeliveryLambda.s3Helper.parseS3ObjectsFromEvent(self.requestContext.event)
                if s3list is not None and len(s3list) > 0:
                    service = self._createService()
                    #self._connectSftp(service.sftpHelper)
                    for s3Object in s3list:
                        service.processOutboundFile(self.requestContext, s3Object)
                    service.closeConnection()
            elif startType == consts.LAMBDA_START_TYPE_TIMER:
                service = self._createService()
                stpDeliveryFiles = service.findFilesToRecover(self.requestContext)
                if len(stpDeliveryFiles) > 0:
                    #self._connectSftp(service.sftpHelper)
                    service.processRecoveryFiles(self.requestContext, stpDeliveryFiles)
                    service.closeConnection()
        except Exception as e:
            logging.error(f"StpOutboundDeliveryLambda: Uncaught exception {e}, closing STP connections...")
            if service is not None:
                service.closeConnection()
            raise


    def _createService(self):
        sftpServer = self.requestContext.environDict.get(envVblNames.ENV_STP_SERVER)
        sftpUserId = self.requestContext.environDict.get(envVblNames.ENV_STP_USERID)
        sftpPassword = self.requestContext.environDict.get(envVblNames.ENV_STP_PASSWORD)
        cfpSftpServer = self.requestContext.environDict.get(envVblNames.ENV_CFP_SFTP_SERVER)
        cfpSftpUserId = self.requestContext.environDict.get(envVblNames.ENV_CFP_SFTP_USERID)
        cfpSftpPassword = self.requestContext.environDict.get(envVblNames.ENV_CFP_SFTP_PASSWORD)
        cfpSftpDirectory = self.requestContext.environDict.get(envVblNames.ENV_CFP_SFTP_DIRECTORY)
        datastoresBucket = self.requestContext.environDict.get(envVblNames.ENV_DATASTORES_BUCKET)
        sftpHelper = None
        if sftpServer == StpOutboundDeliveryLambda.MOCK_STP_SERVER:
            sftpHelper = SftpMockHelper(datastoresBucket, StpOutboundDeliveryLambda.MOCK_STP_ROOT_FOLDER,
                                             StpOutboundDeliveryLambda.MOCK_STP_OUTBOUND_FOLDER,
                                             StpOutboundDeliveryLambda.MOCK_STP_INBOUND_FOLDER)
        elif cfpSftpServer == StpOutboundDeliveryLambda.MOCK_CFP_SERVER:
            sftpHelper = SftpMockHelper(datastoresBucket, StpOutboundDeliveryLambda.MOCK_CFP_ROOT_FOLDER,
                                             StpOutboundDeliveryLambda.MOCK_CFP_OUTBOUND_FOLDER,
                                             StpOutboundDeliveryLambda.MOCK_CFP_INBOUND_FOLDER)
        else:
            sftpDeliveryType = getSftpDeliveryType(self.requestContext)
            if sftpDeliveryType == SftpDeliveryType.STP.value:
                # STP mode
                sftpHelper = SftpHelper(sftpServer, sftpUserId, sftpPassword)
            elif sftpDeliveryType == SftpDeliveryType.CFP.value:
                # CFP mode
                sftpHelper = SftpHelper(cfpSftpServer, cfpSftpUserId, cfpSftpPassword)
            else:
                # SFTP_S3 mode
                #sftpHelper = SftpMockHelper(datastoresBucket, SFTP_USERS_INBOUND_FOLDER, "", "")
                sftpHelper = SftpMockHelper(datastoresBucket, "", "", "")
            
        service = StpOutboundDeliveryService(StpOutboundDeliveryLambda.s3Helper, StpOutboundDeliveryLambda.dbConn, StpOutboundDeliveryLambda.environDict, StpOutboundDeliveryLambda.alert, sftpHelper, self.getModuleName())
        return service
    
    
    def _connectSftp(self, sftpHelper):
        try:
            logging.info("Trying to connect to STP...")
            sftpHelper.connect()
            logging.info("Successfully connected to STP")
        except Exception as e:
            logging.error(f"StpInboundDeliveryLambda: Caught exception {e}, closing STP connections and exiting...")
            sftpHelper.quit()
            raise
    

    def initializeKeepWarm(self):
        if StpOutboundDeliveryLambda.s3Helper is None:
            StpOutboundDeliveryLambda.s3Helper = S3Helper()
        
        
    def getModuleName(self):
        sftpDeliveryType = getSftpDeliveryType(self.requestContext)
        if sftpDeliveryType == SftpDeliveryType.STP.value:
            return "StpOutboundDeliveryLambda"
        elif sftpDeliveryType == SftpDeliveryType.CFP.value:
            return "CfpSftpOutboundDeliveryLambda"
        else:
            return "SftpOutboundDeliveryLambda"
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = StpOutboundDeliveryLambda.get_handler(...)