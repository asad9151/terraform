'''
Created on Aug 14, 2020
Common utility functions for StpDelivery services

@author: VanCampK
'''
from common import envVblNames

from lambdas.stpdelivery.sftpDeliveryType import SftpDeliveryType
from lambdas.stpdelivery.stpDeliveryIndicator import StpDeliveryIndicator


SFTP_USERS_INBOUND_FOLDER = "sftp-users"


def getSftpDeliveryType(requestContext):
    sftpDeliveryTypeEnv = requestContext.environDict.get(envVblNames.ENV_SFTP_DELIVERY_TYPE)
    if sftpDeliveryTypeEnv == SftpDeliveryType.SFTP_S3.value:
        return SftpDeliveryType.SFTP_S3.value
    elif sftpDeliveryTypeEnv == SftpDeliveryType.CFP.value:
        return SftpDeliveryType.CFP.value
    else:
        # default to STP for backward compatibility with existing lambdas
        return SftpDeliveryType.STP.value


def getStpDeliveryIndicator(requestContext):
    '''
    Maps the internal enum delivery type to the numeric code stored in fle_tkg.stp_dlvr_ind
    '''
    sftpDeliveryType = getSftpDeliveryType(requestContext)
    if sftpDeliveryType == SftpDeliveryType.SFTP_S3.value:
        return StpDeliveryIndicator.SFTP_S3.value
    elif sftpDeliveryType == SftpDeliveryType.CFP.value:
        return StpDeliveryIndicator.CFP.value
    else:
        # default to STP
        return StpDeliveryIndicator.STP.value
    