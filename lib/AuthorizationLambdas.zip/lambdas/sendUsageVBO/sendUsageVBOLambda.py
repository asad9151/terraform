'''
Created on Nov 25, 2019

@author: JafferS
'''
from lambdas.lambdaBase import LambdaBase
from lambdas.sendUsageVBO.sendUsageVBOService import SendUsageVBOService
from common import envVblNames
import logging
from common.util.sqsHelper import SqsHelper

class SendUsageVBOLambda(LambdaBase):
    sqsHelper = None
    lambdaClient = None
    service = None
    s3Client = None
        
    def exitOnTimerEvent(self):
        logging.debug("*********exitTimerEvent**********")
        return False
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return False
    
    def handleRequest(self):
        logging.debug("*******handleRequest******")
        LambdaBase.raiseAlertWhenRequestFails = True
        if self.service is None:
            self.service = SendUsageVBOService(SendUsageVBOLambda.sqsHelper,  self.requestContext)
        logging.info("in SendUsageVBOLambda, handle request")
        self.service.sendUsageToVBO()
       
        
    def initializeKeepWarm(self):
        logging.debug("*******initializeKeepWarm******")
        if SendUsageVBOLambda.sqsHelper is None:
            try:
                if SendUsageVBOLambda.environDict.get(envVblNames.ENV_DIRECT_PLUS_USAGE_VBO_QUEUE_URL) is not None:
                    regionName = SendUsageVBOLambda.environDict.get(envVblNames.ENV_SQS_REGION)
                    SendUsageVBOLambda.sqsHelper = SqsHelper(queueUrl=SendUsageVBOLambda.environDict.get(envVblNames.ENV_DIRECT_PLUS_USAGE_VBO_QUEUE_URL), regionName=regionName)
            except:
                raise RuntimeError("SQS not configured")
                

#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SendUsageVBOLambda.get_handler(...)