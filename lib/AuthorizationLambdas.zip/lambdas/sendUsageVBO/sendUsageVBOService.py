import logging
import json
import requests
import math
from common.externalStatusCode import ExternalStatusCode
from common.subTypeGroups import SubTypeGroups
from decimal import Decimal
from common import envVblNames
from common.util.dateUtils import isoFormatToDateTime
from requests.exceptions import RequestException

EXIT_WHEN_MILLISECS_LEFT = 10000

class SendUsageVBOService(object):
    sqsHelper = None
    requestContext = None
    idaasToken = None
    vboUrl  = None
    timeoutSecs = None
    idaasAPIUrl = None
    idaasClientId = None
    idaasClientSecret = None
    
    
    def __init__(self, sqsHelper, requestContext):
        self.sqsHelper = sqsHelper
        self.requestContext = requestContext
        if self.vboUrl is None:
            self.vboUrl = self.requestContext.environDict[envVblNames.ENV_VBO_URL]
        if self.timeoutSecs is None:
            self.timeoutSecs = Decimal(self.requestContext.environDict[envVblNames.ENV_VBO_TIMEOUTSECS])
        if self.idaasAPIUrl is None:
            self.idaasAPIUrl = self.requestContext.environDict[envVblNames.ENV_IDAAS_API_URL]
        if self.idaasClientId is None:
            self.idaasClientId = self.requestContext.environDict[envVblNames.ENV_IDAAS_CLIENT_ID]
        if self.idaasClientSecret is None:
            self.idaasClientSecret = self.requestContext.environDict[envVblNames.ENV_IDAAS_CLIENT_SECRET]
            
        
    def sendUsageToVBO(self):
        logging.info("in SendUsageVBOService, sendUsageToVBO")
        timeLeft = self.requestContext.lambdaContext.get_remaining_time_in_millis()
        logging.info("Time left %s" % timeLeft)
        lastException = None
        while(True and timeLeft > EXIT_WHEN_MILLISECS_LEFT):
            message = self.sqsHelper.getOneMessageFromQueue()
            receipt_handle = None
            if message is not None:
                try:
                    if 'MessageId' in message:
                        logging.info('messageId is: %s ' % message['MessageId'])
                    if 'ReceiptHandle' in message and 'Body' in message:
                        receipt_handle = message['ReceiptHandle']
                        logging.info('current receipt handle is %s' %  receipt_handle)
                        messageBody = json.loads(message['Body'])
                        logging.info ('bodyDict = %s' % messageBody)
                        # messageBody is the SNS Message. Usage record is contained inside 'Message'
                        if 'Message' in messageBody:
                            usageRecord = json.loads(messageBody['Message'])
                            if self.shouldSendRec(usageRecord):
                                vboRec = self.generateVBORec(usageRecord)
                                self.sendRecToVBO(vboRec)
                        logging.info('Deleting msg with handle %s' % receipt_handle)
                        self.sqsHelper.deleteOneMessageFromQueue(receipt_handle)
                except Exception as err:
                    if isinstance(err, RequestException):
                        logging.error('Request Exception while trying to send usage record to VBO. Error = %s' % err)
                    else:
                        logging.error('Error sending usage record to VBO. Error = %s' % err)
                        if receipt_handle is not None:
                            logging.info('Deleting msg with handle %s' % receipt_handle)
                            self.sqsHelper.deleteOneMessageFromQueue(receipt_handle)
                    lastException = err
            else:
                break
            timeLeft = self.requestContext.lambdaContext.get_remaining_time_in_millis()
            logging.info("Time left %s" % timeLeft)
        if lastException is not None:
            raise lastException
            
    def shouldSendRec(self, usageRecord):
        if (usageRecord['request']['previousResearchStatusCode'] == ExternalStatusCode.CHALLENGED.value):
            logging.info('Previous status is challenged')
            return False
        if ('requestor' in usageRecord):
            requestor = usageRecord['requestor']
            if ('researchSubTypesGroups' in requestor):
                subTypeGroups = requestor['researchSubTypesGroups']
                if (len(subTypeGroups) > 0 and len(subTypeGroups) == 1):
                    for group in subTypeGroups: 
                        if group['researchSubTypesGroupCode'] == SubTypeGroups.MINI_SUBMITTER.value:
                            logging.info('Only one subtype group and subtype group is mini')
                            return False
        return True
            


    def sendRecToVBO(self, vboRec):
        if self.idaasToken is None:
            self.idaasToken = self.getIDaaSToken()
        vboRecJson = json.dumps(vboRec)
        logging.info('VBO json %s' % vboRecJson)
        headers = {}
        headers['Content-type'] = 'application/json'
        headers['Authorization'] = 'bearer ' + self.idaasToken
        logging.info(headers['Authorization'])
        logging.info('url: %s ' % self.vboUrl)
        
        logging.info('Before request')
        response = requests.post(url = self.vboUrl, data = vboRecJson, headers = headers, auth=False, timeout=self.timeoutSecs, verify=False)
        logging.info('After request')
        
        logging.info(response.status_code)
        if response.status_code == 401:
            #Token expired. Trying again
            self.idaasToken = self.getIDaaSToken()
            headers['Authorization'] = 'bearer ' + self.idaasToken
            logging.info(headers['Authorization'])
            
            logging.info('SendUsageVBO: Before posting record.')
            response = requests.post(url = self.vboUrl, data = vboRecJson, headers = headers, auth=False, timeout=self.timeoutSecs, verify=False)
            logging.info('SendUsageVBO: After posting record.')
            
            logging.info(response.status_code)
            if response.status_code == 401:
                logging.info("Error message in response is %s:" % response.text)
                raise RequestException('Got back status code %s while trying to get token from IDaaS for the second time. ResearchRequestId is %s' % (response.status_code, vboRec['POAEID']))
        elif response.status_code == 406 or response.status_code == 400:
            logging.info("Error message in response is %s:" % response.text)
            raise Exception('Got back status code %s while trying to send record to VBO. ResearchRequestId is %s' % (response.status_code, vboRec['POAEID']))
        elif response.status_code not in [200, 201, 202, 203, 204, 205, 206]:
            logging.info("Error message in response is %s:" % response.text)
            raise RequestException('Got back status code %s while trying to send record to VBO. ResearchRequestId is %s' % (response.status_code, vboRec['POAEID']))

    def getIDaaSToken(self):
        headers = {}
        headers['Content-type'] = 'application/json'
        headers['Accept'] = 'application/json'
        headers['Authorization'] = 'client_id:' + self.idaasClientId + ',client_secret:' + self.idaasClientSecret
        logging.info("token header is " +  headers['Authorization'] )
        payload = {"grant_type":"client_credentials"}
        logging.info('IDaaS API URL is %s ' %  self.idaasAPIUrl)
        
        logging.info('SendUsageVBO: Before requesting IDaaS token.')
        response = requests.post(self.idaasAPIUrl,data=json.dumps(payload),headers=headers, auth=False, timeout=self.timeoutSecs)
        logging.info('SendUsageVBO: After requesting IDaaS token')
                
        print(response.status_code)
        if response.status_code not in [200, 201, 202, 203, 204, 205, 206]:
            logging.info("Error message in response is %s:" % response.text)
            raise RequestException('Got back status code %s while trying to get token from IDaaS.' % response.status_code)
        else:
            print(response.json())
            if 'access_token' in response.json():
                return response.json().get('access_token')
            else:
                logging.info("Error message in response is %s:" % response.text)
                raise RequestException('No access token returned for status %s while trying to get token from IDaaS.' % response.status_code)
        
    def generateVBORec(self, usageRecord):
        rec = {}
        rec['appID'] = '46'
        rec['capID'] = '126'
        rec['eventType'] = 'INVESTIGATIONS'
        rec['eventID'] = 'INVESTIGATIONS'
        rec['portfolioSize'] = 1
        rec['subjectDunsEntityId'] = self.getSubjectDunsEntityId(usageRecord)
        rec['featureURI'] = self.getFeatureURI(usageRecord)
        duration = self.getInvestigationDuration(usageRecord)
        rec['investigationDuration'] = str(duration)
        rec['responseTime'] = duration
        if ('usage' in usageRecord):
            usage = usageRecord['usage']
            if ('investigationCompletionTypeCode' in usage):
                rec['investigationCompleteCode'] = str(usage['investigationCompletionTypeCode'])
        if ('request' in usageRecord):
            request = usageRecord['request']
            if ('researchRequestId' in request):
                rec['POAEID'] = str(request['researchRequestId'])
            if ('customerReferenceEmail' in request):
                rec['emailAddress'] = request['customerReferenceEmail']
            else:
                rec['emailAddress'] = ''
            if ('userAPIKeyType' in request):
                rec['apiKeyType'] = request['userAPIKeyType']
            if ('subscriberDRT' in request):
                rec['drt'] = request['subscriberDRT']
            if ('sessionGuid' in request):
                rec['GUID'] = request['sessionGuid']
            if ('orderReasonCode' in request):
                rec['reasonCode'] = str(request['orderReasonCode'])
            if ('researchCreationTimestamp' in request):
                rec['investigationPlacementDate'] = request['researchCreationTimestamp']
            if ('researchCompletionTimestamp' in request):
                rec['timeStamp'] = request['researchCompletionTimestamp']
        if ('requestor' in usageRecord):
            requestor = usageRecord['requestor']
            if ('loginKey' in requestor):
                rec['apiKey'] = requestor['loginKey']
            if ('subscriberNumber' in requestor):
                rec['subscriberID'] = str(requestor['subscriberNumber'])
            if ('name' in requestor):
                rec['subscriberName'] = requestor['name']
            if ('iso2AlphaCountryCode' in requestor):
                rec['subscriberCountry'] = requestor['iso2AlphaCountryCode']
            if ('requestorOwnRequestKey' in requestor):
                rec['customerReference'] = requestor['requestorOwnRequestKey']
        if ('subject' in usageRecord):
            subject = usageRecord['subject']
            if ('inquiredDuns' in subject):
                rec['enquiredDuns'] = subject['inquiredDuns']
            if ('organizationName' in subject):
                rec['subjectName'] = subject['organizationName']
            if ('iso2AlphaCountryCode' in subject):
                rec['subjectCountry'] = subject['iso2AlphaCountryCode']
            if ('territory' in subject):
                rec['subjectState'] = subject['territory']
            if ('town' in subject):
                rec['subjectCity'] = subject['town']
        print (rec)
        return rec

    def getSubjectDunsEntityId(self, usageRecord):
        isUTL = False
        subjectDunsEntityId = ''
        if ('usage' in usageRecord):
            usage = usageRecord['usage']
            if ('investigationBillingProductCode' in usage):
                billingProductCode = usage['investigationBillingProductCode']
                if billingProductCode == 14863:
                    isUTL = True
        if isUTL == False:
            if ('subject' in usageRecord):
                subject = usageRecord['subject']
                if ('answeredDuns' in subject):
                    subjectDunsEntityId = subject['answeredDuns']
        return subjectDunsEntityId
            
    def getFeatureURI(self, usageRecord):
        featureURI = ''
        priority = ''
        
        if ('request' in usageRecord):
            request = usageRecord['request'] 
            if 'researchRequestType' in request:
                researchRequestType = request['researchRequestType']
            else:
                researchRequestType = ''
            featureURI = featureURI + researchRequestType + ','
            if 'cases' in request:
                cases = request['cases']
                for case in cases:
                    if ('researchTypes' in case):
                        researchTypes = case['researchTypes']
                        for researchType in researchTypes:
                            typeCode = ''
                            subtypeCode = ''
                            if 'researchTypeCode' in researchType:
                                typeCode = researchType['researchTypeCode']
                            if 'researchSubTypeCode' in researchType:
                                subtypeCode = researchType['researchSubTypeCode']
                            featureURI = featureURI + str(typeCode) + '/' + str(subtypeCode) + ','
        
        if ('usage' in usageRecord):
            usage = usageRecord['usage']
            if ('investigationPriorityTypeCode' in usage):
                priority = usage['investigationPriorityTypeCode']
                            
        featureURI = featureURI + str(priority)
                                
        return featureURI   
    
    def getInvestigationDuration(self, usageRecord):
        submittedDateTime = None
        completedDateTime = None
        durationInDays = 0
        if ('request' in usageRecord):
            request = usageRecord['request']
            if ('researchCreationTimestamp' in request):
                submittedDateTime = isoFormatToDateTime(request['researchCreationTimestamp'])
            if ('researchCompletionTimestamp' in request):
                completedDateTime = isoFormatToDateTime(request['researchCompletionTimestamp'])
        if submittedDateTime is not None and completedDateTime is not None:
            duration = completedDateTime - submittedDateTime
            if (duration.seconds > 0):
                durationInDays = math.ceil((duration.seconds/86400))
        return durationInDays
    