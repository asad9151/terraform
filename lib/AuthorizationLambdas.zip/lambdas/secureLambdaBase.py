'''
Created on Mar 11, 2019

@author: VanCampK
'''
import boto3
import json
import logging
import traceback
import sys
from common.dao.researchUserDao import ResearchUserDao
from common.envVblNames import ENV_SESSION_INACTIVE_MINUTES, ENV_DISABLE_SESSION_CHECK, ENV_GET_TEAMLIST_FROM_IDAAS, getEnvironAsBool, ENV_AUTH_TYPE, ENV_LAMBDA_REGION, ENV_VALIDATE_RESPONSE_SCHEMA
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.awsUtils import createClientConfiguration
from common.util.ValidateUtil import ValidateUtil
import lambdas.errorMessages as errmsg
from lambdas.authTypes import AuthType
from lambdas.lambdaBase import LambdaBase
from lambdas.lambdaCommon import logResponse
import lambdas.lambdaConstants as consts
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaProcessingException, LambdaAuthenticationException
from lambdas.loginSessionDao import LoginSessionDao
from lambdas.requestRejection import RequestRejection
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.util.cloudServicesHelper import CloudServicesHelper


class SecureLambdaBase(LambdaBase):
    '''
    Abstract base class for any python lambda that uses API-GW and needs to be secured
    '''
    loginSessionDao = None
    researchUserDao = None
    lambdaClient = None
    responseValidateUtil = None
    cloudServicesHelper = None
    
    def handleRequest(self):
        
        try:
            if not SecureLambdaBase.loginSessionDao:
                SecureLambdaBase.loginSessionDao = LoginSessionDao()
            if not SecureLambdaBase.researchUserDao:
                SecureLambdaBase.researchUserDao = ResearchUserDao()
            if not SecureLambdaBase.lambdaClient and SecureLambdaBase.environDict.get(ENV_LAMBDA_REGION) is not None:
                SecureLambdaBase.lambdaClient = boto3.client('lambda', region_name=SecureLambdaBase.environDict[ENV_LAMBDA_REGION], config=createClientConfiguration(SecureLambdaBase.environDict))
                
            # Check that session is active, and update it if it is
            self.checkActiveSession()
            
            getTeamListFromIDAAS = getEnvironAsBool(SecureLambdaBase.environDict.get(ENV_GET_TEAMLIST_FROM_IDAAS))
            if getTeamListFromIDAAS is False:
                logging.info('SecureLambdaBase is using team list from database')
                self.updateSessionWithTeamLists()
            else:
                logging.info('SecureLambdaBase is using team list from iDAAS')
                
        except Exception as e:
            return self._buildExceptionResponse('checkActiveSession', e)
        
        try:
            # Delegate authorization to subclass
            self.authorizeRequest()
        except Exception as e:
            return self._buildExceptionResponse('checkActiveSession', e)
        
        # Delegate handling to subclass
        responseBody = None
        try:
            responseBody = self.handleSecureRequest()
            self._validateResponse(responseBody['body'])
            logResponse(self.requestContext, responseBody['body'])
        except Exception as e:
            return self._buildExceptionResponse('handleSecureRequest', e)

        return responseBody


    def authorizeRequest(self):
        '''
        Override this in subclass
        '''
        raise NotImplementedError


    def handleSecureRequest(self):
        '''
        Override this in subclass
        '''
        raise NotImplementedError
    
    
    def needsDbConn(self):
        '''
        Override this in subclass if database connection not needed
        '''
        return True
        
        
    def getResponseSchema(self):
        '''
        Subclass can override this if response schema validation is needed.
        Response schema will be validated only if environment variable ENV_VALIDATE_RESPONSE_SCHEMA ("VALIDATERESPONSESCHEMA") is set to true, and this function returns non-None value.
        '''
        return None
    

    def checkActiveSession(self):
        sessionInactiveMinutes = int(SecureLambdaBase.environDict[ENV_SESSION_INACTIVE_MINUTES])
        authType = SecureLambdaBase.environDict.get(ENV_AUTH_TYPE)
        if authType == AuthType.AUTH_TYPE_CloudServices.value:
            if SecureLambdaBase.cloudServicesHelper is None:
                SecureLambdaBase.cloudServicesHelper = CloudServicesHelper()
            loginSession = SecureLambdaBase.cloudServicesHelper.checkCloudServicesSession(self.requestContext, SecureLambdaBase.environDict, SecureLambdaBase.lambdaClient, SecureLambdaBase.dbConn, SecureLambdaBase.loginSessionDao)
        else:
            logging.info(f'Checking for session with loginKey={self.requestContext.userSession.loginKey} sessionToken={self.requestContext.userSession.sessionToken}')
            loginSession = SecureLambdaBase.loginSessionDao.queryLoginSession(SecureLambdaBase.dbConn, self.requestContext.userSession)
            
        if not loginSession:
            #userSession.loginKey, userSession.sessionToken
            logging.error(f'No session found with loginKey={self.requestContext.userSession.loginKey} sessionToken={self.requestContext.userSession.sessionToken}: authType={authType}')
            raise LambdaAuthenticationException(errmsg.ERR_NOT_AUTHORIZED)
        if not loginSession.get('lgin_ses_id'):
            logging.error('Session not found in database!')
            raise LambdaAuthenticationException(errmsg.ERR_NOT_AUTHORIZED)
            
        logging.info('SecureLambdaBase login session info: lgin_ses_id=' + str(loginSession['lgin_ses_id']) + ' rsch_usr_id=' + 
                     str(loginSession['rsch_usr_id']) + ' dnb_jti_val=' + loginSession['dnb_jti_val'] + ' usr_typ_desc=' +
                     loginSession['usr_typ_desc'] + ' expn_tmst=' + str(loginSession['expn_tmst']) + ' strt_tmst=' +
                     loginSession['strt_tmst'] + ' lst_acs_tmst=' + str(loginSession['lst_acs_tmst']) + ' lg_out_tmst=' +
                     str(loginSession['lg_out_tmst']) + ' LastAccessMins=' + str(loginSession['LastAccessMins']) +
                     ' isExpired=' + str(loginSession['isExpired']) + ' NOW()=' + str(loginSession['NOW()']) +
                     ' sessionInactiveMinutes=' + str(sessionInactiveMinutes))
        # Set the userId into the session (needed until it comes from principalId)
        self.requestContext.userSession.userId = str(loginSession['rsch_usr_id'])
        
        SecureLambdaBase.loginSessionDao.updateActiveLoginSession(SecureLambdaBase.dbConn, self.requestContext.userSession, sessionInactiveMinutes)
        disableSessionCheck = SecureLambdaBase.environDict.get(ENV_DISABLE_SESSION_CHECK) # Any value but false will disable it
        if (loginSession['lg_out_tmst']) or loginSession['LastAccessMins'] > sessionInactiveMinutes or loginSession['isExpired'] == 1:
            logging.error('SESSION_IS_INACTIVE for loginKey=' + str(self.requestContext.userSession.loginKey) + ' token="' + 
                          str(self.requestContext.userSession.sessionToken) + '" is invalid' )
            requestSource = self.requestContext.source
            if requestSource and requestSource == consts.LAMBDA_START_TYPE_SECURE_INVOKE:
                logging.info('(Secure invoke so inactive session ok)')
            elif disableSessionCheck != 'false':
                logging.info('(Session check disabled so continuing anyway)')
            else:
                raise LambdaAuthenticationException(errmsg.ERR_NOT_AUTHORIZED)

        loginSession2 = SecureLambdaBase.loginSessionDao.queryLoginSession(SecureLambdaBase.dbConn, self.requestContext.userSession)
        if loginSession['lst_acs_tmst'] == loginSession2['lst_acs_tmst']:
            logging.warning('SecureLambdaBase lst_acs_tmst unchanged after update - apparent bug in pymysql?')
            
            
    def updateSessionWithTeamLists(self):
        researchTeamsList = SecureLambdaBase.researchUserDao.getUserTeams(SecureLambdaBase.dbConn, self.requestContext.userSession.userId, 0)
        logging.debug('Overwriting researchTeamsList from database with ' + str(researchTeamsList))
        self.requestContext.userSession.teams = researchTeamsList
        localAdminTeamsList = SecureLambdaBase.researchUserDao.getUserTeams(SecureLambdaBase.dbConn, self.requestContext.userSession.userId, 1)
        logging.debug('Overwriting localAdminTeamsList from database with ' + str(localAdminTeamsList))
        self.requestContext.userSession.localAdminTeams = localAdminTeamsList


    def _buildExceptionResponse(self, src, e):
        '''
        Builds a json formatted response with rejection errors if supplied with the Exception
        '''
        statusCode = LambdaStatusCodes.INTERNAL_SERVER_ERROR.value
        errorMessage = errmsg.ERR_INTERNAL_REQUEST
        requestRejection = None
        if isinstance(e, LambdaProcessingException):
            statusCode = e.statusCode.value
            errorMessage = e.errmsg
            requestRejection = e.requestRejection
        else:
            errorMessage = errmsg.ERR_INTERNAL_REQUEST
            
        if requestRejection is None:
            requestRejection = RequestRejection(RejectionReasonCode.INTERNAL_ERROR, rejectionErrorMessage=errorMessage)
            
        if requestRejection.rejectionErrors is None:
            requestRejection.rejectionErrors = []
        if len(requestRejection.rejectionErrors) == 0:
            requestRejection.rejectionErrors.append(RequestRejectionError(errorDescription=errorMessage))
            
        logging.error('error from %s. status=%d, errorMessage=%s requestRejection=%s origException=%s', src, statusCode, errorMessage, str(requestRejection), str(e))
        traceback.print_tb(sys.exc_info()[2])
        if LambdaBase.raiseAlertWhenRequestFails:
            #TODO consider how to get key on request, e.g. caseId/etc.
            LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=errorMessage)
        if requestRejection is None:
            body = errorMessage
        else:
            body = json.dumps(requestRejection.toDict())
        self._validateResponse(body)
        logResponse(self.requestContext, body)
        return self.buildErrorResponse(statusCode, body)
    
    
    def _validateResponse(self, responseBody):
        isValidateResponse = getEnvironAsBool(LambdaBase.environDict.get(ENV_VALIDATE_RESPONSE_SCHEMA))
        if isValidateResponse and self.getResponseSchema() is not None:
            try:
                if SecureLambdaBase.responseValidateUtil is None:
                    SecureLambdaBase.responseValidateUtil = ValidateUtil(self.getResponseSchema())
                responseBodyDict = json.loads(responseBody)
                errors = sorted(SecureLambdaBase.responseValidateUtil.theValidator.iter_errors(responseBodyDict), key=lambda e: e.path)
                if len(errors) == 0:
                    return
                errorSummary = f"{errmsg.ERR_INVALID_RESPONSE} {self.getResponseSchema()}"
                errorMessage = "IRSCHVALIDATERESPONSE ERROR: "
                for error in errors:
                    if error.absolute_path:
                        jsonPath = ''
                        for ele in error.absolute_path:
                            if type(ele) is int:
                                jsonPath = jsonPath.strip(".") + "[" + str(ele) + "]."
                            else:
                                jsonPath += ele + "."
                        jsonPath = jsonPath.strip(".")
                    else:
                        jsonPath = ""
                    errorMessage += jsonPath + ": " + error.message
                LambdaBase.alert.raiseAlert(self.getModuleName(), errorSummary, detailedErrMsg=errorMessage)
            except Exception as e:
                logging.error(f"Failed validating response against schema {self.getResponseSchema()}: {e} - body={responseBody}")
            