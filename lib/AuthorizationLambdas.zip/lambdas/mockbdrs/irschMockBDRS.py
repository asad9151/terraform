import logging
import json
import traceback
import sys
import boto3
import time
from SetLambdaLogging import setLogging
from buildEnvironVarDict import buildEnvironVarDict
from common.util.awsUtils import createClientConfiguration
import lambdas.mockbdrs.controlDuns as controlDuns

OLD_CONTENT_ONLY = 99999
CONTENT_ONLY = 33932
ADDITIONAL_AGENT_PROCESSING_NEEDED = 33934
AUTONOMOUS_ANSWER = 33933
NO_AGENT_INVOLVEMENT = 35372
HTML_TEMPLATE = './lambdas/mockbdrs/BDRS_Doc_Template.html'

organizationPhones = {"isdCode": "1", "telephone": "9999991234"}

addresses = {"town": "Bethlehem",
             "territory": "PA",
             "postalCode": "18014",
             "streetAddress": "123 Main St."}

fabList = [{"researchType": {"type":33523, "subtype": 33549},"function": "addressFunc"},
           {"researchType": {"type":33523, "subtype": 33555}, "function": "phoneFunc"},
           ]

sqsHandle = None
s3Handle = None
environDict = {}

def processDunsResponse(duns,responseType,ticketId,responseDetail):
    global environDict
    sqsMessage = {
            "bulkId" : "11210",
            "tickets" : [
                {
                "ticketId" : "",
                "url" : "",
                "resultCode" : 0,
                "errCode" : "",
                "errMsg" : ""
                }
                ]
            }
    try:
        environDict['s3Handle'].Object(environDict['BDRSSENDS3'], '{}.html'.format(ticketId)).put(Body=open(HTML_TEMPLATE, 'rb'))
    except Exception as e:
        logging.error('processDunsResponse: error writing to S3.  Error = %s',e)
        raise

    sqsMessage['tickets'][0]['ticketId'] = ticketId
    sqsMessage['tickets'][0]['url'] = "http://{}.s3.amazonaws.com/{}.html".format(environDict['BDRSSENDS3'],ticketId)
    sqsMessage['tickets'][0]['resultCode'] = responseType

    if responseDetail != None:
        sqsMessage['tickets'][0]['details'] = responseDetail

    try:
        sqsQueue = environDict['sqsHandle'].get_queue_by_name(QueueName= environDict['BDRSSENDSQS'])
        queueMessage = json.dumps(sqsMessage)
        logging.info('processDunsResponse: message being sent to the queue = %s', queueMessage)
        queueResponse = sqsQueue.send_message(MessageBody= queueMessage)
    except Exception as e:
        logging.error('Error writing message to the SQS queue.  error msg = %s', e)
        raise
    logging.info('processDunsResponse: Queue write successful.  Message ID = %s',queueResponse.get('MessageId'))
    return

def processAutonomousTicket(ticket, dunsNumber, responseType):
    details = {}
    researchResults = {}
    researchTypes = []

    if len(controlDuns.duns[dunsNumber]["researchTypes"]) < len(ticket['submitted']['researchTypes']):
        try:
            logging.info('processDunsResponse: too many research types provided for AUTONOMOUS ANSWER - will be processed as CONTENT_ONLY')
            processDunsResponse(dunsNumber,CONTENT_ONLY,ticket['ticketId'],None)
        except Exception as e:
            logging.error ('processDunsResponse: Error handling an autonomous answer.  error = %s', e)
            raise
        return
    commonTypes = []
    for x in controlDuns.duns[dunsNumber]["researchTypes"]:
        if x in ticket['submitted']['researchTypes']:
            commonTypes.append(x)
    logging.info('processDunsResponse: autonomous types and sub-types being processed = %s', commonTypes)
    
    if len(commonTypes) == 0 or len(commonTypes) < len(ticket['submitted']['researchTypes']):
        try:
            logging.info('processDunsResponse: No autonomous processing opportunities found #1 - processing as CONTENT_ONLY')
            processDunsResponse(dunsNumber,CONTENT_ONLY,ticket['ticketId'],None)
        except Exception as e:
            logging.error ('processDunsResponse: problem handling an autonomous answer.  error = %s', e)
            raise
        return

    #process the autonomous answers for this DunsNumber'
    for d in fabList:
        if d['researchType'] not in commonTypes:
            continue
        func = globals()[d["function"]]
        results = func()
        logging.info ('processDunsResponse: results from type function = %s',results)
        if results != None:
            for k, v in results.items():
                researchResults[k] = v
            resolution = {}
            resolution['researchTypeCode'] = d['researchType']['type']
            resolution['researchSubTypeCode'] = d['researchType']['subtype']
            resolution["resolutionCode"] = 33726
            resolution["subResolutionCode"] = 33731
            researchTypes.append(resolution)
      
    if researchResults:
        # do something with the resolution dictionary
        details['researchResult'] = researchResults
        details['researchTypes'] = researchTypes
        logging.info('processDunsResponse: details before going to processDunsResponse = %s', details)
        logging.info('processDunsResponse: Autonomous processing opportunities found - processing as AUTONOMOUS ANSWER')
        processDunsResponse(dunsNumber,responseType,ticket['ticketId'],details)
    else:
        logging.info('processDunsResponse: details before going to processDunsResponse = %s', details)
        logging.info('processDunsResponse: No autonomous processing opportunities found #2 - processing as CONTENT_ONLY')
        processDunsResponse(dunsNumber,CONTENT_ONLY,ticket['ticketId'],None)
        
def processAdditionalAgentProcessingNeeded(ticket, dunsNumber):
    details = {}
    details['researchComment'] = 'Comment from BDRS to researcher.'

    processDunsResponse(dunsNumber,ADDITIONAL_AGENT_PROCESSING_NEEDED,ticket['ticketId'],details)


def addressFunc():
    addrDict = {}
    addrDict['address'] = []
    addrDict['address'].append(addresses)
    addrDict['countryCode'] = 'US'
    return addrDict

def phoneFunc():
    phoneDict = {}
    phoneList = []
    phoneList.append(organizationPhones)
    phoneDict['organizationPhones'] = phoneList
    return phoneDict

def lambdaHandler(event, context):
    global environDict
    global sqsHandle
    global s3Handle
    if not environDict: 
        try:
            environDict = buildEnvironVarDict()
            logging.info ('environDict = %s', environDict)
        except Exception as e:
            logging.error('error generating environDict.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return -1
    else:
        logging.info('warm-start enviornDict = %s', environDict)

    try:
        setLogging(environDict['logginglevel'])
    except:
        setLogging('INFO')
        logging.warning('logging environment variable missing, setting the level to INFO')

    if not s3Handle:
        environDict['s3Handle'] = boto3.resource('s3', config=createClientConfiguration(environDict))
    if not sqsHandle:
        environDict['sqsHandle'] = boto3.resource('sqs', region_name='us-east-1', config=createClientConfiguration(environDict))
        
    logging.info('event = %s', event)
    logging.info ('event type = %s', type(event))  
    incomingContent = event
    logging.info('sleeping for %s seconds',environDict['DELAYTIME'])
    time.sleep(int(environDict['DELAYTIME']))
    
    for records in incomingContent['Records']:
        if 'body' not in records:
            continue
        try:
            researchRequest = json.loads(records['body'])
            logging.info ('researchRequest = %s',researchRequest)
        except Exception as err:
            logging.error('record contained bad json.  error = %s, Data = %s', err, records['body'])
            continue
        for ticket in researchRequest['tickets']:
            logging.info ('ticket being processed = %s', researchRequest['tickets'])
            if 'duns' not in ticket:
                processDunsResponse(None,CONTENT_ONLY,ticket['ticketId'],None)
                logging.info ('No duns available, processing as CONTENT_ONLY')
                continue
            logging.info ('DunsNumber being processed = %s',ticket['duns'])
            if ticket['duns'] not in controlDuns.duns:
                logging.info ('Duns not found in control list, processing as CONTENT_ONLY')
                processDunsResponse(ticket['duns'],CONTENT_ONLY,ticket['ticketId'],None)
                continue
            dunsNumber = ticket['duns']
            if controlDuns.duns[dunsNumber]['answerType'] == ADDITIONAL_AGENT_PROCESSING_NEEDED:
                logging.info('duns found in control list - processing as ADDITIONAL_AGENT_PROCESSING_NEEDED')
                processAdditionalAgentProcessingNeeded(ticket, dunsNumber)
                continue
            elif controlDuns.duns[dunsNumber]['answerType'] == AUTONOMOUS_ANSWER:
                logging.info('duns found in control list - going to AUTONOMOUS ANSWER processing')
                processAutonomousTicket(ticket, dunsNumber, AUTONOMOUS_ANSWER)
                continue
            elif controlDuns.duns[dunsNumber]['answerType'] == NO_AGENT_INVOLVEMENT:
                logging.info('duns found in control list - going to AUTONOMOUS ANSWER processing')
                processAutonomousTicket(ticket, dunsNumber, NO_AGENT_INVOLVEMENT)
                continue
            else:
                logging.info('bad definition in control list - answer type = %s.  Will deliver CONTENT_ONLY', controlDuns.duns[dunsNumber]['answerType'])
                processDunsResponse(ticket['duns'],CONTENT_ONLY,ticket['ticketId'],None)
                

if __name__ == '__main__':
    pass
