'''
Created on Jun 20, 2019

@author: MorganB
'''
# "type":33523, "subtype": 33549},"function": "addressFunc"
# "type":33523, "subtype": 33555}, "function": "phoneFunc"
# ADDITIONAL_AGENT_PROCESSING_NEEDED = 33934
# AUTONOMOUS_ANSWER = 33933
# NO_AGENT_INVOLVEMENT = 35372

duns = {
    "107584351": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "961970378": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "079904583": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "787190065": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "159796408": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "061337374": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "960630481": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "057444010": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "002324499": {
        "answerType": 33933,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "001344746": {
        "answerType": 33934
    },
    "079940571": {
        "answerType": 33934
    },
    "805499469": {
        "answerType": 33934
    },
    "016740512": {
        "answerType": 33934
    },
    "011143223": {
        "answerType": 33934
    },
    "071457568": {
        "answerType": 33934
    },
    "025663945": {
        "answerType": 33934
    },
    "078512209": {
        "answerType": 33934
    },
    "967000600": {
        "answerType": 33934
    },
    "002136117": {
        "answerType": 33934
    },
    "081020242": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081020263": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081020504": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081021298": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081021306": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081021499": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081022776": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081022948": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081023003": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    },
    "081023139": {
        "answerType": 35372,
        "researchTypes": [
            {
                "type": 33523,
                "subtype": 33549
            },
            {
                "type": 33523,
                "subtype": 33555
            }
        ]
    }
}