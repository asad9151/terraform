'''
Created on Mar 7, 2019

@author: VanCampK
'''
import logging
import json

from lambdas.secureLambdaBase import SecureLambdaBase
from buildUIResponse import buildUIResponse
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.updateuserdata.service import Service
from common.irschRoles import IResearchRole
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaAuthorizationException
import lambdas.errorMessages as errmsg


class SvcLambda(SecureLambdaBase):
    '''
    Handler class for UpdateUserData service.
    Implementation of a Lambda handler as a class for a specific Lambda function.
    Handler: lambdas.updateuserdata.svclambda.handler
    '''
    
    def __init__(self):
        self.service = None
    
    def handleSecureRequest(self):
        if self.service is None:
            self.service = Service(SvcLambda.dbConn)
        
        self.service.updateUser(self.requestContext)
        responseBody = json.dumps({})
           
        return buildUIResponse(LambdaStatusCodes.OK.value, responseBody, 'application/json')

    
    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, IResearchRole.getAllRoles()) == False):
            logging.error('UpdateUserData - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)

#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SvcLambda.get_handler(...)