'''
Created on Feb 13, 2020

@author: VanCampK
'''
import jmespath
import logging
import json

from common.dao.scotsDao import ScotsDao
from common.dao.subjectResearchDao import SubjectResearchDao
from common.util.ValidateUtil import ValidateUtil
from common.mappers.scotsMapper import mapScotsTypeCodeListToDict
from common.rejectionReasonCodes import RejectionReasonCode
from lambdas.exceptions import LambdaConflictException, LambdaValidationException
from lambdas.requestRejectionError import RequestRejectionError
import lambdas.challengecaseapi.challengeCaseApiErrors as apiErrors 
import lambdas.challengecaseapi.challengeCaseApiFields as apiFields
import lambdas.errorMessages as errmsg
from lambdas.util.cloudServicesHelper import CloudServicesHelper


class ChallengeCaseApiValidationService(object):
    '''
    Handles validation of ChallengeCaseApi requests
    '''
    CHALLENGE_REASON_CODE_TABLE = 765
    COMMENT_TYPE_CODE_TABLE = 761
    CHALLENGE_COMMENT_TYPE_CODE = 33594

    
    def __init__(self, dbConn, requestAttachmentLinkService):
        self.dbConn = dbConn
        self.requestAttachmentLinkService = requestAttachmentLinkService
        self.scotsDao = None
        self.subjectResearchDao = None
        self.scotsTypeCodeCache = None
        self.validateUtil = None
        

    def validateRecord(self, requestContext, requestRecord):
        '''
        Validates the given record (challengeCaseRequest) and either rejects it (adds to the requestRejectionErrors list) or does nothing if ok.
        - challengeReasonCode is valid for Scots Table 765
        - commentTypeCode is valid for Scots Table 761 and must be 33594
        '''
        self._loadCache(requestContext)
        ccRequest = requestRecord.challengeCaseRequest
        self._isChallengeable(requestRecord)
        self._validateOneScotsTypeCode(requestRecord, ccRequest.get(apiFields.BOTH_FLD_CHALLENGE_REASON_CODE), apiFields.BOTH_FLD_CHALLENGE_REASON_CODE, ChallengeCaseApiValidationService.CHALLENGE_REASON_CODE_TABLE)
        self._validateCommentTypeCode(requestRecord)
        self._validateAttachments(requestContext, requestRecord)
        
        
    def _validateCommentTypeCode(self, requestRecord):
        researchCommentTypeCode = jmespath.search(apiFields.CC_PATH_RESEARCH_COMMENT_TYPE_CODE, requestRecord.challengeCaseRequest)
        isOkCode = self._validateOneScotsTypeCode(requestRecord, researchCommentTypeCode, apiFields.CC_PATH_RESEARCH_COMMENT_TYPE_CODE, ChallengeCaseApiValidationService.COMMENT_TYPE_CODE_TABLE)
        if isOkCode:
            if researchCommentTypeCode != ChallengeCaseApiValidationService.CHALLENGE_COMMENT_TYPE_CODE:
                reqRejErr = RequestRejectionError(apiFields.CC_PATH_RESEARCH_COMMENT_TYPE_CODE, apiErrors.FAILREC_CHALLENGE_COMMENT_TYPE, researchCommentTypeCode)
                requestRecord.addRejection(reqRejErr, RejectionReasonCode.VALIDATION_ERROR)


    def _loadCache(self, requestContext):
        self._loadScotsTypeCodeCache()

    
    def validateAgainstSchema(self, requestContext, requestRecord):
        '''
        Validates the given requestRecord (challengeCaseRequest) against the iResearchChallengeCaseRequest.json schema and either rejects it or does nothing.
        Updates the requestRecord.requestRejectionErrors if the record was rejected, or leaves the requestRecord unmodified if ok.
        This function should never throw an exception.
        '''
        if self.validateUtil is None:
            self.validateUtil = ValidateUtil("iResearchChallengeCaseRequest.json")
        ccRequest = requestRecord.challengeCaseRequest
        errors = sorted(self.validateUtil.theValidator.iter_errors(ccRequest), key=lambda e: e.path)
        for error in errors:
            if error.absolute_path:
                jsonPath = ''
                for ele in error.absolute_path:
                    if type(ele) is int:
                        jsonPath = jsonPath.strip(".") + "[" + str(ele) + "]."
                    else:
                        jsonPath += ele + "."
                jsonPath = jsonPath.strip(".")
            else:
                jsonPath = ""
            reqRejErrObj = RequestRejectionError(jsonPath, error.message, None)
            requestRecord.addRejection(reqRejErrObj, RejectionReasonCode.VALIDATION_ERROR)


    def _loadScotsTypeCodeCache(self):
        if self.scotsDao is None:
            self.scotsDao = ScotsDao()
        if self.scotsTypeCodeCache is None:
            scotsTableList = []
            scotsTableList.append(ChallengeCaseApiValidationService.CHALLENGE_REASON_CODE_TABLE)
            scotsTableList.append(ChallengeCaseApiValidationService.COMMENT_TYPE_CODE_TABLE)
            qryResult = self.scotsDao.queryScotsTypeCodeLists(self.dbConn, scotsTableList)
            self.scotsTypeCodeCache = mapScotsTypeCodeListToDict(qryResult)
            logging.info("Loaded scotsTypeCodeCache: " + str(self.scotsTypeCodeCache))
                
            
    def _validateOneScotsTypeCode(self, requestRecord, fldValue, jsonPath, scotsTbl):
        validTypeCodes = self.scotsTypeCodeCache.get(int(scotsTbl))
        if validTypeCodes is None:
            logging.error(f"Cannot validate {jsonPath} because scotsTbl={scotsTbl} is not loaded in cache")
            raise LambdaConflictException(f"Cannot validate {jsonPath} because scotsTbl={scotsTbl} is not loaded in cache")
        isValid = str(fldValue) in [str(i) for i in validTypeCodes]
        if not isValid:
            reqRejErr = RequestRejectionError(jsonPath, apiErrors.FAILREC_INVALID_TYPE_CODE, fldValue)
            requestRecord.addRejection(reqRejErr, RejectionReasonCode.VALIDATION_ERROR)
            logging.info(f"Attribute {jsonPath} in scotsTbl {scotsTbl} looking for value {fldValue} not found in {validTypeCodes}")
            return False
        return True
                    
                    
    def _validateAttachments(self, requestContext, requestRecord):
        for idx, attmObj in enumerate(requestRecord.attachments):
            attmName = attmObj.getIncomingFileName()
            try:
                self.requestAttachmentLinkService.validateAttachmentRequest(attmObj, fullValidation=True, requestContext=requestContext)
            except LambdaValidationException as lve:
                logging.error(f"Failed in validateAttachmentRequest: {lve}")
                if errmsg.ERR_ATTACHMENT_LIMIT == str(lve):
                    jsonPath = apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID
                    reqRejErr = RequestRejectionError(jsonPath, str(lve), str(requestRecord.subjectResearchId))
                else:
                    jsonPath = apiFields.CC_FLD_ATTACHMENT_LINKS + "[" + str(idx) + "]." + apiFields.CC_FLD_ATTACHMENT_NAME
                    reqRejErr = RequestRejectionError(jsonPath, str(lve), attmName)
                requestRecord.addRejection(reqRejErr, RejectionReasonCode.VALIDATION_ERROR)
    
    def _isChallengeable(self, requestRecord):
        isChallengeable = True;

        if self.subjectResearchDao is None:
            self.subjectResearchDao = SubjectResearchDao()
        subjRschData = self.subjectResearchDao.querySubjResearch(self.dbConn, requestRecord.subjectResearchId)
        countryCodeData = self.subjectResearchDao.queryCountryCode(self.dbConn, requestRecord.subjectResearchId)
        
        if subjRschData is not None and countryCodeData is not None:
            subjectResearch = subjRschData[apiFields.DB_FLD_SUBJECT_RESEARCH]
            if subjectResearch is not None:
                subjRsch = json.loads(subjectResearch)
                if subjRsch is not None:
                    researchTypes = subjRsch[apiFields.FLD_RESEARCH_TYPES]
            countryCode = countryCodeData[apiFields.DB_FLD_COUNTRY_CODE]
            if countryCode is not None and researchTypes is not None:
                isChallengeable = CloudServicesHelper.isChallengeable(self, researchTypes, countryCode)
        if isChallengeable == False:
            reqRejErr = RequestRejectionError(jsonPathName=apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID, errorDescription=apiErrors.FAILREC_NOT_CHALLENGEABLE_LIMIT_MARKET, providedValue=requestRecord.subjectResearchId)
            requestRecord.addRejection(reqRejErr, RejectionReasonCode.VALIDATION_ERROR)
            