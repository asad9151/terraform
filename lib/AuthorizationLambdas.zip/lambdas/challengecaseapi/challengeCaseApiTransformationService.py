'''
Created on Feb 12, 2020

@author: VanCampK
'''
import jmespath

from attachmentClass import attachment
import constants
from common.actionTypeCodes import ActionTypeCode
from common.util.stringUtils import isNotBlank, convertNewlines
import lambdas.challengecaseapi.challengeCaseApiFields as apiFields


class ChallengeCaseApiTransformationService(object):
    '''
    Performs record-level transformations for the ChallengeCaseApi service
    '''
    
    
    def transformOneRecordToIResearch(self, requestContext, requestRecord):
        '''
        Transforms the ChallengeCaseApi request into the TakeCaseAction request
        '''
        self._transformOneRecordToTakeCaseActionRequest(requestContext, requestRecord)
            
            
    def _transformOneRecordToTakeCaseActionRequest(self, requestContext, requestRecord):
        '''
        Transforms the ChallengeCaseApi request into the TakeCaseAction close request 
        '''
        origRec = requestRecord.challengeCaseRequest
        requestRecord.takeCaseActionRequest = {
            apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID: origRec.get(apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID),
            apiFields.TCA_FLD_ACTION_TYPE_CODE: ActionTypeCode.CHALLENGE.value,
            apiFields.BOTH_FLD_CHALLENGE_REASON_CODE: origRec.get(apiFields.BOTH_FLD_CHALLENGE_REASON_CODE),
            apiFields.TCA_FLD_RESEARCH_COMMENT: convertNewlines(jmespath.search(apiFields.CC_PATH_RESEARCH_COMMENT, origRec))
        }
        
        
    def transformAttachmentRequests(self, requestContext, requestRecord):
        '''
        Parse attachment request list
        '''
        origRec = requestRecord.challengeCaseRequest
        attmReqsList = origRec.get(apiFields.CC_FLD_ATTACHMENT_LINKS)
        if attmReqsList is not None:
            for attmReqs in attmReqsList:
                attmName = attmReqs.get(apiFields.CC_FLD_ATTACHMENT_NAME)
                if isNotBlank(attmName):
                    self._addAttachment(requestRecord, attmName, constants.CHALLENGE_ATTACHMENT)


    def _addAttachment(self, requestRecord, attachmentName, attachmentType):
        attmObj = attachment()
        attmReqDict = {
            "attachmentName": attachmentName,
            "attachmentType": attachmentType,
            "attachmentKey": requestRecord.subjectResearchId
        }
        attmObj.loadRequestAttributes(attmReqDict)
        requestRecord.attachments.append(attmObj)
        
        
    def transformAttachmentResponses(self, requestRecord):
        attachments = requestRecord.attachments
        attachmentsResponse = []
        for attm in attachments:
            requestLinkResp = attm.getRequestAttachmentLinkResponse()
            resp = {
                apiFields.API_RESP_ATTACHMENT_NAME: attm.getIncomingFileName(),
                apiFields.API_RESP_ATTACHMENT_URL: requestLinkResp["signed_URL"]["url"],
                apiFields.API_RESP_ATTACHMENT_FIELDS: requestLinkResp["signed_URL"]["fields"]
            }
            attachmentsResponse.append(resp)
            
        return attachmentsResponse
