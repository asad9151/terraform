'''
Created on Mar 26, 2020

@author: VanCampK
'''
import logging
import sys
import traceback
from common.rejectionReasonCodes import RejectionReasonCode
from databaseClass import databaseClass
from lambdas import errorMessages
from lambdas.attachment.requestAttachmentLinkService import RequestAttachmentLinkService
from lambdas.challengecaseapi.requestRecord import RequestRecord
import lambdas.challengecaseapi.challengeCaseApiFields as apiFields
from lambdas.challengecaseapi.challengeCaseApiSubmissionService import ChallengeCaseApiSubmissionService
from lambdas.challengecaseapi.challengeCaseApiTransformationService import ChallengeCaseApiTransformationService
from lambdas.challengecaseapi.challengeCaseApiValidationService import ChallengeCaseApiValidationService
from lambdas.exceptions import LambdaValidationException, LambdaProcessingException, LambdaAuthorizationException, LambdaAuthenticationException
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.requestRejection import RequestRejection


class ChallengeCaseApiService(object):
    '''
    Service for ChallengeCaseApi
    '''
    challengeCaseApiValidationService = None
    challengeCaseApiTransformationService = None
    challengeCaseApiSubmissionService = None
    requestAttachmentLinkService = None
    
    def __init__(self, dbConn, s3handleForAttachments):
        self.dbConn = dbConn
        self.s3handleForAttachments = s3handleForAttachments
        self.singleRequestRecord = None
        self.dbObj = None


    def _createServices(self, requestContext):
        '''
        Instantiates each dependent service that is not already instantiated
        '''
        if self.dbObj is not None:
            # warm start
            logging.info('ChallengeCaseApiService warm start - testing database connection...')
            self.dbObj.checkConnection()
            logging.info('ChallengeCaseApiService continuing after database connection tested')
        else:
            logging.info('Initializing databaseClass...')
            self.dbObj = databaseClass(requestContext.environDict)
            logging.info('ChallengeCaseApiService continuing after database connection created')

        if not ChallengeCaseApiService.requestAttachmentLinkService:
            ChallengeCaseApiService.requestAttachmentLinkService = RequestAttachmentLinkService(self.dbObj, self.s3handleForAttachments, self.dbConn)
        if ChallengeCaseApiService.challengeCaseApiValidationService is None:
            ChallengeCaseApiService.challengeCaseApiValidationService = ChallengeCaseApiValidationService(self.dbConn, ChallengeCaseApiService.requestAttachmentLinkService)
        if ChallengeCaseApiService.challengeCaseApiTransformationService is None:
            ChallengeCaseApiService.challengeCaseApiTransformationService = ChallengeCaseApiTransformationService()
        if ChallengeCaseApiService.challengeCaseApiSubmissionService is None:
            ChallengeCaseApiService.challengeCaseApiSubmissionService =  ChallengeCaseApiSubmissionService()
    
    
    def processChallengeCaseRequest(self, requestContext, incomingContent, lambdaClient):
        '''
        Main entry point to process a new ChallengeCase Request
        '''
        self._createServices(requestContext)
        try:
            responseRecord = self._processChallengeCaseRequestImpl(requestContext, incomingContent, lambdaClient)
            
        except Exception as e:
            logging.error('processChallengeCaseRequest error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            requestRejection = RequestRejection(RejectionReasonCode.INTERNAL_ERROR, rejectionErrorMessage=errorMessages.ERR_INTERNAL_REQUEST)
            if isinstance(e, LambdaAuthorizationException):
                requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrorMessage=errorMessages.ERR_NOT_AUTHORIZED)
                if e.requestRejection is None:
                    e.requestRejection = requestRejection
                raise e
            elif isinstance(e, LambdaProcessingException):
                if e.requestRejection is None:
                    e.requestRejection = requestRejection
                raise e
            else:
                # Make sure we have requestRejection so client gets back properly formatted response
                raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST, requestRejection=requestRejection)
        
        return responseRecord


    def _processChallengeCaseRequestImpl(self, requestContext, incomingContent, lambdaClient):
        self.singleRequestRecord = RequestRecord()
        self.singleRequestRecord.challengeCaseRequest = incomingContent
        self.singleRequestRecord.subjectResearchId = self.singleRequestRecord.challengeCaseRequest.get(apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID)
        
        ChallengeCaseApiService.challengeCaseApiTransformationService.transformAttachmentRequests(requestContext, self.singleRequestRecord)
        
        ChallengeCaseApiService.challengeCaseApiValidationService.validateAgainstSchema(requestContext, self.singleRequestRecord)
        ChallengeCaseApiService.challengeCaseApiValidationService.validateRecord(requestContext, self.singleRequestRecord)
        if not self.singleRequestRecord.isRejected():
            ChallengeCaseApiService.challengeCaseApiTransformationService.transformOneRecordToIResearch(requestContext, self.singleRequestRecord)
        if self.singleRequestRecord.isRejected():
            logging.error(f"request is rejected due to {self.singleRequestRecord.requestRejectionErrors}")
            requestRejection = RequestRejection(self.singleRequestRecord.rejectionReasonCode, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)

        logging.info("Submitting to back end services...")        
        ChallengeCaseApiService.challengeCaseApiSubmissionService.submitOneRequest(requestContext, self.singleRequestRecord, lambdaClient)
        logging.info("Submitted successfully to back end services.")
        
        attachmentResultDict = self._processAttachmentRequests(requestContext)
        statusCode = attachmentResultDict[ChallengeCaseApiSubmissionService.RESULT_STATUS_CODE]
        apiResponse = {}
        if statusCode == LambdaStatusCodes.OK.value or statusCode == LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
            attachmentsResponse = ChallengeCaseApiService.challengeCaseApiTransformationService.transformAttachmentResponses(self.singleRequestRecord)
            if len(attachmentsResponse) > 0:
                apiResponse[apiFields.API_RESP_ATTACHMENTS] = attachmentsResponse
        else:
            self._handleChallengeCaseFailure(requestContext, attachmentResultDict, statusCode)
            
        return apiResponse


    def _processAttachmentRequests(self, requestContext):
        resultDict = {
            ChallengeCaseApiSubmissionService.RESULT_STATUS_CODE: LambdaStatusCodes.OK.value,
            ChallengeCaseApiSubmissionService.RESULT_ERR_MSG: None,
            ChallengeCaseApiSubmissionService.RESULT_BODY: None
        }
        if len(self.singleRequestRecord.attachments) == 0:
            # No attachments in request
            return resultDict
        
        subjectResearchId = self.singleRequestRecord.subjectResearchId
        for attmObj in self.singleRequestRecord.attachments:
            attmObj.setIncomingAttachmentKey(str(subjectResearchId))
            try:
                logging.info("_processAttachmentRequests: requestAttachmentLink for ")
                attmResponseBody = ChallengeCaseApiService.requestAttachmentLinkService.processAttachmentRequest(requestContext, attmObj)
                attmObj.setRequestAttachmentLinkResponse(attmResponseBody)
            except Exception as e:
                logging.error(f"_processAttachmentRequests failed for {attmObj.getIncomingFileName()}: {e}")
                resultDict[ChallengeCaseApiSubmissionService.RESULT_STATUS_CODE] = LambdaStatusCodes.INTERNAL_SERVER_ERROR.value
                resultDict[ChallengeCaseApiSubmissionService.RESULT_ERR_MSG] = f"Internal error processing attachment {attmObj.getIncomingFileName()}"
                
        return resultDict
    
    
    def _handleChallengeCaseFailure(self, requestContext, resultDict, statusCode):
        logging.error('_handleChallengeCaseFailure: resultDict=' + str(resultDict))
        responseBody = resultDict[ChallengeCaseApiSubmissionService.RESULT_BODY]
        errmsg = None
        if responseBody is not None:
            errorResponse = responseBody.get("errorResponse")
            if errorResponse is not None:
                errmsg = errorResponse.get("errorMessage")
        if statusCode == LambdaStatusCodes.BAD_REQUEST.value or statusCode == LambdaStatusCodes.NOT_FOUND.value:
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.FORBIDDEN.value:
            if errmsg is None:
                errmsg = errorMessages.ERR_NOT_AUTHORIZED
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrorMessage=errmsg)
            raise LambdaAuthorizationException(errmsg, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.UNAUTHORIZED.value:
            raise LambdaAuthenticationException(errorMessages.ERR_NOT_AUTHENTICATED)
        else:
            #Other technical error
            requestRejection = RequestRejection(RejectionReasonCode.INTERNAL_ERROR, rejectionErrorMessage=errorMessages.ERR_INTERNAL_REQUEST)
            raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST, requestRejection=requestRejection)
