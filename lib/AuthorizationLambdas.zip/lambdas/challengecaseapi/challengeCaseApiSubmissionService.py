'''
Created on Feb 12, 2020

@author: VanCampK
'''
import json
import logging
from common import envVblNames
from common.encoders import DecimalAsFloatEncoder
from common.rejectionReasonCodes import RejectionReasonCode
from lambdas.exceptions import LambdaValidationException, LambdaProcessingException, LambdaAuthorizationException, LambdaAuthenticationException
from lambdas import errorMessages
from lambdas import lambdaConstants
from lambdas.lambdaCommon import buildLambdaSecureInvokeEvent, invokeLambdaFunction, parsePayloadFromInvokeResponse, parseHTTPStatusCodeFromInvokeResponse, parseStatusCodeFromPayload
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.requestRejection import RequestRejection
from lambdas.requestRejectionError import RequestRejectionError
import lambdas.challengecaseapi.challengeCaseApiFields as apiFields


class ChallengeCaseApiSubmissionService(object):
    '''
    Submits the requests to the TakeCaseAction service
    '''
    # Elements of the submitOneRequest response dictionary:
    RESULT_STATUS_CODE = "statusCode"
    RESULT_ERR_MSG = "errmsg"
    RESULT_BODY = "responseBody"
    RESULT_ERR_RESPONSE = "errorResponse"
    ERROR_MESSAGE = "errorMessage"
    ERROR_TYPE = "errorType"
    

    def submitOneRequest(self, requestContext, requestRecord, lambdaClient):
        resultDict = self._submitToBackEndService(requestContext, requestRecord.takeCaseActionRequest, requestContext.environDict[envVblNames.ENV_TAKECASEACTION_ARN], lambdaClient)
        statusCode = resultDict[ChallengeCaseApiSubmissionService.RESULT_STATUS_CODE]
        if statusCode != LambdaStatusCodes.OK.value:
            self._handleBackEndServiceFailure(requestContext, resultDict, statusCode, requestRecord)
        # Success
    
    def _handleBackEndServiceFailure(self, requestContext, resultDict, statusCode, requestRecord):
        logging.error('_handleBackEndServiceFailure: resultDict=' + str(resultDict))
        responseBody = resultDict[ChallengeCaseApiSubmissionService.RESULT_BODY]
        errmsg = None
        if responseBody is not None:
            errorResponse = responseBody.get("errorResponse")
            if errorResponse is not None:
                errmsg = errorResponse.get("errorMessage")
        if statusCode == LambdaStatusCodes.BAD_REQUEST.value or statusCode == LambdaStatusCodes.NOT_FOUND.value:
            rejectionError = RequestRejectionError(jsonPathName=apiFields.BOTH_FLD_SUBJECT_RESEARCH_ID, errorDescription=errmsg, providedValue=requestRecord.subjectResearchId)
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrors=[rejectionError])
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.FORBIDDEN.value:
            if errmsg is None:
                errmsg = errorMessages.ERR_NOT_AUTHORIZED
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrorMessage=errmsg)
            raise LambdaAuthorizationException(errmsg, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.UNAUTHORIZED.value:
            raise LambdaAuthenticationException(errorMessages.ERR_NOT_AUTHENTICATED)
        else:
            #Other technical error
            requestRejection = RequestRejection(RejectionReasonCode.INTERNAL_ERROR, rejectionErrorMessage=errorMessages.ERR_INTERNAL_REQUEST)
            raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST, requestRejection=requestRejection)
        
        
    def _submitToBackEndService(self, requestContext, backEndSvcRequest, backEndSvcArn, lambdaClient):
        outgoingBody = json.dumps(backEndSvcRequest, cls=DecimalAsFloatEncoder)
        logging.info(f'_submitToBackEndService: Arn={backEndSvcArn} outgoingBody={outgoingBody}')
        #print('outgoingBody=' + outgoingBody)
        event = buildLambdaSecureInvokeEvent(requestContext.userSession.principalId, 'POST', '/takecaseaction', body=outgoingBody)
        response = invokeLambdaFunction(lambdaClient, event, backEndSvcArn, lambdaConstants.INVOKE_LAMBDA_REQUEST_RESPONSE)
        
        resultDict = {
            ChallengeCaseApiSubmissionService.RESULT_STATUS_CODE: None,
            ChallengeCaseApiSubmissionService.RESULT_ERR_MSG: None,
            ChallengeCaseApiSubmissionService.RESULT_BODY: None
        }
        isSuccess = True
        httpStatusCode = parseHTTPStatusCodeFromInvokeResponse(response)
        resultDict[ChallengeCaseApiSubmissionService.RESULT_STATUS_CODE] = httpStatusCode
        if httpStatusCode != LambdaStatusCodes.OK.value and httpStatusCode != LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
            isSuccess = False
            resultDict[ChallengeCaseApiSubmissionService.RESULT_ERR_MSG] = 'Failed to _submitToBackEndService: response=' + str(response)
            errmsg = 'httpStatusCode=' + str(httpStatusCode)
            logging.error('Failed to _submitToBackEndService #1: errmsg=' + errmsg + ' response=' + str(response))
        else:
            # Handle synchronous invoke response
            responsePayload = parsePayloadFromInvokeResponse(response)
            if responsePayload:
                logging.info('Response payload from _submitToBackEndService:' + str(responsePayload))
                #print('Response payload from SubmitCase:' + str(responsePayload))
                statusCode = parseStatusCodeFromPayload(responsePayload)
                resultDict[ChallengeCaseApiSubmissionService.RESULT_STATUS_CODE] = statusCode
                responseBody = responsePayload.get('body')
                if responseBody is not None:
                    resultDict[ChallengeCaseApiSubmissionService.RESULT_BODY] = json.loads(responseBody)
                if statusCode != LambdaStatusCodes.OK.value:
                    isSuccess = False
                    resultDict[ChallengeCaseApiSubmissionService.RESULT_ERR_MSG] = 'Failed to _submitToBackEndService #3: response payload=' + str(responsePayload)
                    errmsg = 'statusCode=' + str(statusCode)
                    logging.error('Failed to _submitToBackEndService: errmsg=' + errmsg + ' response=' + str(response))
                    #self._addSubmitRejection(requestContext, requestRecord, resultDict)
                
        logging.info('_submitToBackEndService invoked: success=' + str(isSuccess))
        return resultDict
        