'''
@author: VanCampK
'''
import boto3
from botocore.client import Config
import logging
import json

from buildUIResponse import buildUIResponse
from common import envVblNames
from common.util.awsUtils import createClientConfiguration
from common.irschRoles import IResearchRole
from lambdas.secureLambdaBase import SecureLambdaBase
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaAuthorizationException
import lambdas.errorMessages as errmsg
from lambdas.challengecaseapi.challengeCaseApiService import ChallengeCaseApiService


class ChallengeCaseApiLambda(SecureLambdaBase):
    '''
    Handler class for ChallengeCaseApi service.
    Responsible for challenging a case from API users.
    Handler: lambdas.challengecaseapi.challengeCaseApiLambda.handler
    '''
    
    
    def __init__(self):
        super().__init__()
        self.service = None
        self.s3handleForAttachments = None
        self.lambdaClientForTakeCaseAction = None       # used to invoke TakeCaseAction
    
    
    def handleSecureRequest(self):
        incomingContent = self.requestContext.incomingContent
        if self.lambdaClientForTakeCaseAction is None:
            # config is None to stop retries from happening on TakeCaseAction invokes
            self.lambdaClientForTakeCaseAction = boto3.client('lambda', region_name=ChallengeCaseApiLambda.environDict[envVblNames.ENV_LAMBDA_REGION], config=None)
        if self.service is None:
            self.service = ChallengeCaseApiService(ChallengeCaseApiLambda.dbConn, self.s3handleForAttachments)
        responseBody = self._handleImpl(incomingContent)
        msgBody = json.dumps(responseBody)
        return buildUIResponse(LambdaStatusCodes.OK.value, msgBody, 'application/json')
        
        
    def _handleImpl(self, incomingContent):
        return self.service.processChallengeCaseRequest(self.requestContext, incomingContent, self.lambdaClientForTakeCaseAction)


    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7 ]) == False):
            logging.error('ChallengeCaseApiLambda - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)


    def initializeKeepWarm(self):
        if not self.s3handleForAttachments:
            logging.info('Initializing s3handleForAttachments...')
            self.s3handleForAttachments = boto3.client('s3', config=createClientConfiguration(environDict=None, mergeConfig=Config(signature_version='s3v4')))
        

    def getResponseSchema(self):
        return "iResearchChallengeCaseResponse.json"

    
    def isApi(self):
        '''
        By default we are behaving as there is a browser on the other side.
        Subclass can override this if they want API-type behavior.
        '''
        return True
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = ChallengeCaseApiLambda.get_handler(...)