'''
Created on Mar 26, 2020

@author: VanCampK
'''

class RequestRecord(object):
    '''
    Holds attributes about one ChallengeCaseApi request
    '''

    def __init__(self):
        self.challengeCaseRequest = None   # Incoming ChallengeCaseApi request
        self.subjectResearchId = None       # Case# being challenged
        self.subjectResearchDetails = None  # Details of the case from RetrieveCase
        self.takeCaseActionRequest = None   # Outgoing TakeCaseAction request
        self.requestRejectionErrors = []    # list of RequestRejectionError, if any
        self.rejectionReasonCode = None     # reason for rejection, if any
        self.attachments = []               # list of attachments to process
        
        
    def isRejected(self):
        if self.requestRejectionErrors:
            if len(self.requestRejectionErrors) > 0:
                return True
        return False
    
    
    def addRejection(self, requestRejectionError, rejectionReasonCode):
        self.requestRejectionErrors.append(requestRejectionError)
        self.rejectionReasonCode = rejectionReasonCode
