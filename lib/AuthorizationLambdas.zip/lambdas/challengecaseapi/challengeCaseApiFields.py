'''
Created on Feb 13, 2020
Field name constants for UpdateAndClose API

@author: VanCampK
'''

# Common fields in both CC and TCA requests
BOTH_FLD_SUBJECT_RESEARCH_ID = "subjectResearchId"
BOTH_FLD_CHALLENGE_REASON_CODE = "challengeReasonCode"

# Fields only in the incoming ChallengeCase schema
CC_PATH_RESEARCH_COMMENT_TYPE_CODE = "researchComments[0].commentTypeCode"
CC_PATH_RESEARCH_COMMENT = "researchComments[0].researchComment"
CC_FLD_ATTACHMENT_LINKS = "requestAttachmentLinks"
CC_FLD_ATTACHMENT_NAME = "attachmentName"

# Fields only in the outgoing TakeCaseAction schema
TCA_FLD_RESEARCH_COMMENT = "researchComment"
TCA_FLD_ACTION_TYPE_CODE = "actionTypeCode"

# CC Response fields
API_RESP_ATTACHMENTS = "attachmentLinkSignedUrls"
API_RESP_ATTACHMENT_NAME = "attachmentName"
API_RESP_ATTACHMENT_URL = "url"
API_RESP_ATTACHMENT_FIELDS = "fields"

# Fields from database record
DB_FLD_SUBJECT_RESEARCH = "subj_rsch_obj"
DB_FLD_COUNTRY_CODE = "countryCode"

# Fields from subj rsch json
FLD_RESEARCH_TYPES = "researchTypes"
