'''
Created on Mar 3, 2020

@author: VanCampK
'''
from enum import Enum

class SubmitStatus(Enum):
    '''
    statuses returned by Submit module
    '''
    SubmittedWithError = 0
    SubmittedToWithDunsQueue = 1
    SubmittedToNoDunsQueue = 2
