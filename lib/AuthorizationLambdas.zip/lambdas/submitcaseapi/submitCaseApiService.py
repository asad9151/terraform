'''
Created on May 31, 2019

@author: VanCampK
'''
import logging
import constants
import jmespath
import json
import traceback
import sys
from common import updateEventConstants
from common.batchStatusCodes import BatchStatusCode
from common.batchFormatCodes import BatchFormatCode
from common.dao.updateEventDao import UpdateEventDao
import common.envVblNames as envVblNames
from common.mappers.attachmentMapper import mapToAttachmentObj
#from common.notificationTypeCodes import NotificationTypeCode
from common.batchWatchTypeCodes import BatchWatchTypeCode
from common.rejectionReasonCodes import RejectionReasonCode
from common.requestMethodCodes import RequestMethodCode
from common.updateActionCodes import UpdateActionCode
from common.util.dictUtils import isEmptyDictionary, removeEmptyFromDictionary
from common.util.notificationHelper import NotificationHelper
from common.util.sqsHelper import SqsHelper
from common.util.stringUtils import isNotBlank
from databaseClass import databaseClass
from lambdas import lambdaConstants
from lambdas import errorMessages
from lambdas.requestRejection import RequestRejection
from lambdas.attachment.attachmentDao import AttachmentDao
from lambdas.attachment.requestAttachmentLinkService import RequestAttachmentLinkService
from lambdas.exceptions import LambdaValidationException, LambdaProcessingException, LambdaConflictException, LambdaAuthorizationException, LambdaAuthenticationException
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.loginSessionDao import LoginSessionDao
from lambdas.submitcaseapi.batchRecord import BatchRecord
from common.dao.batchRequestDao import BatchRequestDao
from lambdas.submitcaseapi.batchFileParser import BatchFileParser, createBatchRecord
from lambdas.submitcaseapi.requestRecord import RequestRecord
from lambdas.requestRejectionError import RequestRejectionError
import lambdas.submitcaseapi.submitCaseApiErrors as apiErrors
import lambdas.submitcaseapi.submitCaseApiFields as apiFields
from lambdas.submitcaseapi.submitCaseApiSubmissionService import SubmitCaseApiSubmissionService
from lambdas.submitcaseapi.submitCaseApiTransformationService import SubmitCaseApiTransformationService
from lambdas.submitcaseapi.submitCaseApiValidationService import SubmitCaseApiValidationService
from lambdas.submitcaseapi.submitCaseStep import SubmitCaseStep
from lambdas.submitcaseapi.submitCaseType import SubmitCaseType
from lambdas.userSession import UserSession


class SubmitCaseApiService(object):
    '''
    Service for SubmitClassApi
    '''
    BATCH_MAX_REJECTS = 0           # Threshold for rejects in a batch. Beyond this, batch will be rejected.
    BATCH_MAX_NEEDS_APPROVAL = 40   # Threshold for approval. For batches bigger than this, batch will not be processed until approved by an admin.
    BATCH_MAX_WITH_DUNS = 12000     # Threshold for "matched" records (those with a DUNS#) in a batch. If more than this, batch will be rejected.
    MODULE_NAME = 'SubmitCaseApiService'
    
    attachmentDao = None
    batchRequestDao = None
    updateEventDao = None
    batchFileParser = None
    submitCaseApiValidationService = None
    submitCaseApiTransformationService = None
    submitCaseApiSubmissionService = None
    notificationHelper = None
    sqsHelper = None
    requestAttachmentLinkService = None
    loginSessionDao = None
    

    def __init__(self, dbConn, s3handle, lambdaClient, snsClient, s3handleForAttachments):
        self.dbConn = dbConn
        self.s3handle = s3handle
        self.lambdaClient = lambdaClient
        self.snsClient = snsClient
        self.s3handleForAttachments = s3handleForAttachments
        self.attmObj = None
        self.batchRecord = None
        self.singleRequestRecord = None # for non-batch processing
        self.dbObj = None

        
    def loadAttachmentFromDatabase(self, attmId):
        if not attmId or int(attmId) < 1:
            raise LambdaValidationException('attmId not provided or not valid')
        if not SubmitCaseApiService.attachmentDao:
            SubmitCaseApiService.attachmentDao = AttachmentDao()
        dict_rslt = SubmitCaseApiService.attachmentDao.queryAttachment(self.dbConn, attmId)
        if dict_rslt:
            self.attmObj = mapToAttachmentObj(dict_rslt)
        else:
            logging.error('SubmitCaseApiService: attachment not found: attmId=' + str(self.attmObj.getAttachmentId()))
            raise LambdaValidationException('attachment not found')

        logging.info('SubmitCaseApiService.loadAttachmentFromDatabase: ' + str(self.attmObj))
        return self.attmObj
    
    
    def loadBatchFromDatabase(self, requestContext, batchRequestId, startingRecordNumber):
        self.batchRecord = None
        if not batchRequestId or int(batchRequestId) < 1:
            raise LambdaValidationException('batchRequestId not provided or not valid')
        if not SubmitCaseApiService.batchRequestDao:
            SubmitCaseApiService.batchRequestDao = BatchRequestDao()
        dict_rslt = SubmitCaseApiService.batchRequestDao.getBatchRecord(self.dbConn, batchRequestId)
        if dict_rslt:
            self.batchRecord = BatchRecord()
            self.batchRecord.startingRecordNumber = startingRecordNumber
            self.batchRecord.mapFromDict(dict_rslt)
            self._setRequestMethodCodeInSession(requestContext)
            return self._loadBatchDetailsFromDatabase(batchRequestId)
        else:
            errmsg = f"batch not found: batchRequestId={batchRequestId}"
            logging.error(f'SubmitCaseApiService: {errmsg}')
            raise LambdaValidationException(errmsg)
        
    
    def processBatchFile(self, requestContext, localFileName=None, startingRecordNumber=None):
        '''
        Processes a mini-batch file from an uploaded attachment
        Note: localFileName parameter is intended to use for local testing only without need of an attachment (non-production scenario)
        '''
        requestContext.serviceDict['submitCaseType'] = SubmitCaseType.MINI_BATCH.value
        logging.info('SubmitCaseApiService.processBatchFile: attmId=' + str(self.attmObj.getAttachmentId()))
        if not SubmitCaseApiService.batchFileParser:
            SubmitCaseApiService.batchFileParser = BatchFileParser()
        
        self.batchRecord = createBatchRecord(self.attmObj)
        self.batchRecord.startingRecordNumber = startingRecordNumber
        if self.attmObj.getBatchStatusCode() == BatchStatusCode.PARSED.value:
            logging.warning('BatchReqId=' + str(self.attmObj.getBatchRequestId()) + ' batchStatus=' + str(self.attmObj.getBatchStatusCode()) + ' has already been PARSED - ignoring request.')
            return {
                "batchRequestId": self.batchRecord.batchRequestId
            }
                
        try:
            # Validate that the request looks good (high level)
            self._validateBatchRequest()
            
            # Download file from S3 to local storage for parsing
            if not localFileName:
                SubmitCaseApiService.batchFileParser.downloadFromS3ToLocal(self.attmObj, self.s3handle)
            
            # Parse the file into json
            if localFileName:
                self.batchRecord.localFileName = localFileName
                miniBatchRecords = SubmitCaseApiService.batchFileParser.parseFile(self.batchRecord)
            else:
                self.batchRecord.localFileName = self.attmObj.getLocalFileName()
                miniBatchRecords = SubmitCaseApiService.batchFileParser.parseFile(self.batchRecord)
            logging.info(f'processMiniBatch: Read {len(miniBatchRecords)} records from spreadsheet.')
            #logging.debug('processMiniBatch: miniBatchRecords=' + str(miniBatchRecords))
        except LambdaProcessingException as lpe:
            logging.error(apiErrors.FAILBATCH_TECHNICAL_FAILURE + ': ' + SubmitCaseApiService.batchFileParser.getSheetName(self.batchRecord) + ' from spreadsheet ' + self.attmObj.getLocalFileName() + ': error = %s', lpe)
            self._failBatch(requestContext, apiErrors.FAILBATCH_TECHNICAL_FAILURE, lpe.errmsg)
            return {}
        except Exception as e: 
            logging.error(apiErrors.FAILBATCH_BAD_MINIBATCH_SPREADSHEET + ': reading sheet ' + SubmitCaseApiService.batchFileParser.getSheetName(self.batchRecord) + ' from spreadsheet ' + self.attmObj.getLocalFileName() + ': error = %s', e)
            self._failBatch(requestContext, apiErrors.FAILBATCH_BAD_MINIBATCH_SPREADSHEET, str(e))
            return {}
        finally:
            # Cleanup: delete the local file when done
            if not localFileName:
                SubmitCaseApiService.batchFileParser.deleteLocalFile(self.attmObj)
            
        self._storeMiniBatchRecordsIntoBatchRecord(miniBatchRecords, requestContext)
        return self._processBatchRecords(requestContext)
        
        
    def _storeMiniBatchRecordsIntoBatchRecord(self, miniBatchRecords, requestContext):
        # Store all the records into batchRecord
        rowNumberInFile = BatchFileParser.MINIBATCH_NUM_HEADER_ROWS
        recordNumber = 0
        for rec in miniBatchRecords:
            rowNumberInFile += 1
            recordNumber += 1
            if isEmptyDictionary(rec):
                # Stop at first blank row in spreadsheet
                logging.info(f"_storeMiniBatchRecordsIntoBatchRecord: Stopping at blank line rowNumberInFile={rowNumberInFile}")
                break
            
            rec[apiFields.API_FLD_INTERNAL_REF_ID] = str(recordNumber)
            # Duplicate the requestorOwnRequestKey so the database virtual column v_reqr_own_reqs_key works
            requestorOwnRequestKey = rec.get(apiFields.MNB_FLD_REQUEST_KEY)
            if isNotBlank(requestorOwnRequestKey):
                rec[apiFields.IRSCH_FLD_REQUEST_KEY] = str(requestorOwnRequestKey)
            requestRecord = RequestRecord()
            requestRecord.originalRecords = [ rec ]
            requestRecord.recordNumber = recordNumber
            self.batchRecord.requestRecords.append(requestRecord)


    def processBatchFromDetails(self, requestContext):
        if not SubmitCaseApiService.batchFileParser:
            SubmitCaseApiService.batchFileParser = BatchFileParser()
        self._processBatchRecords(requestContext)
    
    def _processBatchRecords(self, requestContext):
        # Transform all the records into standard batch schema and submit them
        for requestRecord in self.batchRecord.requestRecords:
            try:
                SubmitCaseApiService.batchFileParser.transformToSchema(requestContext, requestRecord)
            except Exception as e1:
                logging.error(f"_processBatchRecords transformToSchema error = {e1} on recordNumber={requestRecord.recordNumber}")
                requestRecord.addRejection(RequestRejectionError(jsonPathName=None, errorDescription=apiErrors.FAILREC_FAILED_PARSING_RECORD, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
            
        try:
            if self._isParseStep(requestContext):
                SubmitCaseApiService.batchFileParser.validateRecordCount(self.batchRecord.requestRecords)
            result = self.processBatch(requestContext)
            return result
        except LambdaValidationException as e:
            logging.error('_processBatchRecords error = %s', e)
            self._failBatch(requestContext, e.errmsg, str(e))
            return {}
    
    
    def _failBatch(self, requestContext, summaryMsg, detailedErrMsg):
        self._updateBatchCounts(requestContext)
        self.batchRecord.processingStatusCode = BatchStatusCode.REJECTED.value
        self.batchRecord.batchRejectionErrorText = summaryMsg
        if isNotBlank(detailedErrMsg):
            self.batchRecord.batchRejectionErrorText += ': ' + detailedErrMsg
        self._updateBatchDB(requestContext)
        self._notifyUser(requestContext, BatchWatchTypeCode.BATCH_REJECTED.value, batchRequestId=self.batchRecord.batchRequestId)
        self._notifyBatchRejects(requestContext)
        #raise LambdaValidationException(summaryMsg)
    
    
    def _validateBatchRequest(self):
        '''
        Validates the request (not the contents of the batch file)
        If any failures, raises an exception
        '''
        if self.attmObj.getProcessStatusCd() != constants.PROCESSING_COMPLETE:
            logging.error('AttmId=' + str(self.attmObj.getAttachmentId()) + ' status=' + str(self.attmObj.getProcessStatusCd()) + ' is not in processing completed status')
            raise LambdaConflictException('AttmId=' + str(self.attmObj.getAttachmentId()) + ' status=' + str(self.attmObj.getProcessStatusCd()) + ' is not in processing completed status')
        if self.attmObj.getBatchFormatCode() != BatchFormatCode.EXCEL_SPREADSHEET.value:
            logging.error('AttmId=' + str(self.attmObj.getAttachmentId()) + ' formatCd=' + str(self.attmObj.getBatchFormatCode()) + ' is not a minibatch format file')
            raise LambdaConflictException('AttmId=' + str(self.attmObj.getAttachmentId()) + ' formatCd=' + str(self.attmObj.getBatchFormatCode()) + ' is not a minibatch format file')
    
    
    def processBatch(self, requestContext):
        try:
            result = self._processBatchImpl(requestContext)
        except Exception as e: 
            logging.error(apiErrors.FAILBATCH_TECHNICAL_FAILURE + ': _processBatchImpl error = %s', e)
            self._failBatch(requestContext, apiErrors.FAILBATCH_TECHNICAL_FAILURE, str(e))
            # Propagate exception to generate alert
            raise
        
        return result

    
    def _processBatchImpl(self, requestContext):
        '''
        This is the generic batch processing function, used after the batch has been converted into standardized form.
        '''
        self._createTransactionProcessingServices(requestContext)
            
        rejectCount = 0
        totalCt = 0
        hasDunsCt = 0
        for requestRecord in self.batchRecord.requestRecords:
            totalCt += 1
            try:
                if self._isParseStep(requestContext) and not requestRecord.isRejected():
                    SubmitCaseApiService.submitCaseApiValidationService.validateRecord(requestContext, requestRecord, self.batchRecord)
                    SubmitCaseApiService.submitCaseApiValidationService.validateBatchRecordSchema(requestContext, requestRecord)
            except Exception as e:
                logging.error(apiErrors.FAILBATCH_TECHNICAL_FAILURE + ': _processBatchImpl validateRecord error = %s', e)
                err = RequestRejectionError(errorDescription=apiErrors.FAILREC_TECHNICAL_ERROR)
                requestRecord.addRejection(err, RejectionReasonCode.VALIDATION_ERROR)
                
            if requestRecord.isRejected():
                rejectCount += 1
            else:
                duns = jmespath.search(apiFields.IRSCH_FULL_FLD_DUNS, requestRecord.apiSchemaRecords[0])
                if isNotBlank(duns):
                    hasDunsCt += 1
            
        if rejectCount > SubmitCaseApiService.BATCH_MAX_REJECTS and self._isParseStep(requestContext):
            logging.error(apiErrors.FAILBATCH_THRESHOLD_EXCEEDED + ': ' + str(rejectCount) + ' rejected records exceeds the maximum allowed rejects of ' + str(SubmitCaseApiService.BATCH_MAX_REJECTS))
            #self._insertBatchDetail(requestContext)
            self._failBatch(requestContext, apiErrors.FAILBATCH_THRESHOLD_EXCEEDED, str(rejectCount) + ' rejected records exceeds the maximum allowed rejects of ' + str(SubmitCaseApiService.BATCH_MAX_REJECTS))
        elif totalCt == 0:
            logging.error(apiErrors.FAILBATCH_NO_RECORDS)
            if self._isParseStep(requestContext):
                #self._insertBatchDetail(requestContext)
                self._failBatch(requestContext, apiErrors.FAILBATCH_NO_RECORDS, None)
        elif hasDunsCt > SubmitCaseApiService.BATCH_MAX_WITH_DUNS:
            logging.error(apiErrors.FAILBATCH_MAX_DUNS_RECORDS_EXCEEDED + f" hasDunsCt={hasDunsCt} maxDunsCt={SubmitCaseApiService.BATCH_MAX_WITH_DUNS}")
            if self._isParseStep(requestContext):
                #self._insertBatchDetail(requestContext)
                self._failBatch(requestContext, apiErrors.FAILBATCH_MAX_DUNS_RECORDS_EXCEEDED, None)
        else:
            SubmitCaseApiService.submitCaseApiTransformationService.combineRequests(requestContext, self.batchRecord)
            SubmitCaseApiService.submitCaseApiTransformationService.transformBatchToIResearch(requestContext, self.batchRecord)
            
            # Need to check again on max reject threshold in case more records were rejected during the combine/transform steps
            rejectCount = 0
            for requestRecord in self.batchRecord.requestRecords:
                if requestRecord.isRejected():
                    rejectCount += 1
    
            if rejectCount > SubmitCaseApiService.BATCH_MAX_REJECTS and self._isParseStep(requestContext):
                logging.error(apiErrors.FAILBATCH_THRESHOLD_EXCEEDED + ': ' + str(rejectCount) + ' rejected records exceeds the maximum allowed rejects of ' + str(SubmitCaseApiService.BATCH_MAX_REJECTS))
                #self._insertBatchDetail(requestContext)
                self._failBatch(requestContext, apiErrors.FAILBATCH_THRESHOLD_EXCEEDED, str(rejectCount) + ' rejected records exceeds the maximum allowed rejects of ' + str(SubmitCaseApiService.BATCH_MAX_REJECTS))
            else:
                if self._isSubmitStep(requestContext):
                    SubmitCaseApiService.submitCaseApiSubmissionService.submitAllRequests(requestContext, self.batchRecord)
                if self._isParseStep(requestContext):
                    self._insertBatchDetail(requestContext)
                    if self.batchRecord.isParseInProgress == True:
                        logging.info("_processBatchImpl skipping database update because parse is incomplete")
                    else:
                        self.updateBatch(requestContext)
        
        return {
            "batchRequestId": self.batchRecord.batchRequestId
        }


    def _createTransactionProcessingServices(self, requestContext):
        if not SubmitCaseApiService.batchRequestDao:
            SubmitCaseApiService.batchRequestDao = BatchRequestDao()
        if not SubmitCaseApiService.submitCaseApiTransformationService:
            SubmitCaseApiService.submitCaseApiTransformationService = SubmitCaseApiTransformationService()
        if not SubmitCaseApiService.submitCaseApiSubmissionService:
            SubmitCaseApiService.submitCaseApiSubmissionService = SubmitCaseApiSubmissionService(self.lambdaClient, self.dbConn, SubmitCaseApiService.batchRequestDao)
            
        if self.dbObj is not None:
            # warm start
            logging.info('SubmitCaseApiService warm start - testing database connection...')
            self.dbObj.checkConnection()
            logging.info('SubmitCaseApiService continuing after database connection tested')
        else:
            logging.info('Initializing databaseClass...')
            self.dbObj = databaseClass(requestContext.environDict)
            logging.info('SubmitCaseApiService continuing after database connection created')
            
        if not SubmitCaseApiService.requestAttachmentLinkService:
            SubmitCaseApiService.requestAttachmentLinkService = RequestAttachmentLinkService(self.dbObj, self.s3handleForAttachments, self.dbConn)
        if not SubmitCaseApiService.submitCaseApiValidationService:
            SubmitCaseApiService.submitCaseApiValidationService = SubmitCaseApiValidationService(self.dbConn, SubmitCaseApiService.requestAttachmentLinkService)
        

    def updateBatch(self, requestContext):
        '''
        Handles the updating of the batch for the success flow
        '''
        # Re-read from database, don't update if batch already in PARSED status (handle retry gracefully)
        attmId = self.attmObj.getAttachmentId()
        requestContext.cacheObj = self.loadAttachmentFromDatabase(attmId)
        if self.attmObj.getBatchStatusCode() == BatchStatusCode.PARSED.value:
            logging.warning('Not updating batch BatchReqId=' + str(self.attmObj.getBatchRequestId()) + ' batchStatus=' + str(self.attmObj.getBatchStatusCode()) + ' has already been PARSED.')
            return

        self._updateBatchCounts(requestContext)
        self.batchRecord.processingStatusCode = BatchStatusCode.PARSED.value
        self._updateBatchDB(requestContext)
        self._notifyBatchRejects(requestContext)


    def _updateBatchCounts(self, requestContext):
        totalCt = 0
        totalDetailCt = 0
        rejectCt = 0
        for requestRecord in self.batchRecord.requestRecords:
            totalDetailCt += 1
            if not requestRecord.isSuppressed:
                totalCt += 1
            if requestRecord.isRejected():
                rejectCt += 1
                
        self.batchRecord.totalEntriesCount = totalCt
        self.batchRecord.totalDetailsCount = totalDetailCt
        self.batchRecord.rejectedEntriesCount = rejectCt
    
            
    def _updateBatchDB(self, requestContext):
        '''
        Updates the batch and rejects in the database
        '''
        if not SubmitCaseApiService.batchRequestDao:
            SubmitCaseApiService.batchRequestDao = BatchRequestDao()
        if not SubmitCaseApiService.updateEventDao:
            SubmitCaseApiService.updateEventDao = UpdateEventDao()
        
        logging.info('Updating ' + str(self.batchRecord))
        SubmitCaseApiService.batchRequestDao.updateBatchStatusAndCounts(self.dbConn, self.batchRecord, SubmitCaseApiService.MODULE_NAME)
        SubmitCaseApiService.updateEventDao.insertEvent(self.dbConn, requestContext.userSession.userId, updateEventConstants.AUDIT_BATCH_REQUEST_TABLE,
                                        self.batchRecord.batchRequestId, updateEventConstants.AUDIT_ELEMENT_BATCH_STATUS,
                                        self.batchRecord.processingStatusCode, self.batchRecord.processingStatusCode, UpdateActionCode.MODIFY.value, None,
                                        requestContext.userSession.sessionToken, None, SubmitCaseApiService.MODULE_NAME)

        for requestRecord in self.batchRecord.requestRecords:
            if requestRecord.isRejected():
                logging.error('RequestRejectionErrors on batchRequestId=' + str(self.batchRecord.batchRequestId) + ' InternalRefIds=' + requestRecord.getInternalRefIds() + ': ' + requestRecord.requestRejectionErrorsToString())
                if requestRecord.rejectionReasonCode == RejectionReasonCode.PREVIOUSLY_DETECTED_ERROR:
                    logging.info(f"Skip previously detected database write for batchRequestId={self.batchRecord.batchRequestId} recordNumber={requestRecord.recordNumber}")
                    continue
                #print('requestRecord.originalRecords=' + str(requestRecord.originalRecords))
                originalRecordsJson = json.dumps(requestRecord.originalRecords[0])
                #print('requestRecord.requestRejectionErrors=' + str(requestRecord.requestRejectionErrorsToDict()))
                requestRejectionErrorsJson = json.dumps(requestRecord.requestRejectionErrorsToDict())
                batchRequestRejectId = SubmitCaseApiService.batchRequestDao.insertRejectRecord(self.dbConn, self.batchRecord.batchRequestId,originalRecordsJson,
                                                                        requestRejectionErrorsJson, SubmitCaseApiService.MODULE_NAME)
                logging.info('Inserted batchRequestRejectId=' + str(batchRequestRejectId) + ' on batchRequestId=' + str(self.batchRecord.batchRequestId))
                requestRecord.batchRequestRejectId = batchRequestRejectId
                rejectionReason = requestRecord.rejectionReasonCode.value if requestRecord.rejectionReasonCode else None 
                SubmitCaseApiService.updateEventDao.insertEvent(self.dbConn, requestContext.userSession.userId, updateEventConstants.AUDIT_REQUEST_REJECT_TABLE,
                                                self.batchRecord.batchRequestId, updateEventConstants.AUDIT_ELEMENT_REJECT_ID,
                                                str(batchRequestRejectId), self.batchRecord.processingStatusCode, UpdateActionCode.ADD.value, rejectionReason,
                                                requestContext.userSession.sessionToken, None, SubmitCaseApiService.MODULE_NAME)
                
                
    def _notifyBatchRejects(self, requestContext):
        for requestRecord in self.batchRecord.requestRecords:
            if requestRecord.isRejected():
                self._notifyUser(requestContext, BatchWatchTypeCode.REQUEST_REJECTED.value, batchRequestRejectId=requestRecord.batchRequestRejectId, batchRequestId=self.batchRecord.batchRequestId)
    
    
    def _notifyUser(self, requestContext, notificationTypeCode, researchRequestId=None, subjectResearchId=None, batchRequestId=None, batchRequestRejectId=None):
        try:
            sqsUrl = requestContext.environDict.get(envVblNames.ENV_BATCH_WATCH_QUEUE_URL)
        except KeyError:
            sqsUrl = None
        if sqsUrl is None:
            if not SubmitCaseApiService.notificationHelper:
                # SNS message to Notification service
                notificationTopicARN = requestContext.environDict.get(envVblNames.ENV_NOTIFICATION_TOPIC_ARN)
                SubmitCaseApiService.notificationHelper = NotificationHelper(self.snsClient, notificationTopicARN)
            SubmitCaseApiService.notificationHelper.triggerClientNotification(notificationTypeCode, researchRequestId=researchRequestId, subjectResearchId=subjectResearchId, batchRequestId=batchRequestId, batchRequestRejectId=batchRequestRejectId)
        else:
            # SQS message to BatchWatch service
            msgJson = self.generateMsgJson(notificationTypeCode, researchRequestId=researchRequestId, subjectResearchId=subjectResearchId, batchRequestId=batchRequestId, batchRequestRejectId=batchRequestRejectId)
            if not SubmitCaseApiService.sqsHelper:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                SubmitCaseApiService.sqsHelper = SqsHelper(queueUrl=sqsUrl, regionName=regionName)
            SubmitCaseApiService.sqsHelper.sendMessageToQueue(msgJson)
            
    def generateMsgJson(self, notificationTypeCode, researchRequestId=None, subjectResearchId=None, batchRequestId=None, batchRequestRejectId=None):
        messageBody = {
                        "batchWatchTypeCode" : notificationTypeCode
                      }
        if batchRequestId is None:
            raise ValueError("batchRequestId cannot be None")
        else:
            messageBody["batchRequestId"] = batchRequestId
            if researchRequestId is not None:
                messageBody["researchRequestId"] = researchRequestId
            if subjectResearchId is not None:
                messageBody["subjectResearchId"] = subjectResearchId
            if batchRequestRejectId is not None:
                messageBody["batchRequestRejectId"] = batchRequestRejectId
            messageBody["message"] = "Will be edited in future"
            msg = json.dumps(messageBody)
            return msg
    
    
    def processSubmitResearchRequest(self, requestContext):
        '''
        Main entry point to process a new ResearchRequest via API
        '''
        requestContext.serviceDict['submitCaseType'] = SubmitCaseType.API.value
        self._createTransactionProcessingServices(requestContext)
        # Report any validation errors based on json path
        #SubmitCaseApiService.submitCaseApiValidationService.fieldNameReportType = FieldNameReportType.JSON_SHORTENED_PATH_NAME
        try:
            responseRecord = self._processSubmitResearchRequestImpl(requestContext)
            
        except Exception as e:
            logging.error('processSubmitResearchRequest error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            # TODO retry if not a LambdaValidationException
            # Propagate exception to send back error result and set http error code
            requestRejection = RequestRejection(RejectionReasonCode.INTERNAL_ERROR, rejectionErrorMessage=errorMessages.ERR_INTERNAL_REQUEST)
            if isinstance(e, LambdaProcessingException):
                if e.requestRejection is None:
                    e.requestRejection = requestRejection
                raise e
            else:
                # Make sure we have requestRejection so client gets back properly formatted response
                raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST, requestRejection=requestRejection)
        
        return responseRecord


    def _processSubmitResearchRequestImpl(self, requestContext):
        self.singleRequestRecord = RequestRecord()
        self.singleRequestRecord.originalRecords.append(removeEmptyFromDictionary(requestContext.incomingContent, nPasses=5))
        responseRecord = None
        SubmitCaseApiService.submitCaseApiValidationService.validateApiRecordSchema(requestContext, self.singleRequestRecord)
        #if not self.singleRequestRecord.isRejected():
        SubmitCaseApiService.submitCaseApiTransformationService.transformOneApiRecord(requestContext, self.singleRequestRecord)
        #if not self.singleRequestRecord.isRejected():
        SubmitCaseApiService.submitCaseApiValidationService.validateRecord(requestContext, self.singleRequestRecord, None)
        if not self.singleRequestRecord.isRejected():
            SubmitCaseApiService.submitCaseApiTransformationService.transformOneRecordToIResearch(requestContext, self.singleRequestRecord)
        if self.singleRequestRecord.isRejected():
            requestRejection = RequestRejection(self.singleRequestRecord.rejectionReasonCode, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        else:
            submitCaseResultDict = SubmitCaseApiService.submitCaseApiSubmissionService.submitOneRequest(requestContext, self.singleRequestRecord, invokeType=lambdaConstants.INVOKE_LAMBDA_REQUEST_RESPONSE)
            statusCode = submitCaseResultDict[SubmitCaseApiSubmissionService.RESULT_STATUS_CODE]
            if statusCode == LambdaStatusCodes.OK.value or statusCode == LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
                attachmentResultDict = self._processAttachmentRequests(requestContext, submitCaseResultDict[SubmitCaseApiSubmissionService.RESULT_BODY])
                statusCode = attachmentResultDict[SubmitCaseApiSubmissionService.RESULT_STATUS_CODE]
                if statusCode == LambdaStatusCodes.OK.value or statusCode == LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
                    responseRecord = SubmitCaseApiService.submitCaseApiTransformationService.transformOneIresearchToApiResponse(requestContext, self.singleRequestRecord, submitCaseResultDict[SubmitCaseApiSubmissionService.RESULT_BODY], self.singleRequestRecord.attachments)
                else:
                    self._handleSubmitCaseFailure(requestContext, attachmentResultDict, statusCode)
            else:
                self._handleSubmitCaseFailure(requestContext, submitCaseResultDict, statusCode)
        
        return responseRecord
    
    
    def _handleSubmitCaseFailure(self, requestContext, resultDict, statusCode):
        logging.error('_handleSubmitCaseFailure: resultDict=' + str(resultDict))
        responseBody = resultDict[SubmitCaseApiSubmissionService.RESULT_BODY]
        errmsg = None
        if responseBody is not None:
            errorResponse = responseBody.get("errorResponse")
            if errorResponse is not None:
                errmsg = errorResponse.get("errorMessage")
        if statusCode == LambdaStatusCodes.BAD_REQUEST.value or statusCode == LambdaStatusCodes.NOT_FOUND.value:
            requestRejection = RequestRejection(self.singleRequestRecord.rejectionReasonCode, rejectionErrors=self.singleRequestRecord.requestRejectionErrors)
            raise LambdaValidationException(errorMessages.ERR_VALIDATION_FAILURE, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.FORBIDDEN.value:
            if errmsg is None:
                errmsg = errorMessages.ERR_NOT_AUTHORIZED
            requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR, rejectionErrorMessage=errmsg)
            raise LambdaAuthorizationException(errmsg, requestRejection=requestRejection)
        elif statusCode == LambdaStatusCodes.UNAUTHORIZED.value:
            raise LambdaAuthenticationException(errorMessages.ERR_NOT_AUTHENTICATED)
        else:
            #Other technical error
            requestRejection = RequestRejection(RejectionReasonCode.INTERNAL_ERROR, rejectionErrorMessage=errorMessages.ERR_INTERNAL_REQUEST)
            raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST, requestRejection=requestRejection)
        
        
    def _insertBatchDetail(self, requestContext):
        SubmitCaseApiService.submitCaseApiTransformationService.transformBatchToBatchDetail(requestContext, self.batchRecord)
        submitCaseBatchParserQueueUrl = requestContext.environDict.get(envVblNames.ENV_SUBMITCASEBATCHPARSER_QUEUE_URL)
        SubmitCaseApiService.submitCaseApiSubmissionService.submitAllBatchDetailRequests(requestContext, self.batchRecord, submitCaseBatchParserQueueUrl)
        '''
        if not SubmitCaseApiService.batchRequestDao:
            SubmitCaseApiService.batchRequestDao = BatchRequestDao()
        logging.info("_insertBatchDetail start: Create new dbConn")
        # Create special dbConn without autocommit
        dbConnForBatch = DatabaseConnection(requestContext.environDict, autocommit=False)
        logging.info("_insertBatchDetail start insert")
        try:
            nrecsInserted = SubmitCaseApiService.batchRequestDao.insertBatchDetailRecords(dbConnForBatch, self.batchRecord.batchRequestId, self.batchRecord.requestRecords, SubmitCaseApiService.MODULE_NAME)
            logging.info(f"_insertBatchDetail commit: nrecsInserted={nrecsInserted}")
            dbConnForBatch.commit()
            logging.info("_insertBatchDetail end")
        finally:
            logging.info("_insertBatchDetail closing dbConnForBatch")
            dbConnForBatch.close()
        '''


    def _loadBatchDetailsFromDatabase(self, batchRequestId):
        dict_rslt = SubmitCaseApiService.batchRequestDao.getBatchDetails(self.dbConn, batchRequestId)
        for rec in dict_rslt:
            logging.debug(f"_loadBatchDetailsFromDatabase rec={rec}")
            rr = RequestRecord()
            rr.batchDetailRecord = rec
            origrec = json.loads(rec.get("raw_data_obj"))
            rr.originalRecords.append(origrec)
            rr.recordNumber = rec.get("rec_nbr")
            isRejected = rec.get("rej_indc")
            if isRejected != 0:
                rr.addRejection(apiErrors.FAILREC_PREVIOUSLY_DETECTED, RejectionReasonCode.PREVIOUSLY_DETECTED_ERROR)
            rr.batchRequestRejectId = rec.get("btch_rsch_reqs_rej_id")
                
            self.batchRecord.requestRecords.append(rr)
        
        
    def _isParseStep(self, requestContext):
        step = requestContext.serviceDict.get("step")
        if step == SubmitCaseStep.SUBMIT_CASE_BATCH_PARSER:
            return True
        return False
            
        
    def _isSubmitStep(self, requestContext):
        step = requestContext.serviceDict.get("step")
        if step == SubmitCaseStep.SUBMIT_CASE_BATCH_SUBMITTER:
            return True
        return False


    def _processAttachmentRequests(self, requestContext, iResearchResponseBody):
        resultDict = {
            SubmitCaseApiSubmissionService.RESULT_STATUS_CODE: LambdaStatusCodes.OK.value,
            SubmitCaseApiSubmissionService.RESULT_ERR_MSG: None,
            SubmitCaseApiSubmissionService.RESULT_BODY: None
        }
        if len(self.singleRequestRecord.attachments) == 0:
            # No attachments in request
            return resultDict
        
        researchRequest = iResearchResponseBody.get(apiFields.IRSCH_RESP_RESEARCH_REQUEST)
        if researchRequest is None or researchRequest.get(apiFields.BOTH_RESP_RESEARCH_REQUEST_ID) is None:
            logging.error('_processAttachmentRequests got an invalid response from SubmitCase (failed to get researchRequestId): ' + str(iResearchResponseBody))
            raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST) 
        researchRequestId = researchRequest.get(apiFields.BOTH_RESP_RESEARCH_REQUEST_ID)
        
        for attmObj in self.singleRequestRecord.attachments:
            attmObj.setIncomingAttachmentKey(str(researchRequestId))
            try:
                logging.info("_processAttachmentRequests: requestAttachmentLink for ")
                attmResponseBody = SubmitCaseApiService.requestAttachmentLinkService.processAttachmentRequest(requestContext, attmObj)
                attmObj.setRequestAttachmentLinkResponse(attmResponseBody)
            except Exception as e:
                logging.error(f"_processAttachmentRequests failed for {attmObj.getIncomingFileName()}: {e}")
                resultDict[SubmitCaseApiSubmissionService.RESULT_STATUS_CODE] = LambdaStatusCodes.INTERNAL_SERVER_ERROR.value
                resultDict[SubmitCaseApiSubmissionService.RESULT_ERR_MSG] = f"Internal error processing attachment {attmObj.getIncomingFileName()}"
                
        return resultDict


    def _setRequestMethodCodeInSession(self, requestContext):
        if SubmitCaseApiService.loginSessionDao is None:
            SubmitCaseApiService.loginSessionDao = LoginSessionDao()
        if requestContext.userSession is None:
            requestContext.userSession = UserSession(None)
        if self.batchRecord.authPrinIdObj is not None:
            userSessDict = SubmitCaseApiService.loginSessionDao.queryLoginSessionByUserIdAndToken(self.dbConn, self.batchRecord.userId, self.batchRecord.sessionToken)
            if userSessDict is not None:
                authPrinIdObj = userSessDict.get('auth_prin_id_obj')
                if authPrinIdObj is not None:
                    authPrinId = json.loads(authPrinIdObj)
                    applicationId = authPrinId.get('applicationId')
                    if applicationId is not None:
                        # TODO build cache mapping applicationId's to requestMethodCode's
                        if applicationId == RequestMethodCode.CUSTOMER_FILE_PROCESSING.value:
                            requestContext.userSession.requestMethodCode = RequestMethodCode.CUSTOMER_FILE_PROCESSING.value

        if requestContext.userSession.requestMethodCode is None:
            # default to UI
            requestContext.userSession.requestMethodCode = RequestMethodCode.IRESEARCH_UI.value
        logging.info(f"_setRequestMethodCodeInSession: userSession={requestContext.userSession}")
    