'''
@author: VanCampK
'''
import copy
import jmespath
import json
import logging

from attachmentClass import attachment
from common.commentTypeCodes import CommentTypeCode
from common.util.dictUtils import mergeDictionaries, removeEmptyFromDictionary, removeEmptyValsFromArrayIfOnlyTypeCode
from common.util.stringUtils import isBlank, isNotBlank, convertNewlines
from common.rejectionReasonCodes import RejectionReasonCode
import constants
from lambdas import errorMessages
from lambdas.exceptions import LambdaProcessingException
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.submitcaseapi.converters import Converters
from lambdas.submitcaseapi import submitCaseApiFields as apiFields
import lambdas.submitcaseapi.submitCaseApiErrors as apiErrors
from lambdas.submitcaseapi.submitCaseApiUtil import getDunsFromIResearchSchemaRecord, getResearchSubTypesFromIResearchSchemaRecord, getResearchTypesFromIResearchSchemaRecord, replaceResearchTypesInIResearchSchemaRecord
from lambdas.submitcaseapi.submitCaseType import SubmitCaseType
from lambdas.submitcaseapi.submitCaseApiValidationService import SubmitCaseApiValidationService


class SubmitCaseApiTransformationService(object):
    '''
    Performs record-level transformations for the Submit Case Api service
    '''


    def transformBatchToIResearch(self, requestContext, batchRecord):
        '''
        Transforms all non-rejected and non-suppressed records into the iResearch SubmitCase API schema.
        '''
        for requestRecord in batchRecord.requestRecords:
            if not requestRecord.isRejected() and not requestRecord.isSuppressed:
                self.transformOneRecordToIResearch(requestContext, requestRecord, batchRecord.batchRequestId)
    
    
    def transformOneRecordToIResearch(self, requestContext, requestRecord, batchRequestId=None):
        '''
        Transforms the fields from API json schema into the iResearch SubmitCase API schema.
        Reads requestRecord.apiSchemaRecords and creates requestRecord.iResearchSchemaRecord
        '''
        irschDict = copy.deepcopy(requestRecord.apiSchemaRecords[0])
        # Compress dictionary by removing None's and empty arrays (or arrays that have nothing but a type code)
        if irschDict["subjectResearch"]["submittedData"].get("addresses") is not None:
            removeEmptyValsFromArrayIfOnlyTypeCode(irschDict["subjectResearch"]["submittedData"]["addresses"], "addressUsageTypeCode")
        removeEmptyValsFromArrayIfOnlyTypeCode(irschDict["subjectResearch"]["researchTypes"], "researchSubTypeCode")
        if irschDict.get("researchComments") is not None:
            removeEmptyValsFromArrayIfOnlyTypeCode(irschDict["researchComments"], "commentTypeCode")
        requestRecord.iResearchSchemaRecord = removeEmptyFromDictionary(irschDict, nPasses=5)

        if batchRequestId is not None:
            # Add batchRequestId
            requestRecord.iResearchSchemaRecord[apiFields.IRSCH_FLD_BATCH_REQ_ID] = batchRequestId

        # Add batchResearchRequest (original payload from client)
        requestRecord.iResearchSchemaRecord[apiFields.IRSCH_FLD_BATCH_RESEARCH_REQUEST] = removeEmptyFromDictionary(copy.deepcopy(requestRecord.originalRecords[0]))

        subjRsch = requestRecord.iResearchSchemaRecord["subjectResearch"]
        Converters.convertDuns(subjRsch, requestRecord)
        Converters.convertTelephones(subjRsch, requestRecord)


    def combineRequests(self, requestContext, batchRecord):
        '''
        Combines multiple requests if they share the same DUNS, plus special rules for multi-child linkage.
        First we find all records that share a common DUNS:
        '''
        combineRecordsMap = self._buildCombineRecordMap(batchRecord)
        for key, cmbMap in combineRecordsMap.items():
            #duns = key
            requestRecords = cmbMap['requestRecords']
            if len(requestRecords) > 1:
                keepRecord = requestRecords[0]
                # Merge record 2..n into the first record and suppress all subsequent records
                for i in range(1,len(requestRecords)):
                    unusedRecord = requestRecords[i]
                    keepRecord.apiSchemaRecords.append(unusedRecord.apiSchemaRecords[0])
                    keepRecord.originalRecords.append(unusedRecord.originalRecords[0])
                    unusedRecord.isSuppressed = True
                    newInternalRefId = keepRecord.getInternalRefIds()
                    keepRschTypes = copy.deepcopy(getResearchTypesFromIResearchSchemaRecord(keepRecord.apiSchemaRecords[0]))
                    # compress comments
                    if unusedRecord.apiSchemaRecords[0].get("researchComments") is not None:
                        removeEmptyValsFromArrayIfOnlyTypeCode(unusedRecord.apiSchemaRecords[0]["researchComments"], "commentTypeCode")

                    keepComments = copy.deepcopy(keepRecord.apiSchemaRecords[0].get(apiFields.IRSCH_FLD_RESEARCH_COMMENTS))
                    #print(f"Before mergeDictionaries: keep={keepRecord.apiSchemaRecords[0]['researchComments']} unused={unusedRecord.apiSchemaRecords[0]['researchComments']}")
                    mergeDictionaries(keepRecord.apiSchemaRecords[0], unusedRecord.apiSchemaRecords[0])
                    #print(f"After mergeDictionaries: keep={keepRecord.apiSchemaRecords[0]['researchComments']}")
                    keepRecord.setInternalRefId(newInternalRefId)
                    newRschTypes = getResearchTypesFromIResearchSchemaRecord(unusedRecord.apiSchemaRecords[0])
                    newComments = unusedRecord.apiSchemaRecords[0].get(apiFields.IRSCH_FLD_RESEARCH_COMMENTS)
                    self._mergeRschTypes(keepRecord.apiSchemaRecords[0], keepRschTypes, newRschTypes)
                    self._mergeComments(keepRecord.apiSchemaRecords[0], keepComments, newComments)
                    #print(f"After _mergeComments: keep={keepRecord.apiSchemaRecords[0]['researchComments']}")


    def _buildCombineRecordMap(self, batchRecord):
        '''
        Builds a map from key to the request records that share that key.
        For now the key is just DUNS# but in the future will be expanded for multi-child linkage 
        { 
            '123456789': {
                'requestRecords': [ { all requestRecords with this duns } ]
                'rschSubTypes': [ list of all research sub-types among these requestRecords ]
            },
            ...
        }
        '''
        combineRecordsMap = {}
        for requestRecord in batchRecord.requestRecords:
            if not requestRecord.isRejected():
                duns = getDunsFromIResearchSchemaRecord(requestRecord.apiSchemaRecords[0])
                rschSubTypes = getResearchSubTypesFromIResearchSchemaRecord(requestRecord.apiSchemaRecords[0])
                if duns is not None and rschSubTypes is not None:
                    cmbMap = combineRecordsMap.get(duns)
                    if not cmbMap:
                        cmbMap = { }
                        cmbMap['requestRecords'] = [requestRecord]
                        cmbMap['rschSubTypes'] = rschSubTypes
                        combineRecordsMap[duns] = cmbMap
                    else:
                        allSubTypes = cmbMap['rschSubTypes']
                        for rschSubType in rschSubTypes:
                            if rschSubType in allSubTypes:
                                # Duplicate research sub-type rejected (until multi-child linkage)
                                requestRecord.addRejection(RequestRejectionError(jsonPathName=apiFields.MNB_FLD_RSCH_SUB_TYPE, errorDescription=apiErrors.FAILREC_DUPLICATE_RESEARCH_SUB_TYPE, providedValue=rschSubType), RejectionReasonCode.VALIDATION_ERROR)
                            elif rschSubType in SubmitCaseApiValidationService.STANDALONE_RESEARCH_SUBTYPES:
                                # Standalone research subtype cannot be combined with any other
                                requestRecord.addRejection(RequestRejectionError(jsonPathName=apiFields.MNB_FLD_RSCH_SUB_TYPE, errorDescription=apiErrors.FAILREC_STANDALONE_RESEARCH_SUBTYPE, providedValue=rschSubType), RejectionReasonCode.VALIDATION_ERROR)
                        if not requestRecord.isRejected():
                            cmbMap['requestRecords'].append(requestRecord)
                            for rschSubType in rschSubTypes:
                                allSubTypes.append(rschSubType)
                            
        return combineRecordsMap
    
    def _mergeRschTypes(self, rec, keepRschTypes, newRschTypes):
        for rschType in newRschTypes:
            keepRschTypes.append(rschType)
        replaceResearchTypesInIResearchSchemaRecord(rec, keepRschTypes)
        
        
    def _mergeComments(self, rec, keepComments, newComments):
        if keepComments is None and newComments is None:
            return
        #apiFields.IRSCH_FLD_RESEARCH_COMMENTS
        mergedComments = set()
        if keepComments is not None:
            for cmnt in keepComments:
                if isNotBlank(cmnt[apiFields.IRSCH_FLD_RESEARCH_COMMENT]):
                    # Convert dict to string because set must contain only immutables
                    cmntStr = json.dumps(cmnt, sort_keys=True)
                    mergedComments.add(cmntStr)
        
        if newComments is not None:
            for cmnt in newComments:
                if isNotBlank(cmnt[apiFields.IRSCH_FLD_RESEARCH_COMMENT]):
                    # Convert dict to string because set must contain only immutables
                    cmntStr = json.dumps(cmnt, sort_keys=True)
                    mergedComments.add(cmntStr)
                
        mergedCommentList = []
        for cmntStr in mergedComments:
            cmnt = json.loads(cmntStr)
            mergedCommentList.append(cmnt)
            
        if len(mergedCommentList) > 0:
            rec[apiFields.IRSCH_FLD_RESEARCH_COMMENTS] = mergedCommentList
        else:
            rec.pop(apiFields.IRSCH_FLD_RESEARCH_COMMENTS, None)
        
        
    def transformOneApiRecord(self, requestContext, requestRecord):
        '''
        Transforms an incoming D+ API submitResearchRequest into API record format, e.g.
        originalRecords[0] -> apiSchemaRecords[0]
        '''
        origRec = requestRecord.originalRecords[0]
        irschDict = {
            "researchRequest": {
                "requestMethodCode": requestContext.userSession.requestMethodCode,
                "requestorOrganizationName": requestContext.userSession.subscriberName,
                "requestorCountryCode": requestContext.userSession.subscriberCountry,
                apiFields.API_FLD_REQUESTOR_PREF_LANG_CODE: self._getRequestorPrefLangCode(origRec),
                #"internalDnbRequestorName": requestContext.userSession.emailId,
                apiFields.IRSCH_FLD_PRIORITY : origRec.get(apiFields.API_PATH_FLD_PRIORITY),
                apiFields.IRSCH_FLD_REQUEST_KEY: origRec.get(apiFields.API_FLD_REQUEST_KEY),
                apiFields.IRSCH_FLD_REQUEST_DESCRIPTION: origRec.get(apiFields.API_FLD_REQUEST_DESCRIPTION),
                apiFields.IRSCH_FLD_EXTERNAL_INVS_ID: origRec.get(apiFields.API_FLD_EXTERNAL_INVS_ID),
                apiFields.IRSCH_FLD_THIRD_PARTY_EMAILS: origRec.get(apiFields.API_FLD_THIRD_PARTY_EMAILS),
                apiFields.IRSCH_FLD_CUSTOMER_REF_NAME: origRec.get(apiFields.API_FLD_CUSTOMER_REF_NAME),
                apiFields.IRSCH_FLD_OTHER_APP_TRAN_ID: requestContext.userSession.applicationTranId,
                apiFields.IRSCH_FLD_USER_API_KEY_TYPE: requestContext.userSession.dnbUserAPIKeyType,
                apiFields.IRSCH_FLD_CUSTOMER_REF_EMAIL: requestContext.userSession.dnbUserEmailAddress,
                apiFields.IRSCH_FLD_SESSION_GUID: requestContext.userSession.dnbGUID,
                apiFields.IRSCH_FLD_SUBSCRIBER_DRT: requestContext.userSession.dnbSubscriberDRT,
                apiFields.IRSCH_FLD_SUBSCRIBER_NUMBER: requestContext.userSession.subscriberNumber,
                apiFields.IRSCH_FLD_RESEARCH_REQUEST_TYPE: requestContext.userSession.dnbResearchRequestType
            },
            "subjectResearch": {
                "researchTypes": self._convertResearchTypes(requestRecord),
                "submittedData": self._convertSubmittedData(requestRecord)
            },
            "researchComments": self._convertResearchComments(requestRecord),
            "submitterAttachments": self._convertSubmitterAttachments(requestRecord)
        }
        requestRecord.apiSchemaRecords = [ irschDict ]
        # Parse attachment request list
        attmReqsList = origRec.get(apiFields.API_FLD_ATTACHMENT_REQUESTS)
        if attmReqsList is not None:
            for attmReqs in attmReqsList:
                attmName = attmReqs.get(apiFields.API_FLD_ATTACHMENT_NAME)
                if isNotBlank(attmName):
                    self._addAttachment(requestRecord, attmName, constants.SUBMITTER_ATTACHMENT)


    def _convertResearchTypes(self, requestRecord):
        origRec = requestRecord.originalRecords[0]
        rschSubTypes = origRec.get(apiFields.API_FLD_RSCH_SUB_TYPES)
        if rschSubTypes is None or len(rschSubTypes) == 0:
            requestRecord.addRejection(RequestRejectionError(jsonPathName=apiFields.API_FLD_RSCH_SUB_TYPES, errorDescription=apiErrors.FAILREC_MISSING_RESEARCH_SUB_TYPE, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
            return []
        
        researchTypes = []
        for rschSubType in rschSubTypes:
            typDict =  {
                "researchTypeCode": Converters.convertResearchSubTypeToType(apiFields.API_FLD_RSCH_SUB_TYPES, rschSubType, requestRecord, SubmitCaseType.API.value),
                "researchSubTypeCode": rschSubType
            }
            researchTypes.append(typDict)
            
        return researchTypes
    
    
    def _convertSubmittedData(self, requestRecord):
        subjRsch = copy.deepcopy(requestRecord.originalRecords[0])
        submittedData = subjRsch.get(apiFields.API_FLD_SUBMITTED_DATA)
        if submittedData is None:
            requestRecord.addRejection(RequestRejectionError(jsonPathName=apiFields.API_FLD_SUBMITTED_DATA, errorDescription=apiErrors.FAILREC_MISSING_REQUIRED_FIELD_GENERIC, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
            return None
        Converters.convertDuns(subjRsch, requestRecord)
        Converters.convertTelephones(subjRsch, requestRecord)
        return submittedData

   
    
    def _convertResearchComments(self, requestRecord):
        origRec = requestRecord.originalRecords[0]
        researchComments = origRec.get(apiFields.API_FLD_RESEARCH_COMMENTS)
        if researchComments is None or len(researchComments) == 0:
            return None
        rschCmntDict = {}
        submitterCommentTypes = [
            CommentTypeCode.RESEARCH_REQUESTOR_COMMENT.value,
            CommentTypeCode.REMOVE_FINANCIAL_STATEMENT_COMMENT.value,
            CommentTypeCode.FINANCIAL_RATIOS_COMMENT.value,
            CommentTypeCode.FINANCIAL_FIGURES_COMMENT.value
        ]
        # Map comment type codes to comments
        for idx, researchComment in enumerate(researchComments):
            cmntTypCd = researchComment.get(apiFields.API_FLD_COMMENT_TYP_CD)
            cmntTxt = researchComment.get(apiFields.API_FLD_RESEARCH_COMMENT)
            if cmntTypCd is None or cmntTypCd == 0:
                # ignore
                pass
            elif cmntTypCd in submitterCommentTypes:
                if isBlank(cmntTxt):
                    requestRecord.addRejection(RequestRejectionError(jsonPathName=self._constructArrayJsonPath(idx,apiFields.API_FLD_RESEARCH_COMMENTS,apiFields.API_FLD_RESEARCH_COMMENT), errorDescription=apiErrors.FAILREC_EMPTY_COMMENT, providedValue=None), RejectionReasonCode.VALIDATION_ERROR)
                rschCmntDict[cmntTypCd] = cmntTxt
            else:
                requestRecord.addRejection(RequestRejectionError(jsonPathName=self._constructArrayJsonPath(idx,apiFields.API_FLD_RESEARCH_COMMENTS,apiFields.API_FLD_COMMENT_TYP_CD), errorDescription=apiErrors.FAILREC_INVALID_TYPE_CODE, providedValue=cmntTypCd), RejectionReasonCode.VALIDATION_ERROR)
            
        # Construct final array of comment types in the order expected by the validator
        rschCmntOk = []
        for idx, cmntTypCd in enumerate(submitterCommentTypes):
            cmntTxt = rschCmntDict.get(cmntTypCd)
            cmnDict = {
                apiFields.API_FLD_COMMENT_TYP_CD: cmntTypCd if isNotBlank(cmntTxt) else None,
                apiFields.API_FLD_RESEARCH_COMMENT: convertNewlines(cmntTxt)
            }
            rschCmntOk.append(cmnDict)
        return rschCmntOk
    
    def _convertSubmitterAttachments(self, requestRecord):
        origRec = requestRecord.originalRecords[0]
        attachments = origRec.get(apiFields.API_FLD_ATTACHMENT_REQUESTS)
        if attachments is None or len(attachments) == 0:
            return None
        submitterAttachments = []
        for attach in attachments:
            if isNotBlank(attach[apiFields.API_FLD_ATTACHMENT_NAME]):
                submitterAttachmentDic = {
                    apiFields.IRSCH_FLD_ATTACHMENT_FILENAME : attach[apiFields.API_FLD_ATTACHMENT_NAME]
                }
                submitterAttachments.append(submitterAttachmentDic)
        return submitterAttachments

    def transformOneIresearchToApiResponse(self, requestContext, requestRecord, iResarchResponseBody, attachments):
        '''
        Transforms the output from SubmitCase into the proper response to SubmitResearchRequest API, for a successful invoke
        Raises a LambdaProcessingException in case of invalid response from SubmitCase
        '''
        researchRequest = iResarchResponseBody.get(apiFields.IRSCH_RESP_RESEARCH_REQUEST)
        subjectResearches = iResarchResponseBody.get(apiFields.IRSCH_RESP_SUBJECT_RESEARCHES)
        if researchRequest is None or subjectResearches is None or len(subjectResearches) == 0:
            logging.error('transformOneIresearchToApiResponse got an invalid response from SubmitCase: ' + str(iResarchResponseBody))
            raise LambdaProcessingException(errorMessages.ERR_INTERNAL_REQUEST)
        
        subjectResearchIdentifiers = []
        for subjectResearch in subjectResearches:
            subjectResearchTypes = []
            for rts in subjectResearch[apiFields.IRSCH_RESP_RESEARCH_TYPES]:
                srt = {
                    apiFields.BOTH_RESP_RESEARCH_TYPE_CODE: rts.get(apiFields.BOTH_RESP_RESEARCH_TYPE_CODE),
                    apiFields.BOTH_RESP_RESEARCH_SUB_TYPE_CODE: rts.get(apiFields.BOTH_RESP_RESEARCH_SUB_TYPE_CODE)
                }
                subjectResearchTypes.append(srt)
                
            subjectResearchIdentifier = {
                apiFields.BOTH_RESP_SUBJECT_RESEARCH_ID: subjectResearch.get(apiFields.BOTH_RESP_SUBJECT_RESEARCH_ID),
                apiFields.API_RESP_SUBJECT_RESEARCH_TYPES: subjectResearchTypes
            }
            submittedData = subjectResearch.get(apiFields.IRSCH_RESP_SUBMITTED_DATA)
            if submittedData is not None:
                if submittedData.get(apiFields.BOTH_RESP_DUNS) is not None:
                    subjectResearchIdentifier[apiFields.BOTH_RESP_DUNS] = submittedData.get(apiFields.BOTH_RESP_DUNS)
                if submittedData.get(apiFields.BOTH_RESP_ORGANIZATION_NM) is not None:
                    subjectResearchIdentifier[apiFields.BOTH_RESP_ORGANIZATION_NM] = submittedData.get(apiFields.BOTH_RESP_ORGANIZATION_NM)
            subjectResearchIdentifiers.append(subjectResearchIdentifier)
        
        apiResponse = {
            apiFields.BOTH_RESP_RESEARCH_REQUEST_ID: researchRequest.get(apiFields.BOTH_RESP_RESEARCH_REQUEST_ID),
            apiFields.API_RESP_SUBJECT_RESEARCH_IDENTIFIERS: subjectResearchIdentifiers
        }
        if researchRequest.get(apiFields.BOTH_RESP_REQUEST_KEY) is not None:
            apiResponse[apiFields.BOTH_RESP_REQUEST_KEY] = researchRequest.get(apiFields.BOTH_RESP_REQUEST_KEY)
        if researchRequest.get(apiFields.BOTH_RESP_REQUEST_DESCRIPTION) is not None:
            apiResponse[apiFields.BOTH_RESP_REQUEST_DESCRIPTION] = researchRequest.get(apiFields.BOTH_RESP_REQUEST_DESCRIPTION)
            
        if researchRequest.get(apiFields.BOTH_RESP_EXTERNAL_INVS_ID) is not None:
            apiResponse[apiFields.BOTH_RESP_EXTERNAL_INVS_ID] = researchRequest.get(apiFields.BOTH_RESP_EXTERNAL_INVS_ID)
                        
        if attachments is not None and len(attachments) > 0:
            apiResponse[apiFields.API_RESP_ATTACHMENTS] = self._transformAttachments(attachments)

        return apiResponse
        
        
    def _constructArrayJsonPath(self, idx, prefixPath, suffixPath):
        return prefixPath + "[" + str(idx) + "]." + suffixPath
    

    def transformBatchToBatchDetail(self, requestContext, batchRecord):
        '''
        Transforms all records into the iResearch BatchDetail schema.
        '''
        nrecs = len(batchRecord.requestRecords)
        for i in range(nrecs):
            requestRecord = batchRecord.requestRecords[i]
            self._transformOneRecordToBatchDetail(requestContext, requestRecord, batchRecord.batchRequestId, i+1)
        
        
    def _transformOneRecordToBatchDetail(self, requestContext, requestRecord, batchRequestId, recordNumber):
        requestRecord.batchDetailRecord = {
            "batchRequestId": batchRequestId,
            "recordNumber": recordNumber,
            "batchResearchRequest": requestRecord.originalRecords[0],
            "countryCode": jmespath.search(apiFields.IRSCH_FULL_FLD_COUNTRY_CODE, requestRecord.apiSchemaRecords[0]),
            "duns": jmespath.search(apiFields.IRSCH_FULL_FLD_DUNS, requestRecord.apiSchemaRecords[0]),
            "batchRequestRejectId": requestRecord.batchRequestRejectId,
            "isRejected": requestRecord.isRejected(),
            "isSuppressed": requestRecord.isSuppressed
        }        


    def _addAttachment(self, requestRecord, attachmentName, attachmentType):
        attmObj = attachment()
        attmReqDict = {
            "attachmentName": attachmentName,
            "attachmentType": attachmentType
            #"attachmentKey": attachmentKey
        }
        attmObj.loadRequestAttributes(attmReqDict)
        requestRecord.attachments.append(attmObj)
        
        
    def _transformAttachments(self, attachments):
        attachmentsResponse = []
        for attm in attachments:
            requestLinkResp = attm.getRequestAttachmentLinkResponse()
            resp = {
                apiFields.API_RESP_ATTACHMENT_NAME: attm.getIncomingFileName(),
                apiFields.API_RESP_ATTACHMENT_URL: requestLinkResp["signed_URL"]["url"],
                apiFields.API_RESP_ATTACHMENT_FIELDS: requestLinkResp["signed_URL"]["fields"]
            }
            attachmentsResponse.append(resp)
            
        return attachmentsResponse
    
    def _getRequestorPrefLangCode(self, origRec): 
        prefLangCode = 331
        if origRec.get(apiFields.API_FLD_REQUESTOR_PREF_LANG_CODE) is not None:
            prefLangCode = origRec.get(apiFields.API_FLD_REQUESTOR_PREF_LANG_CODE)
        return prefLangCode
    