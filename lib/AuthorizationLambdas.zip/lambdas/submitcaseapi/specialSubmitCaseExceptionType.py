'''
Created on Jul 29, 2019

@author: VanCampK
'''
from enum import Enum

class SpecialSubmitCaseExceptionType(Enum):
    # These are special exceptions from SubmitCase lambda which need to be handled differently
    ERROR_TYPE_UNK_COUNTRY_TO_SUBTYPE = "com.dnb.irsch.services.exception.SubmitCaseCountryToSubtypeException"
    ERROR_TYPE_ROUTING_RULES = "com.dnb.irsch.services.exception.SubmitCaseWorkflowException"
    ERROR_TYPE_INVALID_DUNS = "com.dnb.irsch.services.exception.SubmitCaseInvalidDunsException"
    