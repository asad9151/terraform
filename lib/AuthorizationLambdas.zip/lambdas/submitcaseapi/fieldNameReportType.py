'''
Created on Jul 29, 2019

@author: VanCampK
'''
from enum import Enum

class FieldNameReportType(Enum):
    # Identifies the type of field to display when reporting validation errors
    JSON_PATH_NAME = 1
    MINI_BATCH_FIELD_NAME = 2
    JSON_SHORTENED_PATH_NAME = 3        # For Direct+ APIs