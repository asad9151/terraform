import copy
import logging
import os
import jmespath
import json
from common.batchType import BatchType
from common.dao.geoValidationDao import GeoValidationDao
from common.dao.scotsDao import ScotsDao
from common.excelReader import ExcelReader
from common.mappers.scotsMapper import mapScotsTypeCodeListToDict
from common.rejectionReasonCodes import RejectionReasonCode
from common.scotsTables import ScotsTable
from common.util.dictUtils import removeEmptyFromDictionary
from common.util.stringUtils import stringHasHtml, isBlank, isPrintable
from common.util.ValidateUtil import ValidateUtil
from lambdas.exceptions import LambdaConflictException, LambdaValidationException
from lambdas import lambdaConstants
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.retrieveInitialData.geoCodeTypeCodes import GeoCodeTypeCode
from lambdas.retrieveInitialData.geoUnitTypeCodes import GeoUnitTypeCode
from lambdas.submitcaseapi import submitCaseApiErrors, submitCaseApiFields
from lambdas.submitcaseapi.fieldNameReportType import FieldNameReportType
from lambdas.submitcaseapi.submitCaseType import SubmitCaseType
import lambdas.submitcaseapi.researchRequestTypeToSubtypesMap as researchRequestTypeToSubtypesMap


class SubmitCaseApiValidationService(object):
    '''
    Performs validations for Submit Case API and Batch requests
    '''
    SPREADSHEET_FIELDNAME_COLUMN = "Description"
    country_codes_cache = []
    geoValidationDao = None
    scotsTypeCodeCache = None
    scotsDao = None
    validate_util = None
    batchValidateUtil = None
            
    # The following research subtypes cannot be specified in combination with any other research subtypes:
    STANDALONE_RESEARCH_SUBTYPES = [ 33575, 34378, 33574, 33564, 33576 ]
    
    
    def __init__(self, db_conn, requestAttachmentLinkService=None):
        self.db_conn = db_conn
        #self.fieldNameReportType = FieldNameReportType.MINI_BATCH_FIELD_NAME
        self.fieldNameReportType = None
        self.requestAttachmentLinkService = requestAttachmentLinkService
        self.validationConfCache = {'mappingDict': {}}
        self.researchRequestTypeToSubtypeCache = None
        
         
    def loadCache(self, submitCaseType):
        if self.validationConfCache['mappingDict'] == None or len(self.validationConfCache['mappingDict']) == 0:
            self.generateMappingDict(submitCaseType)
        if self.researchRequestTypeToSubtypeCache is None:
            self._loadResearchRequestTypeToSubtypeCache(submitCaseType)
        return self.validationConfCache
    

    def generateMappingDict(self, submitCaseType):
        self.validationConfCache['mappingDict'] = {}
        if submitCaseType == SubmitCaseType.MINI_BATCH.value:
            # Have to load both the campaign and minibatch validation configs
            filePathForValidations = lambdaConstants.CAMPAIGN_SUBMIT_FIELD_VALIDATION_CFG
            self._loadMappingDict(filePathForValidations)
            self.validationConfCache['campaignMappingDict'] = copy.deepcopy(self.validationConfCache['mappingDict'])
            logging.info(f"campaignMappingDict len={len(self.validationConfCache['campaignMappingDict'])}")
            # Load the minibatch validation config last so the all_elts_dict is complete
            # WARNING: This works only because the minibatch all_elts_dict is a superset of the campaign all_elts_dict
            filePathForValidations = lambdaConstants.MINIBATCH_SUBMIT_FIELD_VALIDATION_CFG
            self._loadMappingDict(filePathForValidations)
            self.validationConfCache['miniBatchMappingDict'] = copy.deepcopy(self.validationConfCache['mappingDict'])
            logging.info(f"miniBatchMappingDict len={len(self.validationConfCache['miniBatchMappingDict'])}")
        elif submitCaseType == SubmitCaseType.API.value:
            filePathForValidations = lambdaConstants.API_SUBMIT_FIELD_VALIDATION_CFG
            self._loadMappingDict(filePathForValidations)
        else:
            raise LambdaConflictException("Unsupported submitCaseType=" + str(submitCaseType))
        
        
    def _loadMappingDict(self, filePathForValidations):
        logging.info('loading the validation dictionary from this path: ' + filePathForValidations)
        current_path_of_file = os.path.abspath(os.path.dirname(__file__))
        validation_excel_path = os.path.join(current_path_of_file, filePathForValidations)
        self.excelReader = ExcelReader()
        zipped_records = self.excelReader.readCsvAsJson(validation_excel_path)
        logging.info(f"Read {len(zipped_records)} records from validation cfg {filePathForValidations}")
        # Set up the empty key lists
        value_mapper_pointer = 0
        for key, value in zipped_records[0].items():
            value_mapper_pointer += 1
            if value_mapper_pointer < 4:
                logging.debug('value_mapper_pointer[1] key=' + str(key) + ' value=' + value)
            if (value_mapper_pointer > 2):
                self.validationConfCache['mappingDict'][key] = {
                    'required' : [],
                    'optional' : [],
                    'notallowed': [],
                }
        self.validationConfCache['all_elts_dict'] = self._buildAllEltsDict(zipped_records)
        if len(self.validationConfCache['all_elts_dict']) < 1:
            # Problem loading config file
            raise LambdaConflictException("all_elts_dict is empty! Invalid configuration file")
        # Populate the key lists
        for index in range(1,len(zipped_records)):
            REQUIRED_TEXT = 'required'
            OPTIONAL_TEXT = 'optional'
            NOT_ALLOWED_TEXT = 'not allowed'
            pointer = 0
            for key, value in zipped_records[index].items():
                pointer += 1
                if (pointer > 2):   # skip over SubmitCaseApiValidationService.SPREADSHEET_FIELDNAME_COLUMN column
                    if value.strip().lower() == REQUIRED_TEXT:
                        if index < 4:
                            logging.debug('Required for key=' + str(key) + ' jsonpath=' + zipped_records[index]['JsonPath'].strip() + ' keytype=' + str(type(key)))
                        self.validationConfCache['mappingDict'][key]['required'].append(
                            {
                                'jsonpath': zipped_records[index]['JsonPath'].strip(),
                                'fieldname': zipped_records[index][SubmitCaseApiValidationService.SPREADSHEET_FIELDNAME_COLUMN].strip()
                            })
                    elif value.strip().lower() == OPTIONAL_TEXT:
                        self.validationConfCache['mappingDict'][key]['optional'].append(
                            {
                                'jsonpath': zipped_records[index]['JsonPath'].strip(),
                                'fieldname': zipped_records[index][SubmitCaseApiValidationService.SPREADSHEET_FIELDNAME_COLUMN].strip()
                            })
                    elif value.strip().lower() == NOT_ALLOWED_TEXT:
                        self.validationConfCache['mappingDict'][key]['notallowed'].append(
                            {
                                'jsonpath': zipped_records[index]['JsonPath'].strip(),
                                'fieldname': zipped_records[index][SubmitCaseApiValidationService.SPREADSHEET_FIELDNAME_COLUMN].strip()
                            })
        #logging.info('the number of records are' + str(len(zipped_records)))


    def generateRejectionDict(self, jsonpath, fieldname, rejection_msg, provided_value):
        if self.fieldNameReportType == FieldNameReportType.MINI_BATCH_FIELD_NAME:
            if fieldname != "":
                err_fld = fieldname
            else:
                err_fld = jsonpath
        elif self.fieldNameReportType == FieldNameReportType.JSON_PATH_NAME:
            err_fld = jsonpath
        elif self.fieldNameReportType == FieldNameReportType.JSON_SHORTENED_PATH_NAME:
            #err_fld = jsonpath.replace('subjectResearch.submittedData', 'submittedData')
            #err_fld = err_fld.replace('researchRequest.', '')
            if fieldname != "":
                err_fld = fieldname
            else:
                err_fld = jsonpath
        req_rej_err_obj = RequestRejectionError(err_fld, rejection_msg, provided_value)
        rejectionDict = {
                'rejectionErrorObject' : req_rej_err_obj,
                'errorCode' : RejectionReasonCode.VALIDATION_ERROR
            }
        return rejectionDict


    def validationForRequired(self, schemaRecord, requestContext, batchType):
        main_dict = self._getMappingDict(requestContext, batchType)
        rejectionList = []
        subject_research = schemaRecord['subjectResearch']
        research_types = subject_research['researchTypes']
        for research_type in research_types:
            researchSubTypeCode = research_type['researchSubTypeCode']
            if researchSubTypeCode is None:
                rejectionList.append(self.generateRejectionDict(submitCaseApiFields.API_FLD_RSCH_SUB_TYPES, submitCaseApiFields.MNB_FLD_RSCH_SUB_TYPE, submitCaseApiErrors.FAILREC_MISSING_RESEARCH_SUB_TYPE, None))
                continue
            if researchSubTypeCode not in main_dict:
#                 rejectionList.append(self.generateRejectionDict(submitCaseApiFields.API_FLD_RSCH_SUB_TYPES, submitCaseApiFields.MNB_FLD_RSCH_SUB_TYPE, submitCaseApiErrors.FAILREC_UNSUPPORTED_RESEARCH_SUB_TYPE, researchSubTypeCode))
                continue
            self._validateResearchSubTypeSpecialCases(researchSubTypeCode, research_types, rejectionList)
            validation_dict = main_dict[researchSubTypeCode]
            if validation_dict is None:
#                 rejectionList.append(self.generateRejectionDict(submitCaseApiFields.API_FLD_RSCH_SUB_TYPES, submitCaseApiFields.MNB_FLD_RSCH_SUB_TYPE, submitCaseApiErrors.FAILREC_UNSUPPORTED_RESEARCH_SUB_TYPE, researchSubTypeCode))
                continue
            for req_dict in validation_dict['required']:
                req_item = req_dict['jsonpath']
                if "[]" in req_item:
                    req_item = req_item.replace("[]","[0]")
                jmes_result = jmespath.search(req_item, schemaRecord)
                if type(jmes_result) is str:
                    jmes_result = jmes_result.strip()
                if jmes_result  == "" or jmes_result == None:
                    if req_dict['fieldname'] == "researchComments[].researchComment":
                        self._generateSpecialMissingResearchCommentRejection(rejectionList, req_dict, researchSubTypeCode)
                    elif self._isSpecialIgnoredRequiredIRG(researchSubTypeCode, req_dict['fieldname'], schemaRecord):
                        logging.info("Missing required field but ignored because request is from IRG")
                    else:
                        rejectionList.append(self.generateRejectionDict(req_dict['jsonpath'], req_dict['fieldname'], submitCaseApiErrors.FAILREC_MISSING_REQUIRED_FIELD_FOR_RESEARCH_SUB_TYPE, jmes_result))
        return rejectionList


    def _getMappingDict(self, requestContext, batchType):
        submitCaseType = requestContext.serviceDict['submitCaseType']
        main_dict = self.validationConfCache['mappingDict']
        if submitCaseType == SubmitCaseType.MINI_BATCH.value:
            if batchType == BatchType.CAMPAIGN_BATCH.value:
                main_dict = self.validationConfCache['campaignMappingDict']
                logging.info(f"Using campaignMappingDict (len={len(main_dict)})")
            else:
                main_dict = self.validationConfCache['miniBatchMappingDict']
                logging.info(f"Using miniBatchMappingDict (len={len(main_dict)})")
        return main_dict
    

    def _generateSpecialMissingResearchCommentRejection(self, rejectionList, req_dict, researchSubTypeCode):
        if researchSubTypeCode == submitCaseApiFields.RSCH_SUBTYPE_FINANCIAL_RATIOS:
            rejectionList.append(self.generateRejectionDict(req_dict['jsonpath'], req_dict['fieldname'], submitCaseApiErrors.FAILREC_MISSING_REQUIRED_COMMENT_FOR_FINANCIAL_RATIOS, None))
        elif researchSubTypeCode == submitCaseApiFields.RSCH_SUBTYPE_FINANCIAL_FIGURES:
            rejectionList.append(self.generateRejectionDict(req_dict['jsonpath'], req_dict['fieldname'], submitCaseApiErrors.FAILREC_MISSING_REQUIRED_COMMENT_FOR_FINANCIAL_FIGURES, None))
        else:
            rejectionList.append(self.generateRejectionDict(req_dict['jsonpath'], req_dict['fieldname'], submitCaseApiErrors.FAILREC_MISSING_REQUIRED_FIELD_FOR_RESEARCH_SUB_TYPE, None))


    IRG_NEW_DUNS_SUBTYPE_CDS = [33574]
    IRG_REQUEST_METHOD_CODES = [28411,15229,24970,23607,20645,14182,19677,14184,33587,29094,12848,26330,12842,14186]
    IRG_IGNORED_REQUIRED_ELTS_FOR_NEW_DUNS = ["submittedData.addresses[0].streetAddress", "submittedData.addresses[0].town"]


    def _isSpecialIgnoredRequiredIRG(self, researchSubTypeCode, fldnm, schemaRecord):
        if researchSubTypeCode not in SubmitCaseApiValidationService.IRG_NEW_DUNS_SUBTYPE_CDS:
            return False
        if fldnm not in SubmitCaseApiValidationService.IRG_IGNORED_REQUIRED_ELTS_FOR_NEW_DUNS:
            return False
        requestMethodCode = jmespath.search("researchRequest.requestMethodCode", schemaRecord)
        if requestMethodCode not in SubmitCaseApiValidationService.IRG_REQUEST_METHOD_CODES:
            return False
        return True
            

    def _validationForNotAllowed(self, schemaRecord, requestContext, batchType):
        main_dict = self._getMappingDict(requestContext, batchType)
        rejectionList = []
        subject_research = schemaRecord['subjectResearch']
        research_types = subject_research['researchTypes']
        for research_type in research_types:
            researchSubTypeCode = research_type['researchSubTypeCode']
            if researchSubTypeCode is None:
                # error was already reported, just keep going
                continue
            if researchSubTypeCode not in main_dict:
                # error was already reported, just keep going
                continue
            validation_dict = main_dict[researchSubTypeCode]
            if validation_dict is None:
                # error was already reported, just keep going
                continue
            #print(f"_validationForNotAllowed: validation_dict.get('notallowed') = {validation_dict.get('notallowed')}")
            if validation_dict.get('notallowed') is not None:
                for req_dict in validation_dict['notallowed']:
                    req_item = req_dict['jsonpath']
                    if "[]" in req_item:
                        req_item = req_item.replace("[]","[0]")
                    jmes_result = jmespath.search(req_item, schemaRecord)
                    if type(jmes_result) is str:
                        jmes_result = jmes_result.strip()
                    if jmes_result  == "" or jmes_result == None:
                        pass
                    else:
                        rejectionList.append(self.generateRejectionDict(req_dict['jsonpath'], req_dict['fieldname'], submitCaseApiErrors.FAILREC_FIELD_NOT_ALLOWED, jmes_result))
                        
        return rejectionList
        

    def validateRecord(self, requestContext, requestRecord, batchRecord):
        '''
        Validates the given record (apiSchemaRecords[0]) and either rejects it (writes to the rejection list) or does nothing.
        Updates the requestRecord.requestRejectionErrors if the record was rejected, or leaves the requestRecord unmodified if ok.
        This function should never throw a validation exception.

        Validations performed:
        -    Optionality: Each research subtype needs to be associated with a list of required and optional fields. Some fields may be labeled “MandatoryConditional”; that is, if one field is provided then another field becomes mandatory. Or, if one field is not provided then another field becomes mandatory. Other fields may be “OptionalConditional”; that is, the field is optional but only if another field is provided.
        -    Array Limits: Some array values can only have up to N entries allowed. (This will not be necessary for mini-batch since we will have hard coded column names, e.g. PrincipalName[1], PrincipalTitle[1], PricipalName[2], etc. so we may not address this until actual Direct+ APIs are implemented.)
        -    Reference Data Lookup: Some field values must be validated against reference data, e.g. country must be a valid ISO2 country code.
        -    Attachments
        '''
        self.fieldNameReportType = FieldNameReportType.MINI_BATCH_FIELD_NAME
        if requestContext.serviceDict.get('submitCaseType') == SubmitCaseType.API.value:
            self.fieldNameReportType = FieldNameReportType.JSON_SHORTENED_PATH_NAME
            
        root_record = requestRecord.apiSchemaRecords[0]
        batchType = None if batchRecord is None else batchRecord.batchType
        self.loadCache(requestContext.serviceDict['submitCaseType'])

        rejectionList = self.validationForRequired(root_record, requestContext, batchType)
        rejectionList.extend(self._validationForNotAllowed(root_record, requestContext, batchType))
        rejectionList.extend(self._validationForCleanse(root_record))
        rejectionList.extend(self.validateRecordValues(root_record))   
        rejectionList.extend(self._validateAttachments(requestRecord.attachments))
        rejectionList.extend(self._validateResearchRequestType(root_record))
        if rejectionList != None:
            for rejectionDict in rejectionList:
                requestRecord.addRejection(rejectionDict['rejectionErrorObject'], rejectionDict['errorCode'])


    def _buildAllEltsDict(self, zipped_records): 
        all_elts_dict = {}
        for index in range(1,len(zipped_records)):
            #if index > 1:
            if zipped_records[index].get('JsonPath') is None:
                # Ignore empty rows
                continue
            jsonPath = zipped_records[index]['JsonPath'].strip()
            displayName = zipped_records[index][SubmitCaseApiValidationService.SPREADSHEET_FIELDNAME_COLUMN].strip()
            all_elts_dict[jsonPath] = displayName
            if index < 4:
                logging.debug('all_elts_dict[' + jsonPath + '] displayName=' + displayName)
        return all_elts_dict


    def _validationForCleanse(self, schemaRecord):
        all_elts_dict = self.validationConfCache['all_elts_dict']
        rejectionList = []
        for jsonPath, displayName in all_elts_dict.items():
            jmes_result = jmespath.search(jsonPath, schemaRecord)
            err_str = self._checkForInappropriateInput(jmes_result)
            if err_str is not None:
                rejectionList.append(self.generateRejectionDict(jsonPath, displayName, err_str, jmes_result))
                
        return rejectionList
                    

    def _checkForInappropriateInput(self, s):
        '''
        Checks for unprintable characters or potentially harmful HTML tags in an incoming string
        If invalid input, returns error message
        '''
        if s is not None and isinstance(s, str):
            if stringHasHtml(s):
                return submitCaseApiErrors.FAILREC_HTML_TAGS_NOT_ALLOWED
            
            if not isPrintable(s):
                return submitCaseApiErrors.FAILREC_UNPRINTABLE_NOT_ALLOWED
        return None
    
    
    def getCountryCodes(self):
        if not self.geoValidationDao:
            self.geoValidationDao = GeoValidationDao()
        if not self.country_codes_cache:
            self.country_codes_cache = []
            countries = self.geoValidationDao.queryCountryCodes(
                self.db_conn, GeoUnitTypeCode.GEO_UNIT_TYPE_CODE_COUNTRY.value,
                GeoCodeTypeCode.GEO_CODE_TYPE_CODE_ISO2ALPHA.value
            )
            if type(countries) is list:
                for country in countries:
                    if  type(country) is dict:
                        self.country_codes_cache.append(country["countryCode"])
        return self.country_codes_cache


    def validateCountryCodes(self, attributes, schemaRecord):
        self.country_codes_cache = self.getCountryCodes()
        rejectionList = []
        for attribute in attributes:
            if attribute.lower().endswith("countrycode"):
                if "[]" in attribute:
                    attribute = attribute.replace("[]","[0]")
                jmes_result = jmespath.search(attribute, schemaRecord)
                if type(jmes_result) is str:
                    jmes_result = jmes_result.strip()
                if jmes_result and jmes_result not in self.country_codes_cache:
                    rejectionList.append(
                        self.generateRejectionDict(
                            attribute, attributes[attribute],
                            submitCaseApiErrors.FAILREC_INVALID_COUNTRY_CODE,
                            jmes_result
                        )
                    )                   
        return rejectionList
    
    
    def rmv_dups_rjct_err_obj(self, rejectionList):
        rejectionListWithoutDups = []
        for rejection in rejectionList:
            exist = False
            for rej in rejectionListWithoutDups:
                if rejection["rejectionErrorObject"] == rej["rejectionErrorObject"]:
                    exist = True
                    break
            if not exist:
                rejectionListWithoutDups.append(rejection)
        return rejectionListWithoutDups

    
    def validateRecordValues(self, schemaRecord):
        rejectionList = []
        attributes = self.validationConfCache['all_elts_dict']
        rejectionList.extend(self.validateCountryCodes(attributes, schemaRecord))
        rejectionList.extend(self._validateScotsTypeCodes(attributes, schemaRecord))
        return self.rmv_dups_rjct_err_obj(rejectionList)
    
    
    def validateApiRecordSchema(self, requestContext, requestRecord):
        '''
        Validates the given requestRecord (originalRecords[0]) against the iResearchSubmitResearchRequest.json schema and either rejects it or does nothing.
        Updates the requestRecord.requestRejectionErrors if the record was rejected, or leaves the requestRecord unmodified if ok.
        This function should never throw an exception.
        '''
        if self.validate_util is None:
            self.validate_util = ValidateUtil("iResearchSubmitResearchRequest.json")
        subj_research = requestRecord.originalRecords[0]
        errors = sorted(self.validate_util.theValidator.iter_errors(subj_research), key=lambda e: e.path)
        for error in errors:
            if error.absolute_path:
                jsonPath = ''
                for ele in error.absolute_path:
                    if type(ele) is int:
                        jsonPath = jsonPath.strip(".") + "[" + str(ele) + "]."
                    else:
                        jsonPath += ele + "."
                jsonPath = jsonPath.strip(".")
            else:
                jsonPath = ""
            req_rej_err_obj = RequestRejectionError(jsonPath, error.message, None)
            requestRecord.addRejection(req_rej_err_obj, RejectionReasonCode.VALIDATION_ERROR)
    
    
    def validateBatchRecordSchema(self, requestContext, requestRecord):
        '''
        Validates the given requestRecord (originalRecords[0]) against the BatchResearchRequest.json schema and either rejects it or does nothing.
        Updates the requestRecord.requestRejectionErrors if the record was rejected, or leaves the requestRecord unmodified if ok.
        This function should never throw an exception.
        '''
        if self.batchValidateUtil is None:
            self.batchValidateUtil = ValidateUtil("BatchResearchRequest.json")
        subj_research = removeEmptyFromDictionary(copy.deepcopy(requestRecord.originalRecords[0]))
        logging.debug(f"Validating against schema BatchResearchRequest.json: {subj_research}")
        errors = sorted(self.batchValidateUtil.theValidator.iter_errors(subj_research), key=lambda e: e.path)
        for error in errors:
            if error.absolute_path:
                jsonPath = ''
                for ele in error.absolute_path:
                    if type(ele) is int:
                        jsonPath = jsonPath.strip(".") + "[" + str(ele) + "]."
                    else:
                        jsonPath += ele + "."
                jsonPath = jsonPath.strip(".")
            else:
                jsonPath = ""
            req_rej_err_obj = RequestRejectionError(jsonPath, error.message, None)
            requestRecord.addRejection(req_rej_err_obj, RejectionReasonCode.VALIDATION_ERROR)
        
        
    # Maps each of the type code elements to their SCOTS tables for validation:
    SCOTS_TYPE_CODE_VALIDATIONS = {
        "addressUsageTypeCode": ScotsTable.ADDRESS_USAGE.value,
        "industryCodeTypeCode": ScotsTable.INDUSTRY_CODE.value,
        "contactOrganizationRoleCode": ScotsTable.ROLE_PLAYER_TYPE.value,
        "businessRegistrationNumberClassCode": ScotsTable.REGISTRATION_NUMBER.value,
        "orderReasonCode": ScotsTable.ORDER_REASON.value
        #TODO if multi-child linkage is supported: "linkageChangeActionCode": not SCOTS coded (just 1/2/3)
    }

    def loadScotsTypeCodeCache(self):
        if self.scotsDao is None:
            self.scotsDao = ScotsDao()
        if self.scotsTypeCodeCache is None:
            scotsTableList = list(self.SCOTS_TYPE_CODE_VALIDATIONS.values())
            qryResult = self.scotsDao.queryScotsTypeCodeLists(self.db_conn, scotsTableList)
            self.scotsTypeCodeCache = mapScotsTypeCodeListToDict(qryResult)
            logging.info("Loaded scotsTypeCodeCache: " + str(self.scotsTypeCodeCache))


    def _validateScotsTypeCodes(self, attributes, schemaRecord):
        self.loadScotsTypeCodeCache()
        rejectionList = []
        #print(f"_validateScotsTypeCodes: attributes={attributes}")
        for attribute in attributes:
            for typeCode, scotsTbl in self.SCOTS_TYPE_CODE_VALIDATIONS.items():
                if attribute.lower().endswith(typeCode.lower()):
                    if "[]" in attribute or "[0]" in attribute:
                        # Try each elt# in the array until there are no more
                        index = 0
                        while True:
                            attr = attribute.replace("[]", "[" + str(index) + "]").replace("[0]", "[" + str(index) + "]")
                            jmes_result = jmespath.search(attr, schemaRecord)
                            if jmes_result is None:
                                break
                            isOk = self._validateOneScotsTypeCode(attr, scotsTbl, jmes_result, schemaRecord)
                            if not isOk:
                                rejectionList.append(
                                    self.generateRejectionDict(
                                        attr, attributes[attribute],
                                        submitCaseApiErrors.FAILREC_INVALID_TYPE_CODE,
                                        jmes_result
                                    )
                                )                   
                            index += 1
                    else:
                        jmes_result = jmespath.search(attribute, schemaRecord)
                        if jmes_result is not None:
                            isOk = self._validateOneScotsTypeCode(attribute, scotsTbl, jmes_result, schemaRecord)
                            if not isOk:
                                rejectionList.append(
                                    self.generateRejectionDict(
                                        attribute, attributes[attribute],
                                        submitCaseApiErrors.FAILREC_INVALID_TYPE_CODE,
                                        jmes_result
                                    )
                                )                   
                        
        return rejectionList
            
            
    def _validateOneScotsTypeCode(self, attribute, scotsTbl, jmes_result, schemaRecord):
        validTypeCodes = self.scotsTypeCodeCache.get(scotsTbl)
        if validTypeCodes is None:
            raise LambdaConflictException(f"Cannot validate {attribute} because scotsTbl={scotsTbl} is not loaded in cache")
        isValid = str(jmes_result) in [str(i) for i in validTypeCodes]
        if not isValid:
            logging.info(f"Attribute {attribute} in scotsTbl {scotsTbl} looking for value {jmes_result} not found in {validTypeCodes}")
        return isValid 
    
    
    def _validateResearchSubTypeSpecialCases(self, researchSubTypeCode, research_types, rejectionList):
        if researchSubTypeCode in SubmitCaseApiValidationService.STANDALONE_RESEARCH_SUBTYPES:
            # These subtypes cannot be combined with any other subtypes
            for research_type in research_types:
                subtype = research_type['researchSubTypeCode']
                if subtype != researchSubTypeCode:
                    rejectionList.append(self.generateRejectionDict(submitCaseApiFields.API_FLD_RSCH_SUB_TYPES, submitCaseApiFields.MNB_FLD_RSCH_SUB_TYPE, submitCaseApiErrors.FAILREC_STANDALONE_RESEARCH_SUBTYPE, researchSubTypeCode))
                    
                    
    def _validateAttachments(self, attachments):
        rejectionList = []
        attachmentNames = []
        for attmObj in attachments:
            attmName = attmObj.getIncomingFileName()
            if isBlank(attmName):
                rejectionList.append(self.generateRejectionDict(submitCaseApiFields.API_FLD_ATTACHMENT_NAME, submitCaseApiFields.API_FLD_ATTACHMENT_NAME, submitCaseApiErrors.FAILREC_MISSING_ATTACHMENT_NAME, None))
            if attmName in attachmentNames:
                rejectionList.append(self.generateRejectionDict(submitCaseApiFields.API_FLD_ATTACHMENT_NAME, submitCaseApiFields.API_FLD_ATTACHMENT_NAME, submitCaseApiErrors.FAILREC_DUP_ATTACHMENT_NAME, attmName))
            try:
                self.requestAttachmentLinkService.validateAttachmentRequest(attmObj, fullValidation=False)
            except LambdaValidationException as lve:
                logging.error(f"Failed in validateAttachmentRequest: {lve}")
                rejectionList.append(self.generateRejectionDict(submitCaseApiFields.API_FLD_ATTACHMENT_NAME, submitCaseApiFields.API_FLD_ATTACHMENT_NAME, str(lve), attmName))
                
        return rejectionList
    
    def _validateResearchRequestType(self, schemaRecord):
        rejectionList = []
        researchRequest = schemaRecord['researchRequest']
        if 'subscriberDRT'in researchRequest and researchRequest['subscriberDRT'] is not None and 'researchRequestType' in researchRequest and researchRequest['researchRequestType'] is not None:
            researchRequestType = researchRequest['researchRequestType']
            allowedSubtypeList = self.researchRequestTypeToSubtypeCache[researchRequestType]
            if allowedSubtypeList is not None:
                subject_research = schemaRecord['subjectResearch']
                research_types = subject_research['researchTypes']
                for research_type in research_types:
                    researchSubTypeCode = research_type['researchSubTypeCode']
                    if researchSubTypeCode is not None and researchSubTypeCode not in allowedSubtypeList:
                        rejectionList.append(self.generateRejectionDict(submitCaseApiFields.API_FLD_RSCH_SUB_TYPES, submitCaseApiFields.MNB_FLD_RSCH_SUB_TYPE, submitCaseApiErrors.FAILREC_MISSING_RESEARCH_SUB_TYPE, "{0} : {1}".format(researchSubTypeCode,researchRequestType)))
                    continue                
        return rejectionList
    
    def _loadResearchRequestTypeToSubtypeCache(self, submitCaseType):
        if submitCaseType == SubmitCaseType.API.value:
            self.researchRequestTypeToSubtypeCache = json.loads(researchRequestTypeToSubtypesMap.researchRequestTypes)