'''
Created on Jun 2, 2019

@author: VanCampK
'''
import logging
import os
from common.addressUsageTypeCodes import AddressUsageTypeCode
from common.batchType import BatchType
from common.commentTypeCodes import CommentTypeCode
from common.excelReader import ExcelReader
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.stringUtils import isNotBlank, intDefaultNone, defaultNone, decimalDefaultNone, normalizeDuns
from lambdas import errorMessages
from lambdas.exceptions import LambdaValidationException
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.submitcaseapi.batchRecord import BatchRecord
from lambdas.submitcaseapi.converters import Converters
from lambdas.submitcaseapi.spreadsheetValidationException import SpreadsheetValidationException
import lambdas.submitcaseapi.submitCaseApiErrors as apiErrors
import lambdas.submitcaseapi.submitCaseApiFields as apiFields
from lambdas.submitcaseapi.submitCaseType import SubmitCaseType


def createBatchRecord(attmObj):
    '''
    Pulls batch level information from the attachment object
    '''
    batchRecord = BatchRecord()
    batchRecord.batchRequestId = attmObj.getBatchRequestId()
    batchRecord.attmId = attmObj.getAttachmentId()
    batchRecord.batchFormatCode = attmObj.getBatchFormatCode()
    batchRecord.processingStatusCode = attmObj.getBatchStatusCode()
    batchRecord.batchRejectReasonComment = attmObj.getBatchRejectReasonComment()
    batchRecord.batchRejectionErrorText = attmObj.getBatchRejectionErrorText()
    batchRecord.totalEntriesCount = attmObj.getBatchTotalEntriesCount()
    batchRecord.rejectedEntriesCount = attmObj.getBatchRejectedEntriesCount()
    batchRecord.sessionToken = attmObj.getSessionToken()
    batchRecord.batchType = attmObj.getBatchType()
    return batchRecord


class BatchFileParser(object):
    '''
    Reads an incoming mini-batch file from S3 and parses it
    '''
    BATCH_MAX_RECORDS = 12000       # Maximum number of records in a batch. Beyond this, batch will be rejected.
    BDR_COMPLEX_BATCH_SHEETNAME = 'ResearchRequests'
    BDR_SIMPLE_BATCH_SHEETNAME = 'SimpleResearchRequests'
    CAMPAIGN_BATCH_SHEETNAME = 'CampaignResearchRequests'
    
    MINIBATCH_NUM_HEADER_ROWS = 2   #Header rows in spreadsheet

    
    def __init__(self):
        self.excelReader = None
        
        
    def downloadFromS3ToLocal(self, attmObj, s3handle):
        logging.info('downloading mini-batch file from bucket="' + attmObj.getIncomingS3Bucket() + '" s3key="' + attmObj.getIncomingS3Key() + '" to "' + attmObj.getLocalFileName() + '"')
        s3handle.Bucket(attmObj.getIncomingS3Bucket()).download_file(attmObj.getIncomingS3Key(), attmObj.getLocalFileName())

        
    def parseFile(self, batchRecord):
        if not self.excelReader:
            self.excelReader = ExcelReader()
            
        logging.info('Parsing mini-batch sheet ' + self.getSheetName(batchRecord) + ' from file ' + batchRecord.localFileName)
        # Set  minRowNum=2 to skip the first header row
        parsedFile = self.excelReader.readWorkbookSheetAsJson(batchRecord.localFileName, self.getSheetName(batchRecord),  minRowNum=BatchFileParser.MINIBATCH_NUM_HEADER_ROWS, convertAllValsToStr=True)
        logging.info('Done parsing mini-batch sheet ' + self.getSheetName(batchRecord) + ' from file ' + batchRecord.localFileName)
        self._validateMandatoryColumnsExist(parsedFile)
        return parsedFile
    
        
    def deleteLocalFile(self, attmObj):
        logging.info('deleting local mini-batch file from ' + attmObj.getLocalFileName())
        if os.path.exists(attmObj.getLocalFileName()):
            os.remove(attmObj.getLocalFileName())
            logging.info('Local file - %s - deleted', attmObj.getLocalFileName())
        else:
            logging.warning('Local file - %s - not found, not deleted', attmObj.getLocalFileName())


    def _validateMandatoryColumnsExist(self, parsedFile):
        # raise SpreadsheetValidationException if mandatory columns missing
        rec1 = parsedFile[0]
        if apiFields.MNB_FLD_RSCH_SUB_TYPE not in rec1:
            logging.error(apiErrors.FAILBATCH_BAD_MINIBATCH_SPREADSHEET + ': missing required field ' + apiFields.MNB_FLD_RSCH_SUB_TYPE)
            raise SpreadsheetValidationException(apiErrors.FAILBATCH_BAD_MINIBATCH_SPREADSHEET)
    
    
    def validateRecordCount(self, requestRecords):
        if len(requestRecords) > BatchFileParser.BATCH_MAX_RECORDS:
            #print(apiErrors.FAILBATCH_MAX_RECORDS_EXCEEDED + " got " + str(len(requestRecords)) + " records but max is " + str(BatchFileParser.BATCH_MAX_RECORDS))
            logging.error(apiErrors.FAILBATCH_MAX_RECORDS_EXCEEDED + " got " + str(len(requestRecords)) + " records but max is " + str(BatchFileParser.BATCH_MAX_RECORDS))
            raise LambdaValidationException(apiErrors.FAILBATCH_MAX_RECORDS_EXCEEDED)
        

    def transformToSchema(self, requestContext, requestRecord):
        '''
        Transforms the incoming spreadsheet json into the iResearch SubmitCaseRequest json schema.
        If any unknown elements are found, they are left intact.
        '''
        rschSubType = self._convertRschSubType(apiFields.MNB_FLD_RSCH_SUB_TYPE, requestRecord)
        rschComment = self._convertToString(apiFields.MNB_FLD_SUBMITTER_COMMENT, requestRecord)
        finStmtComment = self._convertToString(apiFields.MNB_FLD_FIN_STMT_CONCERN, requestRecord)
        finRatioComment = self._convertToString(apiFields.MNB_FLD_FIN_RATIO_CONCERN, requestRecord)
        finFiguresComment = self._convertToString(apiFields.MNB_FLD_FIN_FIGURES_CONCERN, requestRecord)
        
        irschDict = {
            "researchRequest": {
                "requestMethodCode": requestContext.userSession.requestMethodCode,
                "requestorOrganizationName": self._convertToString(apiFields.MNB_FLD_ORGANIZATION_NAME, requestRecord),
                "requestorPreferredLanguageCode": 331,
                #"internalDnbRequestorName": requestContext.userSession.emailId,
                "requestorOwnRequestKey": self._convertToString(apiFields.MNB_FLD_REQUEST_KEY, requestRecord),
                "internalRefId": requestRecord.getInternalRefIds()
            },
            "subjectResearch": {
                "submittedData": {
                    "duns": self._convertToDuns(apiFields.MNB_FLD_SUBJECT_DUNS, requestRecord),
                    "countryCode": self._convertCountry(apiFields.MNB_FLD_COUNTRY_ISO2, requestRecord),
                    "ceoName": self._convertToString(apiFields.MNB_FLD_CEO_NAME, requestRecord),
                    "ceoJobTitle": self._convertToString(apiFields.MNB_FLD_CEO_TITLE, requestRecord),
                    "organizationName": self._convertToString(apiFields.MNB_FLD_ORG_PRIMARY_NAME, requestRecord),
                    "tradeStyleName": self._convertToString(apiFields.MNB_FLD_TRADE_STYLE_NAME, requestRecord),
                    "url": self._convertToString(apiFields.MNB_FLD_URL, requestRecord),
                    "numberOfEmployees": self._convertToInt(apiFields.MNB_FLD_NUMBER_EMPLOYEES, requestRecord),
                    "salesAmount": self._convertToDecimal(apiFields.MNB_FLD_YEARLY_REVENUE, requestRecord),
                    "primaryIndustryDescription": self._convertToString(apiFields.MNB_FLD_INDUSTRY_DESCR, requestRecord),
                    "legalFormDescription": self._convertToString(apiFields.MNB_FLD_HIST_LEGAL_FORM, requestRecord),
                    "startYear": self._convertToInt(apiFields.MNB_FLD_HIST_START_YEAR, requestRecord),
                    "controlDate": self._convertToString(apiFields.MNB_FLD_HIST_CONTROL_YEAR, requestRecord),
                    "isActiveBusiness": self._convertOperationalStatus(apiFields.MNB_FLD_OPERATIONAL_STATUS, requestRecord),
                    "acquirer": {
                        "duns": self._convertToDuns(apiFields.MNB_FLD_ACQ_DUNS, requestRecord),
                        "organizationName": self._convertToString(apiFields.MNB_FLD_ACQ_BUS_NM, requestRecord),
                        "countryCode": self._convertCountry(apiFields.MNB_FLD_ACQ_COUNTRY_ISO2, requestRecord),
                        "address": {
                            "streetAddress": self._convertToString(apiFields.MNB_FLD_ACQ_ADDR_STREET, requestRecord),
                            "town": self._convertToString(apiFields.MNB_FLD_ACQ_ADDR_TOWN, requestRecord),
                            "territory": self._convertToString(apiFields.MNB_FLD_ACQ_ADDR_REGION, requestRecord),
                            "postalCode": self._convertToString(apiFields.MNB_FLD_ACQ_ADDR_POSTAL_CODE, requestRecord)
                        },
                        "telephone": {
                            "telephone": self._convertToString(apiFields.MNB_FLD_ACQ_TELEPHONE, requestRecord)
                        }
                    },
                    "owner": {
                        "ownerIdentity": {
                            "duns": self._convertToDuns(apiFields.MNB_FLD_OWN_DUNS, requestRecord),
                            "organizationName": self._convertToString(apiFields.MNB_FLD_OWN_BUS_NM, requestRecord),
                            "countryCode": self._convertCountry(apiFields.MNB_FLD_OWN_COUNTRY_ISO2, requestRecord),
                            "address": {
                                "streetAddress": self._convertToString(apiFields.MNB_FLD_OWN_ADDR_STREET, requestRecord),
                                "town": self._convertToString(apiFields.MNB_FLD_OWN_ADDR_TOWN, requestRecord),
                                "territory": self._convertToString(apiFields.MNB_FLD_OWN_ADDR_REGION, requestRecord),
                                "postalCode": self._convertToString(apiFields.MNB_FLD_OWN_ADDR_POSTAL_CODE, requestRecord)
                            },
                            "telephone": {
                                "telephone": self._convertToString(apiFields.MNB_FLD_OWN_TELEPHONE, requestRecord)
                            }
                        },
                        "isParent": self._convertBusinessOwnerType(apiFields.MBN_FLD_OWN_TYPE, requestRecord)
                    },
                    "addresses": [{
                        "town": self._convertToString(apiFields.MNB_FLD_PRIM_ADDR_TOWN, requestRecord),
                        "territory": self._convertToString(apiFields.MNB_FLD_PRIM_ADDR_REGION, requestRecord),
                        "postalCode": self._convertToString(apiFields.MNB_FLD_PRIM_ADDR_POSTAL_CODE, requestRecord),
                        "streetAddress": self._convertToString(apiFields.MNB_FLD_PRIM_ADDR_STREET, requestRecord),
                        "addressUsageTypeCode": AddressUsageTypeCode.PRIMARY_ADDRESS.value
                    }],
                    "contacts": [{
                        "contactName": self._convertToString(apiFields.MNB_FLD_CONTACT_NAME, requestRecord),
                        "emailAddress": self._convertToString(apiFields.MNB_FLD_CONTACT_EMAIL, requestRecord),
                        "phones": [{
                            "telephone": self._convertToString(apiFields.MNB_FLD_CONTACT_PHONE, requestRecord)
                        }]
                    }],
                    "organizationPhones": [{
                        "telephone": self._convertToString(apiFields.MNB_FLD_ORG_TELEPHONE, requestRecord)
                    }],
                    "principals": [{
                        "principalName": self._convertToString(apiFields.MNB_FLD_HIST_PRINCIPAL, requestRecord),
                        "jobTitle": self._convertToString(apiFields.MNB_FLD_HIST_TITLE, requestRecord)
                    }],
                    "shareOwnership": [{
                        "shareOwnerName": self._convertToString(apiFields.MBN_FLD_HIST_SHARE_OWNER_NM, requestRecord),
                        "ownershipSharePercentage": self._convertToDecimal(apiFields.MNB_FLD_HIST_SHARE_OWNER_PCT, requestRecord)
                    }],
                    "submittedRelatedOrganizations": [{
                        "organizationName": self._convertToString(apiFields.MNB_FLD_HIST_RELATED_ORG, requestRecord)
                    }],
                    "submittedDuplicateDunsNumbers": [{
                        "duns": self._convertToDuns(apiFields.MNB_FLD_DUPLICATE_DUNS, requestRecord)
                    }],
                    "lookupRules": self._convertLookupRules(apiFields.MNB_FLD_LOOKUP_RULE, requestRecord)
                },
                "researchTypes": [
                    {
                        "researchTypeCode": Converters.convertResearchSubTypeToType(apiFields.MNB_FLD_RSCH_SUB_TYPE, rschSubType, requestRecord, SubmitCaseType.MINI_BATCH.value),
                        "researchSubTypeCode": rschSubType
                    }
                ]
            },
            "researchComments": [
                {
                    "commentTypeCode": CommentTypeCode.RESEARCH_REQUESTOR_COMMENT.value if isNotBlank(rschComment) else None,
                    "researchComment": rschComment
                },
                {
                    "commentTypeCode": CommentTypeCode.REMOVE_FINANCIAL_STATEMENT_COMMENT.value if isNotBlank(finStmtComment) else None,
                    "researchComment": finStmtComment
                },
                {
                    "commentTypeCode": CommentTypeCode.FINANCIAL_RATIOS_COMMENT.value if isNotBlank(finRatioComment) else None,
                    "researchComment": finRatioComment
                },
                {
                    "commentTypeCode": CommentTypeCode.FINANCIAL_FIGURES_COMMENT.value if isNotBlank(finFiguresComment) else None,
                    "researchComment": finFiguresComment
                }
            ]
        }
        
        requestRecord.apiSchemaRecords = [ irschDict ]


    # Operational status codes:
    OPERATIONAL_STATUS_MAPPING = {
        'Active': True,
        'Inactive': False
    }


    # Business Owner type:
    BUSINESS_OWNER_TYPE_MAPPING = {
        'Parent': True,
        'Headquarters': False
    }
    
    
    def _convertRschSubType(self, fldName, requestRecord):
        '''
        Sample input: 'Chief Executive Officer (CEO) : 33552'
        Sample output: 33552
        '''
        rec = requestRecord.originalRecords[0]
        inp = rec.get(fldName)
        try:
            cd = int(inp.split(':')[1])
        except:
            #No need to record rejection here since validation module will handle this
            #requestRecord.addRejection(RequestRejectionError(jsonPathName=apiFields.MNB_FLD_RSCH_SUB_TYPE, errorDescription=apiErrors.FAILREC_NOT_A_INTEGER_CONVERSION, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
            return None
        return cd


    def _convertToInt(self, fldName, requestRecord):
        '''
        Converts the input value to an integer, even if it came in as a string.
        '''
        rec = requestRecord.originalRecords[0]
        inp = rec.get(fldName)
        outp = None
        if inp:
            try:
                outp = intDefaultNone(inp)
            except:
                requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_NOT_A_INTEGER_CONVERSION, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
             
        return outp


    def _convertToDecimal(self, fldName, requestRecord):
        '''
        Converts the input value to a number, even if it came in as a string.
        '''
        rec = requestRecord.originalRecords[0]
        inp = rec.get(fldName)
        outp = None
        if inp:
            try:
                outp = decimalDefaultNone(inp)
            except:
                requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_NOT_A_NUMBER_CONVERSION, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
             
        return outp


    def _convertToString(self, fldName, requestRecord):
        rec = requestRecord.originalRecords[0]
        inp = defaultNone(rec.get(fldName))
        outp = None
        if inp:
            if isinstance(inp, str):
                outp = defaultNone(inp)
            else:
                try:
                    outp = str(inp)
                except:
                    # Input could not be stringified
                    requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_NOT_A_STRING_CONVERSION, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
             
        return outp
    
    
    def _convertToDuns(self, fldName, requestRecord):
        rec = requestRecord.originalRecords[0]
        inp = defaultNone(rec.get(fldName))
        outp = inp
        if inp:
            try:
                outp = normalizeDuns(inp)
            except:
                # Input could not be stringified
                requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_NOT_A_VALID_DUNS, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
             
        return outp
    
    
    def _convertCountry(self, fldName, requestRecord):
        '''
        Sample input: 'UNITED STATES : US'
        Sample output: US
        '''
        rec = requestRecord.originalRecords[0]
        inp = defaultNone(rec.get(fldName))
        outp = None
        if inp:
            try:
                inpSplit = inp.split(':')
                if len(inpSplit) > 1: 
                    outp = inpSplit[1].strip()
                else:
                    outp = inp
#                 if len(outp) != 2 or not outp.isalpha():
#                     requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_INVALID_COUNTRY_CODE, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
#                     outp = None
            except:
                requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_INVALID_COUNTRY, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)
                outp = None
            
        return outp


    def _convertOperationalStatus(self, fldName, requestRecord):
        '''
        Maps the Active/Inactive code to True/False
        TODO consider moving this into the SubmitCaseApiTransformationService so it works for API users too
        '''
        rec = requestRecord.originalRecords[0]
        inp = defaultNone(rec.get(fldName))
        if not inp:
            return None
        
        isActive = BatchFileParser.OPERATIONAL_STATUS_MAPPING.get(str(inp).strip())
        if isinstance(isActive, bool):
            return isActive

        requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_UNSUPPORTED_OPERATIONAL_STATUS, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)


    def _convertBusinessOwnerType(self, fldName, requestRecord):
        '''
        Maps the Parent/Headquarters code to True/False
        TODO consider moving this into the SubmitCaseApiTransformationService so it works for API users too
        '''
        rec = requestRecord.originalRecords[0]
        inp = defaultNone(rec.get(fldName))
        if not inp:
            # Not valid but it will be caught later during validations
            return None
        
        isParent = BatchFileParser.BUSINESS_OWNER_TYPE_MAPPING.get(inp.strip())
        if isinstance(isParent, bool):
            return isParent

        requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_UNSUPPORTED_BUSINESS_OWNER, providedValue=inp), RejectionReasonCode.VALIDATION_ERROR)


    def _convertLookupRules(self, fldName, requestRecord):
        rec = requestRecord.originalRecords[0]
        inp = defaultNone(rec.get(fldName))
        if not inp:
            return None
        return [{"lookupRule": inp}]


    def getSheetName(self, batchRecord):
        if batchRecord.batchType == BatchType.GENERIC_BATCH.name:
            return BatchFileParser.BDR_COMPLEX_BATCH_SHEETNAME
        elif batchRecord.batchType == BatchType.NEW_DUNS_MINI_BATCH.name:
            return BatchFileParser.BDR_SIMPLE_BATCH_SHEETNAME
        elif batchRecord.batchType == BatchType.CAMPAIGN_BATCH.name:
            return BatchFileParser.CAMPAIGN_BATCH_SHEETNAME
        else:
            logging.error(f"{errorMessages.ERR_UNSUPPORTED_BATCH_TYPE} {batchRecord.batchType}")
            raise LambdaValidationException(errorMessages.ERR_UNSUPPORTED_BATCH_TYPE)