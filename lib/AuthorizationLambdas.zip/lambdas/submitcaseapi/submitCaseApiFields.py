'''
Created on Jun 13, 2019
Direct+ API Field names for SubmitCaseApi

@author: VanCampK
'''

# SUBMIT FIELDS

# Common fields for all research types
API_FLD_INTERNAL_REF_ID = "internalRefId"     # Tracks the record numbers in the original batch
API_FLD_RSCH_SUB_TYPES = "researchSubTypes"
API_FLD_REQUEST_KEY = "requestorOwnRequestKey"
API_FLD_REQUEST_DESCRIPTION = "requestorOwnRequestDescription"
API_FLD_EXTERNAL_INVS_ID = "externalInvestigationId"
API_FLD_THIRD_PARTY_EMAILS = "notificationContacts"
API_FLD_SUBMITTED_DATA = "submittedData"
API_FLD_RESEARCH_COMMENTS = "researchComments"
API_FLD_COMMENT_TYP_CD = "commentTypeCode"
API_FLD_RESEARCH_COMMENT = "researchComment"
API_FLD_DUNS = "duns"
API_FLD_COUNTRY_CODE = "countryCode"
API_FLD_CUSTOMER_REF_NAME = "customerReferenceName"
API_FLD_ATTACHMENT_REQUESTS = "requestAttachmentLinks"
API_FLD_ATTACHMENT_NAME = "attachmentName"
API_PATH_FLD_DUNS = API_FLD_SUBMITTED_DATA + "." + API_FLD_DUNS
API_PATH_FLD_COUNTRY_CODE = API_FLD_SUBMITTED_DATA + "." + API_FLD_COUNTRY_CODE
API_PATH_FLD_PRIORITY = "priority"
API_FLD_REQUESTOR_PREF_LANG_CODE = "requestorPreferredLanguageCode"

IRSCH_FLD_BATCH_REQ_ID = "batchRequestId"
IRSCH_FLD_BATCH_RESEARCH_REQUEST = "batchResearchRequest"       # Stores the original record from a batch, as it came in
IRSCH_FLD_INTERNAL_REF_ID = "internalRefId"     # Tracks the record numbers in the original batch
IRSCH_FLD_RESEARCH_COMMENTS = "researchComments"
IRSCH_FLD_COMMENT_TYP_CD = "commentTypeCode"
IRSCH_FLD_RESEARCH_COMMENT = "researchComment"
IRSCH_FLD_ATTACHMENT_FILENAME = "filename"

MNB_FLD_ORGANIZATION_NAME = "Subscriber Name"

IRSCH_FLD_REQUEST_KEY = "requestorOwnRequestKey"
IRSCH_FLD_EXTERNAL_INVS_ID = "externalInvestigationId"
IRSCH_FLD_REQUEST_DESCRIPTION = "requestorOwnRequestDescription"
IRSCH_FLD_THIRD_PARTY_EMAILS = "notificationContacts"
IRSCH_FLD_CUSTOMER_REF_NAME = "customerReferenceName"
IRSCH_FLD_OTHER_APP_TRAN_ID = "otherApplicationTranId"
IRSCH_FLD_CUSTOMER_REF_EMAIL = "customerReferenceEmail"
IRSCH_FLD_USER_API_KEY_TYPE = "userAPIKeyType"
IRSCH_FLD_SESSION_GUID = "sessionGuid"
IRSCH_FLD_SUBSCRIBER_DRT = "subscriberDRT"
IRSCH_FLD_RESEARCH_REQUEST_TYPE = "researchRequestType"
IRSCH_FLD_REQUESTOR_PREF_LANG_CODE = "requestorPreferredLanguageCode"
IRSCH_FLD_PRIORITY = "priority"
IRSCH_FLD_SUBSCRIBER_NUMBER = "subscriberNumber"
MNB_FLD_REQUEST_KEY = "Client Request Key"

MNB_FLD_SUBJECT_DUNS = "D-U-N-S"

MNB_FLD_COUNTRY_ISO2 = "Expected Physical Address Country (ISO2)"

IRSCH_FLD_RSCH_SUB_TYPE = "subjectResearch.researchTypes[].researchSubTypeCode"     # Only used to record jsonpath
IRSCH_FULL_FLD_COUNTRY_CODE = "subjectResearch.submittedData.countryCode"
IRSCH_FULL_FLD_DUNS = "subjectResearch.submittedData.duns"
MNB_FLD_RSCH_SUB_TYPE = "Research Sub Type Code"
MNB_FLD_SUBMITTER_COMMENT = "Request Comment"

# Fields for Primary Business Name:
MNB_FLD_CEO_NAME = "Expected Primary Principal Name"
MNB_FLD_CEO_TITLE = "Expected Primary Principal Title"
MNB_FLD_ORG_PRIMARY_NAME = "Expected Business Name"
MNB_FLD_TRADE_STYLE_NAME = "Expected Trade Style Name"
MNB_FLD_PRIM_ADDR_REGION = "Expected Physical Address Region"
MNB_FLD_PRIM_ADDR_STREET = "Expected Physical Address Street"
MNB_FLD_PRIM_ADDR_TOWN = "Expected Physical Address Town"
MNB_FLD_PRIM_ADDR_POSTAL_CODE = "Expected Physical Address Postal Code"
#TODO MNB_FLD_PRIM_ADDR_COUNTY = "Expected Physical Address County"
MNB_FLD_ORG_TELEPHONE = "Expected Business Telephone Number"
MNB_FLD_NUMBER_EMPLOYEES = "Expected Number of Employees"
MNB_FLD_YEARLY_REVENUE = "Expected Annual Sales"
MNB_FLD_INDUSTRY_DESCR = "Expected Industry Code / Description"
MNB_FLD_URL = "Subject Business URL"
MNB_FLD_CONTACT_NAME = "Subject Business Contact Name"
MNB_FLD_CONTACT_EMAIL = "Subject Business Contact Email"
MNB_FLD_CONTACT_PHONE = "Subject Business Contact Phone"

# Fields for Expected Financial Information:
MNB_FLD_FIN_STMT_CONCERN = "Financial Statement Concern Text"
MNB_FLD_FIN_RATIO_CONCERN = "Financial Ratio Concern Text"
MNB_FLD_FIN_FIGURES_CONCERN = "Financial Figures Concern Text"

# Fields for Expected History Information:
MNB_FLD_HIST_LEGAL_FORM = "Expected Legal Form Description"
MNB_FLD_HIST_START_YEAR = "Expected Year Started"
MNB_FLD_HIST_CONTROL_YEAR = "Expected Control Year"
MNB_FLD_HIST_PRINCIPAL = "Expected Principal Name"
MNB_FLD_HIST_TITLE = "Expected Principal Title"
MBN_FLD_HIST_SHARE_OWNER_NM = "Expected Share Owner Name"
MNB_FLD_HIST_SHARE_OWNER_PCT = "Expected % of Stock Ownership"
MNB_FLD_HIST_RELATED_ORG = "Expected Related Organization / Affiliate Name"

# Fields for Expected Operational Status Information:
MNB_FLD_OPERATIONAL_STATUS = "Expected Operational Status"

# Fields for Duplicate DUNS Number:
MNB_FLD_DUPLICATE_DUNS = "Duplicate DUNS Number"

# Fields for M&A:
MNB_FLD_ACQ_DUNS = "Acquirer D-U-N-S Number"
MNB_FLD_ACQ_BUS_NM = "Acquirer Business Name"
MNB_FLD_ACQ_COUNTRY_ISO2 = "Acquirer Physical Address Country (ISO2)"
MNB_FLD_ACQ_ADDR_REGION = "Acquirer Physical Address Region"
MNB_FLD_ACQ_ADDR_STREET = "Acquirer Physical Address Street"
MNB_FLD_ACQ_ADDR_TOWN = "Acquirer Physical Address Town"
MNB_FLD_ACQ_ADDR_POSTAL_CODE = "Acquirer Physical Address Postal Code"
MNB_FLD_ACQ_TELEPHONE = "Acquirer Telephone Number"
MNB_FLD_OWN_DUNS = "Owner D-U-N-S Number"
MNB_FLD_OWN_BUS_NM = "Owner Business Name"
MNB_FLD_OWN_COUNTRY_ISO2 = "Owner Physical Address Country (ISO2)"
MNB_FLD_OWN_ADDR_REGION = "Owner Physical Address Region"
MNB_FLD_OWN_ADDR_STREET = "Owner Physical Address Street"
MNB_FLD_OWN_ADDR_TOWN = "Owner Physical Address Town"
MNB_FLD_OWN_ADDR_POSTAL_CODE = "Owner Physical Address Postal Code"
MNB_FLD_OWN_TELEPHONE = "Owner Telephone Number"
MBN_FLD_OWN_TYPE = "Business Owner Type"

# Fields to support CFP GetNext/Manual Lookup:
MNB_FLD_LOOKUP_RULE = "Lookup Rule"

# RESPONSE FIELDS
# Field names common to IRSCH and API
BOTH_RESP_REQUEST_KEY = "requestorOwnRequestKey"
BOTH_RESP_RESEARCH_REQUEST_ID = "researchRequestId"
BOTH_RESP_SUBJECT_RESEARCH_ID = "subjectResearchId"
BOTH_RESP_REQUEST_DESCRIPTION = "requestorOwnRequestDescription"
BOTH_RESP_RESEARCH_TYPE_CODE  = "researchTypeCode"
BOTH_RESP_RESEARCH_SUB_TYPE_CODE  = "researchSubTypeCode"
BOTH_RESP_DUNS = "duns"
BOTH_RESP_ORGANIZATION_NM = "organizationName"
BOTH_RESP_EXTERNAL_INVS_ID = "externalInvestigationId"

# iResearch response fields
IRSCH_RESP_RESEARCH_REQUEST = "researchRequest"
IRSCH_RESP_SUBJECT_RESEARCHES = "subjectResearches"
IRSCH_RESP_RESEARCH_TYPES = "researchTypes"
IRSCH_RESP_SUBMITTED_DATA = "submittedData"

# API response fields
API_RESP_SUBJECT_RESEARCHES = "subjectResearches"              # TODO may change
API_RESP_SUBJECT_RESEARCH_TYPES = "subjectResearchTypes"
API_RESP_SUBJECT_RESEARCH_IDENTIFIERS = "subjectResearchIdentifiers"
API_RESP_ATTACHMENTS = "attachmentLinkSignedUrls"
API_RESP_ATTACHMENT_NAME = "attachmentName"
API_RESP_ATTACHMENT_URL = "url"
API_RESP_ATTACHMENT_FIELDS = "fields"

# Special research subtypes
RSCH_SUBTYPE_FINANCIAL_RATIOS = 33770
RSCH_SUBTYPE_FINANCIAL_FIGURES = 33769
