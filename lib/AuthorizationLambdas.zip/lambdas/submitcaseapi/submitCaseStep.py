'''
Created on Jul 29, 2019

@author: VanCampK
'''
from enum import Enum

class SubmitCaseStep(Enum):
    # Identifies the step in batch processing
    SUBMIT_CASE_BATCH_PARSER = 1
    SUBMIT_CASE_BATCH_SUBMITTER = 2
