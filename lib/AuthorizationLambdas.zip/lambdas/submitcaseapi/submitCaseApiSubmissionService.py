'''
Created on Jun 11, 2019

@author: VanCampK
'''
import copy
import logging
import jmespath
import json
from common import envVblNames
from common.batchWatchTypeCodes import BatchWatchTypeCode
from common.encoders import DecimalAsFloatEncoder
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.stringUtils import isBlank
from common.util.sqsHelper import SqsHelper
from lambdas.exceptions import LambdaProcessingException
from lambdas.lambdaCommon import buildLambdaSecureInvokeEvent, invokeLambdaFunction, parsePayloadFromInvokeResponse, parseHTTPStatusCodeFromInvokeResponse, parseStatusCodeFromPayload, parseStatusCodeFromInvokeResponse
from lambdas import lambdaConstants
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.requestRejectionError import RequestRejectionError
from lambdas.submitcaseapi.specialSubmitCaseExceptionType import SpecialSubmitCaseExceptionType
import lambdas.submitcaseapi.submitCaseApiErrors as apiErrors
import lambdas.submitcaseapi.submitCaseApiFields as apiFields
from lambdas.submitcaseapi.submitStatus import SubmitStatus


class SubmitCaseApiSubmissionService(object):
    '''
    Submits the requests to the BatchDetail or SubmitCaseForBatch service
    '''
    EXIT_WHEN_MILLISECS_LEFT = 10000
    
    # Elements of the submitOneRequest response dictionary:
    RESULT_STATUS_CODE = "statusCode"
    RESULT_ERR_MSG = "errmsg"
    RESULT_BODY = "responseBody"
    RESULT_ERR_RESPONSE = "errorResponse"
    ERROR_MESSAGE = "errorMessage"
    ERROR_TYPE = "errorType"
    
    submitCaseSqsHelper = None
    submitCaseWithDunsSqsHelper = None
    batchDetailSqsHelper = None
    batchDetailWithDunsSqsHelper = None
    submitCaseBatchSubmitterSqsHelper = None
    batchWatchSqsHelper = None
    submitCaseBatchParserSqsHelper = None
    
    
    def __init__(self, lambdaClient, dbConn, batchRequestDao):
        self.lambdaClient = lambdaClient
        self.dbConn = dbConn
        self.batchRequestDao = batchRequestDao
    

    def submitAllRequests(self, requestContext, batchRecord):
        '''
        Submits all requests in a batch
        '''
        nSubmittedWithDuns = 0
        nSubmittedNoDuns = 0
        nError = 0
        nRemaining = len(batchRecord.requestRecords)
        nSkipped = 0
        submitCaseQueueUrl = requestContext.environDict.get(envVblNames.ENV_SUBMITCASE_QUEUE_URL)
        submitCaseWithDunsQueueUrl = requestContext.environDict.get(envVblNames.ENV_SUBMITCASEWITHDUNS_QUEUE_URL)
        for requestRecord in batchRecord.requestRecords:
            if batchRecord.startingRecordNumber is not None and requestRecord.recordNumber < batchRecord.startingRecordNumber:
                logging.info(f"Skipping over record {requestRecord.recordNumber} because startingRecordNumber={batchRecord.startingRecordNumber}")
                nSkipped += 1
                nRemaining -= 1
                continue
            timeLeft = requestContext.lambdaContext.get_remaining_time_in_millis()
            logging.info(f"submitAllRequests: Time left {timeLeft} milliseconds with {nRemaining} records remaining to be submitted.")
            if timeLeft < SubmitCaseApiSubmissionService.EXIT_WHEN_MILLISECS_LEFT:
                logging.warning(f"submitAllRequests: Out of time, pushing message to queue to resume at record {requestRecord.recordNumber}")
                self._abortBatchSubmission(requestContext, batchRecord, requestRecord.recordNumber)
                logging.warning(f"Batch submission INCOMPLETE: {nSubmittedWithDuns} requests submitted to SubmitCaseWithDuns, {nSubmittedNoDuns} submitted to SubmitCase, {nSkipped} skipped and {nError} errors, and {nRemaining} remaining to be submitted.")
                return
            nRemaining -= 1
            if not requestRecord.isRejected() and not requestRecord.isSuppressed:
                # Submit via queue
                statusCode = self._submitOneRequestViaQueue(requestContext, requestRecord, submitCaseQueueUrl, submitCaseWithDunsQueueUrl, batchRecord)
                if statusCode == SubmitStatus.SubmittedWithError.value:
                    nError += 1
                    #TODO automated retry?
                elif statusCode == SubmitStatus.SubmittedToNoDunsQueue.value:
                    nSubmittedNoDuns += 1
                else:
                    nSubmittedWithDuns += 1
            else:
                nSkipped += 1
                logging.warning(f"batchRequestId={batchRecord.batchRequestId} recordNumber={requestRecord.recordNumber}: Won't submit because isRejected={requestRecord.isRejected()} or isSuppressed={requestRecord.isSuppressed}")
                    
        logging.info(f"Batch submission complete: {nSubmittedWithDuns} requests submitted to SubmitCaseWithDuns, {nSubmittedNoDuns} submitted to SubmitCase, {nSkipped} skipped and {nError} errors")
        if nSubmittedWithDuns == 0 and nSubmittedNoDuns == 0:
            # Special case where there was nothing to submit, need to send a message to tell BatchWatchService to check counts again.
            self._notifyBatchWatchSubmissionComplete(requestContext, batchRecord)


    def submitOneRequest(self, requestContext, requestRecord, invokeType=lambdaConstants.INVOKE_LAMBDA_REQUEST_RESPONSE):
        '''
        Submits one request to the SubmitCase lambda VIA INVOKE and returns a dictionary:
        { "statusCode": 200, "errmsg": "", "responseBody": { ... } }
        For asynchronous submit, the responseBody will not be filled in.
        '''
        outgoingBody = json.dumps(requestRecord.iResearchSchemaRecord, cls=DecimalAsFloatEncoder)
        logging.info('SubmitCase: outgoingBody=' + outgoingBody)
        #print('outgoingBody=' + outgoingBody)
        event = buildLambdaSecureInvokeEvent(requestContext.userSession.principalId, 'POST', '/submitcase', body=outgoingBody)
        response = invokeLambdaFunction(self.lambdaClient, event, requestContext.environDict[envVblNames.ENV_SUBMITCASE_ARN], invokeType)
        
        resultDict = {
            SubmitCaseApiSubmissionService.RESULT_STATUS_CODE: None,
            SubmitCaseApiSubmissionService.RESULT_ERR_MSG: None,
            SubmitCaseApiSubmissionService.RESULT_BODY: None
        }
        isSuccess = True
        httpStatusCode = parseHTTPStatusCodeFromInvokeResponse(response)
        resultDict[SubmitCaseApiSubmissionService.RESULT_STATUS_CODE] = httpStatusCode
        if httpStatusCode != LambdaStatusCodes.OK.value and httpStatusCode != LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
            isSuccess = False
            resultDict[SubmitCaseApiSubmissionService.RESULT_ERR_MSG] = 'Failed to submitOneRequest: response=' + str(response)
            errmsg = 'httpStatusCode=' + str(httpStatusCode)
            logging.error('Failed to submitOneRequest #1: errmsg=' + errmsg + ' response=' + str(response))
        elif invokeType == lambdaConstants.INVOKE_LAMBDA_ASYNC:
            # Handle asynchronous invoke response: can only return success or failure indicator
            statusCode = parseStatusCodeFromInvokeResponse(response)
            if statusCode != LambdaStatusCodes.OK.value and statusCode != LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
                isSuccess = False
                resultDict[SubmitCaseApiSubmissionService.RESULT_STATUS_CODE] = statusCode
                resultDict[SubmitCaseApiSubmissionService.RESULT_ERR_MSG] = 'Failed to submitOneRequest #2: response=' + str(response)
                errmsg = 'statusCode=' + str(statusCode)
                logging.error('Failed to submitOneRequest: errmsg=' + errmsg + ' response=' + str(response))
        else:
            # Handle synchronous invoke response
            responsePayload = parsePayloadFromInvokeResponse(response)
            if responsePayload:
                logging.info('Response payload from SubmitCase:' + str(responsePayload))
                #print('Response payload from SubmitCase:' + str(responsePayload))
                statusCode = parseStatusCodeFromPayload(responsePayload)
                resultDict[SubmitCaseApiSubmissionService.RESULT_STATUS_CODE] = statusCode
                responseBody = responsePayload.get('body')
                if responseBody is not None:
                    resultDict[SubmitCaseApiSubmissionService.RESULT_BODY] = json.loads(responseBody)
                if statusCode != LambdaStatusCodes.OK.value:
                    isSuccess = False
                    resultDict[SubmitCaseApiSubmissionService.RESULT_ERR_MSG] = 'Failed to submitOneRequest #3: response payload=' + str(responsePayload)
                    errmsg = 'statusCode=' + str(statusCode)
                    logging.error('Failed to submitOneRequest: errmsg=' + errmsg + ' response=' + str(response))
                    self._addSubmitRejection(requestContext, requestRecord, resultDict)
                
        logging.info('SubmitCaseApiService invoked SubmitCase: success=' + str(isSuccess))
        return resultDict


    def _addSubmitRejection(self, requestContext, requestRecord, resultDict):
        resultErrDict = resultDict[SubmitCaseApiSubmissionService.RESULT_BODY]
        errorResponse = None
        if resultErrDict is not None:
            errorResponse = resultErrDict.get(SubmitCaseApiSubmissionService.RESULT_ERR_RESPONSE)
            if errorResponse is not None:
                errorMessage = errorResponse.get(SubmitCaseApiSubmissionService.ERROR_MESSAGE)
                errorType = errorResponse.get(SubmitCaseApiSubmissionService.ERROR_TYPE)
                # Most issues in SubmitCase are caused by DUNS,
                # since routing rules or country to research subtype errors are discovered from the DUNS firmographic lookup of country
                jsonPath = apiFields.API_PATH_FLD_DUNS
                providedValue = jmespath.search(jsonPath, requestRecord.originalRecords[0])
                if isBlank(providedValue):
                    # If no DUNS provided, then blame it on country code
                    jsonPath = apiFields.API_PATH_FLD_COUNTRY_CODE
                    providedValue = jmespath.search(jsonPath, requestRecord.originalRecords[0])
                rejectionReasonCode = self._mapErrorTypeToRejectionReason(errorType)
                requestRecord.addRejection(RequestRejectionError(jsonPathName=jsonPath, errorDescription=errorMessage, providedValue=providedValue), rejectionReasonCode)
                
        if errorResponse is None:
            requestRecord.addRejection(RequestRejectionError(errorDescription=apiErrors.FAILREC_FAILED_TO_SUBMIT), RejectionReasonCode.INTERNAL_ERROR)


    def _abortBatchSubmission(self, requestContext, batchRecord, startingRecordNumber):
        batchContinuationMessage = {
            "batchRequestId": batchRecord.batchRequestId,
            "startingRecordNumber": startingRecordNumber,
            "source": "SubmitCaseBatchSubmitter"
        }
        try:
            submitCaseBatchSubmitterQueueUrl = requestContext.environDict.get(envVblNames.ENV_SUBMITCASEBATCHSUBMITTER_QUEUE_URL)
            if SubmitCaseApiSubmissionService.submitCaseBatchSubmitterSqsHelper is None:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                SubmitCaseApiSubmissionService.submitCaseBatchSubmitterSqsHelper = SqsHelper(submitCaseBatchSubmitterQueueUrl, regionName=regionName)
                 
            outgoingBody = json.dumps(batchContinuationMessage, cls=DecimalAsFloatEncoder)
            logging.info(f"_abortBatchSubmission posting msg to queue {submitCaseBatchSubmitterQueueUrl}: outgoingBody={outgoingBody}")
            queueResp = SubmitCaseApiSubmissionService.submitCaseBatchSubmitterSqsHelper.sendMessageToQueue(outgoingBody)
            messageId = queueResp.get('MessageId')
            logging.info(f"_abortBatchSubmission: messageId={messageId} queueResp={queueResp}")
            if messageId is not None:
                return
        except Exception as e:
            logging.error(f"Failed to _abortBatchSubmission: e={e}")
            # Propagate exception so alert is raised and AWS retries
            raise e


    def _abortBatchDetailSubmission(self, requestContext, batchRecord, startingRecordNumber, resubmitQueueUrl, fileTrackingId):
        '''
        Sends a message back to own parser queue to restart processing midway through the batch.
        '''
        batchContinuationMessage = copy.deepcopy(requestContext.event) if fileTrackingId is None else {}
        if fileTrackingId is None:
            # For use from SubmitCaseApi
            batchContinuationMessage["batchRequestId"] = batchRecord.batchRequestId
        else:
            # For use from CfpParser
            batchContinuationMessage["fileTrackingId"] = fileTrackingId
        batchContinuationMessage["startingRecordNumber"] = startingRecordNumber
        batchContinuationMessage["source"] = "SubmitCaseBatchParser"
            
        batchRecord.isParseInProgress = True    # stops the database update
        try:
            #submitCaseBatchParserQueueUrl = requestContext.environDict.get(envVblNames.ENV_SUBMITCASEBATCHPARSER_QUEUE_URL)
            if SubmitCaseApiSubmissionService.submitCaseBatchParserSqsHelper is None:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                SubmitCaseApiSubmissionService.submitCaseBatchParserSqsHelper = SqsHelper(resubmitQueueUrl, regionName=regionName)
                 
            outgoingBody = json.dumps(batchContinuationMessage, cls=DecimalAsFloatEncoder)
            logging.info(f"_abortBatchDetailSubmission posting msg to queue {resubmitQueueUrl}: outgoingBody={outgoingBody}")
            queueResp = SubmitCaseApiSubmissionService.submitCaseBatchParserSqsHelper.sendMessageToQueue(outgoingBody)
            messageId = queueResp.get('MessageId')
            logging.info(f"_abortBatchDetailSubmission: messageId={messageId} queueResp={queueResp}")
            if messageId is not None:
                return
        except Exception as e:
            logging.error(f"Failed to _abortBatchDetailSubmission: e={e}")
            # Propagate exception so alert is raised and AWS retries
            raise e
        

    def _mapErrorTypeToRejectionReason(self, errorType):
        rejectionReasonCode = RejectionReasonCode.VALIDATION_ERROR
        if errorType == SpecialSubmitCaseExceptionType.ERROR_TYPE_ROUTING_RULES.value or errorType == SpecialSubmitCaseExceptionType.ERROR_TYPE_UNK_COUNTRY_TO_SUBTYPE.value:
            rejectionReasonCode = RejectionReasonCode.UNSUPPORTED_REQUEST
        elif errorType == SpecialSubmitCaseExceptionType.ERROR_TYPE_INVALID_DUNS.value:
            rejectionReasonCode = RejectionReasonCode.INVALID_SUBJECT_DUNS
        return rejectionReasonCode


    def _submitOneRequestViaQueue(self, requestContext, requestRecord, submitCaseQueueUrl, submitCaseWithDunsQueueUrl, batchRecord):
        '''
        Submits one request to the SubmitCase lambda via queue and returns a SubmitStatus code
        '''
        try:
            if SubmitCaseApiSubmissionService.submitCaseSqsHelper is None:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                SubmitCaseApiSubmissionService.submitCaseSqsHelper = SqsHelper(submitCaseQueueUrl, regionName=regionName)
            if SubmitCaseApiSubmissionService.submitCaseWithDunsSqsHelper is None:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                SubmitCaseApiSubmissionService.submitCaseWithDunsSqsHelper = SqsHelper(submitCaseWithDunsQueueUrl, regionName=regionName)
                 
            outgoingBody = json.dumps(requestRecord.iResearchSchemaRecord, cls=DecimalAsFloatEncoder)
            scSqsHelper = SubmitCaseApiSubmissionService.submitCaseSqsHelper
            scQueueUrl  = submitCaseQueueUrl
            successStatus = SubmitStatus.SubmittedToNoDunsQueue.value
            if requestRecord.hasDuns():
                scSqsHelper = SubmitCaseApiSubmissionService.submitCaseWithDunsSqsHelper
                scQueueUrl  = submitCaseWithDunsQueueUrl
                successStatus = SubmitStatus.SubmittedToWithDunsQueue.value
            logging.debug(f'_submitOneRequestViaQueue: outgoingBody={outgoingBody}')
            #print('outgoingBody=' + outgoingBody)
            logging.debug(f'_submitOneRequestViaQueue: batchRecord={batchRecord} userSession={requestContext.userSession}')
            if batchRecord is not None and batchRecord.sessionToken is not None:
                authPrinIdObj = batchRecord.authPrinIdObj
            elif requestContext.userSession is not None and requestContext.userSession.principalId is not None:
                authPrinIdObj = requestContext.userSession.principalId
                logging.debug(f'_submitOneRequestViaQueue: authPrinIdObj={authPrinIdObj}')
            else:
                raise LambdaProcessingException(f"Unable to find authPrinIdObj for request.")
            event = buildLambdaSecureInvokeEvent(authPrinIdObj, 'POST', '/submitcase', body=outgoingBody)
            strEvent = json.dumps(event)
            logging.info(f'_submitOneRequestViaQueue: posting event to queue {scQueueUrl} for batch {batchRecord.batchRequestId} recordNumber {requestRecord.recordNumber}')
            logging.debug(f'_submitOneRequestViaQueue: full event = {strEvent}')
            queueResp = scSqsHelper.sendMessageToQueue(strEvent)
            messageId = queueResp.get('MessageId')
            logging.info(f'_submitOneRequestViaQueue: messageId={messageId} queueResp={queueResp}')
            if messageId is not None:
                return successStatus
        except Exception as e:
            logging.error('Failed to _submitOneRequestViaQueue: e=' + str(e))
            resultDict = {
                SubmitCaseApiSubmissionService.RESULT_STATUS_CODE: None,
                SubmitCaseApiSubmissionService.RESULT_ERR_MSG: None,
                SubmitCaseApiSubmissionService.RESULT_BODY: None
            }
            self._addSubmitRejection(requestContext, requestRecord, resultDict)
            
        return SubmitStatus.SubmittedWithError.value
    

    def submitAllBatchDetailRequests(self, requestContext, batchRecord, resubmitQueueUrl, fileTrackingId=None):
        '''
        Submits all requests in a batch to BatchDetail service
        '''
        # Get the list of record numbers that have already been processed, in case this is re-run
        existingRecNbrsDict = self.batchRequestDao.getBatchDetailRecordNumbers(self.dbConn, batchRecord.batchRequestId)
        existingRecNbrs = []
        for ernd in existingRecNbrsDict:
            recNbr = ernd.get('rec_nbr')
            if recNbr is not None:
                existingRecNbrs.append(recNbr)
        
        nSubmittedWithDuns = 0
        nSubmittedNoDuns = 0
        nError = 0
        nRemaining = len(batchRecord.requestRecords)
        nSkipped = 0
        batchDetailQueueUrl = requestContext.environDict.get(envVblNames.ENV_BATCHDETAIL_QUEUE_URL)
        batchDetailWithDunsQueueUrl = requestContext.environDict.get(envVblNames.ENV_BATCHDETAILWITHDUNS_QUEUE_URL)
        for requestRecord in batchRecord.requestRecords:
            if batchRecord.startingRecordNumber is not None and requestRecord.recordNumber < batchRecord.startingRecordNumber:
                logging.info(f"Skipping over record {requestRecord.recordNumber} because startingRecordNumber={batchRecord.startingRecordNumber}")
                nSkipped += 1
                nRemaining -= 1
                continue
            timeLeft = requestContext.lambdaContext.get_remaining_time_in_millis()
            logging.info(f"submitAllBatchDetailRequests: Time left {timeLeft} milliseconds with {nRemaining} records remaining to be submitted.")
            if timeLeft < SubmitCaseApiSubmissionService.EXIT_WHEN_MILLISECS_LEFT:
                logging.warning(f"submitAllBatchDetailRequests: Out of time, pushing message to {resubmitQueueUrl} queue to resume at record {requestRecord.recordNumber}")
                self._abortBatchDetailSubmission(requestContext, batchRecord, requestRecord.recordNumber, resubmitQueueUrl, fileTrackingId)
                logging.warning(f"BatchDetail submission INCOMPLETE: {nSubmittedWithDuns} requests submitted to BatchDetailWithDuns, {nSubmittedNoDuns} submitted to BatchDetail, {nSkipped} skipped and {nError} errors, and {nRemaining} remaining to be submitted.")
                return
            nRemaining -= 1
            if requestRecord.recordNumber in existingRecNbrs:
                logging.warning(f"DUP: Skipping recordNumber={requestRecord.recordNumber} in batchRequestId={batchRecord.batchRequestId} because already inserted in database")
                nSkipped += 1
            else:
                statusCode = self._submitOneBatchDetailRequest(requestContext, requestRecord, batchDetailQueueUrl, batchDetailWithDunsQueueUrl)
                if statusCode == SubmitStatus.SubmittedWithError.value:
                    nError += 1
                    #TODO automated retry?
                elif statusCode == SubmitStatus.SubmittedToNoDunsQueue.value:
                    nSubmittedNoDuns += 1
                else:
                    nSubmittedWithDuns += 1
                    
        logging.info(f"BatchDetail submission complete: {nSubmittedWithDuns} requests submitted to BatchDetailWithDuns, {nSubmittedNoDuns} submitted to BatchDetail, {nSkipped} skipped, and {nError} errors, and {nRemaining} remaining to be submitted.")


    def _submitOneBatchDetailRequest(self, requestContext, requestRecord, batchDetailQueueUrl, batchDetailWithDunsQueueUrl):
        '''
        Submits one request to the BatchDetail lambda via queue and returns a status code:
        LambdaStatusCodes.OK.value - in case of successful submit
        LambdaStatusCodes.INTERNAL_SERVER_ERROR.value - in case of error
        '''
        try:
            if SubmitCaseApiSubmissionService.batchDetailSqsHelper is None:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                SubmitCaseApiSubmissionService.batchDetailSqsHelper = SqsHelper(batchDetailQueueUrl, regionName=regionName)
            if SubmitCaseApiSubmissionService.batchDetailWithDunsSqsHelper is None:
                regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                SubmitCaseApiSubmissionService.batchDetailWithDunsSqsHelper = SqsHelper(batchDetailWithDunsQueueUrl, regionName=regionName)
                 
            outgoingBody = json.dumps(requestRecord.batchDetailRecord, cls=DecimalAsFloatEncoder)
            bdSqsHelper = SubmitCaseApiSubmissionService.batchDetailSqsHelper
            bdQueueUrl  = batchDetailQueueUrl
            successStatus = SubmitStatus.SubmittedToNoDunsQueue.value
            if requestRecord.hasDuns():
                bdSqsHelper = SubmitCaseApiSubmissionService.batchDetailWithDunsSqsHelper
                bdQueueUrl  = batchDetailWithDunsQueueUrl
                successStatus = SubmitStatus.SubmittedToWithDunsQueue.value
                
            logging.debug(f"_submitOneBatchDetailRequest posting msg to queue {bdQueueUrl}: outgoingBody={outgoingBody}")
            #print('outgoingBody=' + outgoingBody)
            logging.info(f"_submitOneBatchDetailRequest: posting event to queue {bdQueueUrl} for recordNumber {requestRecord.recordNumber}")
            queueResp = bdSqsHelper.sendMessageToQueue(outgoingBody)
            messageId = queueResp.get('MessageId')
            logging.info(f"_submitOneBatchDetailRequest: messageId={messageId} queueResp={queueResp}")
            if messageId is not None:
                return successStatus
        except Exception as e:
            logging.error('Failed to _submitOneBatchDetailRequest: e=' + str(e))
            resultDict = {
                SubmitCaseApiSubmissionService.RESULT_STATUS_CODE: None,
                SubmitCaseApiSubmissionService.RESULT_ERR_MSG: None,
                SubmitCaseApiSubmissionService.RESULT_BODY: None
            }
            self._addSubmitRejection(requestContext, requestRecord, resultDict)
            
        return SubmitStatus.SubmittedWithError.value
            
    
    def _notifyBatchWatchSubmissionComplete(self, requestContext, batchRecord):
        # Special case message to BWS when all requests in batch have been rejected
        sqsUrl = requestContext.environDict.get(envVblNames.ENV_BATCH_WATCH_QUEUE_URL)
        messageBody = {
                        "batchWatchTypeCode" : BatchWatchTypeCode.REQUEST_REJECTED.value,
                        "batchRequestId": batchRecord.batchRequestId
                      }
        logging.info(f"_notifyBatchWatchSubmissionComplete: Sending Special case message to BWS when all requests in batch have been rejected: {messageBody}")
        msgJson = json.dumps(messageBody)
        if not SubmitCaseApiSubmissionService.batchWatchSqsHelper:
            regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
            SubmitCaseApiSubmissionService.batchWatchSqsHelper = SqsHelper(queueUrl=sqsUrl, regionName=regionName)
        queueResp = SubmitCaseApiSubmissionService.batchWatchSqsHelper.sendMessageToQueue(msgJson)
        messageId = queueResp.get('MessageId')
        logging.info(f"_notifyBatchWatchSubmissionComplete: messageId={messageId} queueResp={queueResp}")
        