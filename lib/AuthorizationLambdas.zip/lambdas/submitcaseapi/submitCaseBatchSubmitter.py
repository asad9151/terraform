'''
@author: VanCampK
'''
import boto3
import logging
import json
import sys
import traceback
from buildUIResponse import buildUIResponse
from common import envVblNames
from common.irschRoles import IResearchRole
from common.util.awsUtils import createClientConfiguration
from common.util.stringUtils import isBlank
from common.util.sqsHelper import SqsHelper
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.lambdaBase import LambdaBase
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaAuthorizationException, LambdaValidationException
from lambdas.submitcaseapi.submitCaseApiService import SubmitCaseApiService
from lambdas.submitcaseapi.submitCaseStep import SubmitCaseStep
import lambdas.errorMessages as errmsg

class SubmitCaseBatchSubmitter(LambdaBase):
    '''
    Handler class for SubmitCaseBatchSubmitter service.
    Responsible for submitting batch requests after approval (or immediately after all batch details gathered if batch doesn't need approval).
    Handler: lambdas.submitcaseapi.submitCaseBatchSubmitter.handler
    '''
    s3handle = None
    snsClient = None
    batchSubmitterSqsHelper = None
    
    def __init__(self):
        super().__init__()
        self.service = None
    
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return True
    
    
    def handleRequest(self):
        if self.service is None:
            self.service = SubmitCaseApiService(SubmitCaseBatchSubmitter.dbConn, SubmitCaseBatchSubmitter.s3handle, None, SubmitCaseBatchSubmitter.snsClient, None)

        LambdaBase.raiseAlertWhenRequestFails = True
        incomingEvent = self.requestContext.event
        if 'Records' not in incomingEvent:
            logging.warning("SubmitCaseBatchSubmitter got event without Records - ignoring")
            return
        
        self.requestContext.serviceDict["step"] = SubmitCaseStep.SUBMIT_CASE_BATCH_SUBMITTER
        records = incomingEvent['Records']
        logging.info(f"Got multi-event request from queue with {len(records)} messages")
        lastException = None
        alertErrMsg = None
        for record in records:
            logging.info(f"SubmitCaseBatchSubmitter record={record}")
            sbody = record.get('body')
            if isinstance(sbody, str):
                body = json.loads(sbody)
            else:
                body = sbody
            batchRequestId = body.get('batchRequestId')
            source = body.get('source')
            startingRecordNumber = body.get('startingRecordNumber')
            messageId = record.get('messageId')
            messageReceiptHandle = record.get('receiptHandle')
            if batchRequestId is None:
                alertErrMsg = f"SubmitCaseBatchSubmitter: Ignoring unsupported request - expecting batchRequestId in incoming request.  record = {record}"
            else:
                logging.info(f"Got request to submit batchRequestId={batchRequestId} from source={source} with startingRecordNumber={startingRecordNumber}: messageId={messageId} messageReceiptHandle={messageReceiptHandle}")
                try:
                    self.service.loadBatchFromDatabase(self.requestContext, batchRequestId, startingRecordNumber)
                    self.service.processBatchFromDetails(self.requestContext)
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except LambdaValidationException as lve:
                    alertErrMsg = f"LambdaValidationException trying to process batchRequestId={batchRequestId}: {lve}"
                    # Raise alert but do not retry batch
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except Exception as e:
                    alertErrMsg = f"Unexpected exception trying to process batchRequestId={batchRequestId}: {e}"
                    traceback.print_tb(sys.exc_info()[2])
                    # Raise alert and retry batch (i.e. don't delete message from queue)
                    lastException = e
            # Continue on to next record regardless of failure of one message
            
        if lastException is not None:
            # Tells lambda to retry, also raises alert from LambdaBase
            raise lastException
        elif alertErrMsg is not None:
            # No retry but raise alert anyway
            LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=alertErrMsg)


    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7 ]) == False):
            logging.error('SubmitCaseBatchSubmitter - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)


    def initializeKeepWarm(self):
        if not SubmitCaseBatchSubmitter.s3handle:
            try:
                logging.info('Initializing s3handle...')
                SubmitCaseBatchSubmitter.s3handle = boto3.resource('s3', config=createClientConfiguration(SubmitCaseBatchSubmitter.environDict))
            except Exception as e:
                logging.error('SubmitCaseBatchSubmitter: problem connecting to s3 client.  error = %s', e)
                return buildUIResponse(LambdaStatusCodes.INTERNAL_SERVER_ERROR.value, 'Internal error in submit case api')
        if not SubmitCaseBatchSubmitter.snsClient:
            try:
                logging.info('Initializing snsClient...')
                SubmitCaseBatchSubmitter.snsClient = boto3.client('sns', region_name=SubmitCaseBatchSubmitter.environDict[envVblNames.ENV_SNS_REGION], config=createClientConfiguration(SubmitCaseBatchSubmitter.environDict))
            except Exception as e:
                logging.error('SubmitCaseBatchSubmitter: problem connecting to sns.  error = %s', e)
                return buildUIResponse(LambdaStatusCodes.INTERNAL_SERVER_ERROR.value, 'Internal error in submit case api')

    
    def isApi(self):
        '''
        By default we are behaving as there is a browser on the other side.
        Subclass can override this if they want API-type behavior.
        '''
        return True
        
        
    def _markMessageComplete(self, messageId, messageReceiptHandle):
        '''
        Deletes a message from the queue because we successfully processed it
        if (StringUtils.isBlank(messageId) || StringUtils.isBlank(messageReceiptHandle)) {
            logger.warn("Not deleting message from queue because no messageId or messageReceiptHandle");
            return;
        }
        String batchDetailQueueUrl = batchDetailConf.getBatchDetailQueueUrl();
        logger.info("Delete message from queue " + batchDetailQueueUrl + ": messageId#" + messageId + " messageReceiptHandle=" + messageReceiptHandle);
        DeleteMessageResult result = sqsClient.deleteMessage(new DeleteMessageRequest(batchDetailQueueUrl, messageReceiptHandle));
        logger.info("Result from deleteMessage: " + result.toString());
        '''
        if isBlank(messageId) or isBlank(messageReceiptHandle):
            logging.warning("Not deleting message from queue because no messageId or messageReceiptHandle")
            return
        batchSubmitterQueueUrl = SubmitCaseBatchSubmitter.environDict[envVblNames.ENV_SUBMITCASEBATCHSUBMITTER_QUEUE_URL]
        if SubmitCaseBatchSubmitter.batchSubmitterSqsHelper is None:
            regionName = SubmitCaseBatchSubmitter.environDict.get(envVblNames.ENV_SQS_REGION)
            SubmitCaseBatchSubmitter.batchSubmitterSqsHelper = SqsHelper(batchSubmitterQueueUrl, regionName=regionName)
        logging.info(f"Delete message from queue {batchSubmitterQueueUrl}: messageId={messageId} messageReceiptHandle={messageReceiptHandle}")
        result = SubmitCaseBatchSubmitter.batchSubmitterSqsHelper.deleteOneMessageFromQueue(messageReceiptHandle)
        logging.info(f"markMesageComplete: messageReceiptHandle={messageReceiptHandle} result={result}")
        
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SubmitCaseBatchSubmitter.get_handler(...)