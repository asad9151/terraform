'''
Utility functions for SubmitCaseApi

@author: VanCampK
'''

def getDunsFromIResearchSchemaRecord(iResearchSchemaRecord):
    subjectResearch = iResearchSchemaRecord.get('subjectResearch')
    if subjectResearch:
        submittedData = subjectResearch.get('submittedData')
        if submittedData:
            duns = submittedData.get('duns')
            return duns
    return None


def getResearchSubTypesFromIResearchSchemaRecord(iResearchSchemaRecord):
    '''
    Returns a list of all research subtypes in the iResearch schema record, or empty list if none
    '''
    subTypes = []
    researchTypes = getResearchTypesFromIResearchSchemaRecord(iResearchSchemaRecord)
    if researchTypes:
        for researchType in researchTypes:
            subType = researchType.get('researchSubTypeCode')
            if subType:
                subTypes.append(subType)
    return subTypes


def getResearchTypesFromIResearchSchemaRecord(iResearchSchemaRecord):
    '''
    Returns a list of all research types/subtypes in the iResearch schema record, or empty list if none
    '''
    subjectResearch = iResearchSchemaRecord.get('subjectResearch')
    if subjectResearch:
        researchTypes = subjectResearch.get('researchTypes')
        return researchTypes
    return None

def replaceResearchTypesInIResearchSchemaRecord(iResearchSchemaRecord, newResearchTypes):
    subjectResearch = iResearchSchemaRecord.get('subjectResearch')
    if subjectResearch:
        subjectResearch['researchTypes'] = newResearchTypes
    