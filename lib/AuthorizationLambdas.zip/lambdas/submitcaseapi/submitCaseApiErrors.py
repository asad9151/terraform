'''
Created on Jun 19, 2019
Error messages for SubmitCaseApi

@author: VanCampK
'''

# Batch failure errors:
FAILBATCH_BAD_MINIBATCH_SPREADSHEET = "Bad batch spreadsheet"                      # Bad spreadsheet
FAILBATCH_TECHNICAL_FAILURE = "Failed processing minibatch"                             # Failed for technical reasons
FAILBATCH_THRESHOLD_EXCEEDED = "Maximum number of rejects exceeded"
FAILBATCH_MAX_RECORDS_EXCEEDED = "Maximum number of records exceeded"
FAILBATCH_NO_RECORDS = "The batch did not contain any data"
FAILBATCH_MAX_DUNS_RECORDS_EXCEEDED = "Maximum number of records with DUNS# exceeded"

# Record failure errors:
FAILREC_MISSING_RESEARCH_SUB_TYPE = "Request has no research sub-type specified"
FAILREC_UNSUPPORTED_RESEARCH_SUB_TYPE = "Unsupported research sub-type"
FAILREC_NOT_A_NUMBER_CONVERSION = "Expected a number"
FAILREC_NOT_A_INTEGER_CONVERSION = "Expected an integer"
FAILREC_NOT_A_STRING_CONVERSION = "Expected a string"
FAILREC_NOT_A_VALID_DUNS = "D-U-N-S must be 7-9 digits"
FAILREC_NOT_A_VALID_TELEPHONE = "telephone must be 1 or more digits with optional extra characters that will be ignored, such as hyphens/plus/parentheses"
FAILREC_INVALID_DUNS = "Invalid D-U-N-S"
FAILREC_INVALID_COUNTRY = "Expected country name : ISO 2-Alpha country code"
FAILREC_INVALID_COUNTRY_CODE = "Expected an ISO 2-Alpha country code"
FAILREC_DUPLICATE_RESEARCH_SUB_TYPE = "Cannot have the same research sub-type more than once for same D-U-N-S"
FAILREC_MISSING_REQUIRED_FIELD_FOR_RESEARCH_SUB_TYPE = "Required field missing"
FAILREC_MISSING_REQUIRED_FIELD_GENERIC = "Required field missing"
FAILREC_UNSUPPORTED_OPERATIONAL_STATUS = "Unsupported operational status"
FAILREC_UNSUPPORTED_BUSINESS_OWNER = "Unsupported business owner type"
FAILREC_TECHNICAL_ERROR = "Failed during record validation"
FAILREC_HTML_TAGS_NOT_ALLOWED = "HTML tags are not allowed"
FAILREC_UNPRINTABLE_NOT_ALLOWED = "Unprintable characters are not allowed"
FAILREC_FAILED_TO_SUBMIT = "Failed to SubmitCase"
FAILREC_INVALID_TYPE_CODE = "Not a valid type code for this element"
FAILREC_EMPTY_COMMENT = "An empty comment was provided"
FAILREC_STANDALONE_RESEARCH_SUBTYPE = "This research subtype cannot be combined with any other research subtypes"
FAILREC_PREVIOUSLY_DETECTED = "A previously detected error"
FAILREC_FAILED_PARSING_RECORD = "Internal error trying to parse this record"
FAILREC_MISSING_ATTACHMENT_NAME = "An attachment was specified without providing an attachment name"
FAILREC_DUP_ATTACHMENT_NAME = "An attachment was specified but the attachment name is not unique"
FAILREC_ATTACHMENT_PROCESSING_ERR = "An internal error occurred processing the attachment"
FAILREC_FIELD_NOT_ALLOWED = "This field is not allowed for this research subtype"
FAILREC_MISSING_REQUIRED_COMMENT_FOR_FINANCIAL_RATIOS = "Required commentTypeCode=33815 missing"
FAILREC_MISSING_REQUIRED_COMMENT_FOR_FINANCIAL_FIGURES = "Required commentTypeCode=33814 missing"
FAILREC_MISSING_RESEARCH_SUB_TYPE = "This research subtype cannot be submitted using researchRequestType provided in header."
