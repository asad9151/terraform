'''
@author: VanCampK
'''
import boto3
from botocore.client import Config
import logging
import json

from buildUIResponse import buildUIResponse
from common.irschRoles import IResearchRole
from common.util.awsUtils import createClientConfiguration
from lambdas.secureLambdaBase import SecureLambdaBase
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.lambdaBase import LambdaBase
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaAuthorizationException, LambdaValidationException
from lambdas.submitcaseapi.submitCaseApiService import SubmitCaseApiService
import lambdas.errorMessages as errmsg
from common import envVblNames


class SubmitCaseApiLambda(SecureLambdaBase):
    '''
    Handler class for SubmitResearchRequest service.
    Responsible for handling incoming requests from customers via Direct+ APIs or batch file.
    Handler: lambdas.submitcaseapi.submitCaseApilambda.handler
    '''
    s3handle = None
    snsClient = None
    s3handleForAttachments = None
    
    def __init__(self):
        super().__init__()
        self.service = None
        self.lambdaClientForSubmitCase = None
    
    def handleSecureRequest(self):
        if self.lambdaClientForSubmitCase is None:
            # config is None to stop retries from happening on SubmitCase invokes
            self.lambdaClientForSubmitCase = boto3.client('lambda', region_name=SubmitCaseApiLambda.environDict[envVblNames.ENV_LAMBDA_REGION], config=None)
        if self.service is None:
            self.service = SubmitCaseApiService(SubmitCaseApiLambda.dbConn, SubmitCaseApiLambda.s3handle, self.lambdaClientForSubmitCase,
                                                SubmitCaseApiLambda.snsClient, SubmitCaseApiLambda.s3handleForAttachments)

        incomingContent = self.requestContext.incomingContent
        responseBody = {}
        if 'submittedData' in incomingContent:
            LambdaBase.raiseAlertWhenRequestFails = False
            responseBody = self.service.processSubmitResearchRequest(self.requestContext)
        else:
            logging.error('SubmitCaseApiLambda: Unsupported request - expecting either attmId or submittedData in incoming request.  event-body = %s', incomingContent)
            raise LambdaValidationException('missing required parameter in SubmitCaseApi request')
        
        logging.info('SubmitCaseApiLambda response=' + str(responseBody))
        msgBody = json.dumps(responseBody)
        return buildUIResponse(LambdaStatusCodes.OK.value, msgBody, 'application/json')


    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7 ]) == False):
            logging.error('SubmitCaseApiLambda - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)


    def initializeKeepWarm(self):
        try:
            if not SubmitCaseApiLambda.s3handle:
                logging.info('Initializing s3handle...')
                SubmitCaseApiLambda.s3handle = boto3.resource('s3', config=createClientConfiguration(SubmitCaseApiLambda.environDict))
            if not SubmitCaseApiLambda.s3handleForAttachments:
                logging.info('Initializing s3handleForAttachments...')
                SubmitCaseApiLambda.s3handleForAttachments = boto3.client('s3', config=createClientConfiguration(SubmitCaseApiLambda.environDict, mergeConfig=Config(signature_version='s3v4')))
            if not SubmitCaseApiLambda.snsClient:
                logging.info('Initializing snsClient...')
                SubmitCaseApiLambda.snsClient = boto3.client('sns', region_name=SubmitCaseApiLambda.environDict[envVblNames.ENV_SNS_REGION], config=createClientConfiguration(SubmitCaseApiLambda.environDict))
        except Exception as e:
            logging.error('SubmitCaseApiLambda: problem in initializeKeepWarm.  error = %s', e)
            return buildUIResponse(LambdaStatusCodes.INTERNAL_SERVER_ERROR.value, 'Internal error in submit case api')
                
        
    def authorizeMiniBatch(self):
        # check that user is the submitter of the batch and that the file is ready to be processed
        attmUserId = self.requestContext.cacheObj.getUserID()
        if (int(self.requestContext.userSession.userId) != int(attmUserId)):
            logging.error('SubmitCaseApiLambda - userId=' + str(self.requestContext.userSession.userId) + ' is not the submitter of the attachment which is userId=' + str(attmUserId))
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
        

    def getResponseSchema(self):
        incomingContent = self.requestContext.incomingContent
        # Schema validation only for submitresearchrequest
        if 'submittedData' in incomingContent:
            return "iResearchSubmitResearchResponse.json"
        else:
            return None

    
    def isApi(self):
        '''
        By default we are behaving as there is a browser on the other side.
        Subclass can override this if they want API-type behavior.
        '''
        return True
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SubmitCaseApiLambda.get_handler(...)