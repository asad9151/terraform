'''
@author: VanCampK
'''
import boto3
import logging
import json
import sys
import traceback
from buildUIResponse import buildUIResponse
from common.util.awsUtils import createClientConfiguration
from common.util.sqsHelper import SqsHelper
from common.util.stringUtils import isBlank
from lambdas.lambdaCommon import createRequestContext, logRequest
from lambdas.lambdaBase import LambdaBase
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaAuthorizationException, LambdaValidationException
from lambdas.submitcaseapi.submitCaseApiService import SubmitCaseApiService
from lambdas.submitcaseapi.submitCaseStep import SubmitCaseStep
import lambdas.errorMessages as errmsg
from common import envVblNames

class SubmitCaseBatchParser(LambdaBase):
    '''
    Handler class for SubmitCaseBatchParser service.
    Responsible for handling incoming batch file requests.
    Handler: lambdas.submitcaseapi.submitCaseBatchParser.handler
    '''
    s3handle = None
    snsClient = None
    batchParserSqsHelper = None
    
    
    def __init__(self):
        super().__init__()
        self.service = None
    
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return True
    
    
    def handleRequest(self):
        if self.service is None:
            self.service = SubmitCaseApiService(SubmitCaseBatchParser.dbConn, SubmitCaseBatchParser.s3handle, None, SubmitCaseBatchParser.snsClient, None)

        self.requestContext.serviceDict["step"] = SubmitCaseStep.SUBMIT_CASE_BATCH_PARSER
        incomingEvent = self.requestContext.event
        LambdaBase.raiseAlertWhenRequestFails = True
        if 'Records' in incomingEvent:
            # Invoked via queue with batch size 1
            records = incomingEvent['Records']
            logging.info(f"Got multi-event request from queue with {len(records)} messages")
            lastException = None
            alertErrMsg = None
            attmId = None
            for record in records:
                logging.info(f"SubmitCaseBatchParser record={record}")
                try:
                    sbody = record.get('body')
                    if isinstance(sbody, str):
                        body = json.loads(sbody)
                    else:
                        body = sbody
                    messageId = record.get('messageId')
                    messageReceiptHandle = record.get('receiptHandle')
                    recordRequestContext = createRequestContext(body, LambdaBase.environDict, self.requestContext.lambdaContext, self, isBodyJson=self.isBodyJson())
                    logRequest(recordRequestContext)
                    attmId = recordRequestContext.body.get('attmId')
                    source = recordRequestContext.body.get('source')
                    startingRecordNumber = body.get('startingRecordNumber')
                    logging.info(f"SubmitCaseBatchParser got attmId={attmId} startingRecordNumber={startingRecordNumber} from source={source}")
                    recordRequestContext.cacheObj = self.service.loadAttachmentFromDatabase(attmId)
                    recordRequestContext.serviceDict["step"] = SubmitCaseStep.SUBMIT_CASE_BATCH_PARSER
                    #self._authorizeBatch()
                    responseBody = self.service.processBatchFile(recordRequestContext, startingRecordNumber=startingRecordNumber)
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except LambdaValidationException as lve:
                    alertErrMsg = f"LambdaValidationException trying to process attmId={attmId}: {lve}"
                    # Raise alert but do not retry batch
                    self._markMessageComplete(messageId, messageReceiptHandle)
                except Exception as e:
                    alertErrMsg = f"Unexpected exception trying to process attmId={attmId}: {e}"
                    traceback.print_tb(sys.exc_info()[2])
                    # Raise alert and retry batch (i.e. don't delete message from queue)
                    lastException = e
                # Continue on to next record regardless of failure of one message
                
            if lastException is not None:
                # Tells lambda to retry, also raises alert from LambdaBase
                raise lastException
            elif alertErrMsg is not None:
                # No retry but raise alert anyway
                LambdaBase.alert.raiseAlert(self.getModuleName(), errmsg.ERR_INTERNAL_REQUEST, detailedErrMsg=alertErrMsg)
                
        else:
            # Deprecated: Invoked directly from ProcessVirusScannedAttachement
            incomingContent = self.requestContext.incomingContent
            responseBody = {}
            if 'attmId' in incomingContent:
                # mini-batch processing is off-line, so need to raise alerts since nobody to listen to any uncaught errors
                attmId = incomingContent['attmId']
                self.requestContext.cacheObj = self.service.loadAttachmentFromDatabase(attmId)
                self._authorizeBatch()
                responseBody = self.service.processBatchFile(self.requestContext)
            else:
                logging.error('SubmitCaseBatchParser: Unsupported request - expecting attmId in incoming request.  event-body = %s', incomingContent)
                raise LambdaValidationException('missing required parameter in SubmitCaseBatchParser request')
            
            logging.info('SubmitCaseBatchParser response=' + str(responseBody))
            msgBody = json.dumps(responseBody)
            return buildUIResponse(LambdaStatusCodes.OK.value, msgBody, 'application/json')

    '''
    def authorizeRequest(self):
        if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7 ]) == False):
            logging.error('SubmitCaseBatchParser - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)
    '''

    def initializeKeepWarm(self):
        if not SubmitCaseBatchParser.s3handle:
            try:
                logging.info('Initializing s3handle...')
                SubmitCaseBatchParser.s3handle = boto3.resource('s3', config=createClientConfiguration(SubmitCaseBatchParser.environDict))
            except Exception as e:
                logging.error('SubmitCaseBatchParser: problem connecting to s3 client.  error = %s', e)
                return buildUIResponse(LambdaStatusCodes.INTERNAL_SERVER_ERROR.value, 'Internal error in submit case api')
        if not SubmitCaseBatchParser.snsClient:
            try:
                logging.info('Initializing snsClient...')
                SubmitCaseBatchParser.snsClient = boto3.client('sns', region_name=SubmitCaseBatchParser.environDict[envVblNames.ENV_SNS_REGION], config=createClientConfiguration(SubmitCaseBatchParser.environDict))
            except Exception as e:
                logging.error('SubmitCaseBatchParser: problem connecting to sns.  error = %s', e)
                return buildUIResponse(LambdaStatusCodes.INTERNAL_SERVER_ERROR.value, 'Internal error in submit case api')
                
        
    def _authorizeBatch(self):
        # check that user is the submitter of the batch and that the file is ready to be processed
        attmUserId = self.requestContext.cacheObj.getUserID()
        if (int(self.requestContext.userSession.userId) != int(attmUserId)):
            logging.error('SubmitCaseBatchParser - userId=' + str(self.requestContext.userSession.userId) + ' is not the submitter of the attachment which is userId=' + str(attmUserId))
            raise LambdaAuthorizationException(errmsg.ERR_NOT_AUTHORIZED)

    
    def isApi(self):
        '''
        By default we are behaving as there is a browser on the other side.
        Subclass can override this if they want API-type behavior.
        '''
        return True
        
        
    def _markMessageComplete(self, messageId, messageReceiptHandle):
        '''
        Deletes a message from the queue because we successfully processed it
        '''
        if isBlank(messageId) or isBlank(messageReceiptHandle):
            logging.warning("Not deleting message from queue because no messageId or messageReceiptHandle")
            return
        batchSubmitterQueueUrl = SubmitCaseBatchParser.environDict[envVblNames.ENV_SUBMITCASEBATCHPARSER_QUEUE_URL]
        if SubmitCaseBatchParser.batchParserSqsHelper is None:
            regionName = SubmitCaseBatchParser.environDict.get(envVblNames.ENV_SQS_REGION)
            SubmitCaseBatchParser.batchParserSqsHelper = SqsHelper(batchSubmitterQueueUrl, regionName=regionName)
        logging.info(f"Delete message from queue {batchSubmitterQueueUrl}: messageId={messageId} messageReceiptHandle={messageReceiptHandle}")
        result = SubmitCaseBatchParser.batchParserSqsHelper.deleteOneMessageFromQueue(messageReceiptHandle)
        logging.info(f"markMesageComplete: messageReceiptHandle={messageReceiptHandle} result={result}")
        
        
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SubmitCaseBatchParser.get_handler(...)