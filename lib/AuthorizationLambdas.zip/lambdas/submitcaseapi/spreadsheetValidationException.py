'''
Created on Jun 14, 2019

@author: VanCampK
'''
from lambdas.exceptions import LambdaValidationException

class SpreadsheetValidationException(LambdaValidationException):
    '''
    Exception raised when spreadsheet was not appropriate format.
    '''

    def __init__(self, errmsg):
        super().__init__(errmsg)
