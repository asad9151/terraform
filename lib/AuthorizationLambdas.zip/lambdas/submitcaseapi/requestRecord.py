'''
Created on Jun 8, 2019

@author: VanCampK
'''
import jmespath
from common.util.stringUtils import isNotBlank
import lambdas.submitcaseapi.submitCaseApiFields as apiFields


class RequestRecord(object):
    '''
    Holds attributes about one SubmitCaseApi request record
    '''

    def __init__(self):
        self.originalRecords = []           # list of original unmodified records (may be more than one if multiple rows from a spreadsheet were combined)
        self.apiSchemaRecords = []          # list of originalRecords transformed into API schema
        self.iResearchSchemaRecord = None   # apiSchemaRecords transformed into a single iResearch SubmitCase schema (after possibly combining multiple apiSchemaRecords) 
        self.requestRejectionErrors = []    # list of RequestRejectionError, if any
        self.rejectionReasonCode = None     # reason for rejection, if any
        self.isSuppressed = False           # True if this record is being suppressed because it was combined with other records into a single request
        self.nRecords = 1                   # May be greater than 1 if other records were combined into this one
        self.batchRequestRejectId = None    # ID of rejected record, if rejected
        self.batchDetailRecord = None       # transformed to BatchDetail schema
        self.recordNumber = None            # sequential record number in the batch
        self.attachments = []               # list of attachments to process
        
        
    def isRejected(self):
        if self.requestRejectionErrors:
            if len(self.requestRejectionErrors) > 0:
                return True
        return False
    
    
    def addRejection(self, requestRejectionError, rejectionReasonCode):
        self.requestRejectionErrors.append(requestRejectionError)
        self.rejectionReasonCode = rejectionReasonCode
        
        
    def getInternalRefIds(self):
        intRefIdSet = set()
        for originalRecord in self.originalRecords:
            intRefId = originalRecord.get(apiFields.API_FLD_INTERNAL_REF_ID)
            if intRefId:
                origIntRefIds = intRefId.split(',')
                for refId in origIntRefIds:
                    intRefIdSet.add(int(refId))
                
        intRefIds = ','.join(str(i) for i in sorted(intRefIdSet))
        return intRefIds
        
        
    def setInternalRefId(self, newIntRefId):
        self.originalRecords[0][apiFields.API_FLD_INTERNAL_REF_ID] = newIntRefId
        self.apiSchemaRecords[0]["researchRequest"][apiFields.IRSCH_FLD_INTERNAL_REF_ID] = newIntRefId
            
            
    def requestRejectionErrorsToString(self):
        errmsg = '['
        for err in self.requestRejectionErrors:
            if len(errmsg) > 1:
                errmsg += ','
            errmsg += str(err)
        errmsg += ']'
        return errmsg


    def requestRejectionErrorsToDict(self):
        errs = []
        for err in self.requestRejectionErrors:
            errs.append(err.toDict())
        return errs
    
    
    def hasDuns(self):
        apiDuns = jmespath.search(apiFields.API_PATH_FLD_DUNS, self.originalRecords[0])
        mnbDuns = self.originalRecords[0].get(apiFields.MNB_FLD_SUBJECT_DUNS)
        if isNotBlank(apiDuns) or isNotBlank(mnbDuns):
            return True
        return False