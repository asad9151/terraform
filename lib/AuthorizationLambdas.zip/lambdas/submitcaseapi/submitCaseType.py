'''
Created on Sep 24, 2019

@author: VanCampK
'''
from enum import Enum

class SubmitCaseType(Enum):
    MINI_BATCH = 1
    API = 2
