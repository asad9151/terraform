'''
Created on Aug 9, 2019

@author: VanCampK
'''
from builtins import staticmethod
import jmespath
import re
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.dictUtils import mergeDictionaries, removeEmptyFromDictionary, removeEmptyValsFromArrayIfOnlyTypeCode, findAllElementsThatContains
from common.util.stringUtils import isBlank, isNotBlank, normalizeDuns, stripNonDigit, removeLastPartOfJsonPath, getLastPartOfJsonPath
from lambdas.requestRejectionError import RequestRejectionError
import lambdas.submitcaseapi.submitCaseApiErrors as apiErrors
from lambdas.submitcaseapi.submitCaseType import SubmitCaseType

class Converters(object):
    '''
    Static converter functions for use in SubmitCaseApi (shared with batchFileParser, submitCaseApiTransformationService, and updateAndCloseApiTransformationService)
    '''
    '''
    If you're getting an "Undefined error from import" error in Eclipse on the next 2 lines, see the 3rd answer in this post:
      https://stackoverflow.com/questions/2112715/how-do-i-fix-pydev-undefined-variable-from-import-errors
      Go to Window - Preferences - PyDev - Interpreters - Python Interpreter
      Go to the Forced builtins tab
      Click on New...
      Type the name of the module (re in this case) and click OK
    '''
    _dunsRegex = re.compile('.*duns$', re.IGNORECASE)
    _telephoneRegex = re.compile('.*telephone$', re.IGNORECASE)


    # Maps each of our supported research subtypes to its research type
    # First we map all the subtypes supported in both mini-batch and APIs:
    SHARED_RESEARCH_SUBTYPE_TO_TYPE_MAPPING = {
        # Primary Business Information
        '33549': '33523',
        '33550': '33523',
        '33766': '33523',
        '33551': '33523',
        '33552': '33523',
        '33553': '33523',
        '33554': '33523',
        '33555': '33523',
        # Financial Information
        '33537': '33520',
        '33769': '33520',
        '33770': '33520',
        '33771': '33520',
        # History
        '33538': '33521',
        '33539': '33521',
        '33540': '33521',
        '33541': '33521',
        '33542': '33521',
        '33544': '33521',
        '33767': '33521',
        # Operational Status
        '33558': '33525',
        # Merger/Acquisition
        '33559': '33526',
        '33768': '33526',
        # Linkage
        '33562': '33529',
        '33563': '33529',
        '33564': '33529',
        # Duplicate Record
        '33560': '33527',
        # Ratings & Scores
        '33566': '33531',
        '33567': '33531',
        '33568': '33531',
        '33569': '33531',
        '33570': '33531',
        '33571': '33531',
        '33572': '33531',
        '33573': '33531',
        # New D-U-N-S Number
        '33574': '33532',
        '33575': '33532',
        # Public Records
        '33543': '33522',
    }
    
    # This is the list of subtypes specific to APIs:
    API_RESEARCH_SUBTYPE_TO_TYPE_MAPPING = {
        # New D-U-N-S Number
        '33576': '33532',
        # Full Credit Risk Review
        '34378': '34377'
    }
    
    # This is the list of subtypes specific to Minibatch:
    MINIBATCH_RESEARCH_SUBTYPE_TO_TYPE_MAPPING = {
        # Enhanced Elements
        '33533': '33518',
        '33534': '33518',
        '33535': '33518',
        '33755': '33518',
        # Government Activity Summary
        '33536': '33519',
        # Public Records
        '33545': '33522',
        '33546': '33522',
        '33547': '33522',
        '33548': '33522',
        # Trade
        '33556': '33524',
        '33557': '33524',
        # Ultimate Beneficial Ownership
        '33561': '33528',
        # CFP specific, not really minibatch
        '34659': '34658',
        '35028': '33532'
    }


    @staticmethod
    def convertResearchSubTypeToType(fldName, rschSubTypeCode, requestRecord, submitCaseType):
        '''
        Maps the research sub-type code to the research type code.
        '''
        if not rschSubTypeCode:
            # Not valid but it will be caught later during validations
            return None
        
        rschTypeCode = Converters.SHARED_RESEARCH_SUBTYPE_TO_TYPE_MAPPING.get(str(rschSubTypeCode))
        if rschTypeCode and rschTypeCode.isdigit():
            return int(rschTypeCode)
        
        if submitCaseType == SubmitCaseType.MINI_BATCH.value:
            rschTypeCode = Converters.MINIBATCH_RESEARCH_SUBTYPE_TO_TYPE_MAPPING.get(str(rschSubTypeCode))
            if rschTypeCode and rschTypeCode.isdigit():
                return int(rschTypeCode)
        
        if submitCaseType == SubmitCaseType.API.value:
            rschTypeCode = Converters.API_RESEARCH_SUBTYPE_TO_TYPE_MAPPING.get(str(rschSubTypeCode))
            if rschTypeCode and rschTypeCode.isdigit():
                return int(rschTypeCode)

        requestRecord.addRejection(RequestRejectionError(jsonPathName=fldName, errorDescription=apiErrors.FAILREC_UNSUPPORTED_RESEARCH_SUB_TYPE, providedValue=rschSubTypeCode), RejectionReasonCode.VALIDATION_ERROR)
        return None


    @staticmethod
    def convertDuns(rschDict, requestRecord):
        dunselementList = findAllElementsThatContains(rschDict, Converters._dunsRegex)
        for dunselement in dunselementList:
            jmes_result = jmespath.search(dunselement, rschDict)
            if jmes_result is not None:
                Converters._convertOneDuns(dunselement, jmes_result, rschDict, requestRecord)
        
            
    @staticmethod
    def _convertOneDuns(dunselement, value, rschDict, requestRecord):
        # Don't convert boolean elements like isChangedDuns
        lastEltName = dunselement.split(".")[-1]
        if lastEltName.startswith("is"):
            return
        
        try:
            duns = normalizeDuns(value)
            # store normalized value if it changed
            if duns != value:
                # Get the parent element and update the child within it
                #parentelement = dunselement.replace(".duns", "")
                parentelement = removeLastPartOfJsonPath(dunselement)
                parentobj = jmespath.search(parentelement, rschDict)
                parentobj[getLastPartOfJsonPath(dunselement)] = duns
        except ValueError:
            requestRecord.addRejection(RequestRejectionError(jsonPathName=dunselement, errorDescription=apiErrors.FAILREC_NOT_A_VALID_DUNS, providedValue=value), RejectionReasonCode.VALIDATION_ERROR)

                
    @staticmethod
    def convertTelephones(rschDict, requestRecord):
        telephoneelementList = findAllElementsThatContains(rschDict, Converters._telephoneRegex)
        for telephoneelement in telephoneelementList:
            jmes_result = jmespath.search(telephoneelement, rschDict)
            if jmes_result is not None:
                Converters._convertOneTelephone(telephoneelement, jmes_result, rschDict, requestRecord)
        
            
    @staticmethod
    def _convertOneTelephone(telephoneelement, value, rschDict, requestRecord):
        try:
            telephone = stripNonDigit(value)
            # store normalized value if it changed
            if telephone != value:
                # Get the parent element and update the child within it
                parentelement = removeLastPartOfJsonPath(telephoneelement)
                #parentelement = telephoneelement.replace(".telephone", "")
                parentobj = jmespath.search(parentelement, rschDict)
                parentobj[getLastPartOfJsonPath(telephoneelement)] = telephone
        except ValueError:
            requestRecord.addRejection(RequestRejectionError(jsonPathName=telephoneelement, errorDescription=apiErrors.FAILREC_NOT_A_VALID_TELEPHONE, providedValue=value), RejectionReasonCode.VALIDATION_ERROR)
    