import logging
import constants
import os
import datetime
from lambdas.adminReporting.adminReportingDao import AdminReportingDao
from lambdas.adminReporting.gmReportingHelper import GMReportingHelper
from lambdas.adminReporting.gmDetailColumns import GMDetailColumns
from openpyxl import Workbook
import openpyxl

class GMAdminReportingService(object):
    requestContext = None
    dao = None
    dbConn = None
    helper = None
    
    SUMMARY_SHEET = 'Summary'
    TOTAL_BY_COUNTRY_SHEET = 'Non-Ls By Country'
    DETAIL_ALL_REQUESTS_SHEET = 'Detail All Requests'
    DETAIL_REQUESTS_COMPLETED_LATE_SHEET = 'Detail Non-Ls Completed Late'
             
    QUALITY_SHEET = 'Quality'
                 
    def __init__(self,  requestContext, dbConn):
        self.requestContext = requestContext
        if self.dao is None:
            self.dao = AdminReportingDao()
        self.dbConn = dbConn
        if self.helper is None:
            self.helper = GMReportingHelper(dbConn)
          
    def generateGMDashboard(self, runDate=None):
        try:
            logging.info("in AdminReportingService, generateGMDashboard")
            if runDate is None:
                runDate = datetime.datetime.now()
            logging.info("Current runDate is %s:" % runDate)
            startDate, endDate = self.helper.getStartEndDates(runDate)
            dbRecs = self.dao.getGMRequestDataForQuarter(self.dbConn, startDate, endDate)
            nonLData = self.helper.getNonLData(dbRecs)
            allRequests = []
            allNonLRequests = []
            nonLrequestsCompletedLate = []
            fileName, localFilePath = self.getFileInfo(runDate);
            wb = self.initWorkbook(localFilePath)
            for dbRec in dbRecs:
                detailRec = self.helper.getRecDetails(dbRec)
                allRequests.append(detailRec)
            for dbRec in nonLData:
                detailRec = self.helper.getRecDetails(dbRec)
                allNonLRequests.append(detailRec)
                if GMDetailColumns.DUE_DATE.value in detailRec and GMDetailColumns.CLOSED_DATE.value in detailRec:
                    dueDate = detailRec[GMDetailColumns.DUE_DATE.value]
                    completedDate = detailRec[GMDetailColumns.CLOSED_DATE.value]
                    dueDate += datetime.timedelta(days=2) #add two days to actual due date to determine requests completed late
                    if completedDate > dueDate:
                        nonLrequestsCompletedLate.append(detailRec)
                logging.info(detailRec)
            self.helper.writeDetails(wb, self.DETAIL_ALL_REQUESTS_SHEET, allRequests)
            self.helper.writeDetails(wb, self.DETAIL_REQUESTS_COMPLETED_LATE_SHEET, nonLrequestsCompletedLate)
            self.helper.writeTotalsByCountry(wb, self.TOTAL_BY_COUNTRY_SHEET, runDate, allNonLRequests, nonLrequestsCompletedLate)
            self.helper.writeSummary(wb, self.SUMMARY_SHEET, runDate)
            self.helper.writeQuality(wb, self.QUALITY_SHEET, allRequests, runDate)
            wb.save(localFilePath)
            self.helper.writeFileToS3(self.requestContext.environDict, fileName, localFilePath)
            self.helper.emailReports(self.requestContext.environDict, runDate, localFilePath)
        except Exception as e1: 
            logging.error('Error while generating GM Dashboard. Error = %s' % e1)
            raise e1
        
        
    def getFileInfo(self, runDate):
        quarterName = self.helper.getQuarterName(runDate)
        parent_folder_for_file = constants.LOCAL_DIRECTORY
        if not os.path.exists(parent_folder_for_file):
            os.makedirs(parent_folder_for_file)
        fileName = 'GMDashboard_' + quarterName + '_' + str(runDate.year) + '.xlsx'
        localFilePath = os.path.join(parent_folder_for_file, fileName)
        
        return fileName, localFilePath    
            
    def initWorkbook(self, localFilePath):
        wb = Workbook()
        logging.info(f"Saving workbook as {localFilePath}")
        wb.save(localFilePath)
        wb = openpyxl.load_workbook(localFilePath)
        wb.create_sheet(self.SUMMARY_SHEET, 0)
        wb.create_sheet(self.TOTAL_BY_COUNTRY_SHEET, 1)
        wb.create_sheet(self.QUALITY_SHEET, 2)
        wb.create_sheet(self.DETAIL_ALL_REQUESTS_SHEET, 3)
        wb.create_sheet(self.DETAIL_REQUESTS_COMPLETED_LATE_SHEET, 4)
        wb.remove(wb.get_sheet_by_name('Sheet'))
                
        return wb