'''
Created on Mar 30, 2020

@author: JafferS
'''
import logging
import calendar
import datetime
import json
from common.util.s3Helper import S3Helper
from common.model.s3Object import S3Object
from common.util.dateUtils import isoFormatToDateTime
from common.util.dateUtils import getBusinessDays
from lambdas.adminReporting.gmDetailColumns import GMDetailColumns
from common.dao.geoDao import GeoDao
from common.SendEmail import SendEmail
from common import envVblNames
from openpyxl.styles import Font
from openpyxl.styles import PatternFill, Alignment
from openpyxl.styles import Border, Side
from common.dao.scotsDao import ScotsDao
from common.scotsTables import ScotsTable

class GMReportingHelper(object):
    s3Helper = None
    geoDao = None
    geoDict = None
    scotsDao = None
    scots_dict = None
    quarters = {}
    quarters[1] = {'startMonth' : 1, 'endMonth' : 3, 'name' : 'Q1', 'month' : 'Jan'}
    quarters[2] = {'startMonth' : 1, 'endMonth' : 3, 'name' : 'Q1', 'month' : 'Feb'}
    quarters[3] = {'startMonth' : 1, 'endMonth' : 3, 'name' : 'Q1', 'month' : 'Mar'}   
    quarters[4] = {'startMonth' : 4, 'endMonth' : 6, 'name' : 'Q2', 'month' : 'Apr'}      
    quarters[5] = {'startMonth' : 4, 'endMonth' : 6, 'name' : 'Q2', 'month' : 'May'}     
    quarters[6] = {'startMonth' : 4, 'endMonth' : 6, 'name' : 'Q2', 'month' : 'Jun'}     
    quarters[7] = {'startMonth' : 7, 'endMonth' : 9, 'name' : 'Q3', 'month' : 'Jul'}      
    quarters[8] = {'startMonth' : 7, 'endMonth' : 9, 'name' : 'Q3', 'month' : 'Aug'}     
    quarters[9] = {'startMonth' : 7, 'endMonth' : 9, 'name' : 'Q3', 'month' : 'Sep'} 
    quarters[10] = {'startMonth' : 10, 'endMonth' : 12, 'name' : 'Q4', 'month' : 'Oct'}      
    quarters[11] = {'startMonth' : 10, 'endMonth' : 12, 'name' : 'Q4', 'month' : 'Nov'}     
    quarters[12] = {'startMonth' : 10, 'endMonth' : 12, 'name' : 'Q4', 'month' : 'Dec'}
        
    S3_FOLDER = 'reporting/gmdashboard'
    
    def __init__(self, dbConn):
        logging.info("in init")
        if self.s3Helper is None:
            self.s3Helper = S3Helper()
        if self.geoDao is None:
            self.geoDao = GeoDao()   
        if self.geoDict is None:
            self.geoDict = self.geoDao.queryTypeCodesToDescriptions(dbConn)
        if self.scotsDao is None:
            self.scotsDao = ScotsDao()
        if self.scots_dict is None:
            self.scots_dict = self.scotsDao.queryTypeCodesToDescriptions(dbConn)
            
    def getStartEndDates(self, runDate):
        month = runDate.month
        logging.info("month is %s:" % month)

        logging.info(self.quarters[month])
        currQuarter = self.quarters[month]
        firstWeekDay, lastdayOfMonth = calendar.monthrange(runDate.year,currQuarter['endMonth'])
        startDate = datetime.datetime(year=runDate.year, month=currQuarter['startMonth'], day=1, hour=0, minute=0, second=0)
        endDate = datetime.datetime(year=runDate.year, month=currQuarter['endMonth'], day=lastdayOfMonth, hour=23, minute=59, second=59)
        logging.info('startDate is %s' % startDate)
        logging.info('endDate is %s' % endDate)
        return startDate, endDate
    
    
    def getRecDetails(self, dbRec):  
        detailsRec = {}
        usageRecord = None
        if 'usg_pstg_obj' in dbRec:
            usageRecord = json.loads(dbRec['usg_pstg_obj'])
        if usageRecord is not None:
            if ('request' in usageRecord):
                request = usageRecord['request']
                if ('researchCreationTimestamp' in request):
                    openDateTime = isoFormatToDateTime(request['researchCreationTimestamp'])
                    openDate = openDateTime.date()
                    detailsRec[GMDetailColumns.OPENED_DATE.value] = openDate
                if ('researchSatisfiedTimestamp' in request):
                    closeDateTime = isoFormatToDateTime(request['researchSatisfiedTimestamp'])
                    closeDate = closeDateTime.date()
                    detailsRec[GMDetailColumns.CLOSED_DATE.value] = closeDate 
                if ('researchRequestId' in request):
                    detailsRec[GMDetailColumns.REQUEST_ID.value] = request['researchRequestId']
                if 'cases' in request and len(request['cases']) > 0:
                        case = request['cases'][0]
                        if 'researchTypes' in case and len(case['researchTypes']) > 0:
                            researchType = case['researchTypes'][0]
                            detailsRec[GMDetailColumns.RESEARCH_SUBTYPE.value] = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.RESEARCH_SUB_TYPE.value, researchType['researchSubTypeCode'] , langId=None) 
            if 'requestor' in usageRecord:
                requestor = usageRecord['requestor']
                if 'requestorOwnRequestKey' in requestor:
                    detailsRec[GMDetailColumns.REQUESTOR_OWN_REQUEST_KEY.value] = requestor['requestorOwnRequestKey']
        if 'submittedOrgName' in dbRec:
            detailsRec[GMDetailColumns.SUBMITTED_BUSINESS_NAME.value] = dbRec['submittedOrgName']
        if 'v_subm_ctry_cd' in dbRec:
            detailsRec[GMDetailColumns.SUBMITTED_COUNTRY.value] = dbRec['v_subm_ctry_cd']
        if 'due_date' in dbRec and dbRec['due_date'] is not None:
            dueDate = datetime.date.fromisoformat(dbRec['due_date'])
            detailsRec[GMDetailColumns.DUE_DATE.value] = dueDate 
        if GMDetailColumns.OPENED_DATE.value in detailsRec and GMDetailColumns.CLOSED_DATE.value in detailsRec:
            detailsRec[GMDetailColumns.TAT_DAYS.value] = getBusinessDays(detailsRec[GMDetailColumns.OPENED_DATE.value], detailsRec[GMDetailColumns.CLOSED_DATE.value])
        
        return detailsRec      
    
    def getQuarterName(self, runDate):
        month = runDate.month
        logging.info("month is %s:" % month)

        logging.info(self.quarters[month])
        currQuarter = self.quarters[month]

        return currQuarter['name']
    
    def writeFileToS3 (self, environDict, fileName, localFilePath):
        s3Object = S3Object()
        s3ObjKey = f"s3://{environDict.get(envVblNames.ENV_DATASTORES_BUCKET)}/{self.S3_FOLDER}/{fileName}"
        s3Object.setS3ObjectKey(s3ObjKey)
        self.s3Helper.copyFromLocalToS3(localFilePath, s3Object)
        
    def writeDetails(self, wb, sheetName, detailRecs):
        wb[sheetName].append(GMDetailColumns.getAllGMDetailColumnNames())
        for rows in wb[sheetName].iter_rows(min_row=1, max_row=1, min_col=1):
            for cell in rows:
                cell.fill = PatternFill(fgColor="00B2A9", fill_type = "solid")
                cell.font = Font(color="FFFFFF", bold=True)
        sheet = wb[sheetName]
        for rec in detailRecs:
            recValues = []
            for column in GMDetailColumns.getAllGMDetailColumnNames():
                if column in rec:
                    if column in [GMDetailColumns.OPENED_DATE.value, GMDetailColumns.CLOSED_DATE.value, GMDetailColumns.DUE_DATE.value]:
                        formattedDate = rec[column].strftime("%m/%d/%Y")
                        recValues.append(formattedDate)
                    elif column == GMDetailColumns.SUBMITTED_COUNTRY.value:
                        countryName = self.geoDict[rec[column]]
                        recValues.append(countryName)
                    else:
                        recValues.append(rec[column])
                else:
                    recValues.append('')
            sheet.append(recValues)
        self.updateColumnSize(wb, sheetName)
            
    def writeTotalsByCountry(self, wb, sheetName, runDate, allRequests, requestsCompletedLate):
        sheet = wb[sheetName]
        monthCounts = {}
        
        # headers
        sheet['A1'] = 'All Requests Completed'
        sheet['F1'] = 'Requests Completed Late'  
        
        sheet.merge_cells('A1:D1')
        sheet.merge_cells('F1:L1')
        
        # format row 1
        for rows in wb[sheetName].iter_rows(min_row=1, max_row=1, min_col=1, max_col=4):
            for cell in rows:
                cell.fill = PatternFill(fgColor="00B2A9", fill_type = "solid")
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal='center') 
        
        for rows in wb[sheetName].iter_rows(min_row=1, max_row=1, min_col=6, max_col=12):
            for cell in rows:
                cell.fill = PatternFill(fgColor="00B2A9", fill_type = "solid")
                cell.font = Font(color="FFFFFF", bold=True)    
                cell.alignment = Alignment(horizontal='center')       
                      
        # quarter name - row 2
        quarterName = self.getQuarterName(runDate)
        sheet['A2'] = quarterName
        sheet['F2'] = quarterName
        
        # headers for row 3
        month = runDate.month
        currQuarter = self.quarters[month]
        startMonth = currQuarter['startMonth']
        endMonth = currQuarter['endMonth']
        currMonth = startMonth
        thirdRow = []
        thirdRow.append('Country')
        while currMonth <= endMonth:
            thisMonth = self.quarters[currMonth]
            thirdRow.append(thisMonth['month'])
            monthCounts[thisMonth['month']] = 0
            currMonth = currMonth + 1
        thirdRow.append('')
        thirdRow.append('Country')
        currMonth = startMonth
        while currMonth <= endMonth:
            thisMonth = self.quarters[currMonth]
            thirdRow.append(thisMonth['month'])
            thirdRow.append('% Late')
            currMonth = currMonth + 1
        sheet.append(thirdRow)
        
        for rows in wb[sheetName].iter_rows(min_row=2, max_row=3, min_col=1, max_col=12):
            for cell in rows:
                cell.font = Font(bold=True) 
                cell.alignment = Alignment(horizontal='center')
        
        # row through all requests and add to countryDict
        countryDict = {}
        grandTotalData = {}
        grandTotalData['grandTotalCounts'] = monthCounts.copy()
        grandTotalData['grandTotalLateCounts'] = monthCounts.copy()
        for rec in allRequests:
            countryCode = rec[GMDetailColumns.SUBMITTED_COUNTRY.value]
            if countryCode not in countryDict:
                countryData = {}
                countryName = self.geoDict[countryCode]
                countryData['countryName'] = countryName
                countryData['monthCounts'] = monthCounts.copy()
                countryData['monthLateCounts'] = monthCounts.copy()
                countryDict[countryCode] = countryData
            countryData = countryDict[countryCode] 
            countryMonthCounts = countryData['monthCounts']
            closedDate = rec[GMDetailColumns.CLOSED_DATE.value]
            currRecMonth = closedDate.month
            currRecQuarter = self.quarters[currRecMonth]
            countryMonthCounts[currRecQuarter['month']] = countryMonthCounts[currRecQuarter['month']] + 1
            gtmonthCounts = grandTotalData['grandTotalCounts']
            gtmonthCounts[currRecQuarter['month']] = gtmonthCounts[currRecQuarter['month']] + 1
            
        
        # row through 'completed late' requests and update rows in countryDict
        for rec in requestsCompletedLate:
            countryCode = rec[GMDetailColumns.SUBMITTED_COUNTRY.value]
            countryData = countryDict[countryCode] 
            countryMonthLateCounts = countryData['monthLateCounts']
            closedDate = rec[GMDetailColumns.CLOSED_DATE.value]
            currRecMonth = closedDate.month
            currRecQuarter = self.quarters[currRecMonth]
            countryMonthLateCounts[currRecQuarter['month']] = countryMonthLateCounts[currRecQuarter['month']] + 1
            gtlmonthCounts = grandTotalData['grandTotalLateCounts']
            gtlmonthCounts[currRecQuarter['month']] = gtlmonthCounts[currRecQuarter['month']] + 1
            
        # adding rows from countryDict to worksheet
        for key in countryDict.keys():
            currentRow = []
            keyData = countryDict[key]
            currentRow.append(keyData['countryName'])
            countryMonthCounts = keyData['monthCounts']
            for month in countryMonthCounts.keys():
                currentRow.append(countryMonthCounts[month])
            currentRow.append('')
            currentRow.append(keyData['countryName'])
            countryMonthLateCounts = keyData['monthLateCounts']
            for monthLate in countryMonthLateCounts.keys():
                currentRow.append(countryMonthLateCounts[monthLate])
                if countryMonthCounts[monthLate] != 0:
                    currentRow.append(str(round(countryMonthLateCounts[monthLate]/countryMonthCounts[monthLate]  * 100, 2)) + '%')
                else:
                    currentRow.append(str(0) + '%')              
            sheet.append(currentRow)
        
        # adding grand totals to worksheet
        grandTotalRow = []
        grandTotalRow.append('Grand Total')
        gtmonthCounts = grandTotalData['grandTotalCounts']
        for month in gtmonthCounts.keys():
            grandTotalRow.append(gtmonthCounts[month])
        grandTotalRow.append('')
        grandTotalRow.append('Grand Total')
        gtlmonthCounts = grandTotalData['grandTotalLateCounts']
        for monthLate in gtlmonthCounts.keys():
            grandTotalRow.append(gtlmonthCounts[monthLate])
            if gtmonthCounts[monthLate] != 0:
                grandTotalRow.append(str(round(gtlmonthCounts[monthLate]/gtmonthCounts[monthLate]  * 100, 2)) + '%')
            else:
                grandTotalRow.append(str(0) + '%') 
        sheet.append(grandTotalRow)             
        self.updateColumnSize(wb, sheetName)
        self.setBorder(wb, sheetName, 1, len(countryDict)+4, 1, 4)
        self.setBorder(wb, sheetName, 1, len(countryDict)+4, 6, 12)
        
    def writeSummary(self, wb, sheetName, runDate):
        month = runDate.month
        currQuarter = self.quarters[month]
        startMonth = currQuarter['startMonth']
        endMonth = currQuarter['endMonth']
        months = []
        currMonth = startMonth
        while currMonth <= endMonth:
            thisMonth = self.quarters[currMonth]
            months.append(thisMonth['month'])
            currMonth = currMonth + 1
            
        sheet = wb[sheetName]
        sheet.append(['Critical Service Levels with Service Level Credits'])
        sheet.append(['Critical Service Measures'])
        for rows in wb[sheetName].iter_rows(min_row=1, max_row=2, min_col=1, max_col=1):
            for cell in rows:
                cell.fill = PatternFill(fgColor="00B2A9", fill_type = "solid")
                cell.font = Font(color="FFFFFF", bold=True)
                
        sheet.append([''])
        sheet.append(['Total Vendor At Risk - Expressed in term of percentage of the Monthly Charge', '6%'])
        sheet.append(['At Risk Pool Percentage Available For Allocation - Expressed as a % of the At Risk amount', '100%'])
        sheet.append(['At Risk Pool Available Unallocated --  Expressed as % of the Pool not Allocated', '0%'])
        for rows in wb[sheetName].iter_rows(min_row=4, max_row=6, min_col=1, max_col=2):
            for cell in rows:
                cell.fill = PatternFill(fgColor="00B2A9", fill_type = "solid")
                cell.font = Font(color="FFFFFF", bold=True)
        sheet.append([''])
        rowData = ['Allocation of Pool Percentage', '50%', '', 'Measurement', 'Fees at Risk', '', '% of']
        for month in months:
            rowData.append(month)
        sheet.append(rowData)
        sheet.append(['Quality', 'Expected', 'Minimum*', 'Window', 'Calculation', 'Allocation*', 'Invoice*', 'Results', 'Results', 'Results'])
        for rows in wb[sheetName].iter_rows(min_row=8, max_row=9, min_col=1, max_col=10):
            for cell in rows:
                cell.fill = PatternFill(fgColor="00B2A9", fill_type = "solid")
                cell.font = Font(color="FFFFFF", bold=True)
        sheet.append(['Data requirements on PIR', '99.00%', '98.00%', 'Monthly', 'Quarterly', '60%', '1.80%', '100.0', '100.0', '100.0'])
        sheet.append(['Different company name', '99.00%', '98.00%', 'Monthly', 'Quarterly', '40%', '1.20%', '100.0', '100.0', '100.0'])
        rowData = ['Allocation of Pool Percentage', '50% ', '', 'Measurement', 'Fees at Risk', 'Fees at Risk', '% of']
        for month in months:
            rowData.append(month)
        sheet.append(rowData)
        sheet.append(['Turnaround Time', 'Expected', 'Minimum*', 'Window', 'Calculation', 'Allocation*', 'Invoice*', 'Results', 'Results', 'Results'])
        for rows in wb[sheetName].iter_rows(min_row=12, max_row=13, min_col=1, max_col=10):
            for cell in rows:
                cell.fill = PatternFill(fgColor="00B2A9", fill_type = "solid")
                cell.font = Font(color="FFFFFF", bold=True)
        sheet.append(['PIR''s Returned After Initial Expected Completion Date', '99.00%', '95.00%', 'Monthly', 'Quarterly', '50%', '1.50%', '100.0', '100.0', '100.0'])
        sheet.append(['PIR''s Returned as Unable to Verify', '99.00%', '98.00%', 'Monthly', 'Quarterly', '50%', '1.50%', '100.0', '100.0', '100.0'])
        sheet.append(['Number of PIR''s-Non L cases', '', '', '', '', '', '', '100.0', '100.0', '100.0'])
        sheet.append(['Total number of PIR''s', '', '', '', '', '', '', '100.0', '100.0', '100.0'])

        self.updateColumnSize (wb, sheetName)
        
    def writeQuality(self, wb, sheetName, allRequests, runDate):
        monthCountsAllRequests = {}
        month = runDate.month
        currQuarter = self.quarters[month]
        startMonth = currQuarter['startMonth']
        endMonth = currQuarter['endMonth']
        currMonth = startMonth
        while currMonth <= endMonth:
            thisMonth = self.quarters[currMonth]
            monthCountsAllRequests[thisMonth['month']] = 0
            currMonth = currMonth + 1
            
        for rec in allRequests:
            closedDate = rec[GMDetailColumns.CLOSED_DATE.value]
            currRecMonth = closedDate.month
            currRecQuarter = self.quarters[currRecMonth]
            monthCountsAllRequests[currRecQuarter['month']] = monthCountsAllRequests[currRecQuarter['month']] + 1
            
        sheet = wb[sheetName]
        # headers
        sheet['A1'] = 'Quality'
        
        # format row 1
        for rows in sheet.iter_rows(min_row=1, max_row=1, min_col=1, max_col=8):
            for cell in rows:
                cell.fill = PatternFill(fgColor="00B2A9", fill_type = "solid")
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal='center') 
        
        sheet.append([''])
        sheet.append([''])
        
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('Data Requirements')
            rowData.append(month)
            rowData.append('') 
        sheet.append(rowData)
        
        # format row
        for rows in sheet.iter_rows(min_row=4, max_row=4, min_col=1, max_col=8):
            for cell in rows:
                cell.font = Font(bold=True)
            
        rowData = []
        for month in monthCountsAllRequests.keys():

            rowData.append('PIR Recorded')
            rowData.append(monthCountsAllRequests[month])
            rowData.append('')
        sheet.append(rowData)
            
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('Errors documented')
            rowData.append(0)
            rowData.append('')
        sheet.append(rowData)
            
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('Quality Score')
            rowData.append(100.0)
            rowData.append('')
        sheet.append(rowData)
            
        sheet.append([''])
        sheet.append([''])
        
        rowData = []       
        for month in monthCountsAllRequests.keys():
            rowData.append('Different company name or Address')
            rowData.append(month)
            rowData.append('')
        sheet.append(rowData)
        
        # format row
        for rows in sheet.iter_rows(min_row=10, max_row=10, min_col=1, max_col=8):
            for cell in rows:
                cell.font = Font(bold=True)
        
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('PIR Recorded')
            rowData.append(monthCountsAllRequests[month])
            rowData.append('')
        sheet.append(rowData)
            
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('Errors documented')
            rowData.append(0)
            rowData.append('')
        sheet.append(rowData)
            
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('Quality Score')
            rowData.append(100.0)
            rowData.append('')
        sheet.append(rowData)
            
        sheet.append([''])
        sheet.append([''])
        
        rowData = []       
        for month in monthCountsAllRequests.keys():
            rowData.append('Unable to Verify')
            rowData.append(month)
            rowData.append('')
        sheet.append(rowData)
    
    # format row
        for rows in sheet.iter_rows(min_row=16, max_row=16, min_col=1, max_col=8):
            for cell in rows:
                cell.font = Font(bold=True)
        
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('PIR Recorded')
            rowData.append(monthCountsAllRequests[month])
            rowData.append('')
        sheet.append(rowData)
            
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('Errors documented')
            rowData.append(0)
            rowData.append('')
        sheet.append(rowData)
            
        rowData = []
        for month in monthCountsAllRequests.keys():
            rowData.append('Quality Score')
            rowData.append(100.0)
            rowData.append('')
        sheet.append(rowData)
            
        self.updateColumnSize (wb, sheetName)
        sheet.merge_cells('A1:H1')

            
    def emailReports(self, environDict, runDate, localFilePath):
        quarter = self.getQuarterName(runDate)
        environ = environDict[envVblNames.ENV_ENVIRONMENT_NAME] 

        try:
            emailObj = SendEmail(environDict[envVblNames.ENV_SMTP_HOST],'IRSRCHAdminReporting@dnb.com')
        except Exception as e:
                logging.error('GMReportingHelper - unable to instantiate email class.  Error = %s ',e)
                raise 
    
        addressList = environDict[envVblNames.ENV_ADMIN_REPORTING_MAIL_TO].split(',')
        subject = environ + ' GM Dashboard for ' + quarter 
        emailObj.send(addressList, subject, 'Attached is the GM dashboard','plain', localFilePath)
        logging.info('Emailed GM Dashboard with attachment %s sent to %s', localFilePath, addressList)
        
    def updateColumnSize (self, wb, sheetName):
        sheet = wb[sheetName]
        for col in sheet.columns:
            max_length = 0
            if type(col[0]).__name__ == 'MergedCell':
                continue
            column = col[0].column_letter # Get the column name
            for cell in col:
                try: # Necessary to avoid error on empty cells
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = (max_length + 2) * 1.2
            sheet.column_dimensions[column].width = adjusted_width
            
    def setBorder(self, wb, sheetName, min_row, max_row, min_col, max_col):
        
        thin_border = Border(left=Side(style='thin'), 
                     right=Side(style='thin'), 
                     top=Side(style='thin'), 
                     bottom=Side(style='thin'))
        sheet = wb[sheetName]
        cellRange = sheet.iter_rows(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col)
        for row in cellRange:
            for cell in row:
                cell.border = thin_border
                
    def getNonLData(self, dbRecs):
        nonLs = []
        for dbRec in dbRecs:
            usageRecord = None
            if 'usg_pstg_obj' in dbRec:
                usageRecord = json.loads(dbRec['usg_pstg_obj'])
                if ('request' in usageRecord):
                    request = usageRecord['request']
                    if 'cases' in request and len(request['cases']) > 0:
                        case = request['cases'][0]
                        if 'researchTypes' in case and len(case['researchTypes']) > 0:
                            researchType = case['researchTypes'][0]
                            if researchType['researchSubTypeCode'] in [33565, 35943]:
                                nonLs.append(dbRec)

        return nonLs

if __name__ == '__main__':
    pass
