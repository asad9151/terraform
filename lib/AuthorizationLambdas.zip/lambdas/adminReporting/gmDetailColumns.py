'''
Created on Jan 21, 2020

@author: JafferS
'''
from enum import Enum

class GMDetailColumns(Enum):
    REQUEST_ID  = "Request Id"
    REQUESTOR_OWN_REQUEST_KEY  = "Requestors Own Request Key"
    RESEARCH_SUBTYPE = "Research Subtype"
    SUBMITTED_BUSINESS_NAME = "Submitted Business Name"
    SUBMITTED_COUNTRY = "Submitted Country"
    OPENED_DATE = "Opened Date"
    CLOSED_DATE = "Closed Date"
    DUE_DATE = "Due Date"
    TAT_DAYS = "TAT Days"
    
    @classmethod
    def hasValue(cls, value):
        return any(value == item.value for item in cls)
    
    @classmethod
    def getGMDetailColumns(cls):
        return list(cls)
        
    @classmethod
    def getAllGMDetailColumnNames(cls):
        return [e.value for e in cls]