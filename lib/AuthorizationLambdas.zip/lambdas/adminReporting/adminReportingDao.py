'''
Created on APr 11, 2019
DAO for RetrieveAdminData service

@author: JafferS
'''
import json
import logging
from common.encoders import IResearchEncoder


class AdminReportingDao(object):
    
    def getGMRequestDataForQuarter(self, dbConn, startDate, endDate):
        paramList = []
        query = '''
            select JSON_UNQUOTE(JSON_EXTRACT(sr.subj_rsch_obj, '$.submittedData.organizationName')) as submittedOrgName, sr.v_subm_ctry_cd, up.usg_pstg_obj, sr.due_date
            from usg_pstg up FORCE INDEX (usg_pstg_ie3, usg_pstg_ie2)
            join subj_rsch sr
            on up.v_rsch_reqs_id = sr.rsch_reqs_id
            where up.row_cre_tmst >= %s
            and up.row_cre_tmst <= %s
            and v_notif_typ_cd = 2
            and up.v_prev_extl_stat_cd != 33626
            and JSON_EXTRACT(up.usg_pstg_obj, '$.requestor.organizationName') = 'GM'
            and JSON_EXTRACT(up.usg_pstg_obj, '$.request.cases[0].researchTypes[0].researchTypeCode') = 33530
        '''
        
        paramList.append(startDate)
        paramList.append(endDate)
        params = tuple(paramList)
        logging.info(f"getGMRequestDataForQuarter: Before running query: {query} params={params}")
        
        dbConn.cursor.execute(query, params)
        
        logging.info("getGMRequestDataForQuarter: After running query")
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        #print('Result of fetchall/zip:')
        #print(json_data)
        dict_arry = json.loads(json_data)
        #self._dumpcsv(dict_arry)
        return dict_arry
