'''
Created on Mar 10, 2019

@author: VanCampK
'''
import json
from common.rejectionReasonCodes import RejectionReasonCode
from common.util.dictUtils import createUpperCaseDict
import lambdas.lambdaConstants as consts
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaValidationException
from lambdas.requestRejection import RequestRejection
from lambdas.requestRejectionError import RequestRejectionError


class RequestContext(object):
    '''
    holds information about the request to be passed on to services
    '''

    def __init__(self, event, userSession, environDict, lambdaContext, lambdaObj, isBodyJson=True):
        self.event = event
        self.method = event.get(consts.EVENT_METHOD)
        self.body = event.get(consts.EVENT_BODY)
        self.path = event.get(consts.EVENT_PATH)
        if self.body is not None and isBodyJson:
            if isinstance(self.body, dict):
                self.incomingContent = self.body
            else:
                try:
                    self.incomingContent = json.loads(self.body)
                except Exception as e:
                    rejectionErrors = []
                    rejectionErrors.append(RequestRejectionError(jsonPathName="body", errorDescription=errmsg.ERR_INVALID_JSON))
                    requestRejection = RequestRejection(RejectionReasonCode.VALIDATION_ERROR.value, rejectionErrorMessage=errmsg.ERR_INVALID_JSON, rejectionErrors=rejectionErrors)
                    raise LambdaValidationException(errmsg.ERR_INVALID_JSON, requestRejection=requestRejection)
                
        self.queryParameters = event.get(consts.EVENT_QUERY_PARAMS)
        self.userSession = userSession
        self.environDict = environDict
        self.lambdaContext = lambdaContext
        # cacheObj can hold some common information that is needed throughout the request to avoid querying it more than once, such as a case
        self.cacheObj = None
        self.lambdaObj = lambdaObj
        self.source = event.get(consts.EVENT_SOURCE)
        self.headers = createUpperCaseDict(event.get(consts.EVENT_HEADERS))
        # dictionary where service-specific or request-specific parameters can get passed thru:
        self.serviceDict = {}
        self.accessKey = None
        eventRequestContext = event.get(consts.EVENT_REQUEST_CONTEXT)
        if eventRequestContext is not None and eventRequestContext.get(consts.EVENT_REQUEST_CONTEXT_IDENTITY) is not None:
            identity = eventRequestContext.get(consts.EVENT_REQUEST_CONTEXT_IDENTITY)
            self.accessKey = identity.get(consts.EVENT_REQUEST_CONTEXT_IDENTITY_ACCESS_KEY)
        
        
    def getLambdaQueryParameter(self, paramName, defaultValue):
        if self.queryParameters == None:
            return defaultValue
        return self.queryParameters.get(paramName, defaultValue)
