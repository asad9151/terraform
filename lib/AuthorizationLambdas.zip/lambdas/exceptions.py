'''
Created on Mar 13, 2019

@author: VanCampK
'''
import logging
from lambdas.lambdaStatusCodes import LambdaStatusCodes

class LambdaProcessingException(Exception):
    '''
    Base class for all lambda processing exceptions. Normally instantiate one of its subclasses.
    This class should be directly instantiated only when the type of error is unknown.
    '''

    def __init__(self, errmsg, requestRejection=None):
        super().__init__(errmsg)
        self.statusCode = LambdaStatusCodes.INTERNAL_SERVER_ERROR
        self.errmsg = errmsg
        self.requestRejection = requestRejection
        

class LambdaValidationException(LambdaProcessingException):
    '''
    Exception to throw when lambda detects a validation failure.
    '''
    
    def __init__(self, errmsg, requestRejection=None):
        super().__init__(errmsg, requestRejection)
        self.statusCode = LambdaStatusCodes.BAD_REQUEST
        

class LambdaAuthenticationException(LambdaProcessingException):
    '''
    Exception to throw when a lambda detects an authentication failure.
    '''
    
    def __init__(self, errmsg, requestRejection=None):
        super().__init__(errmsg, requestRejection)
        self.statusCode = LambdaStatusCodes.UNAUTHORIZED
        

class LambdaAuthorizationException(LambdaProcessingException):
    '''
    Exception to throw when a lambda detects an authorization failure, e.g incorrect role or not authorized for case (forbidden).
    '''
    
    def __init__(self, errmsg, requestRejection=None):
        super().__init__(errmsg, requestRejection)
        self.statusCode = LambdaStatusCodes.FORBIDDEN
        

class LambdaConflictException(LambdaProcessingException):
    '''
    Exception to throw when a lambda detects an internal conflict.
    '''
    
    def __init__(self, errmsg, requestRejection=None):
        super().__init__(errmsg, requestRejection)
        self.statusCode = LambdaStatusCodes.CONFLICT


class LambdaCloudServicesAuthenticationException(LambdaAuthenticationException):
    '''
    Exception to raise when a CloudServices request is received with invalid information
    '''
    
    def __init__(self, errmsg, requestRejection=None):
        super().__init__(errmsg, requestRejection)
        self.statusCode = LambdaStatusCodes.UNAUTHORIZED
        

class LambdaNotFoundException(LambdaProcessingException):
    '''
    Exception to throw when request key was not found.
    '''
    
    def __init__(self, errmsg, requestRejection=None):
        super().__init__(errmsg, requestRejection)
        self.statusCode = LambdaStatusCodes.NOT_FOUND
        

class LambdaAlreadyAlertedException(LambdaProcessingException):
    '''
    Exception to throw when the exception was already caught and alerted in a submodule.
    '''


def createException(statusCode, errmsg, requestRejection=None, isCloudServices=False):
    '''
    Factory to instantiate any of the above exception types by statusCode;
    or a LambdaProcessingException if unsupported statusCode.
    '''
    if statusCode == LambdaStatusCodes.INTERNAL_SERVER_ERROR.value:
        return LambdaProcessingException(errmsg, requestRejection)
    elif statusCode == LambdaStatusCodes.BAD_REQUEST.value:
        return LambdaValidationException(errmsg, requestRejection)
    elif statusCode == LambdaStatusCodes.UNAUTHORIZED.value:
        if isCloudServices:
            return LambdaCloudServicesAuthenticationException(errmsg, requestRejection)
        else:
            return LambdaAuthenticationException(errmsg, requestRejection)
    elif statusCode == LambdaStatusCodes.FORBIDDEN.value:
        return LambdaAuthorizationException(errmsg, requestRejection)
    elif statusCode == LambdaStatusCodes.CONFLICT.value:
        return LambdaConflictException(errmsg, requestRejection)
    elif statusCode == LambdaStatusCodes.NOT_FOUND.value:
        return LambdaNotFoundException(errmsg, requestRejection)
    else:
        logging.error(f'Unsupported statusCode={statusCode}')
        return LambdaProcessingException(errmsg, requestRejection)
        