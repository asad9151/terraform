'''
Created on July 30, 2020

@author: GuardiolaR
'''
from common.requestMethodCodes import RequestMethodCode
from lambdas.exceptions import LambdaValidationException
import lambdas.errorMessages as errmsg

def createUsageRecordMessage(requestMethodQuery, requestMethodDescription):
    return _usageTypeTransformToSchema(requestMethodQuery, requestMethodDescription)


def _usageTypeTransformToSchema(requestMethodQuery, requestMethodDescription):
    isIrgSystem = _isIRGSystem(requestMethodQuery.get("v_reqs_meth_cd"))
    
    result = {}
    result["requestMethodCode"] = requestMethodQuery.get("v_reqs_meth_cd")
    result["usagePartner"] = requestMethodDescription
    
    if isIrgSystem is True:
        result["message"] = "Are you sure you want to retrigger usage to the " + result["usagePartner"] + " downstream system?"
    elif result["requestMethodCode"] == RequestMethodCode.DNB_DIRECT_PLUS.value:
        result["message"] = "Are you sure you want to resend usage to Direct+ Billing?"
    elif result["requestMethodCode"] == RequestMethodCode.SALES_FORCE.value:
        result["message"] = "Are you sure you want to update Salesforce?"
    elif result["requestMethodCode"] == RequestMethodCode.ASCENT_EXCLUSIONS.value:
        result["message"] = "Are you sure you want to resend usage to " + result["usagePartner"] + "?"
    elif result["requestMethodCode"] ==  RequestMethodCode.UNITY.value:
        raise LambdaValidationException(errmsg.ERR_CANNOT_RETRIGGER_UNITY_USAGE)
    else:
        result["message"] = "Are you sure you want to generate a usage record for " + result["usagePartner"] + " if it does not already exists?"

    return result

def _isIRGSystem(value):
    irgSystems = [RequestMethodCode.DNBI_AUSTRALIA.value, RequestMethodCode.DATA_INTEGRATION_TOOLKIT.value, RequestMethodCode.ONBOARD_UI.value, RequestMethodCode.IRG.value,
                  RequestMethodCode.MYDNB_COM.value, RequestMethodCode.DBIA.value, RequestMethodCode.SUPPLIER_PORTAL.value, RequestMethodCode.DAAS_COMPLIANCE.value, RequestMethodCode.DNB_CREDIT.value,
                  RequestMethodCode.DIRECT_ONBOARD_API.value, RequestMethodCode.DBAI_EUROPE.value, RequestMethodCode.DIRECT_2_0.value, RequestMethodCode.DUNSTEL.value, RequestMethodCode.DNBI.value]
    for system in irgSystems:
        if(value == system):
            return True
    
    return False