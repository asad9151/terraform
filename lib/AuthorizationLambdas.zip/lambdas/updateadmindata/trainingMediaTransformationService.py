'''
Created on July 14, 2020

@author: GuardiolaR
'''

from attachmentClass import attachment
import constants
from common import updateEventConstants


class TrainingMediaTransformationService(object):
    '''
    Creates attachment object needed by RequestAttachmentLinkService.
    '''
    def addAttachment(self, mediaFileName):
        attmObj = attachment()
        attmReqDict = {
            "attachmentName": mediaFileName,
            "attachmentType": constants.TRAINING_MEDIA_ATTACHMENT
        }
        attmObj.loadRequestAttributes(attmReqDict)
        
        return attmObj
        
        
    def transformAttachmentResponses(self, attmObj):
        requestLinkResp = attmObj.getRequestAttachmentLinkResponse()
        resp = {
            updateEventConstants.API_RESP_ATTACHMENT_NAME: attmObj.getIncomingFileName(),
            updateEventConstants.API_RESP_ATTACHMENT_URL: requestLinkResp["signed_URL"]["url"],
            updateEventConstants.API_RESP_ATTACHMENT_FIELDS: requestLinkResp["signed_URL"]["fields"]
        }
             
        return resp
    