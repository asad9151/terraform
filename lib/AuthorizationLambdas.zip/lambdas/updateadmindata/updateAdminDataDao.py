'''
Created on Apr 11, 2019
DAO for UpdateAdminData service

@author: JafferS
'''
import json
import logging
import csv
from common.encoders import IResearchEncoder
from common.batchStatusCodes import BatchStatusCode

class UpdateAdminDataDao(object):

    def getSubmitterGroupByName(self, dbConn, submitterGroup):

        query = '''
            select SG.sbms_grp_id as SG_sbms_grp_id, SG.sbms_grp_nme as SG_sbms_grp_nme, UNIX_TIMESTAMP(SG.row_mod_tmst) as SG_mod_timestamp,
            RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme, RU.sbmt_ctry_code as RU_sbmt_ctry_code, RU.acte_indc as RU_acte_indc, RU.acte_indc_tmst as RU_acte_indc_tmst
            from sbms_grp SG
            left join sbmt_sbms_grp SSG
            on SG.sbms_grp_id = SSG.sbms_grp_id
            left join rsch_usr RU
            on SSG.rsch_usr_id = RU.rsch_usr_id
            where SG.sbms_grp_nme = %s
        '''
        
        params = (submitterGroup)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry

    def _dumpcsv(self, dict_arry):
        # Dumps the data to a CSV file for testing/verification
        dict0 = dict_arry[0]
        with open('adminData.csv', 'w', newline='') as f:
            w = csv.DictWriter(f, dict0.keys())
            w.writeheader()
            w.writerows(dict_arry)

    def addSubmitterGroup(self, dbConn, submitterGroup):
        query = '''
        insert into sbms_grp
        (sbms_grp_nme,
        row_crer_id_txt,
        row_modr_id_txt)
        values
        (%s,
         %s,
         %s)
        '''
    
        params = (submitterGroup, 'irschappwrite', 'irschappwrite')
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid;
 
    def updateSubmitterGroup(self, dbConn, submitterTeamId, usersToAdd, usersToDelete):
 
        insertQuery = '''
            INSERT sbmt_sbms_grp
            (rsch_usr_id,
            sbms_grp_id,
            row_crer_id_txt,
            row_modr_id_txt)
            VALUES
            (%s,
             %s,
             %s,
             %s)
            '''       
        deleteQuery = '''
            DELETE FROM sbmt_sbms_grp
            WHERE rsch_usr_id = %s and sbms_grp_id = %s
            '''
        updateQuery = '''
            update sbms_grp
            SET row_mod_tmst = NOW()
            WHERE sbms_grp_id = %s
            '''
        
        recordsToInsert = []
        recordsToDelete = []
        params = (submitterTeamId)
    
        for user in usersToAdd:
            recordsToInsert.append([user, submitterTeamId,'irschappwrite', 'irschappwrite'])
        for user in usersToDelete:
            recordsToDelete.append([user, submitterTeamId])
                
        dbConn.cursor.executemany(insertQuery, recordsToInsert)
        dbConn.cursor.executemany(deleteQuery, recordsToDelete)
        dbConn.cursor.execute(updateQuery, params)
        
        dbConn.dbconn.commit()
        return None
    
    def getSubmitterGroupById(self, dbConn, submitterGroupId):

        query = '''
            select SG.sbms_grp_id as SG_sbms_grp_id, SG.sbms_grp_nme as SG_sbms_grp_nme, UNIX_TIMESTAMP(SG.row_mod_tmst) as SG_mod_timestamp,
            RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme, RU.sbmt_ctry_code as RU_sbmt_ctry_code, RU.acte_indc as RU_acte_indc, RU.acte_indc_tmst as RU_acte_indc_tmst
            from sbms_grp SG
            left join sbmt_sbms_grp SSG
            on SG.sbms_grp_id = SSG.sbms_grp_id
            left join rsch_usr RU
            on SSG.rsch_usr_id = RU.rsch_usr_id
            where SG.sbms_grp_id = %s
        '''
        
        params = (submitterGroupId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry
    
    def getResearchTeamById(self, dbConn, researchTeamId, administerLocalAdmin):
        if administerLocalAdmin:
            teamAdmrIndc = 1
        else:
            teamAdmrIndc = 0

        query = '''
            select RT.rsch_team_id as RT_rsch_team_id, RT.rsch_team_org_nme as RT_rsch_team_org_nme, RT.ctry_code as RT_ctry_code, RT.rsch_team_nme as RT_rsch_team_nme, UNIX_TIMESTAMP(RT.row_mod_tmst) as RT_mod_timestamp, 
            RU.rsch_usr_id as RU_rsch_usr_id, RU.usr_firs_nme as RU_usr_firs_nme, RU.usr_lst_nme as RU_usr_lst_nme, RU.usr_eml_adr as RU_usr_eml_adr, RU.lgin_key as RU_lgin_key, RU.sbmt_org_nme as RU_sbmt_org_nme, RU.sbmt_ctry_code as RU_sbmt_ctry_code, RU.acte_indc as RU_acte_indc, RU.acte_indc_tmst as RU_acte_indc_tmst  
            from rsch_team RT
            left join rsch_team_mbr TM 
            on TM.rsch_team_id = RT.rsch_team_id
            and TM.team_admr_indc = %s
            left join rsch_usr RU on RU.rsch_usr_id = TM.rsch_usr_id  
            where RT.rsch_team_id = %s
 
        '''
        
        params = (teamAdmrIndc, researchTeamId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry
    
    def updateResearchTeam(self, dbConn, researchTeamId, usersToAdd, usersToDelete, administerLocalAdmin):
        if administerLocalAdmin:
            teamAdmrIndc = 1
        else:
            teamAdmrIndc = 0
            
        insertQuery = '''
            INSERT INTO rsch_team_mbr
                (rsch_team_id,
                 rsch_usr_id,
                 row_crer_id_txt,
                 row_modr_id_txt,
                 team_admr_indc)
                 VALUES
                (%s,
                 %s,
                 %s,
                 %s,
                 %s);
            '''       
        deleteQuery = '''
            DELETE FROM rsch_team_mbr
            WHERE rsch_usr_id = %s 
            and rsch_team_id = %s 
            and team_admr_indc = %s
            '''
        updateQuery = '''
            update rsch_team
            SET row_mod_tmst = NOW()
            WHERE rsch_team_id = %s
            '''
        
        recordsToInsert = []
        recordsToDelete = []
        params = (researchTeamId)
    
        for user in usersToAdd:
            recordsToInsert.append([researchTeamId, user, 'irschappwrite', 'irschappwrite', teamAdmrIndc] )
        for user in usersToDelete:
            recordsToDelete.append([user, researchTeamId, teamAdmrIndc])
                
        dbConn.cursor.executemany(insertQuery, recordsToInsert)
        dbConn.cursor.executemany(deleteQuery, recordsToDelete)
        dbConn.cursor.execute(updateQuery, params)
        
        dbConn.dbconn.commit()
        return None


    def addUser(self, dbConn, loginKey, userEmailAddress, rowCreatorId):
        query = '''
        insert into rsch_usr(lgin_key, usr_eml_adr, rsch_usr_obj, rsch_usr_adm_obj, acte_indc, acte_indc_tmst, row_crer_id_txt, row_modr_id_txt)
        values(%s, %s, '{}', '{"submitterRoutingCategories":[],"researchSubTypesGroups":[],"iResearchUserRoles":[],"IDaaSUserRoles":[]}', 1, NOW(), %s, %s)
        '''
    
        params = (loginKey, userEmailAddress, rowCreatorId, rowCreatorId)
        logging.info('addUser: ' + query + " params=" + str(params))
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid;
    
    
    def updateBatchStatusForApprove(self, dbConn, batchRequestId, status, dueDate, campaignPriority, batchReqsObj):
            
        query = '''
            update btch_reqs
            SET prcs_stat_cd = %s,
                stat_tmst = NOW(),
                due_date = %s,
                cmpgn_prty_cd = %s,
                btch_reqs_obj = %s,
                row_modr_id_txt = %s
            WHERE btch_reqs_id = %s
            '''
        params = (status, dueDate, campaignPriority, batchReqsObj, 'updateAdminData', batchRequestId)
        logging.info('approveBatch: ' + query + " params=" + str(params))
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return None
    
    
    def rejectBatch(self, dbConn, batchRequestId, batchRejectReason, batchRejectReasonComment):
            
        query = '''
            update btch_reqs
            SET prcs_stat_cd = %s,
                stat_tmst = NOW(),
                btch_rej_err_txt = %s,
                btch_rej_reas_cmnt = %s,
                row_modr_id_txt = %s
            WHERE btch_reqs_id = %s
            '''
        params = (BatchStatusCode.APPROVER_REJECTED.value, batchRejectReason, batchRejectReasonComment, 'updateAdminData', batchRequestId)
        logging.info('rejectBatch: ' + query + " params=" + str(params))
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return None
    
    
    
    def updateBatchDueDate(self, dbConn, batchRequestId, dueDate):
            
        batchReqQuery = '''
            update btch_reqs
            SET due_date = %s,
            row_modr_id_txt = %s
            WHERE btch_reqs_id = %s
            '''
        
        subjRschQuery = '''
            update subj_rsch sr
            join rsch_reqs rr
            on sr.rsch_reqs_id = rr.rsch_reqs_id
            set sr.due_date = %s,
            sr.row_modr_id_txt = %s
            where rr.btch_reqs_id = %s
            '''
        paramsbatchReq = (dueDate, 'updateAdminData', batchRequestId)
        logging.info('updateBatchDueDate: ' + batchReqQuery + " params=" + str(paramsbatchReq))
        
        paramsSubjRsch = (dueDate, 'updateAdminData', batchRequestId)
        logging.info('updateBatchDueDate: ' + subjRschQuery + " params=" + str(paramsSubjRsch))
        
        dbConn.cursor.execute(batchReqQuery, paramsbatchReq)
        dbConn.cursor.execute(subjRschQuery, paramsSubjRsch)
        
        dbConn.dbconn.commit()
        return None
    
    def addRschRefDataEntry(self, dbConn, dataName, dataType):
        query = '''
        insert into rsch_ref_data
        (data_nme,
        data_type,
        row_crer_id_txt,
        row_modr_id_txt)
        values
        (%s,
         %s,
         %s,
         %s)
        '''
    
        params = (dataName, dataType, 'irschappwrite', 'irschappwrite')
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid;

    def getRschRefDataByNameAndType(self, dbConn, dataName, dataType):

        query = '''
            select RD.rsch_ref_data_id, RD.data_nme, RD.data_type, UNIX_TIMESTAMP(RD.row_mod_tmst) as mod_timestamp ,
            RDC.rsch_ref_data_chld_id, RDC.val
            from rsch_ref_data RD
            left join rsch_ref_data_chld RDC
            on RD.rsch_ref_data_id = RDC.rsch_ref_data_id
            where RD.data_nme = %s and RD.data_type = %s
        '''
        
        params = (dataName, dataType)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry
    
    def getRschRefDataById(self, dbConn, rschRefDataId):

        query = '''
            select RD.rsch_ref_data_id, RD.data_nme, RD.data_type, UNIX_TIMESTAMP(RD.row_mod_tmst) as mod_timestamp ,
            RDC.rsch_ref_data_chld_id, RDC.val
            from rsch_ref_data RD
            left join rsch_ref_data_chld RDC
            on RD.rsch_ref_data_id = RDC.rsch_ref_data_id
            where RD.rsch_ref_data_id = %s
        '''
        
        params = (rschRefDataId)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
    
        return dict_arry

    def updateRschRefData(self, dbConn, rschRefDataId, childrenToAdd, childrenToDelete):
        insertQuery = '''
            INSERT rsch_ref_data_chld
            (rsch_ref_data_id,
            val,
            row_crer_id_txt,
            row_modr_id_txt)
            VALUES
            (%s,
             %s,
             %s,
             %s)
            '''       
        deleteQuery = '''
            DELETE FROM rsch_ref_data_chld
            WHERE rsch_ref_data_id = %s and val = %s
            '''
        updateQuery = '''
            update rsch_ref_data
            SET row_mod_tmst = NOW()
            WHERE rsch_ref_data_id = %s
            '''
        
        recordsToInsert = []
        recordsToDelete = []
        params = (rschRefDataId)
    
        for child in childrenToAdd:
            recordsToInsert.append([rschRefDataId, child, 'UpdateAdminData', 'UpdateAdminData'])
        for child in childrenToDelete:
            recordsToDelete.append([rschRefDataId, child])
                
        dbConn.cursor.executemany(insertQuery, recordsToInsert)
        dbConn.cursor.executemany(deleteQuery, recordsToDelete)
        dbConn.cursor.execute(updateQuery, params)
        
        dbConn.dbconn.commit()
        return None
    
    def updateApiApplication(self, dbConn, apiAppEntlId, partnerFolderName, prcsOptnsObj, modr_id_txt):
        query = "update api_app_entl set prcs_optns_obj = %s, ptnr_fldr_nme = %s, row_mod_tmst=now(), row_modr_id_txt = %s where api_app_entl_id = %s"
        params = (prcsOptnsObj, partnerFolderName, modr_id_txt, apiAppEntlId)
        dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
    
        
    def addTrainingMedia(self, dbConn, mediaType, mediaTitle, mediaDescription, mediaCategory, mediaOrderNumber, mediaKeywords, attmId):
        '''
        Will need the attachment id from the request attachment link, so will initially need the filename to get request attachment link.
        Then will use the record in the attachment table to populate the row_cred_id_txt.
        '''
        insertQuery = '''
            INSERT INTO trng_mdia
            (mdia_typ, 
            mdia_nme, 
            mdia_desc_txt, 
            mdia_ctgy_typ, 
            mdia_ordr_nbr,
            mdia_kywd_txt, 
            attm_id, 
            row_cre_tmst, 
            row_crer_id_txt, 
            row_mod_tmst, 
            row_modr_id_txt) 
            VALUES 
            (%s, 
            %s, 
            %s, 
            %s, 
            %s,
            %s, 
            %s, 
            NOW(), 
            'irschappwrite', 
            NOW(), 
            'irschappwrite'); 
            ''' 
        
        params = (mediaType, mediaTitle, mediaDescription, mediaCategory, mediaOrderNumber, mediaKeywords, attmId)
        dbConn.cursor.execute(insertQuery, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid
    
    
    def updateTrainingMedia(self, dbConn, trainingMediaId, mediaType, mediaTitle, mediaDescription, mediaCategory, mediaOrderNumber, mediaKeywords, attmId):
        paramList = []
        updateQuery = '''
            UPDATE trng_mdia 
            SET
        '''
        
        if mediaType is not None:
            updateQuery += ' mdia_typ = %s'
            paramList.append(mediaType)
        if mediaTitle is not None:
            if len(paramList) > 0:
                updateQuery += ', mdia_nme = %s'
            else:
                updateQuery += ' mdia_nme = %s'
            paramList.append(mediaTitle)
        if mediaDescription is not None:
            if len(paramList) > 0:
                updateQuery += ', mdia_desc_txt = %s'
            else:
                updateQuery += ' mdia_desc_txt = %s'
            paramList.append(mediaDescription)
        if mediaCategory is not None:
            if len(paramList) > 0:
                updateQuery += ', mdia_ctgy_typ = %s'
            else:
                updateQuery += ' mdia_ctgy_typ = %s'
            paramList.append(mediaCategory)
        if mediaOrderNumber is not None:
            if len(paramList) > 0:
                updateQuery += ', mdia_ordr_nbr = %s'
            else:
                updateQuery += ' mdia_ordr_nbr = %s'
            paramList.append(mediaOrderNumber)
        if mediaKeywords is not None:
            if len(paramList) > 0:
                updateQuery += ', mdia_kywd_txt = %s'
            else:
                updateQuery += ' mdia_kywd_txt = %s'
            paramList.append(mediaKeywords)
        if attmId is not None:
            if len(paramList) > 0:
                updateQuery += ', attm_id = %s'
            else:
                updateQuery += ' attm_id = %s'
            paramList.append(attmId)
        updateQuery += ' WHERE trng_mdia_id = %s;' 
        paramList.append(trainingMediaId)   
        
        dbConn.cursor.execute(updateQuery, paramList)
        dbConn.dbconn.commit()
        
        return None
            
        
        
    def deleteTrainingMedia(self, dbConn, trainingMediaId):
        '''
        Will need the attachment id from the request attachment link, so will initially need the filename to get request attachment link.
        Then will use the record in the attachment table to populate the row_cred_id_txt or will we just let the rsch user that created
        the attachment and last modified the file live in the attm table?
        '''
        deleteQuery = '''
            DELETE FROM trng_mdia 
            WHERE trng_mdia_id = %s;
            ''' 
        
        params = (trainingMediaId)
        dbConn.cursor.execute(deleteQuery, params)
        dbConn.dbconn.commit()
        
        return None
    
    
    def getAttachmentId(self, dbConn, attachmentKey, attachmentFolder):
        '''
        This attachment Id will be used to insert the traningMedia record in the trng_mdia table that has a foreign key constraint
        on attm_id.
        '''
        query = '''
            SELECT attm_id from attm 
            WHERE fle_nme = %s
            AND fldr_key= %s;
            '''
        
        params = (attachmentKey, attachmentFolder)
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data = []
        
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        attmId = dict_arry[0]['attm_id']
        return attmId
    
    def addBannerMessage(self, dbConn, bannerMessageObject, bannerStartDate, bannerEndDate, bannerMessageActiveIndicator):
        
        insertQuery = '''
            INSERT INTO bnr_msg
            (bnr_msg_obj,
            effv_tmst, 
            expn_tmst, 
            bnr_msg_act_ind, 
            row_crer_id_txt, 
            row_modr_id_txt) 
            VALUES 
            (%s, 
            %s, 
            %s, 
            %s,
            'updateAdminData', 
            'updateAdminData');
            '''
        
        bannerMessageObject = json.dumps(bannerMessageObject)
        params = (bannerMessageObject, bannerStartDate, bannerEndDate, bannerMessageActiveIndicator)
        dbConn.cursor.execute(insertQuery, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid
    
    
    def updateBannerMessage(self, dbConn, bannerMessageId, bannerTitle, bannerMessage, bannerSeverity, bannerDismissable, bannerNotifyRoles, bannerStartDate, bannerEndDate, bannerMessageActiveIndicator):
        #Get bnr_msg_obj for updates if bannerTitle, bannerMessage, bannerSeverity, bannerDismissable, or bannerNotifyRoles has an update and update the JSON with new values
        bannerMessageObject = None
        if bannerTitle is not None or bannerMessage is not None or bannerSeverity is not None or bannerNotifyRoles is not None:
            bannerMessageObject = self._queryBannerMessageTableForBnrMsgObj(dbConn, bannerMessageId)
            bannerMessageObject = json.loads(bannerMessageObject)
            if bannerTitle is not None:
                bannerMessageObject['bannerTitle'] = bannerTitle
            if bannerMessage is not None:
                bannerMessageObject['bannerMessage'] = bannerMessage
            if bannerSeverity is not None:
                bannerMessageObject['bannerSeverity'] = bannerSeverity
            if bannerDismissable is not None:
                bannerMessageObject['bannerDismissable'] = bannerDismissable
            if bannerNotifyRoles is not None:
                bannerMessageObject['userRole'] = bannerNotifyRoles
            bannerMessageObject = json.dumps(bannerMessageObject)
        
        paramList = []
        updateQuery = '''
            UPDATE bnr_msg
            SET
            '''
         
        if bannerStartDate is not None:
            updateQuery += 'effv_tmst = %s'
            paramList.append(bannerStartDate)
        if bannerEndDate is not None:
            if len(paramList) > 0:
                updateQuery += ', expn_tmst = %s'
            else:
                updateQuery += ' expn_tmst = %s'
            paramList.append(bannerEndDate)
        if bannerMessageActiveIndicator is not None:
            if len(paramList) > 0:
                updateQuery += ', bnr_msg_act_ind = %s'
            else:
                updateQuery += ' bnr_msg_act_ind = %s'
            paramList.append(bannerMessageActiveIndicator)
        if bannerMessageObject is not None:
            if len(paramList) > 0:
                updateQuery += ', bnr_msg_obj = %s'
            else:
                updateQuery += 'bnr_msg_obj = %s'
            paramList.append(bannerMessageObject)
        updateQuery += ' WHERE bnr_msg_id = %s'
        paramList.append(bannerMessageId)
         
        dbConn.cursor.execute(updateQuery, paramList)
        dbConn.dbconn.commit()
        
        return None
    
    
    def _queryBannerMessageTableForBnrMsgObj(self, dbConn, bannerMessageId):
        query = '''
            SELECT bnr_msg_obj
            FROM bnr_msg
            WHERE bnr_msg_id = %s;
            '''
        params = (bannerMessageId)
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data = []
        
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        bnr_msg_obj = dict_arry[0]['bnr_msg_obj']
        
        return bnr_msg_obj
    
    
    def addMaintenanceOutage(self, dbConn, mntnStartDate, mntnEndDate, mntnWarningMinutes, bannerMessageId):    
        
        insertQuery = '''
            INSERT INTO mntn_wndw
            (mntn_effv_tmst, 
            mntn_expn_tmst, 
            mntn_lckt_wrng_mins_cnt, 
            bnr_msg_id, 
            row_crer_id_txt, 
            row_modr_id_txt)
            VALUES
            (%s,
            %s,
            %s,
            %s,
            'updateAdminData', 
            'updateAdminData');
            '''
        
        params = (mntnStartDate, mntnEndDate, mntnWarningMinutes, bannerMessageId)
        dbConn.cursor.execute(insertQuery, params)
        dbConn.dbconn.commit()
        return dbConn.cursor.lastrowid
    
    
    def updateMaintenanceOutage(self, dbConn, mntnWindowId, mntnStartDate, mntnEndDate, mntnWarningMinutes, messageBanner):
        paramList = []
        updateQuery = '''
            UPDATE mntn_wndw
            SET
            '''
        
        if mntnStartDate is not None:
            updateQuery += 'mntn_effv_tmst = %s'
            paramList.append(mntnStartDate)
        if mntnEndDate is not None:
            if len(paramList) > 0:
                updateQuery += ', mntn_expn_tmst = %s'
            else:
                updateQuery += ' mntn_expn_tmst = %s'
            paramList.append(mntnEndDate)
        if mntnWarningMinutes is not None:
            if len(paramList) > 0:
                updateQuery += ', mntn_lckt_wrng_mins_cnt = %s'
            else:
                updateQuery += ' mntn_lckt_wrng_mins_cnt = %s'
            paramList.append(mntnWarningMinutes)
        updateQuery += ' WHERE mntn_wndw_id = %s'
        paramList.append(mntnWindowId)
        
        dbConn.cursor.execute(updateQuery, paramList)
        dbConn.dbconn.commit()
        
        if messageBanner is not None:
            bannerMessageId = self._queryBannerMessageIdForMaintenanceOutage(dbConn, mntnWindowId)
            return bannerMessageId
        
        return None
    
    
    def _queryBannerMessageIdForMaintenanceOutage(self, dbConn, mntnWindowId):
        query = '''
            SELECT bnr_msg_id
            FROM mntn_wndw
            WHERE mntn_wndw_id = %s;
            '''
        params = (mntnWindowId)
        dbConn.cursor.execute(query, params)
        rv = dbConn.cursor.fetchall()
        dict_data = []
        
        for result in rv:
            #print(json.dumps(result, cls=IResearchEncoder) + ',')
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        json_data = json.dumps(dict_data, cls=IResearchEncoder)
        dict_arry = json.loads(json_data)
        bnr_msg_id = dict_arry[0]['bnr_msg_id']
        
        return bnr_msg_id