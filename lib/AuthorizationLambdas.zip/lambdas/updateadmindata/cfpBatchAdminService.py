'''
Created on Nov 5, 2020

@author: VanCampK
'''
import binascii
import copy
import logging
import os

from common.batchStatusCodes import BatchStatusCode
from common.dao.fileTrackingDao import FileTrackingDao
from common.model.s3Object import S3Object
from common import updateEventConstants 
from common.updateActionCodes import UpdateActionCode
from common.util.s3Helper import S3Helper
from common.util.stringUtils import isBlank
from lambdas.exceptions import LambdaValidationException


class CfpBatchAdminService(object):
    '''
    Batch Admin Services for CFP batches
    '''
    APP_MODULE = "UpdateAdminData"


    def __init__(self, dbConn, s3handle, eventDao):
        self.dbConn = dbConn
        self.s3handle = s3handle
        self.eventDao = eventDao
        self.s3Helper = None
        self.fileTrackingDao = None
        
        
    def rerunBatch(self, requestContext, batchRequestId):
        '''
        CFP wants to re-send all the files for this batch, using the same file names, project ID and tracking number.
        In order to cause this start a whole new batch, we need to rename all the files already processed under this batch
        to a new/unique name. That way when the new files arrive with the same file names, we will not reject them,
        and we will create a whole new batch and process it from scratch.
        '''
        self._createServices()
        stpPartnerDeliveryFiles = self.fileTrackingDao.queryPartnerFilesByBatchRequestId(self.dbConn, batchRequestId)
        if stpPartnerDeliveryFiles is None or len(stpPartnerDeliveryFiles) < 1:
            # should never happen for a batch in a completed status
            raise LambdaValidationException(f"Batch id {batchRequestId} has no files")
        
        fileUniqueSuffix = self._generateRandomSuffix()
        for stpPartnerDeliveryFile in stpPartnerDeliveryFiles:
            try:
                self._renameCfpFile(requestContext, stpPartnerDeliveryFile, fileUniqueSuffix)
            except Exception as e:
                logging.error(f"rerunBatch Caught exception {e} renaming {stpPartnerDeliveryFile} with new suffix={fileUniqueSuffix}")
        self.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                     updateEventConstants.AUDIT_BATCH_REQUEST_TABLE, batchRequestId, 
                                     updateEventConstants.AUDIT_ELEMENT_BATCH_STATUS, BatchStatusCode.REOPEN_BATCH.value, 0,
                                     UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                     None, 'UpdateAdminData')
        
        
    def _createServices(self):
        if self.fileTrackingDao is None:
            self.fileTrackingDao = FileTrackingDao()
        if self.s3Helper is None:
            #self.s3Helper = S3Helper(self.s3handle)
            self.s3Helper = S3Helper()
            
            
    def _generateRandomSuffix(self):
        return binascii.b2a_hex(os.urandom(4)).upper().decode("UTF-8")
            
            
    def _renameCfpFile(self, requestContext, stpPartnerDeliveryFile, fileUniqueSuffix):
        srcS3Object = copy.deepcopy(stpPartnerDeliveryFile.s3Object)
        dstS3Object = S3Object(srcS3Object)
        dstS3Object.folder = self._nameDestFolder(srcS3Object.folder)
        dstS3Object.fileName = self._nameDestFile(srcS3Object.fileName, fileUniqueSuffix)
        stpPartnerDeliveryFile.s3Object = dstS3Object
        stpPartnerDeliveryFile.stpFileName = self._nameDestFile(stpPartnerDeliveryFile.stpFileName, fileUniqueSuffix)

        # First: update the database since that's most important (file on S3 is never going to be used again)
        self.fileTrackingDao.updateFileTracking(self.dbConn, stpPartnerDeliveryFile, CfpBatchAdminService.APP_MODULE)
        self.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                     updateEventConstants.AUDIT_FILE_TRACKING_TABLE, stpPartnerDeliveryFile.fileTrackingId, 
                                     updateEventConstants.AUDIT_ELEMENT_FILE_TRACKING_FILE_NAME, dstS3Object.fileName, BatchStatusCode.APPROVER_REJECTED.value,
                                     UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                     None, 'UpdateAdminData')
        # Second: copy to new name on S3
        self.s3Helper.copyFromS3ToS3(srcS3Object, dstS3Object)
        # Third: delete old copy from S3
        self.s3Helper.deleteObject(srcS3Object)
        # Fourth: Special case for IRD4.DAT - delete IRD4.REC from sftp-users S3 folder because CFP cannot rename on iResearch SFTP service if destination file already exists
        if srcS3Object.fileName.endswith("IRD4.DAT"):
            rmS3Object = S3Object(srcS3Object)
            rmS3Object.folder = srcS3Object.folder.replace("sftp-outbound", "sftp-users")
            rmS3Object.fileName = srcS3Object.fileName.replace("IRD4.DAT", "IRD4.REC")
            logging.info(f"Remove IRD4.REC: rmS3Object={rmS3Object}")
            # Ok if this raises an exception - normal for the file to not exist if CFP never picked up the file the first time
            try:
                self.s3Helper.deleteObject(rmS3Object)
            except Exception as e:
                logging.info(f"rerunBatch Caught exception {e} removing {rmS3Object} - this is OK, just means CFP never picked up the file")
        
        
    def _nameDestFolder(self, srcFolder):
        # We move old files into an "archive" folder to avoid triggering lambdas upon arrival in original folder
        if isBlank(srcFolder):
            return srcFolder
        srcFolderParts = srcFolder.split("/")
        if srcFolderParts[0] == "archive":
            # It was already renamed once before and moved to archive, so keep the new one there too
            return srcFolder
        else:
            return "archive/" + srcFolder
        
        
    def _nameDestFile(self, srcFilename, fileUniqueSuffix):
        # Sample old file name: FPC.ANDRETES.A4102620.TR614C.IRD4.DAT
        # Sample new file name: FPC.ANDRETES.A4102620.TR614C_E33E53C9.IRD4.DAT
        srcFilenameParts = srcFilename.split(".")
        if len(srcFilenameParts) > 3:
            srcFilenameParts[3] += f"_{fileUniqueSuffix}"
        else:
            srcFilenameParts[-1] += f"_{fileUniqueSuffix}"
        return ".".join(srcFilenameParts)
        