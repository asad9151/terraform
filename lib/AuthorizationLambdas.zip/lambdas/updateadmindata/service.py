'''
Created on Mar 3, 2019
Service for updating admin data

@author: JafferS
'''
import constants
import logging
import json

import lambdas.errorMessages as errmsg
from lambdas.updateadmindata.updateAdminDataDao import UpdateAdminDataDao
from lambdas.retrieveadmindata.retrieveAdminDataDao import RetrieveAdminDataDao
from common.externalStatusCode import ExternalStatusCode
from common.dao.updateEventDao import UpdateEventDao
from common.dao.researchUserDao import ResearchUserDao
from common.dao.researchRequestDao import ResearchRequestDao
from common.dao.scotsDao import ScotsDao
from common.scotsTables import ScotsTable
from common.util.stringUtils import isNotBlank, isBlank, isInt, intDefaultNone
from lambdas.exceptions import LambdaValidationException
from lambdas.retrieveadmindata.submitterTeamsMapper import mapSubmitterTeamQueryResultToSchema
from lambdas.retrieveadmindata.batchDetailDataMapper import mapBatchDetailResultToSchema
from lambdas.retrieveadmindata.teamMemberMapper import mapTeamQueryResultToSchema
from lambdas.updateadmindata.rschRefDataMapper import mapRschRefDataQueryResultToSchema
from common import updateEventConstants 
from common.batchStatusCodes import BatchStatusCode
from common.batchPriorityCodes import BatchPriorityCode
from common.batchType import BatchType
from common.updateActionCodes import UpdateActionCode
from common.usageRecordTypeCodes import UsageTypeCode
from lambdas.exceptions import LambdaAuthorizationException, LambdaConflictException
from common.util.notificationHelper import NotificationHelper
from common.util.requestNotificationHelper import RequestNotificationHelper
from common.util.sqsHelper import SqsHelper
import common.envVblNames as envVblNames
from common.notificationTypeCodes import NotificationTypeCode
from common.researchRefDataTypeCode import ResearchRefDataTypeCode
from common.dao.apiApplicationEntitlementDao import ApiApplicationEntitlementDao
from lambdas.attachment.requestAttachmentLinkService import RequestAttachmentLinkService
from lambdas.updateadmindata.trainingMediaTransformationService import TrainingMediaTransformationService
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from databaseClass import databaseClass
from lambdas.updateadmindata.usageRecordMessage import createUsageRecordMessage
from lambdas.updateadmindata.cfpBatchAdminService import CfpBatchAdminService
from lambdas.updateadmindata.statusChangeService import StatusChangeService
from common.irschRoles import IResearchRole
from common.irschAdministeredRoles import IResearchAdministeredRole
from common.submitToRemoteAppTypeCode import SubmitToRemoteAppTypeCode

class Service(object):
    APP_MODULE_NM = "UpdateAdminData"
    
    apiEntlDao = None
    dao = None
    eventDao = None
    notificationHelper = None
    requestAttachmentLinkService = None
    requestNotificationHelper = None
    researchRequestDao = None
    retrieveAdminDataDao = None
    scotsDao = None
    scots_dict = None
    trainingMediaTransformationService = None
    trainingMediaValidationService = None
    userDao = None
    cfpResponseGeneratorSqsHelper = None
    cfpBatchAdminService = None
    statusChangeService = None
    submitToRemoteAppSQSHelper = None
    
    ERROR_TYPE = "errorType"
    ERROR_MESSAGE = "errorMessage"
    RESULT_BODY = "responseBody"
    RESULT_ERR_MSG = "errmsg"
    RESULT_ERR_RESPONSE = "errorResponse"
    RESULT_STATUS_CODE = "statusCode"
    
    
    def __init__(self, dbConn, s3handleForAttachments=None):
        self.dbConn = dbConn
        self.dbObj = None
        self.s3handleForAttachments = s3handleForAttachments
        if not Service.apiEntlDao:
            Service.apiEntlDao = ApiApplicationEntitlementDao()
        if not Service.dao:
            Service.dao = UpdateAdminDataDao()
        if not Service.eventDao:
            Service.eventDao = UpdateEventDao()
        if not Service.researchRequestDao:
            Service.researchRequestDao = ResearchRequestDao()
        if not Service.retrieveAdminDataDao:
            Service.retrieveAdminDataDao = RetrieveAdminDataDao()
        if not Service.scotsDao:
            Service.scotsDao = ScotsDao()
        if not Service.scots_dict:
            Service.scots_dict = Service.scotsDao.queryTypeCodesToDescriptions(self.dbConn)
        if not Service.userDao:
            Service.userDao = ResearchUserDao()
        if Service.cfpBatchAdminService is None:
            Service.cfpBatchAdminService = CfpBatchAdminService(dbConn, s3handleForAttachments, Service.eventDao)
        if Service.statusChangeService is None:
            Service.statusChangeService = StatusChangeService(dbConn, Service.scots_dict)
        

    def addSubmitterGroup(self, requestContext):
        newSubmitterGroup = requestContext.incomingContent.get('newSubmissionGroupName', None)
        if newSubmitterGroup is not None and newSubmitterGroup.strip():
            #Check if group already exists
            submitterGroupsFromDB = Service.dao.getSubmitterGroupByName(self.dbConn, newSubmitterGroup.strip().lower())
            if len(submitterGroupsFromDB) == 0:
                rowInserted = Service.dao.addSubmitterGroup(self.dbConn, newSubmitterGroup)
                logging.info('Row Id inserted: ' + str(rowInserted))
                Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.AUDIT_SUBMITTER_GROUP_TABLE, rowInserted, 
                                             updateEventConstants.AUDIT_ELEMENT_SUBMITTER_GROUP_ID, newSubmitterGroup, None,
                                             UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            else:
                raise LambdaValidationException(errmsg.ERR_SUBMITTER_GROUP_EXISTS)
        else:
            raise LambdaValidationException(errmsg.ERR_NEW_SUBMITTER_GROUP_EMPTY)
        
        return rowInserted
    
    def updateSubmitterGroup(self, requestContext):
        submitterTeamId = requestContext.incomingContent.get('submitterTeam').get('submissionGroupId')
        usersFromUI = requestContext.incomingContent.get('submitterTeam').get('users')
        if usersFromUI is None:
            usersFromUI = []
        modifiedTimestamp = requestContext.incomingContent.get('submitterTeam').get('modifiedTimestamp')
        
        if submitterTeamId is not None:
            qryResult = Service.dao.getSubmitterGroupById(self.dbConn, submitterTeamId)
            mappedTeam = mapSubmitterTeamQueryResultToSchema(qryResult)
            if len(mappedTeam.get('submitterTeams')) == 1:
                if modifiedTimestamp is None:
                    raise LambdaValidationException(errmsg.ERR_SUBMITTER_GROUP_TIMESTAMP_MISSING)    
                usersToAdd = set()
                usersToDelete = set()
                team = mappedTeam.get('submitterTeams')[0]
                if team.get('submitterTeam').get('modifiedTimestamp') != modifiedTimestamp:
                    raise LambdaValidationException(errmsg.ERR_SUBMITTER_GROUP_NEEDS_REFRESH)                        
                teamMembers = team.get('teamMembers')
                usersFromDB = self._getUsersFromTeamMembers(teamMembers)
                for user in usersFromUI: 
                    if user not in usersFromDB:
                        usersToAdd.add(user)
                for user in usersFromDB:
                    if user not in usersFromUI:
                        usersToDelete.add(user)
                if len(usersToAdd) > 0 or len(usersToDelete) > 0:
                    Service.dao.updateSubmitterGroup(self.dbConn, submitterTeamId, usersToAdd, usersToDelete)
                logging.info("added users: {}".format(usersToAdd))
                logging.info("removed users: {}".format(usersToDelete))
                for user in usersToAdd:            
                    #Note: using submitter team id instead of row id     
                    Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.AUDIT_SUBMITTER_GROUP_MEMBER_TABLE, int(submitterTeamId), 
                                             updateEventConstants.AUDIT_ELEMENT_SUBMITTER_GROUP_MEMBER_ID, str(user), None,
                                             UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
                for user in usersToDelete: 
                    #Note: using submitter team id instead of row id               
                    Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.AUDIT_SUBMITTER_GROUP_MEMBER_TABLE, int(submitterTeamId), 
                                             updateEventConstants.AUDIT_ELEMENT_SUBMITTER_GROUP_MEMBER_ID, str(user), None,
                                             UpdateActionCode.DELETE.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            else: 
                raise LambdaValidationException(errmsg.ERR_SUBMITTER_GROUP_NOT_EXIST)
        else:
            raise LambdaValidationException(errmsg.ERR_SUBMITTER_GROUP_ID_MISSING)
    
    def updateResearchTeam(self, requestContext, administerLocalAdmin):
        researcherTeamId = requestContext.incomingContent.get('researchTeam').get('researchTeamId')
        usersFromUI = requestContext.incomingContent.get('researchTeam').get('users')
        if usersFromUI is None:
            usersFromUI = []
        modifiedTimestamp = requestContext.incomingContent.get('researchTeam').get('modifiedTimestamp')
        
        if researcherTeamId is not None:
            qryResult = Service.dao.getResearchTeamById(self.dbConn, researcherTeamId, administerLocalAdmin)
            mappedTeam = mapTeamQueryResultToSchema(qryResult, 'teams')
            if len(mappedTeam.get('teams')) == 1:
                if modifiedTimestamp is None:
                    raise LambdaValidationException(errmsg.ERR_RESEARCH_TEAM_TIMESTAMP_MISSING)    
                usersToAdd = set()
                usersToDelete = set()
                team = mappedTeam.get('teams')[0]
                self._checkIfAuthorized(requestContext, administerLocalAdmin, team)
                if team.get('researchTeam').get('modifiedTimestamp') != modifiedTimestamp:
                    raise LambdaValidationException(errmsg.ERR_RESEARCH_TEAM_NEEDS_REFRESH)                        
                teamMembers = team.get('teamMembers')
                usersFromDB = self._getUsersFromTeamMembers(teamMembers)
                for user in usersFromUI: 
                    if user not in usersFromDB:
                        usersToAdd.add(user)
                for user in usersFromDB:
                    if user not in usersFromUI:
                        usersToDelete.add(user)
                if len(usersToAdd) > 0 or len(usersToDelete) > 0:
                    Service.dao.updateResearchTeam(self.dbConn, researcherTeamId, usersToAdd, usersToDelete, administerLocalAdmin)
                logging.info("added users: {}".format(usersToAdd))
                logging.info("removed users: {}".format(usersToDelete))
                for user in usersToAdd:            
                    #Note: using researcher team id instead of row id     
                    Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.AUDIT_TEAM_MEMBER_TABLE, int(researcherTeamId), 
                                             updateEventConstants.AUDIT_ELEMENT_RESEARCH_TEAM_MEMBER_ID, str(user), None,
                                             UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
                for user in usersToDelete: 
                    #Note: using researcher team id instead of row id               
                    Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.AUDIT_TEAM_MEMBER_TABLE, int(researcherTeamId), 
                                             updateEventConstants.AUDIT_ELEMENT_RESEARCH_TEAM_MEMBER_ID, str(user), None,
                                             UpdateActionCode.DELETE.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            else: 
                raise LambdaValidationException(errmsg.ERR_RESEARCH_TEAM_NOT_EXIST)
        else:
            raise LambdaValidationException(errmsg.ERR_RESEARCH_TEAM_ID_MISSING)

    def updateUserAdminData(self, requestContext):
        researchUserId = requestContext.incomingContent.get('researchAdminUser').get('researchUserId')
        modifiedTimestamp = requestContext.incomingContent.get('researchAdminUser').get('modifiedTimestamp')
        userAdminJson = requestContext.incomingContent.get('researchAdminUser').get('userAdministration')
        
        if not researchUserId:
            raise LambdaValidationException(errmsg.ERR_USER_ID_MISSING)
        if not modifiedTimestamp:
            raise LambdaValidationException(errmsg.ERR_TIMESTAMP_MISSING)
        if not userAdminJson:
            raise LambdaValidationException(errmsg.ERR_ADMIN_JSON_MISSING)

        qryResult = Service.userDao.getresearchAdminUser(self.dbConn, researchUserId)
        if not qryResult:
            raise LambdaValidationException(errmsg.ERR_USER_NOT_EXIST)
        else:
            if qryResult.get('timestamp') != modifiedTimestamp:
                raise LambdaValidationException(errmsg.ERR_USER_ADMIN_DATA_NEEDS_REFRESH)   
            Service.userDao.updateResearchUser(self.dbConn, researchUserId, json.dumps(userAdminJson), "UpdateAdminData")              
            logging.info("Updated user: " + str(researchUserId))
            Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.AUDIT_RESEARCH_USER_TABLE, int(researchUserId), 
                                             updateEventConstants.AUDIT_ELEMENT_RESEARCH_USER_ADMIN_OBJ, None, None,
                                             UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            # If an API user, expire any active sessions
            userEmailAddr = qryResult.get('usr_eml_adr')
            loginKey = qryResult.get('lgin_key')
            if isBlank(userEmailAddr):
                logging.info(f"Updated API user {loginKey} so expiring active sessions")
                Service.userDao.expireActiveSessionsForUser(self.dbConn, researchUserId)
                
            self._addUserOrganization(userAdminJson.get('userOrganizationName', None), requestContext)


    def addUser(self, requestContext):
        loginKey = requestContext.incomingContent.get('loginKey', None)
        userEmailAddress = requestContext.incomingContent.get('userEmailAddress', None)
        if loginKey is None and userEmailAddress is None:
            raise LambdaValidationException(errmsg.ERR_ADD_USER_PARAM_MISSING)
        if loginKey is None:
            loginKey = userEmailAddress
        newUserId = Service.dao.addUser(self.dbConn, loginKey, userEmailAddress, Service.APP_MODULE_NM)
        if newUserId is None:
            raise LambdaValidationException(errmsg.ERR_USER_EXISTS)

        logging.info(f'New rsch_usr_id inserted: {newUserId}')
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                         updateEventConstants.AUDIT_RESEARCH_USER_TABLE, newUserId, 
                                         updateEventConstants.AUDIT_ELEMENT_LOGIN_KEY, loginKey, None,
                                         UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                         None, Service.APP_MODULE_NM)
        
        return newUserId
    
    def approveBatch(self, requestContext, sqsHelper):
        campaignPriority = requestContext.incomingContent.get('campaignPriority', None)
        batchRequestId = requestContext.incomingContent.get('batchRequestId', None)
        if batchRequestId is None:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_BATCH_REQUEST_ID)

        batchDueTimestamp = requestContext.incomingContent.get('batchDueTimestamp', None)
        if batchDueTimestamp is None:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_DUE_DATE_MISSING)
        lookupRule = requestContext.incomingContent.get('lookupRule', None)
        qryResult = Service.retrieveAdminDataDao.getBatchDetails(self.dbConn, batchRequestId)
        batchDetails = mapBatchDetailResultToSchema(qryResult)
        
        if not batchDetails.get('batchDetailData').get('batchRequestId'):
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_NO_SUCH_BATCH)
        if batchDetails.get('batchDetailData').get('batchType') == BatchType.CAMPAIGN_BATCH.name:
            if campaignPriority is None:
                raise LambdaValidationException(errmsg.ERR_BATCH_CAMPAIGN_PRIORITY_MISSING)
            elif campaignPriority != BatchPriorityCode.HIGH.value and campaignPriority != BatchPriorityCode.MEDIUM.value and campaignPriority != BatchPriorityCode.LOW.value:
                raise LambdaValidationException(errmsg.ERR_BATCH_CAMPAIGN_PRIORITY_INCORRECT_CODE)
        elif batchDetails.get('batchDetailData').get('batchType') != BatchType.CAMPAIGN_BATCH.name:
            if campaignPriority is not None:
                raise LambdaValidationException(errmsg.ERR_BATCH_CAMPAIGN_PRIORITY_PARAM_NOT_VALID)
        if lookupRule is not None and not BatchType.isCfpBatch(batchDetails.get('batchDetailData').get('batchType')):
            raise LambdaValidationException(errmsg.ERR_BATCH_LOOKUP_RULE_PARAM_NOT_VALID)
   
        batchStatusCode = batchDetails.get('batchDetailData').get('batchStatusCode')
        
        if not batchStatusCode or batchStatusCode != BatchStatusCode.PENDING_APPROVAL.value:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_INCORRECT_STATUS)  
                  
        batchReqsObj = self._updateBatchRequestObj(qryResult, lookupRule)

        Service.dao.updateBatchStatusForApprove(self.dbConn, batchRequestId, BatchStatusCode.APPROVED.value, batchDueTimestamp, campaignPriority, batchReqsObj)
        self._sendMessageToQueue(batchRequestId, sqsHelper, batchReqsObj)
        
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                    updateEventConstants.AUDIT_BATCH_REQUEST_TABLE, batchRequestId, 
                                    updateEventConstants.AUDIT_ELEMENT_BATCH_STATUS, BatchStatusCode.APPROVED.value, BatchStatusCode.APPROVED.value,
                                    UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                    None, Service.APP_MODULE_NM)

    
    def rejectBatch(self, requestContext, snsClient):
        batchRequestId = requestContext.incomingContent.get('batchRequestId', None)
        batchRejectReasonComment = requestContext.incomingContent.get('batchRejectReasonComment')
        if batchRequestId is None:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_BATCH_REQUEST_ID)
        
        qryResult = Service.retrieveAdminDataDao.getBatchDetails(self.dbConn, batchRequestId)
        batchDetails = mapBatchDetailResultToSchema(qryResult)
        logging.info(f"rejectBatch: batchDetails={batchDetails}")
        
        if not batchDetails.get('batchDetailData').get('batchRequestId'):
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_NO_SUCH_BATCH)
            
        batchStatusCode = batchDetails.get('batchDetailData').get('batchStatusCode')
        
        if not batchStatusCode or batchStatusCode != BatchStatusCode.PENDING_APPROVAL.value:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_INCORRECT_STATUS)  
                  
        Service.dao.rejectBatch(self.dbConn, batchRequestId, errmsg.ERR_BATCH_ADMIN_REJECTED, batchRejectReasonComment)
        
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                     updateEventConstants.AUDIT_BATCH_REQUEST_TABLE, batchRequestId, 
                                     updateEventConstants.AUDIT_ELEMENT_BATCH_STATUS, BatchStatusCode.APPROVER_REJECTED.value, BatchStatusCode.APPROVER_REJECTED.value,
                                     UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                     None, Service.APP_MODULE_NM)

        if BatchType.isCfpBatch(batchDetails.get('batchDetailData').get('batchType')):
            self._notifyCfpResponse(requestContext, batchRequestId)
        else:
            self._sendNotification(requestContext, batchRequestId, snsClient)


    def updateBatchDueDate(self, requestContext):
        batchRequestId = requestContext.incomingContent.get('batchRequestId', None)
        if batchRequestId is None:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_BATCH_REQUEST_ID)

        batchDueTimestamp = requestContext.incomingContent.get('batchDueTimestamp', None)
        if batchDueTimestamp is None:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_DUE_DATE_MISSING)
        
        qryResult = Service.retrieveAdminDataDao.getBatchDetails(self.dbConn, batchRequestId)
        batchDetails = mapBatchDetailResultToSchema(qryResult)
        
        if not batchDetails.get('batchDetailData').get('batchRequestId'):
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_NO_SUCH_BATCH)
            
        batchStatusCode = batchDetails.get('batchDetailData').get('batchStatusCode')
        
        if not batchStatusCode or batchStatusCode != BatchStatusCode.SUBMITTED.value:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_INCORRECT_STATUS)  
                  
        Service.dao.updateBatchDueDate(self.dbConn, batchRequestId, batchDueTimestamp)
        
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                    updateEventConstants.AUDIT_BATCH_REQUEST_TABLE, batchRequestId, 
                                    updateEventConstants.AUDIT_ELEMENT_BATCH_DUE_DATE, batchDueTimestamp, None,
                                    UpdateActionCode.MODIFY.value, batchStatusCode, requestContext.userSession.sessionToken,
                                    None, Service.APP_MODULE_NM)
    
        if batchDetails.get('batchDetailData').get('batchType') == BatchType.CFP_LOOKUP_INV_BATCH.value:
            self._sendMessageToSubmitToRemoteApp(requestContext, batchRequestId, SubmitToRemoteAppTypeCode.HANDLE_BATCH_AFTER_UPDATE_DUE_DATE.value)

    def _sendMessageToQueue(self, batchRequestId, sqsHelper, batchReqsObj):
        msg = {}
        msg["batchRequestId"] = batchRequestId
        msg["source"] = Service.APP_MODULE_NM
        msgJsonStr = json.dumps(msg)
        logging.info("Message sent to submitCaseBatchSubmitter queue %s", msgJsonStr)
        try:
            queueResp = sqsHelper.sendMessageToQueue(msgJsonStr)
            messageId = queueResp.get('MessageId')
            logging.info("message id is: %s", messageId)
        except:
            Service.dao.updateBatchStatusForApprove(self.dbConn, batchRequestId, BatchStatusCode.PENDING_APPROVAL.value, None, None, batchReqsObj)
            logging.info("Failed to send message to submitCaseBatchSubmitter queue for batch %s", batchRequestId)
            raise Exception("Failed to send message to submitCaseBatchSubmitter queue for batch " + str(batchRequestId))
        
        
    def _getUsersFromTeamMembers(self, teamMembers):
        users = []
        for member in teamMembers:
            userid = member.get('researchUser').get('researchUserId')
            users.append(userid)
        return users
        
    def _checkIfAuthorized (self, requestContext, administerLocalAdmin, team):
        if administerLocalAdmin == False: 
            #administering researchers so check if this user is authorized to update this team
            teamName = team.get('researchTeam').get('researchTeamName') 
            if teamName not in requestContext.userSession.localAdminTeams:
                raise LambdaAuthorizationException(errmsg.ERR_USER_NOT_AUTHORIZED_TO_UPDATE_TEAM)  


    def _sendNotification(self, requestContext, batchRequestId, snsClient):
        if not Service.notificationHelper:
            # SNS message to Notification service
            notificationTopicARN = requestContext.environDict.get(envVblNames.ENV_NOTIFICATION_TOPIC_ARN)
            Service.notificationHelper = NotificationHelper(snsClient, notificationTopicARN)
        Service.notificationHelper.triggerClientNotification(NotificationTypeCode.BATCH_REJECTED_BY_ADMIN.value, batchRequestId=batchRequestId)
        
        
    def addTeamGroup(self, requestContext):
        newTeamGroupName = requestContext.incomingContent.get('newTeamGroupName', None)
        if newTeamGroupName is not None and newTeamGroupName.strip():
            #Check if group already exists
            teamGroupsFromDB = Service.dao.getRschRefDataByNameAndType(self.dbConn, newTeamGroupName.strip().lower(), ResearchRefDataTypeCode.TEAM_GROUP.value)
            if len(teamGroupsFromDB) == 0:
                rowInserted = Service.dao.addRschRefDataEntry(self.dbConn, newTeamGroupName.strip(), ResearchRefDataTypeCode.TEAM_GROUP.value)
                logging.info('Row Id inserted: ' + str(rowInserted))
                Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.RSCH_REF_DATA_TABLE, rowInserted, 
                                             updateEventConstants.AUDIT_ELEMENT_RSCH_REF_DATA_ID, newTeamGroupName + ' ' + str(ResearchRefDataTypeCode.TEAM_GROUP.value), None,
                                             UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            else:
                raise LambdaValidationException(errmsg.ERR_TEAM_GROUP_EXISTS)
        else:
            raise LambdaValidationException(errmsg.ERR_NEW_TEAM_GROUP_EMPTY)
        
        return rowInserted
    
    def updateTeamGroup(self, requestContext):
        teamGroupId = requestContext.incomingContent.get('teamGroup').get('teamGroupId')
        teamsFromUI = requestContext.incomingContent.get('teamGroup').get('researchTeamIds')
        if teamsFromUI is None:
            teamsFromUI = []
        elif all(isinstance(x, int) for x in teamsFromUI) == False:
            raise LambdaValidationException(errmsg.ERR_TEAM_GROUP_REQUIRE_INTEGER)
        modifiedTimestamp = requestContext.incomingContent.get('teamGroup').get('modifiedTimestamp')
        
        if teamGroupId is not None:
            qryResult = Service.dao.getRschRefDataById(self.dbConn, teamGroupId)
            mappedGroup = mapRschRefDataQueryResultToSchema(qryResult)
            if len(mappedGroup.get('rschRefData')) == 1:
                if modifiedTimestamp is None:
                    raise LambdaValidationException(errmsg.ERR_TEAM_GROUP_TIMESTAMP_MISSING)    
                teamsToAdd = set()
                teamsToDelete = set()
                group = mappedGroup.get('rschRefData')[0]
                if group.get('refData').get('modifiedTimestamp') != modifiedTimestamp:
                    raise LambdaValidationException(errmsg.ERR_TEAM_GROUP_NEEDS_REFRESH)                        
                teamList = group.get('children')
                teamsFromDB = self._getTeamIdsFromTeamList(teamList)
                for team in teamsFromUI: 
                    if team not in teamsFromDB:
                        teamsToAdd.add(team)
                for team in teamsFromDB:
                    if team not in teamsFromUI:
                        teamsToDelete.add(team)
                if len(teamsToAdd) > 0 or len(teamsToDelete) > 0:
                    Service.dao.updateRschRefData(self.dbConn, teamGroupId, teamsToAdd, teamsToDelete)
                logging.info("added teams: {}".format(teamsToAdd))
                logging.info("removed teams: {}".format(teamsToDelete))
                for team in teamsToAdd:            
                    #Note: using team group id instead of row id     
                    Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.RSCH_REF_DATA_CHILD_TABLE, int(teamGroupId), 
                                             updateEventConstants.AUDIT_ELEMENT_RSCH_REF_DATA_CHILD_ID, str(team), None,
                                             UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
                for team in teamsToDelete: 
                    #Note: using team group id instead of row id               
                    Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.RSCH_REF_DATA_CHILD_TABLE, int(teamGroupId), 
                                             updateEventConstants.AUDIT_ELEMENT_RSCH_REF_DATA_CHILD_ID, str(team), None,
                                             UpdateActionCode.DELETE.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            else: 
                raise LambdaValidationException(errmsg.ERR_TEAM_GROUP_NOT_EXIST)
        else:
            raise LambdaValidationException(errmsg.ERR_TEAM_GROUP_ID_MISSING)

    def _getTeamIdsFromTeamList(self, teamList):
        teams = []
        for team in teamList:
            teamId = int(team.get('childValue'))
            teams.append(teamId)
        return teams
    
    def addCountryGroup(self, requestContext):
        newCountryGroupName = requestContext.incomingContent.get('newCountryGroupName', None)
        if newCountryGroupName is not None and newCountryGroupName.strip():
            #Check if group already exists
            countryGroupsFromDB = Service.dao.getRschRefDataByNameAndType(self.dbConn, newCountryGroupName.strip().lower(), ResearchRefDataTypeCode.COUNTRY_GROUP.value)
            if len(countryGroupsFromDB) == 0:
                rowInserted = Service.dao.addRschRefDataEntry(self.dbConn, newCountryGroupName.strip(), ResearchRefDataTypeCode.COUNTRY_GROUP.value)
                logging.info('Row Id inserted: ' + str(rowInserted))
                Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.RSCH_REF_DATA_TABLE, rowInserted, 
                                             updateEventConstants.AUDIT_ELEMENT_RSCH_REF_DATA_ID, newCountryGroupName + ' ' + str(ResearchRefDataTypeCode.COUNTRY_GROUP.value), None,
                                             UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            else:
                raise LambdaValidationException(errmsg.ERR_COUNTRY_GROUP_EXISTS)
        else:
            raise LambdaValidationException(errmsg.ERR_NEW_COUNTRY_GROUP_EMPTY)
        
        return rowInserted
    
    def updateCountryGroup(self, requestContext):
        countryGroupId = requestContext.incomingContent.get('countryGroup').get('countryGroupId')
        countryListFromUI = requestContext.incomingContent.get('countryGroup').get('countryCodes')
        if countryListFromUI is None:
            countryListFromUI = []
        elif all((isinstance(x, str) and x.isalpha() and len(x) == 2) for x in countryListFromUI) == False:
            raise LambdaValidationException(errmsg.ERR_COUNTRY_GROUP_REQUIRE_STRING)
        countryListFromUI = [x.upper() for x in countryListFromUI]
        modifiedTimestamp = requestContext.incomingContent.get('countryGroup').get('modifiedTimestamp')
        
        if countryGroupId is not None:
            qryResult = Service.dao.getRschRefDataById(self.dbConn, countryGroupId)
            mappedGroup = mapRschRefDataQueryResultToSchema(qryResult)
            if len(mappedGroup.get('rschRefData')) == 1:
                if modifiedTimestamp is None:
                    raise LambdaValidationException(errmsg.ERR_COUNTRY_GROUP_TIMESTAMP_MISSING)    
                countriesToAdd = set()
                countiresToDelete = set()
                group = mappedGroup.get('rschRefData')[0]
                if group.get('refData').get('modifiedTimestamp') != modifiedTimestamp:
                    raise LambdaValidationException(errmsg.ERR_COUNTRY_GROUP_NEEDS_REFRESH)                        
                countryList = group.get('children')
                countryListFromDB = self._getCountryCodeListFromCountries(countryList)
                for country in countryListFromUI: 
                    if country.upper() not in countryListFromDB:
                        countriesToAdd.add(country.upper())
                for country in countryListFromDB:
                    if country.upper() not in countryListFromUI:
                        countiresToDelete.add(country.upper())
                if len(countriesToAdd) > 0 or len(countiresToDelete) > 0:
                    Service.dao.updateRschRefData(self.dbConn, countryGroupId, countriesToAdd, countiresToDelete)
                logging.info("added countries: {}".format(countriesToAdd))
                logging.info("removed countries: {}".format(countiresToDelete))
                for country in countriesToAdd:            
                    #Note: using country group id instead of row id     
                    Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.RSCH_REF_DATA_CHILD_TABLE, int(countryGroupId), 
                                             updateEventConstants.AUDIT_ELEMENT_RSCH_REF_DATA_CHILD_ID, country, None,
                                             UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
                for country in countiresToDelete: 
                    #Note: using country group id instead of row id               
                    Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.RSCH_REF_DATA_CHILD_TABLE, int(countryGroupId), 
                                             updateEventConstants.AUDIT_ELEMENT_RSCH_REF_DATA_CHILD_ID, country, None,
                                             UpdateActionCode.DELETE.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            else: 
                raise LambdaValidationException(errmsg.ERR_COUNTRY_GROUP_NOT_EXIST)
        else:
            raise LambdaValidationException(errmsg.ERR_COUNTRY_GROUP_ID_MISSING)
        
    def _getCountryCodeListFromCountries(self, countries):
        CountryCodeList = []
        for country in countries:
            countryCode = country.get('childValue')
            CountryCodeList.append(countryCode)
        return CountryCodeList
    
    def _addUserOrganization(self, userOrg, requestContext):
        if userOrg is not None and userOrg.strip():
            #Check if userOrg already exists
            userOrgFromDB = Service.dao.getRschRefDataByNameAndType(self.dbConn, userOrg.strip().lower(), ResearchRefDataTypeCode.USER_ORGANIZATION.value)
            if len(userOrgFromDB) == 0:
                rowInserted = Service.dao.addRschRefDataEntry(self.dbConn, userOrg.strip(), ResearchRefDataTypeCode.USER_ORGANIZATION.value)
                logging.info('Row Id inserted: ' + str(rowInserted))
                Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.RSCH_REF_DATA_TABLE, rowInserted, 
                                             updateEventConstants.AUDIT_ELEMENT_RSCH_REF_DATA_ID, userOrg + ' ' + str(ResearchRefDataTypeCode.USER_ORGANIZATION.value), None,
                                             UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
            else:
                logging.info('User organization already exists. User org: %s' % userOrg)
        else:
            logging.info('No user organization to add')
            
    def updateApiAppEntitlement(self, requestContext):
        apiAppEntlId = requestContext.incomingContent.get('apiAppEntitlement').get('apiAppEntlId')
        modifiedTimestamp = requestContext.incomingContent.get('apiAppEntitlement').get('modifiedTimestamp')
        prcsOptnsObj = requestContext.incomingContent.get('apiAppEntitlement').get('prcsOptnsObj')
        partnerFolderName = requestContext.incomingContent.get('apiAppEntitlement').get('partnerFolderName')
                
        if not apiAppEntlId:
            raise LambdaValidationException(errmsg.ERR_API_APP_ENTITLEMENT_ID_MISSING)
        if not modifiedTimestamp:
            raise LambdaValidationException(errmsg.ERR_API_APP_ENTITLEMENT_TIMESTAMP_MISSING)
        if not prcsOptnsObj:
            raise LambdaValidationException(errmsg.ERR_API_APP_ENTITLEMENT_PROCESS_OPTIONS_OBJ_MISSING)
        if partnerFolderName is None:
            raise LambdaValidationException(errmsg.ERR_API_APP_ENTITLEMENT_PARTNER_FOLDER_MISSING)
        
        qryResultForExistingPartnerFolderName = Service.apiEntlDao.queryApiAppForExistingPartnerFolderName(self.dbConn, partnerFolderName)
        if len(qryResultForExistingPartnerFolderName) > 0:
            if apiAppEntlId != qryResultForExistingPartnerFolderName[0].get('api_app_entl_id'):
                logging.info("PartnerFolderName is not unique.")
                raise LambdaValidationException(errmsg.ERR_API_APP_ENTITLEMENT_PARTNER_FOLDER_NOT_UNIQUE)
            else:
                logging.info("PartnerFolderName is unique.")
        
        qryResult = Service.apiEntlDao.queryApiAppUsingApiAppEntlId(self.dbConn, apiAppEntlId)
        if not qryResult:
            raise LambdaValidationException(errmsg.ERR_API_APP_ENTITLEMENT_NOT_EXIST)
        else:
            if qryResult.get('mod_timestamp') != modifiedTimestamp:
                raise LambdaValidationException(errmsg.ERR_API_APP_ENTITLEMENT_NEEDS_REFRESH)   
            Service.dao.updateApiApplication(self.dbConn, apiAppEntlId, partnerFolderName, json.dumps(prcsOptnsObj), "UpdateAdminData")              
            logging.info("Updated Api App Entl: " + str(apiAppEntlId))
            Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                             updateEventConstants.API_APP_ENTITLEMENT_TABLE, apiAppEntlId, 
                                             updateEventConstants.AUDIT_ELEMENT_API_APP_ENTITLEMENT_ID, None, None,
                                             UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                             None, Service.APP_MODULE_NM)
    
    
    def addTrainingMedia(self, requestContext):
        mediaType = requestContext.incomingContent.get('trainingMediaRecord').get('mediaType', None)
        mediaTitle = requestContext.incomingContent.get('trainingMediaRecord').get('mediaTitle', None)
        mediaDescription = requestContext.incomingContent.get('trainingMediaRecord').get('mediaDescription', None)
        mediaCategory = requestContext.incomingContent.get('trainingMediaRecord').get('mediaCategory', None)
        mediaFileName = requestContext.incomingContent.get('trainingMediaRecord').get('mediaFileName', None)
        mediaOrderNumber = requestContext.incomingContent.get('trainingMediaRecord').get('mediaOrderNumber', None)
        mediaKeywords = requestContext.incomingContent.get('trainingMediaRecord').get('mediaKeywords', None)
        attachmentKey = None
        attmId = None
        
        if mediaFileName is None:
            raise LambdaValidationException(errmsg.ERR_MEDIA_FILE_NAME)
        else:
            #instantiate dependent services
            self._createAttachmentServices(requestContext)
        
        #def transformAttachmentRequests()
        attmObj = Service.trainingMediaTransformationService.addAttachment(mediaFileName)
        
        #processMediaAttachmentRequestImpl - this is new service
        attachmentResultDict = self._processAttachmentRequests(requestContext, attmObj)
        statusCode = attachmentResultDict[Service.RESULT_STATUS_CODE]
        apiResponse = {}
        if statusCode == LambdaStatusCodes.OK.value or statusCode == LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
            attachmentResponse = Service.trainingMediaTransformationService.transformAttachmentResponses(attmObj)
            if len(attachmentResponse) > 0:
                apiResponse[updateEventConstants.API_RESP_ATTACHMENT] = attachmentResponse
                attachmentKey = attachmentResponse.get(updateEventConstants.API_RESP_ATTACHMENT_FIELDS).get(updateEventConstants.API_RESP_KEY, None)
                attachmentKey = attachmentKey[20:]
                attmId = Service.dao.getAttachmentId(self.dbConn, attachmentKey, constants.MEDIA_ATTACHMENT_FOLDER)
                logging.info(f'training media attachment id = {attmId}')

        if mediaType is None:
            raise LambdaValidationException(errmsg.ERR_MEDIA_TYPE)
        if mediaTitle is None:
            raise LambdaValidationException(errmsg.ERR_MEDIA_TITLE)
        if mediaCategory is None:
            raise LambdaValidationException(errmsg.ERR_MEDIA_CATEGORY)

        rowInserted = Service.dao.addTrainingMedia(self.dbConn, mediaType, mediaTitle, mediaDescription, mediaCategory, mediaOrderNumber, mediaKeywords, attmId)
        logging.info('Row Id inserted: ' + str(rowInserted))
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                     updateEventConstants.AUDIT_TRAINING_MEDIA_TABLE, rowInserted, 
                                     updateEventConstants.AUDIT_ELEMENT_TRAINING_MEDIA_ID, mediaTitle, None,
                                     UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                     None, 'irschappwrite')

        return apiResponse

        
    def updateTrainingMedia(self, requestContext):
        trainingMediaId = requestContext.incomingContent.get('trainingMediaRecord').get('trainingMediaId', None)
        mediaType = requestContext.incomingContent.get('trainingMediaRecord').get('mediaType', None)
        mediaTitle = requestContext.incomingContent.get('trainingMediaRecord').get('mediaTitle', None)
        mediaDescription = requestContext.incomingContent.get('trainingMediaRecord').get('mediaDescription', None)
        mediaCategory = requestContext.incomingContent.get('trainingMediaRecord').get('mediaCategory', None)
        mediaFileName = requestContext.incomingContent.get('trainingMediaRecord').get('mediaFileName', None)
        mediaOrderNumber = requestContext.incomingContent.get('trainingMediaRecord').get('mediaOrderNumber', None)
        mediaKeywords = requestContext.incomingContent.get('trainingMediaRecord').get('mediaKeywords', None)
        attachmentKey = None
        apiResponse = None
        
        if trainingMediaId is None:
            raise LambdaValidationException(errmsg.ERR_TRAINING_MEDIA_ID)
        if mediaFileName is not None:
            self._createAttachmentServices(requestContext)
            #def transformAttachmentRequests()
            attmObj = Service.trainingMediaTransformationService.addAttachment(mediaFileName)
            
            #processMediaAttachmentRequestImpl - this is new service
            attachmentResultDict = self._processAttachmentRequests(requestContext, attmObj)
            statusCode = attachmentResultDict[Service.RESULT_STATUS_CODE]
            apiResponse = {}
            if statusCode == LambdaStatusCodes.OK.value or statusCode == LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
                attachmentResponse = Service.trainingMediaTransformationService.transformAttachmentResponses(attmObj)
                if len(attachmentResponse) > 0:
                    apiResponse[updateEventConstants.API_RESP_ATTACHMENT] = attachmentResponse
                    attachmentKey = attachmentResponse.get(updateEventConstants.API_RESP_ATTACHMENT_FIELDS).get(updateEventConstants.API_RESP_KEY, None)
                    attachmentKey = attachmentKey[20:]
                    attmId = Service.dao.getAttachmentId(self.dbConn, attachmentKey, constants.MEDIA_ATTACHMENT_FOLDER)
                    logging.info(f'training media attachment id = {attmId}')
        elif mediaFileName is None:
            attmId = None

        Service.dao.updateTrainingMedia(self.dbConn, trainingMediaId, mediaType, mediaTitle, mediaDescription, mediaCategory, mediaOrderNumber, mediaKeywords, attmId)
        logging.info('Row Id udpated:' + str(trainingMediaId))
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                     updateEventConstants.AUDIT_TRAINING_MEDIA_TABLE, str(trainingMediaId), 
                                     updateEventConstants.AUDIT_ELEMENT_TRAINING_MEDIA_ID, mediaTitle, None,
                                     UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                     None, 'irschappwrite')
        
        if apiResponse is not None:
            return apiResponse
        else:
            return {}
            
    
    def deleteTrainingMedia(self, requestContext):
        trainingMediaId = requestContext.incomingContent.get('trainingMediaRecord').get('trainingMediaId', None)
        
        if trainingMediaId is None:
            raise LambdaValidationException(errmsg.ERR_TRAINING_MEDIA_ID)
        else:
            Service.dao.deleteTrainingMedia(self.dbConn, trainingMediaId)   
            logging.info('Row Id deleted: ' + str(trainingMediaId))
            Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                         updateEventConstants.AUDIT_TRAINING_MEDIA_TABLE, str(trainingMediaId), 
                                         updateEventConstants.AUDIT_ELEMENT_TRAINING_MEDIA_ID, None, None,
                                         UpdateActionCode.DELETE.value, None, requestContext.userSession.sessionToken,
                                         None, 'irschappwrite')
            
    
    def _processAttachmentRequests(self, requestContext, attmObj):
        resultDict = {
            Service.RESULT_STATUS_CODE: LambdaStatusCodes.OK.value,
            Service.RESULT_ERR_MSG: None,
            Service.RESULT_BODY: None
        }
        try:
            logging.info("_processAttachmentRequests: requestAttachmentLink for ")
            attmResponseBody = Service.requestAttachmentLinkService.processAttachmentRequest(requestContext, attmObj)
            attmObj.setRequestAttachmentLinkResponse(attmResponseBody)
        except Exception as e:
            logging.error(f"_processAttachmentRequests failed for {attmObj.getIncomingFileName()}: {e}")
            resultDict[Service.RESULT_STATUS_CODE] = LambdaStatusCodes.INTERNAL_SERVER_ERROR.value
            resultDict[Service.RESULT_ERR_MSG] = f"Internal error processing attachment {attmObj.getIncomingFileName()}"
                
        return resultDict
    
    
    def _createAttachmentServices(self, requestContext):
        if self.dbObj is not None:
            # warm start
            logging.info('UpdateAdminData warm start - testing database connection...')
            self.dbObj.checkConnection()
            logging.info('UpdateAdminData continuing after database connection tested')
        else:
            logging.info('Initializing databaseClass...')
            self.dbObj = databaseClass(requestContext.environDict)
            logging.info('UpdateAdminData service continuing after database connection created')
        
        if Service.requestAttachmentLinkService is None:
            Service.requestAttachmentLinkService = RequestAttachmentLinkService(self.dbObj, self.s3handleForAttachments, self.dbConn) 
        if Service.trainingMediaTransformationService is None:
            Service.trainingMediaTransformationService = TrainingMediaTransformationService()
    
    
    def retrieveUsageRecordType(self, requestContext):
        researchRequestId = requestContext.incomingContent.get('researchRequestId', None)
        
        if researchRequestId is None:
            raise LambdaValidationException(errmsg.ERR_RESEARCH_REQUEST_ID_MISSING)
        
        requestMethodQuery = Service.researchRequestDao.queryResearchRequest(self.dbConn, researchRequestId)
        if requestMethodQuery is None or len(requestMethodQuery) == 0:
            raise LambdaValidationException(errmsg.ERR_RESEARCH_REQUEST_ID_INVALID)
        
        requestStatusCode = requestMethodQuery.get("extl_stat_cd")
        if requestStatusCode != ExternalStatusCode.CHALLENGED.value and requestStatusCode != ExternalStatusCode.CLOSED.value:
            raise LambdaValidationException(errmsg.ERR_RESEARCH_REQUEST_INCORRECT_STATUS)
        
        requestMethodDescription = Service.scotsDao.getShortDescription(self.scots_dict, ScotsTable.REQUEST_METHOD.value, requestMethodQuery.get("v_reqs_meth_cd"), langId=None)
        retriggerUsageMessage = createUsageRecordMessage(requestMethodQuery, requestMethodDescription)
        
        return retriggerUsageMessage
    
    
    def resendUsageRecord(self, requestContext, snsClient):
        researchRequestId = requestContext.incomingContent.get('researchRequestId', None)
        
        if researchRequestId is None:
            raise LambdaValidationException(errmsg.ERR_RESEARCH_REQUEST_ID_MISSING)
        
        self._sendRequestNotification(requestContext, researchRequestId, snsClient)
    
    
    def statusChangeValidate(self, requestContext):
        return self._statusChangeActionImpl(requestContext, True)
    
    
    def statusChangeAction(self, requestContext):
        return self._statusChangeActionImpl(requestContext, False)
        
        
    def _statusChangeActionImpl(self, requestContext, isValidateOnly):
        subjectResearchId = requestContext.incomingContent.get('subjectResearchId')
        internalStatusCode = requestContext.incomingContent.get('internalStatusCode')
        if subjectResearchId is None:
            raise LambdaValidationException(errmsg.ERR_SUBJECT_RESEARCH_ID_MISSING)
        if internalStatusCode is None:
            raise LambdaValidationException(errmsg.ERR_INTERNAL_STATUS_CODE_MISSING)
        
        return Service.statusChangeService.statusChangeAction(requestContext, isValidateOnly, subjectResearchId, internalStatusCode)
    
    
    def _sendRequestNotification(self, requestContext, researchRequestId, snsClient):
        if not Service.requestNotificationHelper:
            # SNS message to Notification service for request
            triggerGenerateNotificationTopicARN = requestContext.environDict.get(envVblNames.ENV_TRIGGER_GENERATE_NOTIFICATION_TOPIC_ARN)
            Service.notificationHelper = RequestNotificationHelper(snsClient, triggerGenerateNotificationTopicARN)
        Service.notificationHelper.triggerUsageNotification(UsageTypeCode.RESEARCH_REQUEST.value, researchRequestId=researchRequestId)   


    def _updateBatchRequestObj(self, qryResult, lookupRule):
        batchReqsObj = qryResult[0].get("btch_reqs_obj")
        if lookupRule is None:
            return batchReqsObj
        
        batchAttributes = json.loads(batchReqsObj) if isNotBlank(batchReqsObj) else {}
        lookupRules = batchAttributes.get("lookupRules")
        if lookupRules is not None and len(lookupRules) > 0:
            lookupRules[0]["lookupRule"] = lookupRule
        else:
            batchAttributes["lookupRules"] = [ {"lookupRule": lookupRule} ]

        return json.dumps(batchAttributes)
    
    
    def cancelBatch(self, requestContext, sqsHelper):
        batchRequestId = requestContext.incomingContent.get('batchRequestId', None)
        
        if batchRequestId is None:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_BATCH_REQUEST_ID)
        
        qryResult = Service.retrieveAdminDataDao.getBatchDetails(self.dbConn, batchRequestId)
        batchDetails = mapBatchDetailResultToSchema(qryResult)
        
        if not batchDetails.get('batchDetailData').get('batchRequestId'):
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_NO_SUCH_BATCH)
   
        batchStatusCode = batchDetails.get('batchDetailData').get('batchStatusCode')
        
        if not batchStatusCode or batchStatusCode != BatchStatusCode.SUBMITTED.value:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_INCORRECT_STATUS)
        
        principalId = requestContext.userSession.principalId  
                  
        self._sendMessageToCancelQueue(batchRequestId, principalId, sqsHelper)
        
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                    updateEventConstants.AUDIT_BATCH_REQUEST_TABLE, batchRequestId, 
                                    updateEventConstants.AUDIT_ELEMENT_BATCH_STATUS, BatchStatusCode.APPROVED.value, BatchStatusCode.APPROVED.value,
                                    UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                    None, Service.APP_MODULE_NM)
        
        
    def _sendMessageToCancelQueue(self, batchRequestId, principalId, sqsHelper):
        msg = {}
        msg["batchRequestId"] = batchRequestId
        msg["principalId"] = json.dumps(principalId)
        msgJsonStr = json.dumps(msg)
        logging.info("Message sent to sendToCancelBatch queue %s", msgJsonStr)
        try:
            queueResp = sqsHelper.sendMessageToQueue(msgJsonStr)
            messageId = queueResp.get('MessageId')
            logging.info("message id is: %s", messageId)
        except:
            logging.info("Failed to send message to sendToCancelBatch queue for batch %s", batchRequestId)
            raise Exception("Failed to send message to sendToCancelBatch queue for batch " + str(batchRequestId))
        
        
    def _notifyCfpResponse(self, requestContext, batchRequestId):
        if not Service.cfpResponseGeneratorSqsHelper:
            try:
                Service.cfpResponseGeneratorSqsHelper = SqsHelper(queueUrl=requestContext.environDict[envVblNames.ENV_CFPRESPONSEGENERATOR_QUEUE_URL],
                                                                  regionName=requestContext.environDict[envVblNames.ENV_SQS_REGION])
            except:
                raise LambdaConflictException("CFPRESPONSEGENERATOR_QUEUE_URL or SQS_REGION not configured")
        outgoingDict = {
            'batchRequestId': batchRequestId,
            'source': Service.APP_MODULE_NM
        }
        outgoingBody = json.dumps(outgoingDict)
        logging.info(f"_notifyCfpResponse posting msg: outgoingBody={outgoingBody}")
        queueResp = self.cfpResponseGeneratorSqsHelper.sendMessageToQueue(outgoingBody)
        messageId = queueResp.get('MessageId')
        logging.info(f"_notifyCfpResponse: messageId={messageId} queueResp={queueResp}")


    def rerunBatch(self, requestContext):
        batchRequestId = requestContext.incomingContent.get('batchRequestId', None)
        
        if batchRequestId is None:
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_BATCH_REQUEST_ID)
        qryResult = Service.retrieveAdminDataDao.getBatchDetails(self.dbConn, batchRequestId)
        batchDetails = mapBatchDetailResultToSchema(qryResult)
        
        if not batchDetails.get('batchDetailData').get('batchRequestId'):
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_NO_SUCH_BATCH)
   
        batchStatusCode = batchDetails.get('batchDetailData').get('batchStatusCode')
        if not batchStatusCode or batchStatusCode not in BatchStatusCode.getCompletedStatusList():
            logging.error(f"Attempt to rerun batch with status={batchStatusCode} (needs to be in a completed status)")
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_INCORRECT_STATUS)
        
        if not BatchType.isCfpBatch(batchDetails.get('batchDetailData').get('batchType')):
            logging.error(f"Attempt to rerun batch of type {batchDetails.get('batchDetailData').get('batchType')} (needs to be a CFP type batch)")
            raise LambdaValidationException(errmsg.ERR_BATCH_ADMIN_NOT_CFP_BATCH)

        Service.cfpBatchAdminService.rerunBatch(requestContext, batchRequestId)
        
        
    def addBannerMessage(self, requestContext, hasOutage=False):
        '''
        maintenanceOutages can include a banner message. hasOutage determines whether banner message is related to
        outage.  The path for the requestContext is determined by whether banner is being added for outage or is
        a standard alert banner with no associated outage. 
        '''
        if hasOutage:
            requestContextPath = requestContext.incomingContent.get('maintenanceOutage').get('messageBanner')
            # bannerSeverity for maintenance window should default to 'Outage' unless superAdmin decides otherwise
            bannerSeverity = requestContextPath.get('bannerSeverity', 'Outage')
        else:
            requestContextPath = requestContext.incomingContent.get('messageBanner')
            bannerSeverity = requestContextPath.get('bannerSeverity')
 
        bannerTitle = requestContextPath.get('bannerTitle')
        bannerMessage = requestContextPath.get('bannerMessage')
        # if bannerDismissable not provided, defaulted to dismissable banner
        bannerDismissable = requestContextPath.get('bannerDismissable', True)
        # if no role is specified, banner audience is defaulted to All Roles
        bannerNotifyRoles = requestContextPath.get('bannerNotifyRoles', [])
        bannerStartDate = requestContextPath.get('bannerStartDate')
        bannerEndDate = requestContextPath.get('bannerEndDate')
        bannerMessageActiveIndicator = requestContextPath.get('bannerActive')
        
        # updateAdminData schema requires that messageBanner exists in requestContext
        if requestContextPath is None:
            raise LambdaValidationException(errmsg.ERR_MESSAGE_BANNER_MISSING)
        
        # Required parameters for bnr_msg table
        if bannerSeverity is None:
            raise LambdaValidationException(errmsg.ERR_BANNER_SEVERITY)
        if bannerNotifyRoles is None:
            raise LambdaValidationException(errmsg.ERR_BANNER_NOTIFY_ROLES)
        if bannerMessageActiveIndicator is None:
            raise LambdaValidationException(errmsg.ERR_BANNER_MESSAGE_ACTIVE_INDICATOR)
        
        # Enhancement below would be to pass back role name that did not pass criteria. 
        # Follow up to Determine why two sets of roles not matching IDaaS (IResearchRole) and administered roles (IResearchAdministeredRole)
        if len(bannerNotifyRoles) == 0:
            pass
        else:
            for role in bannerNotifyRoles:
                if role['role'] not in IResearchRole.getAllRoleNames() and role['role'] not in IResearchAdministeredRole.getAllRoleNames():
                    raise LambdaValidationException(errmsg.ERR_USER_ROLE_INVALID)
        
        # Builds Banner Message Layout json according to spec found in Business Object Model/src/main/resources/python/BannerMessageLayout.json then adds new record to bnr_msg table.
        bannerMessageObject = {
            'bannerTitle': bannerTitle,
            'bannerMessage': bannerMessage,
            'bannerSeverity': bannerSeverity,
            'bannerDismissable': bannerDismissable,
            'userRole': bannerNotifyRoles
        }
        
        rowInserted = Service.dao.addBannerMessage(self.dbConn, bannerMessageObject, bannerStartDate, bannerEndDate, bannerMessageActiveIndicator)
        logging.info('Row Id inserted: ' + str(rowInserted))
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                    updateEventConstants.AUDIT_BNR_MSG_TABLE, rowInserted, 
                                    updateEventConstants.AUDIT_ELEMENT_BANNER_MESSAGE_ID, bannerSeverity, None,
                                    UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                    None, Service.APP_MODULE_NM)

        return rowInserted
    
    
    def updateBannerMessage(self, requestContext, bannerMessageId = None):
        '''
        maintenanceOutages can include a banner message. bannerMessageId being passed determines that banner message is related to
        an outage and the mntn_wndw table has already been queried for the bannerMessageId.  The path for the requestContext is determined by whether 
        banner is being updated for outage or if this is a standard alert banner update with no associated outage. 
        '''
        if bannerMessageId is not None:
            requestContextPath = requestContext.incomingContent.get('maintenanceOutage').get('messageBanner')
            bannerMessageIdStr = bannerMessageId 
        else:
            requestContextPath = requestContext.incomingContent.get('messageBanner')
            bannerMessageIdStr = requestContextPath.get('bannerMessageId')
            
        bannerTitle = requestContextPath.get('bannerTitle', None)
        bannerMessage = requestContextPath.get('bannerMessage', None)
        bannerSeverity = requestContextPath.get('bannerSeverity', None)
        bannerDismissable = requestContextPath.get('bannerDismissable', None)
        bannerNotifyRoles = requestContextPath.get('bannerNotifyRoles', None)
        bannerStartDate = requestContextPath.get('bannerStartDate', None)
        bannerEndDate = requestContextPath.get('bannerEndDate', None)
        bannerMessageActiveIndicator = requestContextPath.get('bannerActive', None)
        
        # Confirm that request contains required/valid bannerMessageId
        bannerMessageId = intDefaultNone(bannerMessageIdStr) if isInt(bannerMessageIdStr) else None
        if isBlank(bannerMessageIdStr):
            logging.info('bannerMessageId missing or is invalid string')
            raise LambdaValidationException(errmsg.ERR_BANNER_MESSAGE_ID)
        
        # updateAdminData schema requires that messageBanner exists in requestContext if update is being made
        if requestContextPath is None:
            logging.info('messageBanner is missing from requestContext.')
            raise LambdaValidationException(errmsg.ERR_MESSAGE_BANNER_MISSING)
        
        # Ensure that update exists
        if bannerTitle is None and bannerMessage is None and bannerSeverity is None and bannerDismissable is None and bannerNotifyRoles is None and bannerStartDate is None and bannerEndDate is None and bannerMessageActiveIndicator is None:
            logging.info('messageBanner provided without any updates to be made.')
            raise LambdaValidationException(errmsg.ERR_BANNER_UPDATES_INVALID)
        
        # Enhancement below would be to pass back role name that did not pass criteria. 
        # Follow up to Determine why two sets of roles not matching IDaaS (IResearchRole) and administered roles (IResearchAdministeredRole)
        if bannerNotifyRoles is not None:
            if len(bannerNotifyRoles) == 0:
                pass
            else:
                for role in bannerNotifyRoles:
                    if role['role'] not in IResearchRole.getAllRoleNames() and role['role'] not in IResearchAdministeredRole.getAllRoleNames():
                        raise LambdaValidationException(errmsg.ERR_USER_ROLE_INVALID)
        
        Service.dao.updateBannerMessage(self.dbConn, bannerMessageId, bannerTitle, bannerMessage, bannerSeverity, bannerDismissable, bannerNotifyRoles, bannerStartDate, bannerEndDate, bannerMessageActiveIndicator)
        logging.info('Row Id updated: ' + str(bannerMessageId))
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                    updateEventConstants.AUDIT_BNR_MSG_TABLE, bannerMessageId, 
                                    updateEventConstants.AUDIT_ELEMENT_BANNER_MESSAGE_ID, None, None,
                                    UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                    None, Service.APP_MODULE_NM)
        
        
    def addMaintenanceOutage(self, requestContext):
        mntnStartDate = requestContext.incomingContent.get('maintenanceOutage').get('mntnStartDate')
        mntnEndDate = requestContext.incomingContent.get('maintenanceOutage').get('mntnEndDate')
        mntnWarningMinutes = requestContext.incomingContent.get('maintenanceOutage').get('mntnLockoutWarningMinutes')
        
        # Required parameters for mntn_wndow table
        if mntnStartDate is None:
            raise LambdaValidationException(errmsg.ERR_MAINTENANCE_START_TIME)
        if mntnEndDate is None:
            raise LambdaValidationException(errmsg.ERR_MAINTENANCE_END_TIME)
        if mntnWarningMinutes is None:
            raise LambdaValidationException(errmsg.ERR_MAINTENANCE_LOCKOUT_WARNING_MINUTES)
        
        # Required parameters per updateAdminData schema are messageBanner and messageBanner.bannerActive.  This check is done in def addBannerMessage
        bannerMessageId = self.addBannerMessage(requestContext, True)
        
        rowInserted = Service.dao.addMaintenanceOutage(self.dbConn, mntnStartDate, mntnEndDate, mntnWarningMinutes, bannerMessageId)
        logging.info('Row Id inserted: ' + str(rowInserted))
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                     updateEventConstants.AUDIT_MAINTENANCE_WINDOW_TABLE, rowInserted, 
                                     updateEventConstants.AUDIT_ELEMENT_MAINTENANCE_WINDOW_ID, None, None,
                                     UpdateActionCode.ADD.value, None, requestContext.userSession.sessionToken,
                                     None, Service.APP_MODULE_NM)
        
    
    def updateMaintenanceOutage(self, requestContext):
        mntnWindowIdStr = requestContext.incomingContent.get('maintenanceOutage').get('mntnWindowId', None)
        mntnStartDate = requestContext.incomingContent.get('maintenanceOutage').get('mntnStartDate', None)
        mntnEndDate = requestContext.incomingContent.get('maintenanceOutage').get('mntnEndDate', None)
        mntnWarningMinutes = requestContext.incomingContent.get('maintenanceOutage').get('mntnLockoutWarningMinutes', None)
        messageBanner = requestContext.incomingContent.get('maintenanceOutage').get('messageBanner', None)
        
        # Confirm that request contains required/valid mntnWindowId
        mntnWindowId = intDefaultNone(mntnWindowIdStr) if isInt(mntnWindowIdStr) else None
        if isBlank(mntnWindowId):
            logging.info('mntnWindowId missing or is invalid string')
            raise LambdaValidationException(errmsg.ERR_MAINTENANCE_WINDOW_ID_NO_RESULT)
        
        # Confirm request contains at least one update
        if mntnStartDate is None and mntnEndDate is None and mntnWarningMinutes is None and messageBanner is None:
            raise LambdaValidationException(errmsg.ERR_MAINTENANCE_UPDATES)
        
        # Update mntn_wndw record and return bannerId in event banner message needs an update
        bannerMessageId = Service.dao.updateMaintenanceOutage(self.dbConn, mntnWindowId, mntnStartDate, mntnEndDate, mntnWarningMinutes, messageBanner)
        logging.info('Row Id updated: ' + str(mntnWindowId))
        # Record update event
        Service.eventDao.insertEvent(self.dbConn, int(requestContext.userSession.userId), 
                                     updateEventConstants.AUDIT_MAINTENANCE_WINDOW_TABLE, mntnWindowId, 
                                     updateEventConstants.AUDIT_ELEMENT_MAINTENANCE_WINDOW_ID, None, None,
                                     UpdateActionCode.MODIFY.value, None, requestContext.userSession.sessionToken,
                                     None, Service.APP_MODULE_NM)
        
        # Determine if banner message is used and if so whether banner message is being updated or added new
        if bannerMessageId is not None:
            self.updateBannerMessage(requestContext, bannerMessageId)
            
    def _sendMessageToSubmitToRemoteApp(self, requestContext, batchRequestId, typeCode):
        
        message = {
            'batchRequestId' : batchRequestId,
            'submitToRemoteAppTypeCode': typeCode
        }
        
        submitToRemoteAppQueueUrl = requestContext.environDict.get(envVblNames.ENV_SUBMITTOREMOTEAPP_QUEUE_URL)
        if self.submitToRemoteAppSQSHelper is None:
            regionName = requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
            self.submitToRemoteAppSQSHelper = SqsHelper(submitToRemoteAppQueueUrl, regionName=regionName)
                 
        outgoingBody = json.dumps(message)
        logging.info(f"sendMessageToSubmitToRemoteApp posting msg to queue {submitToRemoteAppQueueUrl}: outgoingBody={outgoingBody}")
        queueResp = self.submitToRemoteAppSQSHelper.sendMessageToQueue(outgoingBody)
        messageId = queueResp.get('MessageId')
        logging.info(f"sendMessageToSubmitToRemoteApp: messageId={messageId} queueResp={queueResp}")
