'''
Created on Mar 7, 2019

@author: VanCampK
'''
import boto3
from botocore.client import Config
import logging
import json
import lambdas.errorMessages as errmsg

from lambdas.secureLambdaBase import SecureLambdaBase
from buildUIResponse import buildUIResponse
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.updateadmindata.service import Service
from common.irschRoles import IResearchRole
from common.irschAdministeredRoles import IResearchAdministeredRole
from common.adminUpdateAction import AdminUpdateAction
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.exceptions import LambdaAuthorizationException
from lambdas.exceptions import LambdaValidationException
from common.envVblNames import ENV_GET_TEAMLIST_FROM_IDAAS, getEnvironAsBool
from common.util.awsUtils import createClientConfiguration
from common.util.sqsHelper import SqsHelper
from common import envVblNames

class SvcLambda(SecureLambdaBase):
    '''
    Handler class for UpdateAdminData service.
    Implementation of a Lambda handler as a class for a specific Lambda function.
    Handler: lambdas.updateadmindata.svclambda.handler
    '''
    
    def __init__(self):
        super().__init__()
        self.service = None
        self.adminUpdateAction = None
        self.sqsHelper = None
        self.snsClient = None
        self.s3handleForAttachments = None
    
    def handleSecureRequest(self):
        if self.service is None:
            self.service = Service(SvcLambda.dbConn, self.s3handleForAttachments)
        if self.sqsHelper is None:
            try:
                if self.adminUpdateAction == AdminUpdateAction.CANCEL_BATCH:
                    queueURL = self.requestContext.environDict.get(envVblNames.ENV_CANCEL_BATCH_QUEUE_URL, None)
                else:
                    queueURL = self.requestContext.environDict.get(envVblNames.ENV_SUBMITCASEBATCHSUBMITTER_QUEUE_URL, None)
                
                if queueURL is not None:
                    regionName = self.requestContext.environDict.get(envVblNames.ENV_SQS_REGION)
                    self.sqsHelper = SqsHelper(queueUrl=queueURL, regionName=regionName)
            except:
                if self.adminUpdateAction == AdminUpdateAction.CANCEL_BATCH:
                    raise RuntimeError("CANCELBATCHQUEUEURL not configured")
                else:
                    raise RuntimeError("SUBMITCASEBATCHSUBMITTERQUEUEURL not configured")
        if self.snsClient is None:
            logging.info('Initializing snsClient...')
            self.snsClient = boto3.client('sns', region_name=SvcLambda.environDict[envVblNames.ENV_SNS_REGION], config=createClientConfiguration(SvcLambda.environDict))


        getTeamListFromIDAAS = getEnvironAsBool(SecureLambdaBase.environDict.get(ENV_GET_TEAMLIST_FROM_IDAAS))
        
        apiResponse = None
        
        if self.adminUpdateAction == AdminUpdateAction.ADD_SUBMITTER_GROUP:
            self.service.addSubmitterGroup(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_SUBMITTER_GROUP:
            self.service.updateSubmitterGroup(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_RESEARCHERS_ON_RESEARCH_TEAM:
            if getTeamListFromIDAAS is True:
                raise LambdaValidationException('Cannot update researchers through admin screens while getTeamListFromIDAAS is True')
            administerLocalAdmin = False
            self.service.updateResearchTeam(self.requestContext, administerLocalAdmin)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_LOCAL_ADMINS_ON_RESEARCH_TEAM:
            administerLocalAdmin = True
            self.service.updateResearchTeam(self.requestContext, administerLocalAdmin)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_USER_ADMIN_DATA:
            self.service.updateUserAdminData(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.ADD_USER:
            self.service.addUser(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.APPROVE_BATCH:
            self.service.approveBatch(self.requestContext, self.sqsHelper)
        elif self.adminUpdateAction == AdminUpdateAction.REJECT_BATCH:
            self.service.rejectBatch(self.requestContext, self.snsClient)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_DUE_DATE:
            self.service.updateBatchDueDate(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.ADD_TEAM_GROUP:
            self.service.addTeamGroup(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.ADD_COUNTRY_GROUP:
            self.service.addCountryGroup(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_TEAM_GROUP:
            self.service.updateTeamGroup(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_COUNTRY_GROUP:
            self.service.updateCountryGroup(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_API_APPI_ENTITLEMENT:
            self.service.updateApiAppEntitlement(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.ADD_TRAINING_MEDIA:
            apiResponse = self.service.addTrainingMedia(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_TRAINING_MEDIA:
            apiResponse = self.service.updateTrainingMedia(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.DELETE_TRAINING_MEDIA:
            self.service.deleteTrainingMedia(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.DETERMINE_USAGE_DESTINATION:
            apiResponse = self.service.retrieveUsageRecordType(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.TRIGGER_RESEND_USAGE_RECORD:
            self.service.resendUsageRecord(self.requestContext, self.snsClient)
        elif self.adminUpdateAction == AdminUpdateAction.CASE_STATUS_CHANGE_VALIDATE:
            apiResponse = self.service.statusChangeValidate(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.CASE_STATUS_CHANGE_ACTION:
            apiResponse = self.service.statusChangeAction(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.CANCEL_BATCH:
            self.service.cancelBatch(self.requestContext, self.sqsHelper)
        elif self.adminUpdateAction == AdminUpdateAction.RERUN_BATCH:
            self.service.rerunBatch(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.ADD_BANNER_MESSAGE:
            self.service.addBannerMessage(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_BANNER_MESSAGE:
            self.service.updateBannerMessage(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.ADD_MAINTENANCE_OUTAGE:
            self.service.addMaintenanceOutage(self.requestContext)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_MAINTENANCE_OUTAGE:
            self.service.updateMaintenanceOutage(self.requestContext)
        else:
            raise LambdaValidationException(f"{errmsg.ERR_UNSUPPORTED_UPDATE_ADMIN_ACTION}: {self.adminUpdateAction}")
            
        if apiResponse is not None:
            responseBody = json.dumps(apiResponse)
        else:
            responseBody = json.dumps({})
           
        return buildUIResponse(LambdaStatusCodes.OK.value, responseBody, 'application/json')

    
    def authorizeRequest(self):
        
        self.adminUpdateAction = self.requestContext.incomingContent.get('updateAdminAction', None)
        
        if self.adminUpdateAction is None:
            raise LambdaValidationException(errmsg.ERR_ADMIN_UPDATE_ACTION_NOT_FOUND)
        
        if self.adminUpdateAction == AdminUpdateAction.ADD_SUBMITTER_GROUP or self.adminUpdateAction == AdminUpdateAction.UPDATE_SUBMITTER_GROUP:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_RESEARCHERS_ON_RESEARCH_TEAM:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_LOCAL_ADMINS_ON_RESEARCH_TEAM:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_USER_ADMIN_DATA:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        elif self.adminUpdateAction == AdminUpdateAction.ADD_USER:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        elif self.adminUpdateAction == AdminUpdateAction.APPROVE_BATCH:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchAdministeredRole.IRESEARCH_BATCH_ADMIN ]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        elif self.adminUpdateAction == AdminUpdateAction.REJECT_BATCH:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchAdministeredRole.IRESEARCH_BATCH_ADMIN ]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        elif self.adminUpdateAction == AdminUpdateAction.UPDATE_DUE_DATE:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchAdministeredRole.IRESEARCH_BATCH_ADMIN ]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        if self.adminUpdateAction == AdminUpdateAction.ADD_TEAM_GROUP or self.adminUpdateAction == AdminUpdateAction.UPDATE_TEAM_GROUP:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        if self.adminUpdateAction == AdminUpdateAction.ADD_COUNTRY_GROUP or self.adminUpdateAction == AdminUpdateAction.UPDATE_COUNTRY_GROUP:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        if self.adminUpdateAction == AdminUpdateAction.ADD_COUNTRY_GROUP or self.adminUpdateAction == AdminUpdateAction.UPDATE_API_APPI_ENTITLEMENT:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        if self.adminUpdateAction == AdminUpdateAction.ADD_TRAINING_MEDIA or self.adminUpdateAction == AdminUpdateAction.UPDATE_TRAINING_MEDIA or self.adminUpdateAction == AdminUpdateAction.DELETE_TRAINING_MEDIA:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        if self.adminUpdateAction == AdminUpdateAction.DETERMINE_USAGE_DESTINATION or self.adminUpdateAction == AdminUpdateAction.TRIGGER_RESEND_USAGE_RECORD:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        if self.adminUpdateAction == AdminUpdateAction.CASE_STATUS_CHANGE_VALIDATE or self.adminUpdateAction == AdminUpdateAction.CASE_STATUS_CHANGE_ACTION:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
        if self.adminUpdateAction in [ AdminUpdateAction.CANCEL_BATCH, AdminUpdateAction.RERUN_BATCH]:
            if (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_SUPER_ADMIN]) == False):
                logging.error('updateadmindata - user does not have any of the required roles')
                raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)
    
    def initializeKeepWarm(self):
        if not self.s3handleForAttachments:
            logging.info('Initializing s3handleForAttachments...')
            self.s3handleForAttachments = boto3.client('s3', config=createClientConfiguration(environDict=None, mergeConfig=Config(signature_version='s3v4')))


#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SvcLambda.get_handler(...)