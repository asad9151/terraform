'''
Created on Mar 3, 2021

@author: VanCampK
'''
import logging

from common import updateEventConstants
from common.dao.researchRequestDao import ResearchRequestDao
from common.dao.scotsDao import ScotsDao
from common.dao.subjectResearchDao import SubjectResearchDao
from common.dao.updateEventDao import UpdateEventDao
from common.internalStatusCode import InternalStatusCode
from common.scotsTables import ScotsTable
from common.updateActionCodes import UpdateActionCode
from common.util.dateUtils import getCurrentJavaDatetimestamp
from common.util.stateHelper import StateHelper
import lambdas.errorMessages as errmsg
from lambdas.exceptions import LambdaValidationException
from lambdas.fileadmin.fileBasedAdminDao import FileBasedAdminDao


class StatusChangeService(object):
    '''
    Handles changes to case status
    '''
    APP_MODULE_NM = "UpdateAdminData"


    def __init__(self, dbConn, scots_dict):
        self.dbConn = dbConn
        self.scots_dict = scots_dict
        self.subjectResearchDao = None
        self.researchRequestDao = None
        self.scotsDao = None
        self.fileBasedAdminDao = None
        self.updateEventDao = None


    def _createServices(self, requestContext):
        if self.subjectResearchDao is None:
            self.subjectResearchDao = SubjectResearchDao()
        if self.researchRequestDao is None:
            self.researchRequestDao = ResearchRequestDao()
        if self.scotsDao is None:
            self.scotsDao = ScotsDao()
        if self.fileBasedAdminDao is None:
            self.fileBasedAdminDao = FileBasedAdminDao()
        if self.updateEventDao is None:
            self.updateEventDao = UpdateEventDao()
        
        
    def statusChangeAction(self, requestContext, isValidateOnly, subjectResearchId, internalStatusCode):
        '''
        Allowed status changes:
        RECEIVED (33607) -> CLOSED
        SUBMITTED_TO_BDRS (33662) -> CLOSED, READY_TO_BE_ASSIGNED
        READY_TO_BE_ASSIGNED (33692) -> CLOSED
        ASSIGNED (33609) -> CLOSED
        RESEARCH_IN_PROGRESS (33610) -> CLOSED
        REROUTED (33613) -> CLOSED
        CLOSED (33617) -> ASSIGNED or RESEARCH_IN_PROGRESS
        CHALLENGED (33618) -> none        
        '''
        self._createServices(requestContext)
        subjectResearch = self.subjectResearchDao.querySubjResearch(self.dbConn, subjectResearchId)
        if subjectResearch is None or len(subjectResearch) == 0:
            raise LambdaValidationException(errmsg.ERR_SUBJECT_RESEARCH_ID_INVALID)
        
        researchRequestId = subjectResearch.get("rsch_reqs_id")
        researchRequest = self.researchRequestDao.queryResearchRequest(self.dbConn, researchRequestId)
        if researchRequest is None or len(researchRequest) == 0:
            raise LambdaValidationException(errmsg.ERR_RESEARCH_REQUEST_ID_INVALID)
        
        currInternalStatusCode = subjectResearch.get("curr_rsch_intrl_stat_cd")
        
        logging.info(f"Requested status change on subjectResearchId={subjectResearchId} to internalStatusCode={internalStatusCode}: currInternalStatusCode={currInternalStatusCode} isValidateOnly={isValidateOnly}")
        self._validateStatusTransition(currInternalStatusCode, internalStatusCode)
        
        requestMethodDescription = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.REQUEST_METHOD.value, researchRequest.get("v_reqs_meth_cd"), langId=None)
        
        # Get back all subj_rsch on this rsch_reqs_id, in case multi-case
        subjectResearches = self.subjectResearchDao.querySubjResearchByResearchRequestId(self.dbConn, researchRequestId)
        logging.debug(f"Found {len(subjectResearches)} cases in researchRequestId={researchRequestId}")
        isMultiCase = len(subjectResearches) > 1
        
        if isValidateOnly:
            return self._createStatusChangeMessage(currInternalStatusCode, internalStatusCode, requestMethodDescription, isMultiCase)
        
        self._changeStatus(requestContext, subjectResearchId, researchRequestId, currInternalStatusCode, internalStatusCode, subjectResearch, researchRequest, subjectResearches)
        return {}
    
    
    def _validateStatusTransition(self, currInternalStatusCode, internalStatusCode):
        if internalStatusCode == InternalStatusCode.CLOSED.value:
            if currInternalStatusCode not in [ InternalStatusCode.RECEIVED.value, InternalStatusCode.SUBMITTED_TO_BDRS.value,
                                              InternalStatusCode.READY_TO_BE_ASSIGNED.value, InternalStatusCode.ASSIGNED.value,
                                              InternalStatusCode.RESEARCH_IN_PROGRESS.value, InternalStatusCode.REROUTED.value ]:
                raise LambdaValidationException(errmsg.ERR_SUBJECT_REQUEST_INCORRECT_STATUS)
        elif internalStatusCode == InternalStatusCode.READY_TO_BE_ASSIGNED.value:
            if currInternalStatusCode not in [ InternalStatusCode.SUBMITTED_TO_BDRS.value ]:
                raise LambdaValidationException(errmsg.ERR_SUBJECT_REQUEST_INCORRECT_STATUS)
        elif internalStatusCode == InternalStatusCode.ASSIGNED.value:
            if currInternalStatusCode not in [ InternalStatusCode.CLOSED.value ]:
                raise LambdaValidationException(errmsg.ERR_SUBJECT_REQUEST_INCORRECT_STATUS)
        elif internalStatusCode == InternalStatusCode.RESEARCH_IN_PROGRESS.value:
            if currInternalStatusCode not in [ InternalStatusCode.CLOSED.value ]:
                raise LambdaValidationException(errmsg.ERR_SUBJECT_REQUEST_INCORRECT_STATUS)
        else:
            raise LambdaValidationException(errmsg.ERR_UNSUPPORTED_STATUS)
        
            
    def _createStatusChangeMessage(self, currInternalStatusCode, internalStatusCode, requestMethodDescription, isMultiCase):
        '''
        - If new status is CLOSED, add warning that "downstream processing (e.g. billing, usage) will not be sent (for source-system)".
        - If previous status was CLOSED, add warning that "downstream processing (e.g. billing, usage) has already happened, and may be sent a second time (for source-system) if the case is re-closed".
        - If a multi-case request, add warning that other cases in the request will not be modified.
        '''
        msg = ""
        if internalStatusCode == InternalStatusCode.CLOSED.value:
            msg = f"Downstream processing (e.g. billing, usage) will not be sent for {requestMethodDescription}. "
        elif currInternalStatusCode == InternalStatusCode.CLOSED.value:
            msg = f"Downstream processing (e.g. billing, usage) has already happened, and may be sent a second time for {requestMethodDescription} if the case is re-closed. "
        if isMultiCase:
            msg += "Please note this is a multi-case request - other cases in the request will not be modified."
        warningResponse = {
            "warningMessage": msg,
            "warningType": 5
        }
        logging.info(f"Returning status change warning: {warningResponse}")
        return warningResponse
        
        
    def _changeStatus(self, requestContext, subjectResearchId, researchRequestId, currInternalStatusCode, internalStatusCode, subjectResearch, researchRequest, subjectResearches):
        externalStatusCode = StateHelper.mapInternalToExternalStatus(internalStatusCode)
        updatedExternalStatusCode = None
        
        # First update the subj_rsch record
        # Don't update external status code unless actually changed
        if externalStatusCode != subjectResearch.get("curr_rsch_extl_stat_cd"):
            updatedExternalStatusCode = externalStatusCode
            
        # Special update for case close
        if internalStatusCode == InternalStatusCode.CLOSED.value:
            closeDateTime = getCurrentJavaDatetimestamp()
        else:
            closeDateTime = None
        
        self.fileBasedAdminDao.updateSubjectResearchStatus(self.dbConn, subjectResearchId, internalStatusCode, updatedExternalStatusCode, closeDateTime, StatusChangeService.APP_MODULE_NM)
        self.updateEventDao.insertEvent(self.dbConn, requestContext.userSession.userId, updateEventConstants.AUDIT_SUBJECT_RESEARCH_TABLE,
                                    subjectResearchId, updateEventConstants.AUDIT_ELEMENT_INTERNAL_STATUS,
                                    internalStatusCode, internalStatusCode, UpdateActionCode.MODIFY.value, None,
                                    requestContext.userSession.sessionToken, None, StatusChangeService.APP_MODULE_NM)

        # Don't update the rsch_reqs unless (1) it's changed and (2) all cases in the request are in consistent state with this one
        if updatedExternalStatusCode is not None:
            isExternalStatesConsistent = True
            if len(subjectResearches) > 1:
                isExternalStatesConsistent = self._checkMultiCaseStatus(subjectResearches, subjectResearchId, updatedExternalStatusCode)
            if isExternalStatesConsistent:
                self.fileBasedAdminDao.updateResearchRequestStatus(self.dbConn, researchRequestId, updatedExternalStatusCode, StatusChangeService.APP_MODULE_NM)
                self.updateEventDao.insertEvent(self.dbConn, requestContext.userSession.userId, updateEventConstants.AUDIT_RESEARCH_REQUESTS_TABLE,
                                            researchRequestId, updateEventConstants.AUDIT_ELEMENT_REQ_EXTERNAL_STATUS,
                                            updatedExternalStatusCode, updatedExternalStatusCode, UpdateActionCode.MODIFY.value, None,
                                            requestContext.userSession.sessionToken, None, StatusChangeService.APP_MODULE_NM)
            else:
                logging.info(f"Not updating rsch_reqs extl_stat_cd because multi-case request is not in consistent state")
        
        
    def _checkMultiCaseStatus(self, subjectResearches, subjectResearchId, updatedExternalStatusCode):
        '''
        Returns True if all cases in the request have the same external status, or False if not
        '''
        for subjRsch in subjectResearches:
            subjRschId = subjRsch.get("subj_rsch_id")
            if subjRschId != subjectResearchId:
                extlStatCd = subjRsch.get("curr_rsch_extl_stat_cd")
                if extlStatCd != updatedExternalStatusCode:
                    return False
        return True