'''
Created on Apr 11, 2019

@author: JafferS
'''
from itertools import groupby

def mapRschRefDataQueryResultToSchema(qryResult):
    groupDict = _group(qryResult)
    return _transformGroupItemsToSchema(groupDict)

def _group(qryResult):
    groupDict = groupby(qryResult, lambda qryResult: qryResult['rsch_ref_data_id'])
    return groupDict

def _transformGroupItemsToSchema(groupDict):
    rschRefData = []
    for refData, children in groupDict:
        refDataItem = None
        childList = []
        for child in children:
            if refDataItem == None:
                refDataItem = _transformRefDataItemToSchema(child)

            childData = _transformChildToSchema(child)
            if bool(childData) is True:
                childList.append(childData)
        refDataEntry = {
            "refData": refDataItem,
            "children": childList
        }
        rschRefData.append(refDataEntry)  
         
    result = {}
    result["rschRefData"] = rschRefData
    return result

def _transformRefDataItemToSchema(rec):

    result = {}
    result["rschRefDataId"] = rec.get("rsch_ref_data_id")
    result["dataName"] = rec.get("data_nme")
    result["dataType"] = rec.get("data_type")
    result["modifiedTimestamp"] = rec.get("mod_timestamp")

    return result

def _transformChildToSchema(rec):
    result = {}
    if rec.get("rsch_ref_data_chld_id", None) is not None:
        result["childId"] = rec.get("rsch_ref_data_chld_id")
        result["childValue"] = rec.get("val")
    return result