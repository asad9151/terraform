'''
Created on Aug 9, 2019

@author: VanCampK
'''

class RequestRejection(object):
    '''
    Holds an API error response object in comformance with iResearchRequestRejectionLayout.json
    '''

    def __init__(self, rejectionReasonCode, rejectionErrors=None, rejectionErrorMessage=None):
        self.rejectionReasonCode = rejectionReasonCode          # Use common.RejectionReasonCode.value
        self.rejectionErrors = rejectionErrors                  # List of RequestRejectionError
        self.rejectionErrorMessage = rejectionErrorMessage      # String
        
        
    def __str__(self):
        err = 'RequestRejection(rejectionReasonCode=' + str(self.rejectionReasonCode)
        if self.rejectionErrors is not None:
            for rejectionError in self.rejectionErrors:
                err += ' rejectionError=' + str(rejectionError)
        if self.rejectionErrorMessage is not None:
            err += ' rejectionErrorMessage=' + self.rejectionErrorMessage
        err += ')'
        return err

        
    def toDict(self):
        rejectionDict = {
            "rejectionReasonCode": self.rejectionReasonCode if (self.rejectionReasonCode is None or isinstance(self.rejectionReasonCode, int)) else self.rejectionReasonCode.value
        }
        if self.rejectionErrors is not None and len(self.rejectionErrors) > 0:
            # Store into set to de-dup
            rejectionErrorSet = set()
            for rejectionError in self.rejectionErrors:
                rejectionErrorSet.add(rejectionError)
            rejErrors = []
            for rejectionError in list(sorted(rejectionErrorSet)):
                rejErrors.append(rejectionError.toDict())
            rejectionDict["rejectionErrors"] = rejErrors
        if self.rejectionErrorMessage is not None:
            rejectionDict["rejectionErrorMessage"] = self.rejectionErrorMessage
        return { "rejectionInformation": rejectionDict }