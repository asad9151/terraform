'''
Created on Jun 21, 2019

@author: VanCampK
'''
from enum import Enum

class AuthType(Enum):
    AUTH_TYPE_IResearch = "iResearch"             # Internal authorization, for use by iResearch UI with authorizer
    AUTH_TYPE_CloudServices = "CloudServices"     # Cloud Services authorization with IAM policy
