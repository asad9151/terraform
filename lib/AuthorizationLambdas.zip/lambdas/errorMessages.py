'''
Lambda error messages

@author: VanCampK
'''
ERR_INTERNAL_REQUEST = 'Internal error processing request'
ERR_NOT_AUTHORIZED = 'Not authorized'
ERR_NOT_AUTHENTICATED = 'Not authenticated'
ERR_INTERNAL_RESPONSE = 'Internal error sending response'
ERR_UNSUPPORTED_OPTION = 'The supplied option is not supported'
ERR_KEY_NOT_FOUND = 'The supplied key is not valid'
ERR_VALIDATION_FAILURE = 'Request not valid'
ERR_INVALID_USER_TYPE = 'Unknown user type'
ERR_MISSING_ROLES = 'User does not have required roles'
ERR_REQUIRED_FIELD_MISSING = "Required field missing"
ERR_STRING_EXPECTED = "The supplied value is expected to contain a string"
ERR_INTEGER_EXPECTED = "The supplied value is expected to contain only integer digits"
ERR_INTEGER_TOO_LARGE = "The supplied integer value exceeds the maximum 9 digits"
ERR_INTEGER_TOO_SMALL = "The supplied integer value has less than 9 digits"
ERR_NOT_VALID_COUNTRY = "Expected a valid 2-character ISO2 country code"
ERR_NOT_VALID_APPLICATION_ID = "A valid application ID was not provided"
ERR_DATE_FORMAT_YYYY_MM_DD = "Expected a date YYYY-MM-DD"
ERR_DATE_OR_TS_FORMAT_YYYY_MM_DD = "Expected a date or timestamp YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS or YYYY-MM-DDTHH:MM:SS.mmm"
ERR_TIMESTAMP_FORMAT_UTC = "Expected a timestamp in UTC format e.g. YYYY-MM-DDTHH:MM:SS"
ERR_MAX_VALUE_EXCEEDED = "Value exceeds the maximum {maxValue}"
ERR_MIN_VALUE_BELOW = "Value is below the minimum {minValue}"
ERR_INVALID_JSON = "Not a valid json object"
ERR_INVALID_RESPONSE = "Response does not validate against schema but was sent anyway"
ERR_CONNECT_FAILURE = "Failed to connect"
ERR_PARAMETER_NOT_COMBINED = "{param} cannot be combined with other unexpected parameters"
ERR_LOCAL_FILE_WRITE_FAILURE = 'Failure writing local file'
ERR_LOCAL_FILE_CREATE_FAILURE = 'Failure creating local file'
ERR_LOCAL_FILE_DOES_NOT_EXIST = 'Local file does not exist'
ERR_S3_PROCESSING_FAILURE = 'error occurred processing an s3 object'
ERR_EMAIL_SERVER_CONNECTION_FAILURE = 'Failed to connect to an email server'
ERR_NO_RECORD_FOUND = 'No request was found with the supplied parameters'
ERR_CASE_NOT_ASSIGNED = "The selected case is not assigned to a researcher"
ERR_FILE_HAS_NO_RECORDS = "The file provided has no records"
ERR_FILE_NAME_INCONSISTENT = "The provided file does not conform to expected file naming conventions"
ERR_ZIPFILE_MISSING_REQUEST_JSON = "The provided zip file does not contain a records.json in the top-most folder"
ERR_INVALID_ACCESS_KEY = "Missing or unknown accessKey in CloudServices request"
ERR_INVALID_APP_ID_FOR_ACCESS_KEY = "The supplied application ID does not match the accessKey"
ERR_INVALID_LOGIN_ID_FOR_ACCESS_KEY = "The supplied login ID does not match the accessKey"
ERR_BATCH_STUCK_IN_RECEIVED = "Batch stuck in received status"
ERR_REQUEST_STUCK_IN_RECEIVED = "Research Request stuck in received status"

ERR_ADMIN_UPDATE_ACTION_NOT_FOUND = 'Admin update action code missing'

ERR_NEW_SUBMITTER_GROUP_EMPTY = 'New submitter group is empty'
ERR_SUBMITTER_GROUP_EXISTS = 'Submitter Group already exists'
ERR_SUBMITTER_GROUP_ID_MISSING = 'Submitter Group id is missing'
ERR_SUBMITTER_GROUP_NOT_EXIST = 'Submitter Group does not exist'
ERR_SUBMITTER_GROUP_TIMESTAMP_MISSING = 'Submitter Group timestamp is missing'
ERR_SUBMITTER_GROUP_NEEDS_REFRESH = 'Submitter Group needs refresh'

ERR_RESEARCH_TEAM_ID_MISSING = 'Research Team id is missing'
ERR_RESEARCH_TEAM_NOT_EXIST = 'Research Team does not exist'
ERR_RESEARCH_TEAM_TIMESTAMP_MISSING = 'Research Team timestamp is missing'
ERR_RESEARCH_TEAM_NEEDS_REFRESH = 'Research Team needs refresh'
ERR_RESEARCH_TEAM_NOT_EXIST = 'Research Team does not exist'
ERR_USER_NOT_AUTHORIZED_TO_UPDATE_TEAM = 'User not authorized to update this team'

ERR_USER_ID_MISSING = 'ResearchUserId is required for this action.'
ERR_TIMESTAMP_MISSING = 'Timestamp is required for this action.'
ERR_ADMIN_JSON_MISSING = 'User Administration data is required for this action.'
ERR_USER_ADMIN_DATA_NEEDS_REFRESH = 'User admin data needs refresh.'
ERR_USER_NOT_EXIST = 'User does not exist.'
ERR_ADD_USER_PARAM_MISSING = "Must provide either a loginKey or userEmailAddress"
ERR_USER_EXISTS = 'User loginKey already exists'
ERR_MINIBATCH_DUP_REQUESTS = 'Too many requests in batch, investigate possible dups'
ERR_ALL_BATCH_REQUESTS_REJECTED = 'All records in the batch were rejected.'
ERR_VALUE_TOO_LONG = 'Value is too long'
ERR_BATCH_ADMIN_STATUS_MISSING = 'Batch status is missing.'
ERR_BATCH_ADMIN_PAGING_PARAM_MISSING = 'Required paging parameter missing.'
ERR_BATCH_ADMIN_PAGING_PAGE_SIZE = 'Page size has to be greater than 0.'
ERR_BATCH_ADMIN_BATCH_REQUEST_ID = 'Batch request id missing.'
ERR_BATCH_ADMIN_DUE_DATE_MISSING = 'Batch due date missing.'
ERR_BATCH_ADMIN_INCORRECT_STATUS = 'Batch is not correct status for action.'
ERR_BATCH_ADMIN_NO_SUCH_BATCH = 'No existing batch with given batch request id.'            
ERR_BATCH_ADMIN_REJECTED = 'Administrator has rejected the batch'
ERR_BATCH_ADMIN_NOT_CFP_BATCH = 'This action is only applicable for CFP batches.'
ERR_BATCH_CAMPAIGN_PRIORITY_MISSING = 'campaignPriority parameter missing.'
ERR_BATCH_CAMPAIGN_PRIORITY_PARAM_NOT_VALID = 'campaignPriority is only valid for a campaign Batch.'
ERR_BATCH_CAMPAIGN_PRIORITY_INCORRECT_CODE = 'campaignPriority value is not valid.'
ERR_BATCH_LOOKUP_RULE_PARAM_NOT_VALID = 'lookupRule is only valid for a CFP batch.'
ERR_UNSUPPORTED_ATTACHMENT_TYPE = 'Unsupported attachment type'
ERR_BAD_ATTACHMENT_FILENAME = 'Invalid attachment file name: Must consist of at least one character followed by a valid extension. Valid extensions are: '
ERR_ATTACHMENT_FILENAME_TOO_LONG = 'Invalid attachment file name, cannot be longer than 194 characters long'
ERR_UNSUPPORTED_BATCH_TYPE = 'Unsupported batch type'
ERR_ATTACHMENT_LIMIT = 'attachment limit reached'
ERR_S3_FILE_NOT_FOUND = "S3 event received but file was not found in the file tracking database"
ERR_DUP_INBOUND_STP_FILE = "Duplicate file received from STP or SFTP"
ERR_UNKNOWN_INBOUND_STP_FILENAME = "Invalid inbound STP file moved to dead file folder"
ERR_UNKNOWN_INBOUND_SFTP_FILENAME = "Invalid inbound SFTP-S3 file moved to dead file folder"
ERR_UNSUPPORTED_UPDATE_ADMIN_ACTION = "Unsupported updateAdminAction"

ERR_NEW_TEAM_GROUP_EMPTY = 'New team group is empty'
ERR_TEAM_GROUP_EXISTS = 'Team group already exists'
ERR_TEAM_GROUP_ID_MISSING = 'Team Group id is missing'
ERR_TEAM_GROUP_NOT_EXIST = 'Team Group does not exist'
ERR_TEAM_GROUP_TIMESTAMP_MISSING = 'Team Group timestamp is missing'
ERR_TEAM_GROUP_NEEDS_REFRESH = 'Team Group needs refresh'
ERR_TEAM_GROUP_REQUIRE_INTEGER = 'All items need to be an integer.'

ERR_NEW_COUNTRY_GROUP_EMPTY = 'New country group is empty'
ERR_COUNTRY_GROUP_EXISTS = 'Country group already exists'
ERR_COUNTRY_GROUP_ID_MISSING = 'Country Group id is missing'
ERR_COUNTRY_GROUP_NOT_EXIST = 'Country Group does not exist'
ERR_COUNTRY_GROUP_TIMESTAMP_MISSING = 'Country Group timestamp is missing'
ERR_COUNTRY_GROUP_NEEDS_REFRESH = 'Country Group needs refresh'
ERR_COUNTRY_GROUP_REQUIRE_STRING = 'All items need to be 2 letter strings.'

ERR_API_APP_ENTITLEMENT_ID_MISSING = 'ApiAppEntlId missing.'
ERR_API_APP_ENTITLEMENT_TIMESTAMP_MISSING = 'API App Entitlement timestamp is missing'
ERR_API_APP_ENTITLEMENT_PROCESS_OPTIONS_OBJ_MISSING = 'API App Entitlement process options object is missing'
ERR_API_APP_ENTITLEMENT_PARTNER_FOLDER_MISSING = 'API App Entitlement partner folder is missing'
ERR_API_APP_ENTITLEMENT_NOT_EXIST = 'API App Entitlement does not exist.'
ERR_API_APP_ENTITLEMENT_NEEDS_REFRESH  = 'API App Entitlement needs refresh.'
ERR_API_APP_ENTITLEMENT_PARTNER_FOLDER_NOT_UNIQUE = "Partner Folder Name already exists for another API App Entitlement.  This must be a unique value for each ApiAppEntlId." 

ERR_TRAINING_MEDIA_ID = 'trainingMediaId is missing.'
ERR_TRAINING_MEDIA_ID_NO_RESULT = 'trainingMediaId is invalid.'
ERR_TRAINING_MEDIA_ID_INVALID = 'trainingMedia must be numeric value.' 
ERR_MEDIA_TYPE = 'mediaType is missing.'
ERR_MEDIA_TITLE = 'mediaTitle is missing.'
ERR_MEDIA_CATEGORY = 'mediaCategory is missing.'
ERR_MEDIA_FILE_NAME = 'mediaFileName is missing.'
ERR_MEDIA_RANK = 'trainingMediaRating is missing.'
ERR_MEDIA_RANK_INVALID = "trainingMediaRating must be numeric value greater than or equal to 0 and less than or equal to 5."
ERR_MEDIA_PARAMS_MISSING = 'trainingMediaRating or trainingMediaAttachment are required.'
ERR_CAMPAIGN_PARAMETERS = 'campaignPriority and campaignRouting are required parameters.'
ERR_CAMPAIGN_PARAMETERS_DATATYPE = 'campaignPriority and campaignRouting must be an integer'

ERR_RESEARCH_REQUEST_ID_MISSING = 'researchRequestId is missing.'
ERR_RESEARCH_REQUEST_ID_INVALID = 'The supplied researchRequestId is invalid.'
ERR_RESEARCH_REQUEST_INCORRECT_STATUS = 'researchRequestId is not in correct status to retrigger usage.'
ERR_CANNOT_RETRIGGER_UNITY_USAGE = 'Usage cannot be retriggered for Unity.'

ERR_SUBJECT_RESEARCH_ID_MISSING = 'subjectResearchId is missing'
ERR_INTERNAL_STATUS_CODE_MISSING = 'internalStatusCode is missing'
ERR_SUBJECT_RESEARCH_ID_INVALID = 'The supplied subjectResearchId is invalid'
ERR_SUBJECT_REQUEST_INCORRECT_STATUS = 'The supplied subjectResearchId is not in the correct status for this change'
ERR_UNSUPPORTED_STATUS = 'The specified status is not supported'

ERR_BANNER_SEVERITY = 'bannerSeverity is missing.'
ERR_BANNER_NOTIFY_ROLES = 'bannerNotifyRoles is missing.'
ERR_BANNER_MESSAGE_ACTIVE_INDICATOR = 'bannerMessageActiveIndicator is missing.'
ERR_USER_ROLE_INVALID = 'bannerNotifyRoles has an invalid role.'
ERR_MESSAGE_BANNER_MISSING = 'messageBanner is missing.'
ERR_BANNER_MESSAGE_ID = 'bannerMessageId is missing.'
ERR_BANNER_UPDATES_INVALID = 'bannerTitle, bannerMessage, bannerSeverity ,bannerDismissable, bannerNotifyRoles, bannerStartDate, bannerEndDate, or bannerActive requires an update.'

ERR_MAINTENANCE_START_TIME = 'mntnStartDate is missing.'
ERR_MAINTENANCE_END_TIME = 'mntnEndDate is missing.'
ERR_MAINTENANCE_LOCKOUT_WARNING_MINUTES = 'mntnLockoutWarningMinutes is missing.'
ERR_MAINTENANCE_WINDOW_ID_NO_RESULT = 'mntnWindowId is invalid.'
ERR_MAINTENANCE_WINDOW_ID_INVALID = 'mntnWindowId must be numeric value.' 
ERR_MAINTENANCE_UPDATES = 'mntnStartDate, mntnEndDate, mntnLockoutWarningMinutes, or messageBanner requires an update.'

ERR_UNSUPPORTED_KEEPALIVE_ACTION = "Unsupported keepaliveService action."
ERR_KEEPALIVE_ACTION_NOT_FOUND = 'keepaliveAction code is missing.'
ERR_USER_SESSION_INVALID = 'User session is invalid.'