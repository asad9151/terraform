'''
Created on Mar 9, 2019

@author: VanCampK
'''
import ast
import logging
import lambdas.lambdaConstants as consts
from common.irschRoles import IResearchRole
from common.irschAdministeredRoles import IResearchAdministeredRole
from common.userTypes import UserType
from common.util.dictUtils import createUpperCaseDict
from common.requestMethodCodes import RequestMethodCode

class UserSession(object):
    '''
    Encapsulates the user's login session information
    '''

    def __init__(self, event):
        if event is None:
            self.requestContext = None
        else:
            self.requestContext = event.get(consts.EVENT_REQUEST_CONTEXT)
        self.principalId = None
        self.sessionToken = None
        self.emailId = None
        self.loginKey = None
        self.userType = None
        self.firstName = None
        self.lastName = None
        self.company = None
        self.userId = None
        self.subscriberNumber = None
        self.subscriberName = None
        self.subscriberCountry = None
        self.applicationId = None
        self.applicationTranId = None
        self.requestMethodCode = None
        self.dnbUserAPIKeyType = None
        self.dnbGUID = None
        self.dnbUserEmailAddress = None
        self.dnbSubscriberDRT = None
        self.dnbResearchRequestType = None
        self.roles = []
        self.teams = []  # researcher's teams
        self.localAdminTeams = []
        self.routing_categories = []
        self.subtype_groups = []
        self.team_groups = []
        self.country_groups = []
        if self.requestContext is None:
            return
        authorizer = self.requestContext.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER)
        if authorizer is None:
            self.parseCloudServicesEvent(event)
        else:
            self.parseAuthorizerEvent(authorizer)
            
            
    def parseAuthorizerEvent(self, authorizer):
        # Have to use ast.literal_eval() instead of json.loads() because string contains single quotes
        self.principalId = ast.literal_eval(authorizer.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID))
        if self.principalId is None:
            return
        self.sessionToken = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_SESSION_TOKEN)
        self.emailId = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_EMAIL)
        self.loginKey = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_LOGIN_KEY)
        #userTypeStr = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_USER_TYPE)
        self.userType = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_USER_TYPE, UserType.USER_TYPE_UI.value)
        #TODO set requestMethodCode according to 'applicationId'
        self.requestMethodCode = RequestMethodCode.IRESEARCH_UI.value
        self.firstName = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_FIRST_NAME)
        self.lastName = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_LAST_NAME)
        self.company = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_COMPANY)
        self.subscriberNumber = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_SUBSCRIBER_NUMBER)
        # TODO once principalId has userId field:
        #self.userId = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_USERID)
        groups = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_GROUPS)
        for group in groups:
            if IResearchRole.hasValue(group):
                self.roles.append(IResearchRole[group])
            if IResearchAdministeredRole.hasValue(group):
                self.roles.append(IResearchAdministeredRole[group])
            if group.startswith(consts.IRESEARCH_TEAM_PREFIX):
                # Add the team from iDAAS GROUPS list into the session.
                # Note that if getTeamListFromIDAAS is false, these lists will be overwritten by secureLambdaBase
                self.teams.append(group)
                self.localAdminTeams.append(group)
        self.routing_categories = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_ROUTING_CATEGORIES)
        self.subtype_groups = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_SUBTYPE_GROUPS)
        self.team_groups = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_TEAM_GROUPS)
        self.country_groups = self.principalId.get(consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_COUNTRY_GROUPS)
        
    def parseCloudServicesEvent(self, event):
        headers = createUpperCaseDict(event.get(consts.EVENT_HEADERS))
        logging.info(f"Got no authorizer so reading DNB data from headers {headers}")
        self.loginKey = headers.get(consts.EVENT_HEADER_CS_LOGINID)
        self.subscriberName = headers.get(consts.EVENT_HEADER_CS_SUBSCRIBER_NAME)
        self.subscriberNumber = headers.get(consts.EVENT_HEADER_CS_SUBSCRIBER_NUMBER)
        self.subscriberCountry = headers.get(consts.EVENT_HEADER_CS_SUBSCRIBER_COUNTRY)
        self.applicationId = headers.get(consts.EVENT_HEADER_CS_APPLICATION_ID)
        self.applicationTranId = headers.get(consts.EVENT_HEADER_CS_APPLICATION_TRANID)
        self.dnbUserAPIKeyType = headers.get(consts.EVENT_HEADER_CS_USER_API_KEY_TYPE)
        self.dnbGUID = headers.get(consts.EVENT_HEADER_CS_GUID)
        self.dnbUserEmailAddress = headers.get(consts.EVENT_HEADER_CS_USER_EMAIL_ADDRESS)
        self.dnbSubscriberDRT = headers.get(consts.EVENT_HEADER_CS_USER_SUBSCRIBER_DRT)
        self.dnbResearchRequestType = headers.get(consts.EVENT_HEADER_CS_RESEARCH_REQUEST_TYPE)

        logging.info(f"Got CS user with loginKey={self.loginKey} subscriberName={self.subscriberName} subscriberNumber={self.subscriberNumber} subscriberCountry={self.subscriberCountry} applicationId={self.applicationId} applicationTranId={self.applicationTranId}")


    def updateFromUserAdministration(self, userAdministrationDict):
        self.roles = []
        self.routing_categories = []
        self.subtype_groups = []
        self.team_groups = []
        self.country_groups = []
        iDaaSUserRoles = userAdministrationDict.get('IDaaSUserRoles')
        iResearchUserRoles = userAdministrationDict.get('iResearchUserRoles')
        researchSubTypesGroups = userAdministrationDict.get('researchSubTypesGroups')
        submitterRoutingCategories = userAdministrationDict.get('submitterRoutingCategories')
        researchTeamGroups = userAdministrationDict.get('researchTeamGroups')
        researchCountryGroups = userAdministrationDict.get('researchCountryGroups')
        if iDaaSUserRoles is not None:
            for iDaaSUserRole in iDaaSUserRoles:
                iDaaSRoleName = iDaaSUserRole.get('iDaaSRoleName')
                if IResearchRole.hasValue(iDaaSRoleName):
                    self.roles.append(IResearchRole[iDaaSRoleName])
        if iResearchUserRoles is not None:
            for iResearchUserRole in iResearchUserRoles:
                iResearchRoleName = iResearchUserRole.get('iResearchRoleName')
                if IResearchAdministeredRole.hasValue(iResearchRoleName):
                    self.roles.append(IResearchAdministeredRole[iResearchRoleName])
        if researchSubTypesGroups is not None:
            for researchSubTypesGroup in researchSubTypesGroups:
                researchSubTypesGroupCode = researchSubTypesGroup.get('researchSubTypesGroupCode')
                if researchSubTypesGroupCode is not None:
                    self.subtype_groups.append(researchSubTypesGroupCode)
        if submitterRoutingCategories is not None:
            for submitterRoutingCategory in submitterRoutingCategories:
                submitterRoutingCategoryCode = submitterRoutingCategory.get('submitterRoutingCategoryCode')
                if submitterRoutingCategoryCode is not None:
                    self.routing_categories.append(submitterRoutingCategoryCode)
        if researchTeamGroups is not None:
            for researchTeamGroup in researchTeamGroups:
                teamGroupId = researchTeamGroup.get('teamGroupId')
                if teamGroupId is not None:
                    self.team_groups.append(teamGroupId)
        if researchCountryGroups is not None:
            for researchCountryGroup in researchCountryGroups:
                countryGroupId = researchCountryGroup.get('countryGroupId')
                if countryGroupId is not None:
                    self.country_groups.append(countryGroupId)

    def __str__(self):
        return (
            f"UserSession: loginKey={self.loginKey} "
            f"userId={self.userId} "
            f"sessionToken={self.sessionToken} "
            f"emailId={self.emailId} "
            f"userType={self.userType} "
            f"firstName={self.firstName} "
            f"lastName={self.lastName} "
            f"company={self.company} "
            f"subscriberNumber={self.subscriberNumber} "
            f"subscriberName={self.subscriberName} "
            f"subscriberCountry={self.subscriberCountry} "
            f"applicationId={self.applicationId} "
            f"applicationTranId={self.applicationTranId} "
            f"roles={self.roles} "
            f"teams={self.teams} "
            f"localAdminTeams={self.localAdminTeams} "
            f"routing_categories={self.routing_categories} "
            f"subtype_groups={self.subtype_groups} "
            f"requestMethodCode={self.requestMethodCode} "
            f"team_groups={self.team_groups} "
            f"country_groups={self.country_groups} "
            f"researchRequestType={self.dnbResearchRequestType}"
        )
