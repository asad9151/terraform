'''
Created on Mar 15, 2019

@author: VanCampK
'''
import json
from common.encoders import IResearchEncoder

class LoginSessionDao(object):

    def updateActiveLoginSession(self, dbConn, userSession, sessionInactiveMinutes):
        '''
        Checks for an active session on the user/jti supplied in the session.
        If found, updates its last-access time and returns a number greater than 0.
        If not found or not active, returns 0.
        '''
        if not userSession.sessionToken:
            return 0
        
        query = '''
update lgin_ses set lst_acs_tmst=NOW()
where rsch_usr_id=(select RU.rsch_usr_id from rsch_usr RU where RU.lgin_key = %s)
and dnb_jti_val = %s
and lg_out_tmst is null
and TIMESTAMPDIFF(MINUTE,lst_acs_tmst,NOW()) < %s
and (expn_tmst is null OR expn_tmst > NOW())
        '''
        params = (userSession.loginKey, userSession.sessionToken, sessionInactiveMinutes)
        updatedRecordCount = dbConn.cursor.execute(query, params)
        '''
        if updatedRecordCount < 1:
            logging.error('updateActiveLoginSession: Updated 0 rows for loginKey=' + userSession.loginKey + ' sessionToken=' +
                           userSession.sessionToken + ' sessionInactiveMinutes=' + str(sessionInactiveMinutes) + ' query=' + query)
        ''' 
        dbConn.dbconn.commit()
        return updatedRecordCount

    
    def queryLoginSession(self, dbConn, userSession):
        '''
        Returns the login session.
        '''
        if not userSession or not userSession.sessionToken:
            return None
        
        query = '''
select *, TIMESTAMPDIFF(MINUTE,lst_acs_tmst,NOW()) as LastAccessMins, NOW(),
case when expn_tmst is null then 0 when expn_tmst > NOW() then 0 else 1 end as isExpired
from lgin_ses LS
join rsch_usr RU on RU.rsch_usr_id = LS.rsch_usr_id
where RU.lgin_key = %s
and LS.dnb_jti_val = %s
        '''
        params = (userSession.loginKey, userSession.sessionToken)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            return dict_rslt
        
        return None        

    
    def queryLoginSessionByUserIdAndToken(self, dbConn, userId, sessionToken):
        '''
        Returns the login session.
        '''
        query = '''
select * from lgin_ses where rsch_usr_id = %s and dnb_jti_val = %s
        '''
        params = (userId, sessionToken)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            return dict_rslt
        
        return None        


    def logoutUserSession(self, dbConn, userSession):
        '''
        Forces the current session to be logged out.
        '''
        if not userSession.sessionToken:
            return 0
        
        query = '''
update lgin_ses set lg_out_tmst=NOW()
where rsch_usr_id=%s
and dnb_jti_val = %s
        '''
        params = (userSession.userId, userSession.sessionToken)
        updatedRecordCount = dbConn.cursor.execute(query, params)
        dbConn.dbconn.commit()
        return updatedRecordCount

    def queryLatestUnexpiredLoginSession(self, dbConn, userSession):
        '''
        Checks to see if the current user has an unexpired session, and if so returns it.
        '''
        query = '''
select *, TIMESTAMPDIFF(MINUTE,lst_acs_tmst,NOW()) as LastAccessMins, NOW(),
case when expn_tmst is null then 0 when expn_tmst > NOW() then 0 else 1 end as isExpired
from lgin_ses LS
join rsch_usr RU on RU.rsch_usr_id = LS.rsch_usr_id
where RU.lgin_key = %s and LS.usr_typ_desc = %s
order by lgin_ses_id desc
limit 1
        '''
        params = (userSession.loginKey, userSession.userType)
        dbConn.cursor.execute(query,params)
        rv = dbConn.cursor.fetchall()
        dict_data=[]
        for result in rv:
            dict_data.append(result)
    
        # We convert it to json so we convert all the Decimals and Timestamps, then convert it back to a dictionary
        if len(dict_data) > 0:
            json_data = json.dumps(dict_data[0], cls=IResearchEncoder)
            #print(json_data)
            dict_rslt = json.loads(json_data)
            return dict_rslt
        
        return None        
