'''
Created on Mar 2, 2019
Common functions for all lambdas.

@author: VanCampK
'''
import logging
import json
from SetLambdaLogging import setLogging
from buildEnvironVarDict import buildEnvironVarDict
import lambdas.lambdaConstants as consts
from common import envVblNames
import lambdas.errorMessages as errmsg
from lambdas.userSession import UserSession
from lambdas.requestContext import RequestContext
from lambdas.exceptions import LambdaProcessingException

def createRequestContext(event, environDict, context, lambdaObj, isBodyJson=True):
    if not event:
        logging.error('createRequestContext - no data passed in the EVENT variable from Lambda')
        raise LambdaProcessingException(errmsg.ERR_INTERNAL_REQUEST)
    userSession = _getUserSessionFromEvent(event)
    requestContext = RequestContext(event, userSession, environDict, context, lambdaObj, isBodyJson)
    return requestContext

def initLambdaEnviron(event, environDict):
    if not environDict:
        setLogging(logging.INFO)
        environDict = buildEnvironVarDict()

    try:
        setLogging(environDict[envVblNames.ENV_LOGGINGLEVEL])
    except Exception as e:
        print (f'Failed to setLogging: {e}')

    logging.info ('environDict has keys: ' + ','.join(environDict.keys()))
    
    # record incoming information 
    logging.info('Lambda - incoming event = %s', event)
    return environDict

def _getUserSessionFromEvent(event):
    userSession = UserSession(event)
    return userSession
    
def logRequest(requestContext):
    details = ""
    if requestContext.method == 'POST':
        details = 'body=' + str(requestContext.body)
    elif requestContext.method == 'GET':
        if requestContext.queryParameters:
            details = 'query=' + str(requestContext.queryParameters)
    # TODO support other methods...
    logging.info('IRSCHREQUEST ' + str(requestContext.userSession) + ' path=' + str(requestContext.path) +
                 ' method=' + str(requestContext.method) + ' :' + details )

def logResponse(requestContext, responseBody):
    maxRespLogSz = 300
    envMaxRespLogSz = requestContext.environDict.get(envVblNames.ENV_MAX_RESPONSE_LOG_SIZE)
    if envMaxRespLogSz is not None:
        maxRespLogSz = int(envMaxRespLogSz)
    blen=len(responseBody)
        
    logging.info(f'IRSCHRESPONSE loginKey={requestContext.userSession.loginKey} with body (len={blen}):' + responseBody[:maxRespLogSz])
    
# Returns True only if the user has ALL of the roles in the roles array
def checkIfUserHasAllRoles(userSession, roles):
    for role in roles:
        if role not in userSession.roles:
            return False
    return True

# Returns True if the user has ANY of the roles in the roles array
def checkIfUserHasAnyRoles(userSession, roles):
    for role in roles:
        if role in userSession.roles:
            return True
    return False

def buildLambdaSecureInvokeEvent(authPrinIdStr, method, path, body=None, queryParams={}):
    # Use this to build an event that can be passed to a secureLambda when directly invoking it,
    # when the user's session is known
    event = {}
    event[consts.EVENT_SOURCE] = consts.LAMBDA_START_TYPE_SECURE_INVOKE
    authorizer = {}
    authorizer[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID] = authPrinIdStr
    requestContext = {}
    requestContext[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER] = authorizer
    event[consts.EVENT_REQUEST_CONTEXT] = requestContext
    event[consts.EVENT_METHOD] = method
    event[consts.EVENT_BODY] = body
    event[consts.EVENT_PATH] = path
    event[consts.EVENT_QUERY_PARAMS] = queryParams
    return event


'''
def buildAuthPrinIdStr(sessionToken, userEmail, userType, firstName, lastName, company, roles):
    principalId = {}
    principalId[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_SESSION_TOKEN] = sessionToken
    principalId[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_EMAIL] = userEmail
    principalId[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_USER_TYPE] = userType
    principalId[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_FIRST_NAME] = firstName
    principalId[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_LAST_NAME] = lastName
    principalId[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_COMPANY] = company
    groups = []
    for role in roles:
        groups.append(role.value)
    principalId[consts.EVENT_REQUEST_CONTEXT_AUTHORIZER_PRINCIPALID_GROUPS] = groups
    prinIdStr = json.dumps(principalId)
    return prinIdStr
'''


def invokeLambdaFunction(boto3LambdaClient, event, lambdaFunctionArn, invokeType):
    try:
        payload = json.dumps(event)
        logging.info('Invoking lambda function ' + str(lambdaFunctionArn) + ' invokeType=' + invokeType + ' with payload=%s', payload)
        response = boto3LambdaClient.invoke(
            FunctionName = lambdaFunctionArn,
            InvocationType = invokeType,
            Payload= payload
        )
    except Exception as err:
        logging.error('invokeLambdaFunction: problem invoking lambda function.  Err = %s', err)
        #raise LambdaProcessingException('Exception invoking lambda ' + lambdaFunctionArn + ' err=' + str(err))
        raise LambdaProcessingException(errmsg.ERR_INTERNAL_REQUEST)

    logging.info('Back from Invoking lambda function ' + lambdaFunctionArn + ' with response=' + str(response))
    return response


def parseHTTPStatusCodeFromInvokeResponse(response):
    # Returns metadata HTTPStatusCode from lambda invoke, or None
    # Hint: Compare to LambdaStatusCodes.OK.value
    responseMetaData = response.get('ResponseMetadata')
    if responseMetaData:
        return responseMetaData.get('HTTPStatusCode')
    
    return None


def parsePayloadFromInvokeResponse(response):
    responseStreamingPayload = response.get('Payload')
    if responseStreamingPayload:
        responsePayload = json.loads(responseStreamingPayload.read().decode("utf-8"))
        return responsePayload

    return None


def parseStatusCodeFromInvokeResponse(response):
    return response.get('StatusCode')


def parseStatusCodeFromPayload(responsePayload):
    # Returns payload statusCode from lambda invoke, or None
    # Hint: Compare to LambdaStatusCodes.OK.value
    if responsePayload:
        return responsePayload.get('statusCode')
    return None
