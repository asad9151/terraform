import logging
import json
import requests
from common.externalStatusCode import ExternalStatusCode
from common.subTypeGroups import SubTypeGroups
from decimal import Decimal
from common.util.dateUtils import isoFormatToDateTime
from requests.exceptions import RequestException

SOURCE_TYPE = 'dp_iresearch'
SOURCE='http-stream'
EXIT_WHEN_MILLISECS_LEFT = 10000
DATE_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
CANCEL_COMPLETION_CODE = 6348

class SendUsageSplunkService(object):
    sqsHelper = None
    requestContext = None
    
    def __init__(self, sqsHelper, requestContext):
        self.sqsHelper = sqsHelper
        self.requestContext = requestContext
        
        
    def sendUsageToSplunk(self):
        splunkUrl = self.requestContext.environDict['SPLUNKURL']
        splunkIndex = self.requestContext.environDict['SPLUNKINDEX']
        timeoutSecs = Decimal(self.requestContext.environDict['SPLUNKTIMEOUTSECS'])
        splunkUsername = self.requestContext.environDict['SPLUNKUSERNAME']
        splunkPassword = self.requestContext.environDict['SPLUNKPASSWORD']
        
        timeLeft = self.requestContext.lambdaContext.get_remaining_time_in_millis()
        logging.info("Time left %s" % timeLeft)
        lastException = None
        while(True and timeLeft > EXIT_WHEN_MILLISECS_LEFT):
            message = self.sqsHelper.getOneMessageFromQueue()
            logging.info("message is %s " % message)
            receipt_handle = None
            if message is not None:
                try:
                    if 'MessageId' in message:
                        logging.info('messageId is: %s ' % message['MessageId'])
                    if 'ReceiptHandle' in message and 'Body' in message:
                        receipt_handle = message['ReceiptHandle']
                        logging.info('current receipt handle is %s' %  receipt_handle)
                        messageBody = json.loads(message['Body'])
                        logging.info ('bodyDict = %s' % messageBody)
                        # messageBody is the SNS Message. Usage record is contained inside 'Message'
                        if 'Message' in messageBody:
                            usageRecord = json.loads(messageBody['Message'])
                            if self.shouldSendRec(usageRecord):
                                splunkRec = self.generateSplunkRec(usageRecord)
                                self.sendRecToSplunk(splunkRec, splunkUrl, splunkIndex, timeoutSecs, splunkUsername, splunkPassword)
                        logging.info('Deleting msg with handle %s' % receipt_handle)
                        self.sqsHelper.deleteOneMessageFromQueue(receipt_handle)
                except Exception as err:
                    if isinstance(err, RequestException):
                        logging.error('Request Exception while trying to send usage record to Splunk. Error = %s' % err)
                    else:
                        logging.error('Error sending usage record to splunk. Error = %s' % err)
                        if receipt_handle is not None:
                            logging.info('Deleting msg with handle %s' % receipt_handle)
                            self.sqsHelper.deleteOneMessageFromQueue(receipt_handle)
                    lastException = err
            else:
                break
            timeLeft = self.requestContext.lambdaContext.get_remaining_time_in_millis()
            logging.info("Time left %s" % timeLeft)
        if lastException is not None:
            raise lastException
            
    def shouldSendRec(self, usageRecord):
        if (usageRecord['request']['previousResearchStatusCode'] == ExternalStatusCode.CHALLENGED.value):
            logging.info('Previous status is challenged')
            return False
        if ('requestor' in usageRecord):
            requestor = usageRecord['requestor']
            if ('researchSubTypesGroups' in requestor):
                subTypeGroups = requestor['researchSubTypesGroups']
                if (len(subTypeGroups) > 0 and len(subTypeGroups) == 1):
                    for group in subTypeGroups: 
                        if group['researchSubTypesGroupCode'] == SubTypeGroups.MINI_SUBMITTER.value:
                            logging.info('Only one subtype group and subtype group is mini')
                            return False
        if ('usage' in usageRecord):
            usage = usageRecord['usage']
            if ('investigationCompletionTypeCode' in usage):
                investigationCompletionTypeCode = usage['investigationCompletionTypeCode']
                if investigationCompletionTypeCode == CANCEL_COMPLETION_CODE:
                    return False
        return True
            

    def sendRecToSplunk(self, splunkRec, splunkUrl, splunkIndex, timeoutSecs, splunkUsername, splunkPassword):
        splunkRecJson = json.dumps(splunkRec)
        logging.info('Splunk json %s' % splunkRecJson)
        headers = {'x-splunk-input-mode': 'streaming'}
        basicAuthCredentials = (splunkUsername, splunkPassword)
        url = splunkUrl + "?source=" + SOURCE + "&sourcetype=" + SOURCE_TYPE + "&index=" + splunkIndex
        logging.info('url: %s ' % url)
        
        logging.info('SendUsageSplunk: Before posting record.')
        response = requests.post(url = url, data = splunkRecJson, headers = headers, auth=basicAuthCredentials, timeout=timeoutSecs, verify=False)
        logging.info('SendUsageSplunk: After posting record.')
        
        logging.info(response.status_code)
        if response.status_code not in [200, 201, 202, 203, 204, 205, 206]:
            raise RequestException('Got back status code %s and response text is %s while trying to send record to splunk. ResearchRequestId is %d' % (response.status_code, response.text, splunkRec['researchRequestId']))

        
    def generateSplunkRec(self, usageRecord):
        splunkRecord = {}
        if ('notificationId' in usageRecord):
            splunkRecord['notificationId'] = usageRecord['notificationId']
        if ('usage' in usageRecord):
            usage = usageRecord['usage']
            if ('investigationPriorityTypeCode' in usage):
                splunkRecord['investigationPriorityTypeCode'] = usage['investigationPriorityTypeCode']
            if ('investigationCompletionTypeCode' in usage):
                splunkRecord['investigationCompletionTypeCode'] = usage['investigationCompletionTypeCode']
            if ('investigationTypeCode' in usage):
                splunkRecord['investigationTypeCode'] = usage['investigationTypeCode']
            if ('investigationBillingProductCode' in usage):
                splunkRecord['investigationBillingProductCode'] = usage['investigationBillingProductCode']
            if ('quantity' in usage):
                splunkRecord['quantity'] = usage['quantity']
        if ('request' in usageRecord):
            request = usageRecord['request']
            if ('researchRequestId' in request):
                splunkRecord['researchRequestId'] = request['researchRequestId']
            if ('requestMethodCode' in request):
                splunkRecord['requestMethodCode'] = request['requestMethodCode']
            if ('researchCreationTimestamp' in request):
                createDateTime = isoFormatToDateTime(request['researchCreationTimestamp'])
                splunkRecord['investigationCreationTimestamp'] = createDateTime.strftime(DATE_FORMAT)[:-3]
            if ('researchSatisfiedTimestamp' in request):
                satisfiedDateTime = isoFormatToDateTime(request['researchSatisfiedTimestamp'])
                splunkRecord['investigationSatisfiedTimestamp'] = satisfiedDateTime.strftime(DATE_FORMAT)[:-3]
            if ('researchCompletionTimestamp' in request):
                completionDateTime = isoFormatToDateTime(request['researchCompletionTimestamp'])
                splunkRecord['investigationCompletionTimestamp'] = completionDateTime.strftime(DATE_FORMAT)[:-3]
            if ('customerReferenceEmail' in request):
                splunkRecord['requestorEmailAddress'] = request['customerReferenceEmail']
        if ('requestor' in usageRecord):
            requestor = usageRecord['requestor']
            if ('loginKey' in requestor):
                splunkRecord['requestorLoginKey'] = requestor['loginKey']
            if ('subscriberNumber' in requestor):
                splunkRecord['requestorSubscriberNumber'] = requestor['subscriberNumber']
            if ('geoRefId' in requestor):
                splunkRecord['requestorGeoRefID'] = requestor['geoRefId']
            if ('iso2AlphaCountryCode' in requestor):
                splunkRecord['requestorISO2AlphaCountryCode'] = requestor['iso2AlphaCountryCode']
            if ('requestorOwnRequestKey' in requestor):
                splunkRecord['requestorOwnRequestKey'] = requestor['requestorOwnRequestKey']
        if ('subject' in usageRecord):
            subject = usageRecord['subject']
            if ('inquiredDuns' in subject):
                splunkRecord['inquiredDuns'] = subject['inquiredDuns']
            if ('answeredDuns' in subject):
                splunkRecord['answeredDuns'] = subject['answeredDuns']
            if ('organizationName' in subject):
                splunkRecord['subjectOganizationName'] = subject['organizationName']
            if ('geoRefId' in subject):
                splunkRecord['subjectGeoRefId'] = subject['geoRefId']
            if ('iso2AlphaCountryCode' in subject):
                splunkRecord['subjectISO2AlphaCountryCode'] = subject['iso2AlphaCountryCode']
            if ('territory' in subject):
                splunkRecord['subjectTerritory'] = subject['territory']
        splunkRecord['featureURI'] = self.getFeatureURI(usageRecord)

        print (splunkRecord)
        return splunkRecord
    
    def getFeatureURI(self, usageRecord):
        featureURI = ''
        priority = ''
        
        if ('request' in usageRecord):
            request = usageRecord['request']            
            if 'cases' in request:
                cases = request['cases']
                for case in cases:
                    if ('researchTypes' in case):
                        researchTypes = case['researchTypes']
                        for researchType in researchTypes:
                            typeCode = ''
                            subtypeCode = ''
                            if 'researchTypeCode' in researchType:
                                typeCode = researchType['researchTypeCode']
                            if 'researchSubTypeCode' in researchType:
                                subtypeCode = researchType['researchSubTypeCode']
                            featureURI = featureURI + str(typeCode) + '/' + str(subtypeCode) + ','
                            
        if ('usage' in usageRecord):
            usage = usageRecord['usage']
            if ('investigationPriorityTypeCode' in usage):
                priority = usage['investigationPriorityTypeCode']
                            
        featureURI = featureURI + str(priority)
                                
        return featureURI 

