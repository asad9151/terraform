'''
Created on Nov 25, 2019

@author: JafferS
'''
from lambdas.lambdaBase import LambdaBase
from lambdas.sendusagesplunk.sendUsageSplunkService import SendUsageSplunkService
from common import envVblNames
import logging
from common.util.sqsHelper import SqsHelper

class SendUsageSplunkLambda(LambdaBase):
    sqsHelper = None
    lambdaClient = None
    service = None
    s3Client = None
        
    def exitOnTimerEvent(self):
        logging.debug("*********exitTimerEvent**********")
        return False
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return False
    
    def handleRequest(self):
        logging.debug("*******handleRequest******")
        LambdaBase.raiseAlertWhenRequestFails = True
        if self.service is None:
            self.service = SendUsageSplunkService(SendUsageSplunkLambda.sqsHelper,  self.requestContext)
            
        self.service.sendUsageToSplunk()
       
        
    def initializeKeepWarm(self):
        logging.debug("*******initializeKeepWarm******")
        if SendUsageSplunkLambda.sqsHelper is None:
            try:
                if SendUsageSplunkLambda.environDict.get(envVblNames.ENV_DIRECT_PLUS_USAGE_QUEUE_URL) is not None:
                    regionName = SendUsageSplunkLambda.environDict.get(envVblNames.ENV_SQS_REGION)
                    SendUsageSplunkLambda.sqsHelper = SqsHelper(queueUrl=SendUsageSplunkLambda.environDict.get(envVblNames.ENV_DIRECT_PLUS_USAGE_QUEUE_URL), regionName=regionName)
            except:
                raise RuntimeError("SQS not configured")
                

#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = SendUsageSplunkLambda.get_handler(...)