'''
Created on Oct 29, 2019

@author: MorganB
'''
import os.path
import logging
from common.zipFiles import zipFiles
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg

def zipLocalFiles(zipDict, ymdString):
    filesToZipList = []
    zipFileName = '/tmp/usageProcessingArchive-' + ymdString + '.zip'
    
    for file in zipDict.values():
        if os.path.isfile(file):
            filesToZipList.append(file)
        else:
            logging.error('zipLocalFiles: files - %s - cannot be found - processing terminated', file)
            raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_DOES_NOT_EXIST)
    
    if len(filesToZipList) == 0:
        #we should never get here
        logging.error('zipLocalFiles: filesToZipList length = 0.  No localFiles found')
        raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_DOES_NOT_EXIST)
    
    returnedZipFile = zipFiles(filesToZipList,zipFileName)
    if returnedZipFile == None:
        logging.error('zipLocalFiles: error creating partner recon zip file ')
        raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_DOES_NOT_EXIST)
    else:
        return returnedZipFile
if __name__ == '__main__':
    pass