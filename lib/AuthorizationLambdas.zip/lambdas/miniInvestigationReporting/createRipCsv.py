'''
Created on Oct 11, 2019

@author: MorganB
'''
import collections
import logging
import copy
from common.writeCSV import writeCSV
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg

chargeBackList = ['Altares-chargeback', 
                  'Heineken-chargeback', 
                  'Bisnode-chargeback', 
                  'HDBC-chargeback',
                  'UK_delivery-chargeback',
                  'TSR-chargeback']

met_MiniInvestLineOrder = ["title", 
                           "date1",
                           "date2",
                            "item1",
                            "value",
                            "name1",
                            "phone1",
                            "email1",
                            "name2",
                            "phone2",
                            "email2",
                            "name3",
                            "phone3",
                            "email3"]

ripFormatOrder = ['Partner', 
                      'Creator_User_Id', 
                      'Originator_User_ID', 
                      'Originator_Business_entity_ID', 
                      'Recipient_User_ID', 
                      'Recipient_Business_entity_ID', 
                      'Intercompany_type_ID',         
                      'Transaction Category', 
                      'Description', 
                      'DateOfCharge', 
                      'Split_Count', 
                      'Split_Owner_1', 
                      'Account_1', 
                      'costCenter', 
                      'Function_1', 
                      'Project_1', 
                      'Foreign_Currency_1', 
                      'Foreign_Amount_Neg', 
                      'Product_1',
                      'Split_Owner_2',
                      'Account_2', 
                      'OrgUnit', 
                      'Function_2',
                      'Project_2',
                      'Foreign_Currency_2',
                      'Foreign_Amount_Pos',
                      'Product_2']
    
mon = [None,'Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']

def createRipCsv(partnerDict,ripLineItemMasterDict,reportTimesDict):
    ripList = []
    ripLine = {}
    totalRemitance = 0.0

    met_MiniInvestLineDict = {"title": "Mini Investigations",
                              "date1": "",
                              "date2": "",
                              "item1":0,
                              "value": 0,
                              "name1": "Tracey Green",
                              "phone1": "610-882-7283",
                              "email1":"greent@dnb.com",
                              "name2":"Katie Parry",
                              "phone2": "610-882-6279",
                              "email2": "ParryK@dnb.com",
                              "name3": "Tracey Green",
                              "phone3": "610-882-7283",
                              "email3": "greent@dnb.com"
                            }
    
    timeList = reportTimesDict['timeList']
    ymdString = reportTimesDict['ymdString']
    monNumber = int(timeList[1])
    descriptionText = 'Mini Inv Reimbursement-' + mon[monNumber] + ' ' + str(timeList[0])[2:]
    
    ordDict = collections.OrderedDict(sorted(partnerDict.items()))
    
    numberOfRipLineItems = 0
    for subdoc in ordDict.values():
        ripLine = copy.deepcopy(ripLineItemMasterDict)
        tallyValue = 0.0
        for k, v in subdoc.items():
            if k == 'tally':
                ripLine['Foreign_Amount_Pos'] = v
                totalRemitance += v
                ripLine['Foreign_Amount_Neg'] = v * -1
                tallyValue = v
                continue
            ripLine[k] = v
        # don't include a RIP line if there is no remittance 
        if int(ripLine['Foreign_Amount_Pos']) == 0:
            continue 
        ripLine['DateOfCharge'] = ymdString
        ripLine['Description'] = descriptionText
        numberOfRipLineItems += 1
        ### reverse the credits and debits for entities we are charging back
        ### also, walk back the amount put into the totalRemitance and then subtract the amount from totalRemitance 
        if ripLine['Partner'] in chargeBackList:
            ripLine['Foreign_Amount_Pos'] = ripLine['Foreign_Amount_Pos'] * -1
            ripLine['Foreign_Amount_Neg'] = ripLine['Foreign_Amount_Neg'] * -1
            totalRemitance += (tallyValue * -2)
        ripList.append(ripLine) 
    
    logging.info('createRipCsv - ripList = %s', ripList)
    
    ripCsvFile = '/tmp/ACT_MiniInvest-'+ ymdString + '.csv'
    
    returnedRipFileName = writeCSV(ripList,ripCsvFile,ripFormatOrder)
    if returnedRipFileName == None:
        logging.error('creatRipCsv: rip csv file not created')
        raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_WRITE_FAILURE)
    else: 
        logging.info('creatRipCsv: rip csv file - %s - create', returnedRipFileName)

        #### Rip Reconciliation File Processing (MET) #### 
    met_MiniInvestLineDict['item1'] = numberOfRipLineItems
    met_MiniInvestLineDict['date1'] = ymdString
    met_MiniInvestLineDict['date2'] = ymdString
    met_MiniInvestLineDict['value'] = totalRemitance * -1
    logging.info('MET_MiniInvestLineDict = %s', met_MiniInvestLineDict)
    ripReconCsvFile = '/tmp/met_MiniInvest-'+ ymdString + '.csv'
    ripReconList = []
    ripReconList.append(met_MiniInvestLineDict)
    
    returnedRipReconFileName = writeCSV(ripReconList,ripReconCsvFile,met_MiniInvestLineOrder)
    if returnedRipReconFileName == None:
        logging.error('creatRipCsv - rip csv recon file not created')
        raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_WRITE_FAILURE)
    else:
        logging.info('creatRipCsv: rip recon csv file - %s - create', returnedRipReconFileName)
    
    return ripCsvFile,ripReconCsvFile
if __name__ == '__main__':
    pass