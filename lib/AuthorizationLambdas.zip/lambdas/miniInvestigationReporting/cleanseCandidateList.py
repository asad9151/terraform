'''
Created on Nov 6, 2019

@author: MorganB
'''
import json
import logging
from lambdas.miniInvestigationReporting.billingIntercoHelper import isMiniLinkage

CANCELLED_TYPE = 33921
CANCELLED_SUBTYPE_LIST = [34351,33923]
RESEARCH_REQUEST_USAGE_RECORD = 2


def caseCancelled(candidate):
    if 'researchTypesForCases' in candidate['request']:
        for res in candidate['request']['researchTypesForCases']:
            for resType in res['researchTypes']:
                if 'resolutionCode' not in resType:
                    logging.error('cleanseCandidateList::caseCancelled : no resolution code found.  Proceeding as non-cancelled request')
                    return False 
                if resType['resolutionCode'] != CANCELLED_TYPE:
                    return False
        return True
    

    if 'cases' not in candidate['request']:
        return False

    for case in candidate['request']['cases']:
        for resType in case['researchTypes']:
            if 'resolutionCode' not in resType:
                logging.error('cleanseCandidateList::caseCancelled : no resolution code found.  Proceeding as non-cancelled request')
                return False 
            if resType['resolutionCode'] != CANCELLED_TYPE:
                return False
    return True
    
    
def cleanseCandidateList(candidateList,refDataObj):
    miniUsageList = []       
    for ent in candidateList:
        candidateJson =  json.loads(ent['usg_pstg_obj'])
        if candidateJson['notificationTypeCode'] != RESEARCH_REQUEST_USAGE_RECORD:
            continue
        if caseCancelled(candidateJson):
            continue
        if 'previousResearchStatusCode' in candidateJson['request']:
            if candidateJson['request']['previousResearchStatusCode'] == refDataObj.CHALLENGE_CODE_PREVIOUS_STATUS :
                continue 
        if 'previousResearchInternalStatusCode' in candidateJson['request']:
            if candidateJson['request']['previousResearchInternalStatusCode'] == refDataObj.self.CHALLENGE_CODE_PREVIOUS_INTERNAL_STATUS :
                continue
                                    
        if ('investigationTypeCode' in candidateJson['usage'] and candidateJson['usage']['investigationTypeCode'] != 13755) and isMiniLinkage(candidateJson) == False:
            continue
        miniUsageList.append(candidateJson)
 
    return miniUsageList

if __name__ == '__main__':
    pass