'''
Created on Oct 30, 2019

@author: MorganB
'''
import copy

def formatLineItem(usageEvent,partner, country_abbv,countryDict, linkageNode = None, nodeLevel = None, nodeResolutionDesc = None, approvalFormat = False, miniBillingFormat = False):
    reconFormat = False
    reconMiniBillingMasterDict = {'PARTNER': '',
                               'CUSTOMER_NAME': '',
                               'RESOLVED_DATE': '',
                               'DUNS': '',
                               'BUSINESS_NAME': '',
                               'COUNTRY_NAME': '',
                               'CORRESPONDING_OFFICE': '',
                               'CORRESPONDING_GROUP': '',
                               'REGION': ''
                               }
        
    reconLineItemMasterDict = {'PARTNER': '',
                               'CUSTOMER_NAME': '',
                               'CUSTOMER_COUNTRY': '',
                               'REQUEST_METHOD_CODE': '',
                               'RESOLVED_DATE': '',
                               'DUNS': '',
                               'BUSINESS_NAME': '',
                               'COUNTRY_NAME': '',
                               'CORRESPONDING_OFFICE': '',
                               'CORRESPONDING_GROUP': '',
                               'REGION': '',
                               'NODE_LEVEL': '',
                               'REQUESTOR_OWN_REQUEST_KEY': '',
                               'RESOLUTION_AT_NODE_LEVEL': '',
                               'REQUEST_ID': ''
                               }


    approvalLineItemMasterDict = {'PARTNER': '',
                               'CUSTOMER_NAME': '',
                               'RESOLVED_DATE': '',
                               'DUNS': '',
                               'BUSINESS_NAME': '',
                               'COUNTRY_NAME': '',
                               'CORRESPONDING_OFFICE': '',
                               'CORRESPONDING_GROUP': '',
                               'REGION': '',
                               'COST': ''
                               }
    if approvalFormat:
        lineItemDict = copy.deepcopy(approvalLineItemMasterDict)
    elif miniBillingFormat:
        lineItemDict = copy.deepcopy(reconMiniBillingMasterDict)
    else:
        reconFormat = True
        lineItemDict = copy.deepcopy(reconLineItemMasterDict)
    
    lineItemDict['PARTNER'] = partner
    if 'organizationName' in usageEvent['requestor']:
        lineItemDict['CUSTOMER_NAME'] = usageEvent['requestor']['organizationName']
    else:     
        lineItemDict['CUSTOMER_NAME'] = ' '
    lineItemDict['RESOLVED_DATE'] = ' '
    if linkageNode is None:
        lineItemDict['RESOLVED_DATE'] = usageEvent['request']["researchCompletionTimestamp"].split('T')[0]
    else:
        if 'resolutionTimestamp' in linkageNode:
            lineItemDict['RESOLVED_DATE'] = linkageNode['resolutionTimestamp'].split('T')[0]
    lineItemDict['DUNS'] = ' '
    if linkageNode is None:
        if 'answeredDuns' in usageEvent['subject']:
            lineItemDict['DUNS'] = usageEvent['subject']['answeredDuns']
    else:
        if 'duns' in linkageNode:
            lineItemDict['DUNS'] = linkageNode['duns']
    lineItemDict['BUSINESS_NAME'] = ' '
    if linkageNode is None:
        if 'organizationName' in usageEvent['subject']: 
            lineItemDict['BUSINESS_NAME'] = usageEvent['subject']['organizationName']
    else:
        if 'organizationName' in linkageNode:
            lineItemDict['BUSINESS_NAME'] = linkageNode['organizationName']

    lineItemDict['COUNTRY_NAME'] = countryDict[country_abbv]['Country']
    lineItemDict['CORRESPONDING_OFFICE'] = countryDict[country_abbv]['Corresponding_Office']
    lineItemDict['CORRESPONDING_GROUP'] = countryDict[country_abbv]['Corresponding_Group']
    lineItemDict['REGION'] = countryDict[country_abbv]['Region']
    
    if reconFormat:
        if 'requestorOwnRequestKey' in usageEvent['requestor']:
            lineItemDict['REQUESTOR_OWN_REQUEST_KEY'] = usageEvent['requestor']['requestorOwnRequestKey']
        if 'researchRequestId' in usageEvent['request']:
            lineItemDict['REQUEST_ID'] = usageEvent['request']['researchRequestId']
        if 'iso2AlphaCountryCode' in usageEvent['requestor']:
            requestorCountryCode = usageEvent['requestor']['iso2AlphaCountryCode']
            if requestorCountryCode is not None and requestorCountryCode in countryDict:
                lineItemDict['CUSTOMER_COUNTRY'] = countryDict[requestorCountryCode]['Country']   
        if nodeResolutionDesc is not None:
            lineItemDict['RESOLUTION_AT_NODE_LEVEL'] = nodeResolutionDesc
        if nodeLevel is not None:
            lineItemDict['NODE_LEVEL'] = nodeLevel
        if 'requestMethodCode' in usageEvent['request']:
            lineItemDict['REQUEST_METHOD_CODE'] = usageEvent['request']['requestMethodCode']
    
    ## for charging approval processing 
    if approvalFormat:
        if 'billingCharge' in usageEvent:
            lineItemDict['COST'] = usageEvent['billingCharge']
            
    return lineItemDict          

if __name__ == '__main__':
    pass