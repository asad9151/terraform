'''
Created on Nov 6, 2019

@author: JafferS
'''
from common.researchTypeCode import ResearchTypeCode

def isMiniLinkage(candidateJson):
    isMiniLinkage = False
    if 'request' in candidateJson:
            if 'cases' in candidateJson['request']:
                cases = candidateJson['request']['cases']
                for case in cases:
                    if 'researchTypes' in case:
                        for researchType in case['researchTypes']:
                            if 'researchTypeCode' in researchType:
                                if researchType['researchTypeCode'] == ResearchTypeCode.MINI_LINKAGE.value:
                                    isMiniLinkage = True
                                    break
    return isMiniLinkage

if __name__ == '__main__':
    pass