import logging
from common.requestMethodCodes import RequestMethodCode as APPL
from lambdas.miniInvestigationReporting.billingIntercoHelper import isMiniLinkage
    
def analyzeUsageList(miniUsageList, ripRefDataObj): 
    ripableList = [] 
    miniBillableList = []    
    minLinkageBillableList = []  
    ripLikeList = [APPL.DNB_DIRECT_PLUS.value, APPL.IRESEARCH_UI.value, APPL.ER_AND_C.value, APPL.GOVT_PORTAL.value, APPL.CUSTOMER_FILE_PROCESSING.value, APPL.MINI_PORTAL.value, APPL.SALES_FORCE.value, APPL.ASCENT_EXCLUSIONS.value, APPL.ASCENT_VIOLATIONS.value, APPL.ASCENT_SAMUEI.value] 

    for usageEvent in miniUsageList:
        isMiniLinkageInd = isMiniLinkage(usageEvent)
        if isMiniLinkageInd:
            minLinkageBillableList.append(usageEvent)
        application = usageEvent['request']['requestMethodCode']
        if application in ripLikeList:
            # mini linkage interco
            if isMiniLinkageInd:
                ripableList.append(usageEvent)
                continue
            
            '''
            Interco for Mini subtypes  will be generated to pay the mini-investigation team for completing the research, if user has the Routing Flag of 'Mini Investigation' (34414).
            Billing will be generated if the user only has research sub-type group of Mini Submitter (34448), has the Routing Flag of 'Mini Investigation' (34414), and 
            the request is from the UI or Mini Portal.
            '''
            if 'submitterRoutingCategories' not in usageEvent['requestor'] or len(usageEvent['requestor']['submitterRoutingCategories']) == 0:
                continue

            for codes in usageEvent['requestor']['submitterRoutingCategories']:
                if codes['submitterRoutingCategoryCode'] == ripRefDataObj.MINI_SUBMITTER_ROUTING_CATEGORY:
                    ripableList.append(usageEvent) 
                    if application == APPL.IRESEARCH_UI.value or application == APPL.MINI_PORTAL.value:
                        if 'researchSubTypesGroups' in usageEvent['requestor']:
                            if (len(usageEvent['requestor']['researchSubTypesGroups']) > 0 and len(usageEvent['requestor']['researchSubTypesGroups']) == 1):
                                for group in usageEvent['requestor']['researchSubTypesGroups']:
                                    if group['researchSubTypesGroupCode'] == ripRefDataObj.MINI_SUBSCRIBER_SUBTYPE_GROUP:
                                        miniBillableList.append(usageEvent)
                    break
            continue


    # this log statement, if uncommented, should be outside the for loop
    # logging.info(f'ripableList:  {ripableList},  miniBillableList: {miniBillableList}, minLinkageBillableList: {minLinkageBillableList}')
    return ripableList,miniBillableList,minLinkageBillableList

if __name__ == '__main__':
    pass