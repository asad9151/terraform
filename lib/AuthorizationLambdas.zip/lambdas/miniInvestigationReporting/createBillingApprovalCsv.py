'''
Created on Nov 22, 2019

@author: MorganB
'''
import logging
from common.writeCSV import writeCSV
# from common.zipFiles import zipFiles
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg

def createBillingApprovalCsv(custApprovalItemList,customer, reportTimesDict):
    approvalFormatOrder = ['COST',
                           'CUSTOMER_NAME',
                           'RESOLVED_DATE',
                           'DUNS',
                           'BUSINESS_NAME',
                           'COUNTRY_NAME',
                           'CORRESPONDING_OFFICE',
                           'CORRESPONDING_GROUP',
                           'REGION',
                           'PARTNER']
    totalLineDict = {}
    totalLineDict['COST'] = 0.0
    totalLineDict['CUSTOMER_NAME'] = ' ' 
    totalLineDict['RESOLVED_DATE'] = ' '
    totalLineDict['DUNS'] = ' '
    totalLineDict['BUSINESS_NAME'] = ' '
    totalLineDict['COUNTRY_NAME'] = ' '
    totalLineDict['CORRESPONDING_OFFICE'] = ' '
    totalLineDict['CORRESPONDING_GROUP'] = ' '
    totalLineDict['REGION'] = ' '
    totalLineDict['PARTNER'] = ' '
     
    logging.info('createBillingApprovalCsv: billingApprovalDict = %s', custApprovalItemList)
    ymdString = reportTimesDict['ymdString']
    custApprovalCsvFileName = '/tmp/CustomerChargeReconciliation-' + ymdString + '-' + customer + '.csv'
    total = 0.0
    for rec in custApprovalItemList:
        total = total + float(rec['COST'])
    totalLineDict['COST'] = total
    custApprovalItemList.append(totalLineDict)
        
    returnedFileName = writeCSV(custApprovalItemList,custApprovalCsvFileName,approvalFormatOrder)
    if returnedFileName == None:
        logging.error('createBillingApprovalCsv: error in writeCSV for: customer %s',customer)
        raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_CREATE_FAILURE)
    return returnedFileName

if __name__ == '__main__':
    pass