'''
Created on Oct 21, 2019

@author: MorganB
'''

import logging
from common.writeCSV import writeCSV
from common.zipFiles import zipFiles
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg

def createPartnerReconCsv(reconReportList, reportTimesDict):
    reconFormatOrder = ['PARTNER',
                        'CUSTOMER_NAME',
                        'CUSTOMER_COUNTRY',
                        'REQUEST_METHOD_CODE',
                        'RESOLVED_DATE',
                        'DUNS',
                        'BUSINESS_NAME',
                        'COUNTRY_NAME',
                        'CORRESPONDING_OFFICE',
                        'CORRESPONDING_GROUP',
                        'REGION',
                        'NODE_LEVEL',
                        'REQUESTOR_OWN_REQUEST_KEY',
                        'RESOLUTION_AT_NODE_LEVEL',
                        'REQUEST_ID']
    
    logging.info('createReconCsv: reconReportList = %s', reconReportList)
    ymdString = reportTimesDict['ymdString']
    
    sortedPartnerDict = {}
    masterList = []
    for x in reconReportList:
        if x['PARTNER'] not in sortedPartnerDict:
            sortedPartnerDict[x['PARTNER']] = []
        sortedPartnerDict[x['PARTNER']].append(x)
    
    partnerCSVList = []
    for partner, recordList in sortedPartnerDict.items():
        partnerReconCsvFile = '/tmp/PartnerReconciliation-' + ymdString + '-' + partner + '.csv'
        returnedFileName = writeCSV(recordList,partnerReconCsvFile,reconFormatOrder)
        if returnedFileName == None:
            logging.error('createPartnerReconCsv: error in writeCSV for: partner %s',partner)
            continue
        partnerCSVList.append(partnerReconCsvFile)
        masterList.extend(recordList)
    
    masterPartnerReconCsvFile = '/tmp/MasterPartnerReconciliation-' + ymdString + '.csv'
    masterReturnedFileName = writeCSV(masterList,masterPartnerReconCsvFile,reconFormatOrder)
    if masterReturnedFileName == None:
        logging.error('createPartnerReconCsv: error in writeCSV for master file')   
    else:
        partnerCSVList.append(masterPartnerReconCsvFile)
    
    zipFileName = '/tmp/PartnerReconciliationZip-'+ ymdString + '.zip'
    returnedZipFile = zipFiles(partnerCSVList,zipFileName)
    if returnedZipFile == None:
        logging.error('createPartnerReconCsv: error creating partner recon zip file ')
        raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_CREATE_FAILURE)
    else:
        return returnedZipFile
        
if __name__ == '__main__':
    pass
