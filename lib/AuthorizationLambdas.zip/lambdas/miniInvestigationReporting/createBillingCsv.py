'''
Created on Oct 30, 2019

@author: MorganB
''' 
import logging 
from common.writeCSV import writeCSV
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg

def createBillingCsv(billingReportList,reportTimesDict):
    reconBillingOrder = ['CUSTOMER_NAME',
                        'RESOLVED_DATE',
                        'DUNS',
                        'BUSINESS_NAME',
                        'COUNTRY_NAME',
                        'CORRESPONDING_OFFICE',
                        'CORRESPONDING_GROUP',
                        'REGION',
                        'PARTNER'] 
 
    ymdString = reportTimesDict['ymdString']
    billingCsvFile = '/tmp/CustomerBillingReport-' + ymdString + '.csv'

    returnedFileName = writeCSV(billingReportList,billingCsvFile,reconBillingOrder)
    if returnedFileName == None:
        logging.error('createBillingCsv - error writing to local file for billing report')
        raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_WRITE_FAILURE)
    else:
        logging.info('createBillingCsv - CSV billing file written to local storage')

    return returnedFileName

if __name__ == '__main__':
    pass