'''
Created on Oct 29, 2019

@author: MorganB
'''
from datetime import datetime

def getReportTimes(reportDay):
    
    reportTimeDict = {}
    reportTimeDict['reportTime'] = datetime.now()
    if reportDay != 'all':
        adjustTime = reportTimeDict['reportTime'].replace(day=int(reportDay) ,hour=23, minute=59, second=59)
        reportTimeDict['reportTime'] = adjustTime
        
    reportTimeDict['timeList'] = reportTimeDict['reportTime'].strftime("%Y %m %d").split(' ')
    reportTimeDict['ymdString'] = reportTimeDict['timeList'][0]+reportTimeDict['timeList'][1]+reportTimeDict['timeList'][2]
    return reportTimeDict

if __name__ == '__main__':
    d = getReportTimes('all')
    print (d)