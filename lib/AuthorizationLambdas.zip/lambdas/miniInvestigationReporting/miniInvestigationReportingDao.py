'''
Created on Oct 11, 2019

@author: MorganB
'''
import logging
import json

class miniInvestigationReportingDao(object):
    '''
    classdocs
    '''
    def __init__(self, dbConn, reportTimesDict):
        self.dbConn = dbConn
        self.startingRecord = 0
        self.endingRecord = 0
        self.reportTime = reportTimesDict['reportTime']

    def findStartingLocation(self, processId):
        findStartSQL = 'SELECT endg_usg_pstg_id FROM extr_usg_evnt where bilg_func_typ_desc = %s ORDER BY row_cre_tmst desc LIMIT 1;'
        self.dbConn.cursor.execute(findStartSQL,processId)
        res = self.dbConn.cursor.fetchall()
        if len(res) != 1:
            previousLastRecordProcessed = 0
        else:
            previousLastRecordProcessed = list(res[0].values())[0]
        self.startingRecord = previousLastRecordProcessed + 1
        return previousLastRecordProcessed
    
    def getUnprocessedRecords(self,processId,startRecordNumberOverride):
        unprocessedRecordSQL= 'SELECT usg_pstg_id,usg_pstg_obj,row_cre_tmst FROM usg_pstg where usg_pstg_id > %s and row_cre_tmst < %s and v_notif_typ_cd = 2 order by usg_pstg_id asc;'
        
        ## if startrecordNumberOverride is not 'None', that means that an override was submitted through a file in an S3 bucket
        if startRecordNumberOverride == None:
            try:
                lastProcessedRecord = self.findStartingLocation(processId)
            except Exception as e:
                logging.error('miniInvestigationReportingDao - error returned from findStaringLocation in getUnprocessedRecords.  Error = %s ',e)
                raise
        else:
            lastProcessedRecord = int(startRecordNumberOverride) - 1
            self.startingRecord = int(startRecordNumberOverride)
        
        logging.info('miniInvestigationReportingDao - Record to start processing = %s', lastProcessedRecord)
        self.dbConn.cursor.execute(unprocessedRecordSQL,(lastProcessedRecord, self.reportTime))
        candidateRecordList = self.dbConn.cursor.fetchall()
        
        if len(candidateRecordList) == 0:
            logging.info('miniInvestigationReportingDao - no records found on database to process in this invocation ')
            return None
        else:
            self.endingRecord = candidateRecordList[-1]['usg_pstg_id']
            logging.info('miniInvestigationReportingDao - Last record being processed in this invocation = %s', self.endingRecord)
            return candidateRecordList
        
    def updateTrackingDatabase(self, s3ObjectName, miniInvestigationRecordCount):
        logging.info('miniInvestigationReportingDao - updating the tracking database')
        
        bilg_func_typ_desc = 'mini-investigation'
        strt_usg_pstg_id = self.startingRecord 
        endg_usg_pstg_id = self.endingRecord
        extr_fle_rec_cnt = miniInvestigationRecordCount
        usg_extr_info_obj = {
                                "destinationSystemDescription": "mini-investigation processing"
                                }
        row_crer_id_txt = 'miniInvestigationReporting'
        row_modr_id_txt = 'miniInvestigationReporting'         
        artifactList = []
        artifactList.append(s3ObjectName)
        usg_extr_info_obj['usageFilesLocation'] = artifactList
        
        trackingRecordSqlValues = (bilg_func_typ_desc,
                                        strt_usg_pstg_id,
                                        endg_usg_pstg_id,
                                        extr_fle_rec_cnt,
                                        json.dumps(usg_extr_info_obj),
                                        row_crer_id_txt,
                                        row_modr_id_txt)
        trackingRecordSqlStatement = '''INSERT INTO extr_usg_evnt 
                                            (extr_tmst,  
                                            bilg_func_typ_desc,
                                            strt_usg_pstg_id, 
                                            endg_usg_pstg_id, 
                                            extr_fle_rec_cnt,
                                            usg_extr_info_obj,  
                                            row_crer_id_txt,  
                                            row_modr_id_txt) 
                                            VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s)'''
        try:
            self.dbConn.cursor.execute(trackingRecordSqlStatement, trackingRecordSqlValues)
        except Exception as e:
            logging.error('miniInvestigationReportingDao - error updating tracking table.  error = %s ',e)
            raise 
            