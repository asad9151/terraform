'''
Created on Oct 1, 2019

@author: MorganB
'''
import logging 
from lambdas.miniInvestigationReporting.createRipCsv import createRipCsv
from lambdas.miniInvestigationReporting.createBillingCsv import createBillingCsv
from lambdas.miniInvestigationReporting.createMiniLinkageBillingCsv import createMiniLinkageBillingCsv
from lambdas.miniInvestigationReporting.billingIntercoHelper import isMiniLinkage
from lambdas.miniInvestigationReporting.createPartnerReconCsv import createPartnerReconCsv
from lambdas.miniInvestigationReporting.createBillingApprovalCsv import createBillingApprovalCsv
from lambdas.miniInvestigationReporting.zipLocalFiles import zipLocalFiles
from lambdas.miniInvestigationReporting.formatLineItem import formatLineItem
from lambdas.miniInvestigationReporting.cleanseCandidateList import cleanseCandidateList
from lambdas.miniInvestigationReporting.analyzeUsageList import analyzeUsageList
from lambdas.miniInvestigationReporting.emailReports import emailReports
from common.util.dateUtils import isoFormatToDateTime
from common.scotsTables import ScotsTable
from common.zipFiles import zipFiles
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg
import json

class miniInvestigationReportingService(object):
    '''
    classdocs
    '''

    def __init__(self,environDict, ripRefDataObj,reportTimesDict, scots_dict, scotsDao):
        self.miniInvestigationSubTypes = {"address":33549,
                                          "newDunsMini": 33575,
                                          "businessName": 33550,
                                          "ceo": 33552,
                                          "SIC": 33554,
                                          "telephone": 33555,
                                          "legalStructure": 33538}
        
        self.environDict = environDict
        self.countryDict = ripRefDataObj.getCountryDict()
        self.partnerDict = ripRefDataObj.getPartnerDict()
        self.miniLinkageChargeDict = ripRefDataObj.getMiniLinkageChargesDict()
        self.ripLineItemMasterDict = ripRefDataObj.getRipFormatDict()
        self.ripRefDataObj = ripRefDataObj
        self.reportTimesDict = reportTimesDict
        self.usageList = []
        self.ripableList = []
        self.miniBillableList = []
        self.minLinkageBillableList = []
        self.partnerRipReport = []
        self.backupReportList = []
        self.miniLinkageBillingDict = {}
        self.billingApprovalDict = {}
        self.billingApprovalDict['altares'] = []
        self.billingApprovalDict['heineken'] = []
        self.billingApprovalDict['bisnode'] = []
        self.billingApprovalDict['hdbc'] = [] 
        self.billingApprovalDict['tsr'] = [] 
        self.localFiles = {}
        self.ripRecordsFound = False 
        self.billingRecordsFound = False
        self.ALTARES_PARTNER_NO = '41'
        self.HDBC_PARTNER_NO = '44'
        self.HEINEKEN_PARTNER_NO = '42'
        self.BISNODE_PARTNER_NO = '43'
        self.TSR_PARTNER_NO = '45'
        self.scots_dict = scots_dict
        self.scotsDao = scotsDao

    
        
    def processCandidateUsageRecords(self,candidateList):
        
        self.usageList = cleanseCandidateList(candidateList,self.ripRefDataObj)
        
        if len(self.usageList) == 0:
            logging.warning('error in miniInvestigationReportingService: no usageList returned from cleanseCandidateList') 
            return None, 0

        try:
            self.ripableList, self.miniBillableList, self.minLinkageBillableList = analyzeUsageList(self.usageList,self.ripRefDataObj)
        except Exception as e:
            logging.error('error in miniInvestigationReportingService:analyzeUsageList.  Error = %s', e)
            raise 
        
        try: 
            if len(self.ripableList) != 0:
                self.createRipAndReconReport(self.ripableList)
            else:
                logging.warning('miniInvestigationReportingService: no RIPable records identified ')
        except Exception as e:
            logging.error('error in miniInvestigationReportingService generating RIP csv reports.  Error = %s',e)
            raise 
        
        try: 
            if len(self.miniBillableList) != 0:
                self.createMiniBillingReport(self.miniBillableList)
            else:
                logging.warning('miniInvestigationReportingService: no mini billable records identified ')
        except Exception as e:
            logging.error('error in miniInvestigationReportingService generating Mini Billing csv reports.  Error = %s',e)
            raise 
        
        try: 
            if len(self.minLinkageBillableList) != 0:
                self.createMiniLinkageBillingReport(self.minLinkageBillableList)
            else:
                logging.warning('miniInvestigationReportingService: no Mini linkage billing records identified ')
        except Exception as e:
            logging.error('error in miniInvestigationReportingService generating Mini linkage Billing csv reports.  Error = %s',e)
            raise
        
        # no RIPable or billable records produced
        if len(self.miniBillableList) == 0 and len(self.ripableList) == 0 and len(self.minLinkageBillableList) == 0:
            return None, 0
        
        # for the customers we charge, we need to send them a report where they approval the expenses before they are applied
        # if at least one of the customers for which we need to get approval has records, process the list.  Figure out which
        # customer(s) we need to process in the createBillingApprovalReport function 
        for customer in self.billingApprovalDict:
            if len(customer) != 0:
                try:
                    self.createBillingApprovalReport(self.billingApprovalDict)
                except Exception as e:
                    logging.error('miniInvestigationReportingService - error returned from createBilingApprovalReport.  Error = %s ',e)
                    raise
                break
        
        try: 
            zippedFile = zipLocalFiles(self.localFiles, self.reportTimesDict['ymdString'])
            return zippedFile, len(self.usageList)
        except Exception as e:
            logging.error('miniInvestigationReportingService - error in artifact zip processing.  Error = %s ',e)
            raise

    
    def createRipAndReconReport(self,ripableList):
        logging.info ('miniInvestigationReportingService - entering createRipAndReconReport function')
        reconReportList = []
        for usageEvent in ripableList:
            if isMiniLinkage(usageEvent):
                if 'cases' not in usageEvent['request'] or  ('cases' in usageEvent['request'] and len(usageEvent['request']['cases']) == 0):
                    continue
                case = usageEvent['request']['cases'][0]
                if 'researchResult' not in case:
                    continue
                if 'linkageNodes' not in case['researchResult'] or ('linkageNodes' in case['researchResult'] and len(case['researchResult']['linkageNodes']) == 0):
                    continue
                nodes = case['researchResult']['linkageNodes']
                nodeNumber = 0
                for node in nodes:
                    nodeNumber = nodeNumber + 1
                    if 'resolutionCode' not in node:
                        continue
                    if 'countryCode' not in node:
                        continue
                    countryCode = node['countryCode']
                    if 'addedByResearcherIndicator' in node and node['addedByResearcherIndicator'] == True:
                        if countryCode not in self.countryDict:
                            continue
                        if self.countryDict[countryCode]['PartnerNo'] == '0':
                            continue
                        partnerNo = self.countryDict[countryCode]['PartnerNo']
                        reimbursement = float(self.countryDict[countryCode]['Reimbursement'])
                        try:
                            self.partnerDict[partnerNo]['tally'] = self.partnerDict[partnerNo]['tally'] + reimbursement
                        except Exception as e:
                            logging.error("TALLY ADD ERRROR Error = %s", e)
                        nodeResolutionDesc = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.RESOLUTION.value, node['resolutionCode'] , langId=None)
                        reconReportList.append(formatLineItem(usageEvent,
                                                self.partnerDict[partnerNo]['Partner'],
                                                countryCode, 
                                                self.countryDict,
                                                linkageNode = node,
                                                nodeLevel = nodeNumber,
                                                nodeResolutionDesc = nodeResolutionDesc))
                        
            else:
                if 'iso2AlphaCountryCode' not in usageEvent['subject']:
                    continue
                countryCode = usageEvent['subject']['iso2AlphaCountryCode']
                if countryCode not in self.countryDict:
                    continue
                self.specialUsageEventProcessing(usageEvent,countryCode, self.countryDict[countryCode]['Reimbursement']) 
                if self.countryDict[countryCode]['PartnerNo'] == '0':
                    continue
                partnerNo = self.countryDict[countryCode]['PartnerNo']
                reimbursement = float(self.countryDict[countryCode]['Reimbursement'])
                try:
                    self.partnerDict[partnerNo]['tally'] = self.partnerDict[partnerNo]['tally'] + reimbursement
                except Exception as e:
                    logging.error("TALLY ADD ERRROR Error = %s", e)
            
                reconReportList.append(formatLineItem(usageEvent,
                                                       self.partnerDict[partnerNo]['Partner'],
                                                       countryCode, 
                                                       self.countryDict))
            
        try:
            self.localFiles['ripCsv'], self.localFiles['ripReconCsv'] = createRipCsv(self.partnerDict,self.ripLineItemMasterDict,self.reportTimesDict)
        except Exception as e:
            logging.error('miniInvestigationReportingService: error detected in createRipCsv processing .  Error = %s', e)
            raise
        
        try:
            self.localFiles['partnerReconCsv'] = createPartnerReconCsv(reconReportList, self.reportTimesDict)
            return
        except Exception as e:
            logging.error('miniInvestigationReportingService: error detected in createPartnerReconCsv. Error = %s', e)
            raise 
       
    
    def createMiniBillingReport(self, billableList):
        logging.info ('miniInvestigationReportingService - entering createBillingReport function')
        billingReportList = []
        for usageEvent in billableList:
            if 'iso2AlphaCountryCode' not in usageEvent['subject']:
                continue
            countryCode = usageEvent['subject']['iso2AlphaCountryCode']
            if countryCode not in self.countryDict:
                continue
            partnerNo = self.countryDict[countryCode]['PartnerNo']
            
            if partnerNo == '0':
                partner = 'N/A'
            else:            
                partner = self.partnerDict[partnerNo]['Partner']
            
            billingReportList.append(formatLineItem(usageEvent,
                                                         partner,
                                                         countryCode, 
                                                         self.countryDict, miniBillingFormat = True))
        try:
            self.localFiles['billingCsv'] = createBillingCsv(billingReportList,self.reportTimesDict)
        except Exception as e:
            logging.error('miniInvestigationReportingService: error detected in createBillingCsv. Error = %s', e)
            raise 
        
    def createMiniLinkageBillingReport(self, minLinkageBillableList):
        dateFormat = "%m/%d/%Y"
        logging.info ('minLinkageBillableList = %s',json.dumps(minLinkageBillableList)) 
        logging.info ('miniInvestigationReportingService - entering createMiniLinkageBillingReport function')
        self.miniLinkageBillingDict = {}
        for usageEvent in minLinkageBillableList:
            if 'organizationName' not in usageEvent['requestor']:
                continue
            customer = usageEvent['requestor']['organizationName'].strip().lower()
            if customer not in self.miniLinkageBillingDict:
                self.miniLinkageBillingDict[customer] = {}
                self.miniLinkageBillingDict[customer]['recs'] = []
                self.miniLinkageBillingDict[customer]['TotalINVForCustomer'] = 0
                self.miniLinkageBillingDict[customer]['TotalFABForCustomer'] = 0
                self.miniLinkageBillingDict[customer]['GrandTotalForCustomer'] = 0
            if 'cases' not in usageEvent['request'] or  ('cases' in usageEvent['request'] and len(usageEvent['request']['cases']) == 0):
                continue
            case = usageEvent['request']['cases'][0]
            if 'researchResult' not in case:
                continue
            rec = {}
            rec['Total INV'] = 0
            rec['Total FAB'] = 0
            rec['Grand Total'] = 0
            rec['Request Id'] = usageEvent['request']['researchRequestId']
            if 'requestorOwnRequestKey' in usageEvent['requestor']:
                rec['Account Number'] = usageEvent['requestor']['requestorOwnRequestKey']
            if 'researchCompletionTimestamp' not in usageEvent['request']:
                continue
            completeDateTime = isoFormatToDateTime(usageEvent['request']['researchCompletionTimestamp'])
            rec['Date Completed'] = completeDateTime.strftime(dateFormat)
            if 'linkageNodes' not in case['researchResult'] or ('linkageNodes' in case['researchResult'] and len(case['researchResult']['linkageNodes']) == 0):
                continue
            nodes = case['researchResult']['linkageNodes']
            lvlOneNode = nodes[0]
            if 'countryCode' not in lvlOneNode:
                continue
            countryCode = lvlOneNode['countryCode']
            if countryCode not in self.miniLinkageChargeDict:
                continue
            countryChargeRec = self.miniLinkageChargeDict[countryCode]

            rec['Lvl 1 Outcome'] = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.RESOLUTION.value, lvlOneNode['resolutionCode'] , langId=None) 
            rec['Lvl 1 Country'] = countryChargeRec['Country']
            rec['Lvl 1 Inv'] = float(countryChargeRec['INVCharge'])
            rec['Lvl 1 FAB'] = float(countryChargeRec['FABCharge'])

            rec['Total INV'] = rec['Lvl 1 Inv']
            rec['Total FAB'] = rec['Lvl 1 FAB']
            rec['Grand Total'] = rec['Lvl 1 Inv'] + rec['Lvl 1 FAB']
            if len(nodes) > 1:
                lvlTwoNode = nodes[1]
                if 'countryCode' not in lvlTwoNode:
                    continue                
                countryCode = lvlTwoNode['countryCode']
                if countryCode not in self.miniLinkageChargeDict:
                    continue
                countryChargeRec = self.miniLinkageChargeDict[countryCode]
                    
                rec['Lvl 2 Outcome'] = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.RESOLUTION.value, lvlTwoNode['resolutionCode'] , langId=None) 
                rec['Lvl 2 Country'] = countryChargeRec['Country']
                rec['Lvl 2 Inv'] = float(countryChargeRec['INVCharge'])
                rec['Lvl 2 FAB'] = float(countryChargeRec['FABCharge'])
                rec['Total INV'] = rec['Total INV'] + rec['Lvl 2 Inv']
                rec['Total FAB'] = rec['Total FAB'] + rec['Lvl 2 FAB']
                rec['Grand Total'] = rec['Grand Total'] + rec['Lvl 2 Inv'] + rec['Lvl 2 FAB']
            if len(nodes) > 2:
                lvlThreeNode = nodes[len(nodes) - 1]
                if 'countryCode' not in lvlThreeNode:
                    continue  
                countryCode = lvlThreeNode['countryCode']
                if countryCode not in self.miniLinkageChargeDict:
                    continue
                countryChargeRec = self.miniLinkageChargeDict[countryCode]
                rec['Lvl 3 Outcome'] = self.scotsDao.getShortDescription(self.scots_dict, ScotsTable.RESOLUTION.value, lvlThreeNode['resolutionCode'] , langId=None)
                rec['Lvl 3 Country'] = countryChargeRec['Country']
                rec['Lvl 3 Inv'] = float(countryChargeRec['INVCharge'])
                rec['Lvl 3 FAB'] = float(countryChargeRec['FABCharge'])
                rec['Total INV'] = rec['Total INV'] + rec['Lvl 3 Inv']
                rec['Total FAB'] = rec['Total FAB'] + rec['Lvl 3 FAB']
                rec['Grand Total'] = rec['Grand Total'] + rec['Lvl 3 Inv'] + rec['Lvl 3 FAB']
            if 'Grand Total'  in rec and rec['Grand Total'] > 0:
                self.miniLinkageBillingDict[customer]['recs'].append(rec)
                self.miniLinkageBillingDict[customer]['TotalINVForCustomer'] = self.miniLinkageBillingDict[customer]['TotalINVForCustomer'] + rec['Total INV']
                self.miniLinkageBillingDict[customer]['TotalFABForCustomer'] = self.miniLinkageBillingDict[customer]['TotalFABForCustomer'] + rec['Total FAB']
                self.miniLinkageBillingDict[customer]['GrandTotalForCustomer'] = self.miniLinkageBillingDict[customer]['GrandTotalForCustomer'] + rec['Grand Total']
        logging.info('miniLinkageBillingDict = %s',json.dumps(self.miniLinkageBillingDict))    
        
        try:
            self.localFiles['miniLinkageBillingCsv'] = createMiniLinkageBillingCsv(self.miniLinkageBillingDict,self.reportTimesDict)
        except Exception as e:
            logging.error('miniInvestigationReportingService: error detected in createMiniLinkageCustomerCsv. Error = %s', e)
            raise 

                
    
    def createBillingApprovalReport(self, billingApprovalDict):
        approvalCsvList = []
        for k, v in billingApprovalDict.items():
            custApprovalItemList = []
            if len(v) == 0:
                continue
            for usageEvent in v:
                if 'iso2AlphaCountryCode' not in usageEvent['subject']:
                    continue
                countryCode = usageEvent['subject']['iso2AlphaCountryCode']
                if countryCode not in self.countryDict:
                    continue
                partnerNo = self.countryDict[countryCode]['PartnerNo']
                if partnerNo == '0':
                    partner = 'N/A'
                else:            
                    partner = self.partnerDict[partnerNo]['Partner']

                custApprovalItemList.append(formatLineItem(usageEvent,
                                                           partner,
                                                           countryCode, 
                                                           self.countryDict,
                                                           approvalFormat=True))
            approvalFile = createBillingApprovalCsv(custApprovalItemList, k, self.reportTimesDict) 
            if approvalFile == None:
                raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_WRITE_FAILURE) 
            else: 
                approvalCsvList.append(approvalFile)
        
        zipFileName = '/tmp/CustomerChargingReconciliationZip-'+ self.reportTimesDict['ymdString'] + '.zip'
        returnedZipFile = zipFiles(approvalCsvList,zipFileName)
        if returnedZipFile == None:
            logging.error('miniInvestigationReportingService: error creating customer charging recon zip file ')
            raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_CREATE_FAILURE)
        else: 
            self.localFiles['ripCustomerApprovalCsv']  = returnedZipFile 
    
    
    def specialUsageEventProcessing(self,usageEvent, countryCode,reimbursement):
        appleChinaApplicableSubtypes = [33730,33731,33734]
        
        if 'organizationName' not in usageEvent['requestor']:
            return
        customer = usageEvent['requestor']['organizationName'].strip().lower()

        if customer[0:5] == 'apple':
            if countryCode == 'CN':
                if 'researchTypesForCases' in usageEvent['request']:
                    for reqType in usageEvent['request']['researchTypesForCases']:
                        for reqList in reqType['researchTypes']:
                            if reqList['resolutionCode'] == 34321:
                                cnApplePartnerNo = self.countryDict['CN-APPLE']['PartnerNo']
                                cnAppleReimbursement = float(self.countryDict['CN-APPLE']['Reimbursement'])
                                self.partnerDict[cnApplePartnerNo]['tally'] = self.partnerDict[cnApplePartnerNo]['tally'] + cnAppleReimbursement
                                break
                            elif reqList['resolutionCode'] == 34322 and reqList['subResolutionCode'] in appleChinaApplicableSubtypes:
                                cnApplePartnerNo = self.countryDict['CN-APPLE']['PartnerNo']
                                cnAppleReimbursement = float(self.countryDict['CN-APPLE']['Reimbursement'])
                                self.partnerDict[cnApplePartnerNo]['tally'] = self.partnerDict[cnApplePartnerNo]['tally'] + cnAppleReimbursement
                                break
                        else:
                            continue
                        break
                    return
                
                if 'cases' in usageEvent['request']:
                    for case in usageEvent['request']['cases']:
                        for reqList in case['researchTypes']:
                            if reqList['resolutionCode'] == 34321:
                                cnApplePartnerNo = self.countryDict['CN-APPLE']['PartnerNo']
                                cnAppleReimbursement = float(self.countryDict['CN-APPLE']['Reimbursement'])
                                self.partnerDict[cnApplePartnerNo]['tally'] = self.partnerDict[cnApplePartnerNo]['tally'] + cnAppleReimbursement
                                break
                            elif reqList['resolutionCode'] == 34322 and reqList['subResolutionCode'] in appleChinaApplicableSubtypes:
                                cnApplePartnerNo = self.countryDict['CN-APPLE']['PartnerNo']
                                cnAppleReimbursement = float(self.countryDict['CN-APPLE']['Reimbursement'])
                                self.partnerDict[cnApplePartnerNo]['tally'] = self.partnerDict[cnApplePartnerNo]['tally'] + cnAppleReimbursement
                                break
                        else:
                            continue
                        break
                    return
                return 
        
        if customer[0:7] == 'altares':
            self.partnerDict[self.ALTARES_PARTNER_NO]['tally'] = self.partnerDict[self.ALTARES_PARTNER_NO]['tally'] + float(reimbursement)
            usageEvent['billingCharge'] = reimbursement
            self.billingApprovalDict['altares'].append(usageEvent)
            return
        
        if customer[0:4] == 'hdbc':
            self.partnerDict[self.HDBC_PARTNER_NO]['tally'] = self.partnerDict[self.HDBC_PARTNER_NO]['tally'] + float(reimbursement)
            usageEvent['billingCharge'] = reimbursement
            self.billingApprovalDict['hdbc'].append(usageEvent)
            return
        
        if customer[0:8] == 'heineken':
            self.partnerDict[self.HEINEKEN_PARTNER_NO]['tally'] = self.partnerDict[self.HEINEKEN_PARTNER_NO]['tally'] + float(reimbursement)
            usageEvent['billingCharge'] = reimbursement
            self.billingApprovalDict['heineken'].append(usageEvent)
            return 

        if customer[0:7] == 'bisnode':
            self.partnerDict[self.BISNODE_PARTNER_NO]['tally'] = self.partnerDict[self.BISNODE_PARTNER_NO]['tally'] + float(reimbursement)
            usageEvent['billingCharge'] = reimbursement
            self.billingApprovalDict['bisnode'].append(usageEvent)
            return
        
        if customer[0:3] == 'tsr':
            self.partnerDict[self.TSR_PARTNER_NO]['tally'] = self.partnerDict[self.TSR_PARTNER_NO]['tally'] + float(reimbursement)
            usageEvent['billingCharge'] = reimbursement
            self.billingApprovalDict['tsr'].append(usageEvent)
            return
        
        
    def sendReports(self):
        emailReports(self.environDict, self.localFiles, self.reportTimesDict)