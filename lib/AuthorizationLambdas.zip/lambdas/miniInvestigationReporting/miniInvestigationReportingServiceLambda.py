'''
Created on Oct 1, 2019

@author: MorganB
'''

from common.util.awsUtils import createClientConfiguration
from lambdas.lambdaBase import LambdaBase
from common.dao.scotsDao import ScotsDao
from lambdas.miniInvestigationReporting.miniInvestigationReportingService import miniInvestigationReportingService
from lambdas.miniInvestigationReporting.RipReferenceData import RipReferenceData
from lambdas.miniInvestigationReporting.miniInvestigationReportingDao import miniInvestigationReportingDao
from lambdas.miniInvestigationReporting.getReportTimes import getReportTimes
from lambdas.miniInvestigationReporting.saveRipCsvToS3 import saveRipCsvToS3
from lambdas.miniInvestigationReporting.getS3Overrides import getS3Overrides
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg
import logging
import boto3


class miniInvestigationReportingLambda(LambdaBase):

    processId = 'mini-investigation'
    s3Handle = ''
            
    def exitOnTimerEvent(self):
        logging.debug("*********exitTimerEvent**********")
        return False
    
    def needsDbConn(self):
        logging.debug("needsdbconn*****")
        return True
    
    def handleRequest(self):
        miniInvestigationRecordCount = 0
        startRecordNumberOverride = None
        LambdaBase.raiseAlertWhenRequestFails = True
        incomingEvent = self.requestContext.event
        reportTimesDict = getReportTimes(self.environDict['reportUpUntilDay'])
            
        miniInvestigationReportingLambda.s3Handle = boto3.resource('s3', config=createClientConfiguration(self.environDict))
        
        ## if the lambda was invoked because a file was placed into the S3 bucket, see if there was an override file
        ## the file may contain an override for the reportUpUntilDay or for where the database read should start
        if 'Records' in incomingEvent and 's3' in incomingEvent['Records'][0]:
            logging.info('iniInvestigationReportingServiceLambda: function starting due to S3 override file')
            s3Overrides = {}
            s3Overrides = getS3Overrides(incomingEvent,miniInvestigationReportingLambda.s3Handle)
            if s3Overrides:
                if 'reportUpUntilDay' in s3Overrides:
                    logging.info('miniInvestigationReportingServiceLambda: reportUpUntilDay being overridden. the new value = %s', s3Overrides['reportUpUntilDay'])
                    reportTimesDict = getReportTimes(s3Overrides['reportUpUntilDay'])
                if 'startRecordNumberOverride' in s3Overrides:
                    startRecordNumberOverride = s3Overrides['startRecordNumberOverride'] 
                
        try:
            ripRefDataObj = RipReferenceData()
            ripRefDataObj.loadFiles()
        except Exception as e:
            logging.error ('miniInvestigationReportingServiceLambda: unable to load artifact documents.  Error = %s', e)
            raise
        
        ## determine the date up until when the entries will be processed 
        ## there is a 'reportUpUntilDay' entry in the environDict.  this is the day of the current month that will be 
        ## the cut off record processing in the current month.  This value must be numeric.  A value of 'all' is also 
        ## valid.  this means that all unprocessed records are considered eligible
        try:
            dbObj = miniInvestigationReportingDao(self.dbConn,reportTimesDict)
        except Exception as e:
            logging.error ('miniInvestigationReportingServiceLambda - unable to connecting to database.  Error = %s', e)
            raise
        try:    
            candidateList = dbObj.getUnprocessedRecords(miniInvestigationReportingLambda.processId,startRecordNumberOverride)
            if candidateList == None:
                logging.info ('miniInvestigationReportingServiceLambda - no unprocessed records found - process ending')
                return
        except Exception as e:
            logging.error ('miniInvestigationReportingServiceLambda - error in database processing.  Error = %s', e) 
            raise
        
        ### review the unprocessed records.  Identify which ones needed for customer billing and which ones need 
        ### interco processing.  Create the reporting artifacts from the billing and interco records.  
        ### Create the archive zip file from the artifacts and return it the function.  Also return the nubmer of 
        ### candidate records 
        try:
            archivableArtifact = None
            scotsDao = ScotsDao()
            scots_dict = scotsDao.queryTypeCodesToDescriptions(self.dbConn)
            ripServiceObj = miniInvestigationReportingService(self.environDict,ripRefDataObj,reportTimesDict, scots_dict, scotsDao)
            archivableArtifact, miniInvestigationRecordCount = ripServiceObj.processCandidateUsageRecords(candidateList)
        except Exception as e: 
            logging.error ('miniInvestigationReportingServiceLambda - error processing usage data.  Error = %s', e)
            raise
        if archivableArtifact == None:
            logging.error ('miniInvestigationReportingServiceLambda - no artifact created from usage processing') 
            return 
        
        ### save archive artifact to S3.  Return the name of the S3 object
        try:
            s3ObjectName = None 
            s3ObjectName = saveRipCsvToS3(archivableArtifact, miniInvestigationReportingLambda.s3Handle, self.environDict)
        except Exception as e:
            logging.error ('miniInvestigationReportingServiceLambda - error saving archive file to S3.  Error = %s', e) 
            raise
        if s3ObjectName == None:
            logging.error ('miniInvestigationReportingServiceLambda - no S3 object name returned from saveRipCsvToS3.  Processing terminated')
            raise LambdaProcessingException(errmsg.ERR_S3_PROCESSING_FAILURE)
          
        ### if the s3 save work, update the tracking database 
        try:
            dbObj.updateTrackingDatabase(s3ObjectName,miniInvestigationRecordCount)
        except Exception as e:
            logging.error ('miniInvestigationReportingServiceLambda - error updated tracking database  Error = %s', e)
            raise 
        
        ### now, let's send out the RIP report! 
        try:
            ripServiceObj.sendReports()
        except Exception as e:
            logging.error ('miniInvestigationReportingServiceLambda - error sending reports  Error = %s', e)
            raise 
        
handler = miniInvestigationReportingLambda.get_handler(...)
        