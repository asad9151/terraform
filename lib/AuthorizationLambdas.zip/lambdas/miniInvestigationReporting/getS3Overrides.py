'''
Created on Nov 11, 2019
@author: MorganB
'''

import logging
from urllib.parse import unquote_plus
import json

def getS3Overrides(event, s3Handle):
    overrides = {}
    try:
        incomingS3Bucket = (event['Records'][0]['s3']['bucket']['name'])
    except Exception as e:
        logging.error('getS3Overrides: missing bucket name from event data.  error msg = %s',e)
        raise
        
    try: 
        incomingS3Key = (unquote_plus(event['Records'][0]['s3']['object']['key']))
    except Exception as e:
        logging.error('getS3Overrides: missing S3Key from event data  error msg = %s',e)
        raise
        
    logging.info('getS3Overrides:  bucket = %s', incomingS3Bucket)
    logging.info('getS3Overrides:  key = %s', incomingS3Key)
    try:
        obj = s3Handle.Object(incomingS3Bucket, incomingS3Key)
        s3Obj = obj.get()['Body'].read().decode('utf-8') 
        logging.info('getS3Overrides: s3 file contents read')
    except Exception as e:
        logging.error('getS3Overrides: reading s3 file contents had an error.  error = %s', e)
        raise
    
    try:
        overrideInput = json.loads(s3Obj)
    except Exception as e:
        logging.warning('getS3Overrides: override file was either empty or did not contain JSON format.  The miniInvestigationUsage process will be kicked off using the environment variable values.  Error = %s', e)
        return overrides
    
    if 'reportUpUntilDay' not in overrideInput:
        pass
    elif overrideInput['reportUpUntilDay'] == 'all':
        overrides['reportUpUntilDay'] = 'all'
    elif str(overrideInput['reportUpUntilDay']).isnumeric():
        overrides['reportUpUntilDay'] = int(overrideInput['reportUpUntilDay'])
    else:
        logging.error('getS3Overrides: reportUpUntilDay must be all or numeric value.  Provided value = %s',overrideInput['reportUpUntilDay'])
        
    if 'startRecordNumberOverride' not in overrideInput:
        pass
    elif str(overrideInput['startRecordNumberOverride']).isnumeric():
        if int(overrideInput['startRecordNumberOverride']) > 0:
            overrides['startRecordNumberOverride'] = int(overrideInput['startRecordNumberOverride'])
        else:
            logging.error('getS3Overrides: startRecordNumberOverride cannot be 0')

    else:
        logging.error('getS3Overrides: startRecordNumberOverride must be a numeric value.  Provided value = %s',overrideInput['startRecordNumberOverride'])

    return overrides

if __name__ == '__main__':
    pass