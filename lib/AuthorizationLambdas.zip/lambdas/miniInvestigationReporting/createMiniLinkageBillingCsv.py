'''
Created on Oct 21, 2019

@author: MorganB
'''

import logging
from common.writeCSV import writeCSV
from common.zipFiles import zipFiles
from lambdas.exceptions import LambdaProcessingException
import lambdas.errorMessages as errmsg

def createMiniLinkageBillingCsv(miniLinkageBillingDict, reportTimesDict):
    formatOrder = ['Request Id',
                   'Account Number',
                   'Date Completed',
                   'Lvl 1 Outcome',
                   'Lvl 1 Country',
                   'Lvl 1 Inv',
                   'Lvl 1 FAB',
                   'Lvl 2 Outcome',
                   'Lvl 2 Country',
                   'Lvl 2 Inv',
                   'Lvl 2 FAB',
                   'Lvl 3 Outcome',
                   'Lvl 3 Country',
                   'Lvl 3 Inv',
                   'Lvl 3 FAB',
                   'Total INV',
                   'Total FAB',
                   'Grand Total'
                      ]
    
    logging.info('createMiniLinkageBillingCsv: miniLinkageBillingDict = %s', miniLinkageBillingDict)
    ymdString = reportTimesDict['ymdString']
    
    billingCSVList = []
    for customer in miniLinkageBillingDict:
        customerMiniLinkageBillingCsv = '/tmp/MiniLinkageBilling-' + ymdString + '-' + customer + '.csv'
        rec = {}
        rec['Lvl 3 Country'] = 'Totals'
        rec['Total INV'] = miniLinkageBillingDict[customer]['TotalINVForCustomer']
        rec['Total FAB'] = miniLinkageBillingDict[customer]['TotalFABForCustomer']
        rec['Grand Total'] = miniLinkageBillingDict[customer]['GrandTotalForCustomer']
        miniLinkageBillingDict[customer]['recs'].append(rec)
        returnedFileName = writeCSV(miniLinkageBillingDict[customer]['recs'],customerMiniLinkageBillingCsv,formatOrder)
        if returnedFileName == None:
            logging.error('createMiniLinkageBillingCsv: error in writeCSV for: partner %s',customer)
            continue
        billingCSVList.append(customerMiniLinkageBillingCsv)
    
    zipFileName = '/tmp/MiniLinkageBillingZip-'+ ymdString + '.zip'
    returnedZipFile = zipFiles(billingCSVList,zipFileName)
    if returnedZipFile == None:
        logging.error('createMiniLinkageBillingCsv: error creating mini linkage billing zip file ')
        raise LambdaProcessingException(errmsg.ERR_LOCAL_FILE_CREATE_FAILURE)
    else:
        return returnedZipFile
        
if __name__ == '__main__':
    pass
