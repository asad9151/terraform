'''
Created on Sep 1, 2020
DAO class to handle updating the click count or rating for training media.

@author: GuardiolaR
'''
import logging

class TrainingMediaStatsDao(object):
    
    def updateTrainingMediaRank(self, dbConn, trainingMediaId, rating):
        updateQuery = '''
            UPDATE trng_mdia 
            SET mdia_vte_cnt = mdia_vte_cnt + %s, mdia_vte_tot_nbr = mdia_vte_tot_nbr + 1
            WHERE trng_mdia_id = %s
        '''
        paramList = (rating, trainingMediaId)   
        dbConn.cursor.execute(updateQuery, paramList)
        logging.info("updating viewer rating for training media")
        dbConn.dbconn.commit()
        
        return None
    
    
    def updateTrainingViewCount(self, dbConn, trainingMediaId, viewCount):
        updateQuery = '''
            UPDATE trng_mdia 
            SET mdia_vws_cnt = mdia_vws_cnt + %s
            WHERE trng_mdia_id = %s
        ''' 
        paramList = (viewCount, trainingMediaId)
        dbConn.cursor.execute(updateQuery, paramList)
        logging.info("updating view count for training media")
        dbConn.dbconn.commit()
        
        return None