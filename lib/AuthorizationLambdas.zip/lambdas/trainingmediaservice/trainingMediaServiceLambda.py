'''
Created on Aug 27, 2020

@author: GuardiolaR
'''
from botocore.client import Config
from buildUIResponse import buildUIResponse
from common.actionTypeCodes import ActionTypeCode
from common.irschRoles import IResearchRole
from common.util.awsUtils import createClientConfiguration
from lambdas.exceptions import LambdaAuthorizationException
from lambdas.lambdaCommon import checkIfUserHasAnyRoles
from lambdas.lambdaStatusCodes import LambdaStatusCodes
from lambdas.secureLambdaBase import SecureLambdaBase
from lambdas.trainingmediaservice.trainingMediaService import TrainingMediaService
import boto3
import json
import lambdas.errorMessages as errmsg
import logging


class TrainingMediaServiceLambda(SecureLambdaBase):
    '''
    Handler class for trainingmediaservice.
    Implementation of a Lambda handler as a class for a specific Lambda function.
    Handler: lambdas.trainingmediaservice.trainingMediaServiceLambda.handler
    '''
    
    def __init__(self):
        super().__init__()
        self.service = None
        self.s3Client = None
    
    def handleSecureRequest(self):
        if self.service is None:
            self.service = TrainingMediaService(TrainingMediaServiceLambda.dbConn)
        if self.s3Client is None:
            try:
                logging.info('Initializing s3...')
                self.s3Client = boto3.client('s3', config=createClientConfiguration(TrainingMediaServiceLambda.environDict, mergeConfig=Config(signature_version='s3v4')))
            except Exception as e:
                raise RuntimeError('S3 not configured')
            
        getUsersOpt = self.requestContext.getLambdaQueryParameter(TrainingMediaService.QUERY_PARAM_TRAINING_MEDIA_ATTACHMENT, 'false')
        if getUsersOpt.lower() == 'false':
            logging.info('attachment pre-signed URL output turned off')
            if self.requestContext.incomingContent.get('trainingMediaRating', None) is not None:
                self.service.updateTrainingMediaRanking(self.requestContext)
                responseBody = json.dumps({})
            else:
                logging.error('trainingmediaservice - invalid request, trainingMediaRating or trainingMediaAttachment is required.')
                raise LambdaAuthorizationException(errmsg.ERR_MEDIA_PARAMS_MISSING)             
        else:
            logging.info('fetching attachment pre-signed URL')
            trainingMediaUrl = self.service.retriveTrainingMediaRecord(self.requestContext, self.s3Client)
            responseBody = json.dumps(trainingMediaUrl)
                    
        return buildUIResponse(LambdaStatusCodes.OK.value, responseBody, 'application/json')

    
    def authorizeRequest(self):
        getUsersOpt = self.requestContext.getLambdaQueryParameter(TrainingMediaService.QUERY_PARAM_TRAINING_MEDIA_ATTACHMENT, 'false')
        if getUsersOpt.lower() == 'true' and  (checkIfUserHasAnyRoles(self.requestContext.userSession, [ IResearchRole.IRESEARCH_RESEARCHER_LOCALADMIN, IResearchRole.IRESEARCH_RESEARCHER, IResearchRole.IRESEARCH_SUBMITTER_US_SUPER7, IResearchRole.IRESEARCH_TECH_SUPPORT, IResearchRole.IRESEARCH_SUPER_ADMIN, IResearchRole.IRESEARCH_INTERNAL_REVIEWER]) == False):
            logging.error('trainingmediaservice - user does not have any of the required roles')
            raise LambdaAuthorizationException(errmsg.ERR_MISSING_ROLES)

                                               
#Every lambda needs the following line or will fail with: [ERROR] TypeError: __init__() missing 1 required positional argument: 'params'
handler = TrainingMediaServiceLambda.get_handler(...)