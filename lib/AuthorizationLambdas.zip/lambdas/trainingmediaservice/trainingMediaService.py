'''
Created on Aug 27, 2020
Service for retrieving training media for end users and for updating metric feedback provided by end users.

@author: GuardiolaR
'''
import constants
import lambdas.errorMessages as errmsg
import logging
from common.util.stringUtils import isBlank, intDefaultNone, isInt
from lambdas.exceptions import LambdaValidationException, LambdaProcessingException
from lambdas.retrieveadmindata.retrieveAdminDataDao import RetrieveAdminDataDao
from lambdas.retrieveadmindata.trainingMediaDataMapper import mapTrainingMediaSummaryDataResultToSchema
from lambdas.trainingmediaservice.updateTrainingMediaStatsDao import TrainingMediaStatsDao


class TrainingMediaService(object):
    QUERY_PARAM_TRAINING_MEDIA_ID = 'trainingMediaId'
    QUERY_PARAM_TRAINING_MEDIA_ATTACHMENT = 'trainingMediaAttachment'
    QUERY_PARAM_TRAINING_MEDIA_RATING = 'trainingMediaRating'
    
    dao = None
    trainingMediaStatsDao = None

    def __init__(self, dbConn):
        self.dbConn = dbConn
        if TrainingMediaService.dao is None:
            TrainingMediaService.dao = RetrieveAdminDataDao()
        if not TrainingMediaService.trainingMediaStatsDao:
            TrainingMediaService.trainingMediaStatsDao = TrainingMediaStatsDao()
    
        
    def retriveTrainingMediaRecord(self, requestContext, s3Client):
        trainingMediaIdStr = requestContext.getLambdaQueryParameter(TrainingMediaService.QUERY_PARAM_TRAINING_MEDIA_ID, None)
        trainingMediaId = intDefaultNone(trainingMediaIdStr) if isInt(trainingMediaIdStr) else None
        if isBlank(trainingMediaId):
            logging.info('trainingMediaId missing or is invalid string')
            raise LambdaValidationException(errmsg.ERR_TRAINING_MEDIA_ID_INVALID)
        
        qryResult = TrainingMediaService.dao.getTrainingMediaData(self.dbConn, trainingMediaId, None)
        if qryResult is None:
            logging.info('trainingMediaId is invalid')
            raise LambdaValidationException(errmsg.ERR_TRAINING_MEDIA_ID_NO_RESULT)
        
        mappedResult = mapTrainingMediaSummaryDataResultToSchema(qryResult, trainingMediaId)
        result = self._generateURL(requestContext, s3Client, mappedResult)
        if result["trainingMediaAttachmentURL"] is not None:
            TrainingMediaService.trainingMediaStatsDao.updateTrainingViewCount(self.dbConn, trainingMediaId, 1)  
            
        return result
    


    def _generateURL(self, requestContext, s3Client, mappedResult):
        try:
            fileName = mappedResult.get('trainingMediaRecord').get('mediaFileName')
            putkey = constants.TRAINING_MEDIA_DATA_S3_FOLDER + fileName
            download_url = s3Client.generate_presigned_url(
                'get_object',
                 Params={
                    'Bucket': str(requestContext.environDict['uploadBucket']) ,
                    'Key': putkey
                },
                ExpiresIn=3600
            )
            #logging.info(download_url)
            result = {}
            result["trainingMediaAttachmentURL"] = download_url
            return result

        except Exception as e:
            logging.error('Error while retrieving attachment for training media.  error = %s', e)
            raise LambdaProcessingException('Error while retrieving attachment for training media')
        
        
    def updateTrainingMediaRanking(self, requestContext): 
        trainingMediaIdStr = requestContext.incomingContent.get(TrainingMediaService.QUERY_PARAM_TRAINING_MEDIA_ID, None)
        trainingMediaId = intDefaultNone(trainingMediaIdStr) if isInt(trainingMediaIdStr) else None
        if isBlank(trainingMediaId):
            logging.info('trainingMediaId missing or is invalid string')
            raise LambdaValidationException(errmsg.ERR_TRAINING_MEDIA_ID_INVALID)
        
        mediaRatingStr = requestContext.incomingContent.get(TrainingMediaService.QUERY_PARAM_TRAINING_MEDIA_RATING, None)
        mediaRating = intDefaultNone(mediaRatingStr) if isInt(mediaRatingStr) else None
        if mediaRating is None or mediaRating < 0 or mediaRating > 5:
            logging.info('trainingMediaRating must be a numeric value from 0 to 5.')
            raise LambdaValidationException(errmsg.ERR_MEDIA_RANK_INVALID)
        
        TrainingMediaService.trainingMediaStatsDao.updateTrainingMediaRank(self.dbConn, trainingMediaId, mediaRating)
        
        return None
          
              
        
        