'''
Created on March 4, 2018

@author: MorganB
'''
import json
import uuid
from encodeJWT import encodeJWT
import logging
import datetime
from common.userTypes import UserType
from common.envVblNames import ENV_TOKEN_EXPIRATION_TIME, ENV_OL_SECRET_KEY
from common.irschRoles import IResearchRole
from common.dao.userAuthorizationDao import UserAuthorizationDao
from common.util.dateUtils import isMicrosecondTimestamp, isoFormatToDateTime, dateTimeToIsoFormat
from common.util.stringUtils import isNotBlank


def buildSessionTokenResponseBody(OLIdTokenDecoded, environDict, dbConn, user_type=UserType.USER_TYPE_UI.value, userAuthorizationDao=None):
    # Used by UI authorizer (NOT used by Cloud Services APIs)
    JWTPayload = {}
    responseBody ={}
    
    JWTPayload["jti"] = uuid.uuid4().hex.upper()
    JWTPayload["iss"] = 'iResearchUILogonValidation'
    JWTPayload["iat"] = int(datetime.datetime.utcnow().timestamp())
    x = datetime.datetime.utcnow() + datetime.timedelta(seconds=int(environDict[ENV_TOKEN_EXPIRATION_TIME]))
    JWTPayload["exp"] = int(x.timestamp())
    OLIdTokenDecoded["exp"] = int(x.timestamp())
    JWTPayload["user_type"] = user_type
    if 'loginKey' in OLIdTokenDecoded:
        responseBody['loginKey'] = OLIdTokenDecoded['loginKey']
        JWTPayload["sub"] = OLIdTokenDecoded['loginKey'] 
        JWTPayload["loginKey"] = OLIdTokenDecoded['loginKey']
        if 'email' in OLIdTokenDecoded:
            responseBody['email'] = OLIdTokenDecoded['email']
            JWTPayload["email"] = OLIdTokenDecoded['email']
    elif 'email' in OLIdTokenDecoded:
        responseBody['email'] = OLIdTokenDecoded['email']
        responseBody['loginKey'] = OLIdTokenDecoded['email']
        JWTPayload["email"] = OLIdTokenDecoded['email']
        JWTPayload["sub"] = OLIdTokenDecoded['email'] 
        JWTPayload["loginKey"] = OLIdTokenDecoded['email']
        OLIdTokenDecoded["loginKey"] = OLIdTokenDecoded['email']
    else:
        logging.error('authResponse-buildResponseBody error - email address and loginKey missing from OneLogin JWT.  Process ending')
        raise Exception('authResponse-buildResponseBody error')

    # Get the iResearch-administered roles to add into the ones we got from IDaaS:
    queryIresearchSupplementalAuthInfo(dbConn, OLIdTokenDecoded, userAuthorizationDao)
    
    if 'given_name' in OLIdTokenDecoded:
        responseBody['given_name'] = OLIdTokenDecoded['given_name']
        JWTPayload["given_name"] = OLIdTokenDecoded['given_name']
    if 'family_name' in OLIdTokenDecoded:
        responseBody['family_name'] = OLIdTokenDecoded['family_name']
        JWTPayload["family_name"] = OLIdTokenDecoded['family_name']
    if 'company' in OLIdTokenDecoded:
        # OIDC v1
        responseBody['company'] = OLIdTokenDecoded['company']
        JWTPayload["company"] = OLIdTokenDecoded['company']
    elif 'params' in OLIdTokenDecoded:
        # OIDC v2 'params': {'company': '0500 Dun & Bradstreet Inc.', ...
        params = OLIdTokenDecoded['params']
        if 'company' in params:
            responseBody['company'] = params['company']
            JWTPayload["company"] = params['company']
    if 'language' in OLIdTokenDecoded:
        responseBody['language'] = OLIdTokenDecoded['language']
        JWTPayload["language"] = OLIdTokenDecoded['language'] 
    if 'country' in OLIdTokenDecoded:
        responseBody['country'] = OLIdTokenDecoded['country']
        JWTPayload["country"] = OLIdTokenDecoded['country']    
    if 'groups' in OLIdTokenDecoded:
        responseBody['groups'] = OLIdTokenDecoded['groups']
        JWTPayload["groups"] = OLIdTokenDecoded['groups']
    if 'idaas_groups' in OLIdTokenDecoded:
        responseBody['idaas_groups'] = OLIdTokenDecoded['idaas_groups']
        JWTPayload["idaas_groups"] = OLIdTokenDecoded['idaas_groups']
    if 'irsch_groups' in OLIdTokenDecoded:
        responseBody['irsch_groups'] = OLIdTokenDecoded['irsch_groups']
        JWTPayload["irsch_groups"] = OLIdTokenDecoded['irsch_groups']
    if 'rsch_usr_id' in OLIdTokenDecoded:
        responseBody['rsch_usr_id'] = OLIdTokenDecoded['rsch_usr_id']
        JWTPayload["rsch_usr_id"] = OLIdTokenDecoded['rsch_usr_id']
    if 'routing_categories' in OLIdTokenDecoded:
        responseBody['routing_categories'] = OLIdTokenDecoded['routing_categories']
        JWTPayload["routing_categories"] = OLIdTokenDecoded['routing_categories']
    if 'subtype_groups' in OLIdTokenDecoded:
        responseBody['subtype_groups'] = OLIdTokenDecoded['subtype_groups']
        JWTPayload["subtype_groups"] = OLIdTokenDecoded['subtype_groups']
    if 'team_groups' in OLIdTokenDecoded:
        responseBody['team_groups'] = OLIdTokenDecoded['team_groups']
        JWTPayload["team_groups"] = OLIdTokenDecoded['team_groups']
    if 'country_groups' in OLIdTokenDecoded:
        responseBody['country_groups'] = OLIdTokenDecoded['country_groups']
        JWTPayload["country_groups"] = OLIdTokenDecoded['country_groups']
    if 'nonce' in OLIdTokenDecoded:
        responseBody['nonce'] = OLIdTokenDecoded['nonce']     
         
    logging.info('buildSessionTokenReponse - JWTPayload = %s',JWTPayload)
    nowTs = datetime.datetime.utcnow()
    expTs = datetime.datetime.fromtimestamp(OLIdTokenDecoded["exp"])
    logging.info(f'buildSessionTokenReponse: expTs={expTs} nowTs={nowTs}')
    try:
        btoken = encodeJWT(JWTPayload, environDict[ENV_OL_SECRET_KEY])
        responseBody["session_token"] = btoken.decode('utf-8')
    except:
        logging.error('authResponse-buildResponseBody - error getting session token')
        raise
    
    return responseBody


def buildCloudServicesPayloadForRecordLogin(requestContext, dbConn, userAuthorizationDao=None):
    '''
    Creates the payload to pass to RecordLogin for Cloud Services user
    '''
    x = datetime.datetime.utcnow() + datetime.timedelta(seconds=int(requestContext.environDict[ENV_TOKEN_EXPIRATION_TIME]))
    exp = int(x.timestamp())
    groupsList = []
    for role in requestContext.userSession.roles:
        groupsList.append(role.value)
    body = {
        "jti": uuid.uuid4().hex.upper(),
        "iss":"secureLambdaBase",
        "iat": int(datetime.datetime.utcnow().timestamp()),
        "exp": exp,
        "user_type": requestContext.userSession.userType,
        "sub": requestContext.userSession.loginKey,
        "loginKey": requestContext.userSession.loginKey,
        "company": requestContext.userSession.subscriberName,
        "country": requestContext.userSession.subscriberCountry,
        "groups": groupsList,
        "applicationId": int(requestContext.userSession.applicationId)
    }
    queryIresearchSupplementalAuthInfo(dbConn, body, userAuthorizationDao)
    jwtPayload = {
        "body": body,
        "aws_event": {
            "resource": "/recordlogin",
            "path": "/recordlogin",
            "httpMethod": "POST",
            "headers": {}
        },
        "dnb_jwt_body": body
    }
    logging.info('buildCloudServicesPayloadForRecordLogin: ' + str(jwtPayload))
    return jwtPayload
    
    
def queryIresearchSupplementalAuthInfo(dbConn, userDict, userAuthorizationDao=None):
    '''
    If the user is already known to iResearch, queries the iResearch rsch_usr table rsch_usr_adm_obj
    to get supplemental authorization information about the user and add it into the OLIDToken dictionary:
    irsch_groups: list of iResearch administered roles (empty if a new user or has no iResearch roles)
    rsch_usr_id: the researchUserId of the user (or omitted if a new user)
    routing_categories: list of submitter routing category codes (empty unless a type of submitter with special routing needs)
    subtype_groups: list of submitter research subtype groups (empty if not a submitter)
    '''
    if userAuthorizationDao is None:
        userAuthorizationDao = UserAuthorizationDao()
    loginKey = userDict["loginKey"]
    logging.info("Querying rsch_usr data for loginKey=" + str(loginKey))
    userAuthData = userAuthorizationDao.queryUserAuthorization(dbConn, loginKey)
    
    irsch_groups = []
    routing_categories = []
    subtype_groups = []
    team_groups = []
    country_groups = []
    if userAuthData is not None:
        # Will not be populated for a new user
        logging.info("Got back supplemental info on user: " + str(userAuthData))
        userDict["rsch_usr_id"] = userAuthData["rsch_usr_id"]
        userAdminStr = userAuthData["rsch_usr_adm_obj"]
        if isNotBlank(userAdminStr):
            userAdminDict = json.loads(userAdminStr)
            iResearchUserRoles = userAdminDict.get("iResearchUserRoles")
            if iResearchUserRoles is not None:
                for roleObj in iResearchUserRoles:
                    iResearchRoleName = roleObj["iResearchRoleName"]
                    irsch_groups.append(iResearchRoleName)
            submitterRoutingCategories = userAdminDict.get("submitterRoutingCategories")
            if submitterRoutingCategories is not None:
                for categoryObj in submitterRoutingCategories:
                    categoryCode = categoryObj["submitterRoutingCategoryCode"]
                    routing_categories.append(categoryCode)
            researchSubTypesGroups = userAdminDict.get("researchSubTypesGroups")
            if researchSubTypesGroups is not None:
                for subtypeGroupObj in researchSubTypesGroups:
                    subtypeGroupCode = subtypeGroupObj["researchSubTypesGroupCode"]
                    subtype_groups.append(subtypeGroupCode)
            researchTeamGroups = userAdminDict.get("researchTeamGroups")
            if researchTeamGroups is not None:
                for researchTeamGroup in researchTeamGroups:
                    teamGroupId = researchTeamGroup["teamGroupId"]
                    team_groups.append(teamGroupId)
            researchCountryGroups = userAdminDict.get("researchCountryGroups")
            if researchCountryGroups is not None:
                for researchCountryGroup in researchCountryGroups:
                    countryGroupId = researchCountryGroup["countryGroupId"]
                    country_groups.append(countryGroupId)      
                                  
        userObjStr = userAuthData["rsch_usr_obj"]
        if isNotBlank(userObjStr):
            _fixupResearchUserTimestamps(userAuthorizationDao, dbConn, userDict["rsch_usr_id"], userObjStr)
            

    if len(irsch_groups) > 0:
        userDict["irsch_groups"] = irsch_groups
    
    # Create a consolidated list of IDaaS groups plus iResearch groups:
    idaas_groups = getIresearchGroupsFromIdaas(userDict.get("groups"))
    consolidated_groups = set()
    if idaas_groups is not None and len(idaas_groups) > 0:
        userDict["idaas_groups"] = idaas_groups
        consolidated_groups |= set(idaas_groups)
    consolidated_groups |= set(irsch_groups)
    if len(consolidated_groups) > 0:
        userDict["groups"] = list(consolidated_groups)
        
    if len(routing_categories) > 0:
        userDict["routing_categories"] = routing_categories
    if len(subtype_groups) > 0:
        userDict["subtype_groups"] = subtype_groups
    if len(team_groups) > 0:
        userDict["team_groups"] = team_groups    
    if len(country_groups) > 0:
        userDict["country_groups"] = country_groups
        
def getIresearchGroupsFromIdaas(groups):
    '''
    Filter the set of IDaaS groups to only include valid iResearch roles
    '''
    if groups is None:
        return None
    logging.info("Original groups list from IDaaS: '" + str(groups) + "'")
    idaas_irsch_groups = []
    for group in groups:
        if IResearchRole.hasValue(group):
            idaas_irsch_groups.append(group)
        else:
            logging.debug("Removing non-iResearch IDaaS group: '" + group + "'")
    logging.info("Filtered groups list from IDaaS: " + str(idaas_irsch_groups))
    return idaas_irsch_groups


def _fixupResearchUserTimestamps(userAuthorizationDao, dbConn, rschUserId, userObjStr):
    '''
    This function takes care of fixing timestamps stored in the rsch_usr_obj so they are consistent with java-generated timestamps
    '''
    userObjDict = json.loads(userObjStr)
    isChanged = False
    if _updateOneTimestamp(userObjDict, "termsAndConditionsLatestConsentTimestamp"):
        isChanged = True
    if _updateOneTimestamp(userObjDict, "termsAndConditionsInitialConsentTimestamp"):
        isChanged = True
    if isChanged:
        newUserObjStr = json.dumps(userObjDict)
        logging.info(f"_fixupResearchUserTimestamps updating rsch_usr_id={rschUserId} with rsch_usr_obj={newUserObjStr}")
        userAuthorizationDao.updateUserObject(dbConn, rschUserId, newUserObjStr, "_fixupResearchUserTimestamps")


def _updateOneTimestamp(userObjDict, fieldName):
    origTs = userObjDict.get(fieldName)
    if isMicrosecondTimestamp(origTs):
        dt = isoFormatToDateTime(origTs)
        newTs = dateTimeToIsoFormat(dt)
        userObjDict[fieldName] = newTs
        return True
    return False


if __name__ == '__main__':
    pass
    
    