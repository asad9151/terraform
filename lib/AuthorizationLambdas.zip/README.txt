Top-level folder for iResearch python code.

To run all unit tests, from command line (in this directory) use: 
python -m unittest -b
(The -b throws away all standard output except from failing tests.)

or better yet, to get coverage reporting about our unit tests, install nose2 and run:
nose2

You can also run nose2 from the top-level directory

To run pylint on all python modules use (in this directory):
pylint **/*.py
Or from the AuthorizationLambdas directory:
pylint --rcfile=src/main/python/pylintrc src/main/python/**/*.py
