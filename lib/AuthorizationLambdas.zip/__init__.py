'''
Created on November 10, 2019
Top-level module for python code in iResearch
@author: VanCampK
'''
