'''
Created on Feb 14, 2019

@author: MorganB
'''
headerValues = {
    'X-Requested-With': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,x-requested-with',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST,GET,OPTIONS',
    'Access-Control-Max-Age': '600',
    'X-XSS-Protection': '1; mode=block',    # BDR-813
    'X-Frame-Option': 'DENY',   # BDR-806
    'Content-Security-Policy': 'frame-ancestors \'none\'; default-src \'self\'',  # BDR-806 (optional)
    'X-Content-Type-Options': 'nosniff',    # BDR-809
    'Strict-Transport-Security': 'max-age=31536000' # BDR-809
    }

#def buildUIResponse(statusCode,body, contentType = 'application/json'):
def buildUIResponse(statusCode,body, contentType = 'application/x-www-form-urlencoded'):
    response = {}
    response['statusCode'] = statusCode
    headerValues['Content-Type'] = contentType
    response['headers'] = headerValues
    response['body'] = body
    return response
    


if __name__ == '__main__':
    pass