'''
Updated on March 18, 2019

@author: MorganB
'''
import logging
import traceback
import sys
import boto3
from determineStartType import determineStartType
from SetLambdaLogging import setLogging
from buildEnvironVarDict import buildEnvironVarDict 
from databaseClass import databaseClass
from attachmentClass import attachment
import constants
import json
from common import envVblNames
from common.alert import Alert
from common.util.sqsHelper import SqsHelper
from lambdas.lambdaCommon import buildLambdaSecureInvokeEvent
from common.researchTeamCode import ResearchTeamCode
from common.submitToRemoteAppTypeCode import SubmitToRemoteAppTypeCode
from common.util.applicationConfigHelper import ApplicationConfigHelper
from common.util.awsUtils import createClientConfiguration


environDict = {}
dbObj = type('',(object,),{})()
submitCaseBatchParserSqsHelper = None
submitToRemoteAppSQSHelper = None
applicationConfigHelper = None

def parseHttpResponse(responseBody):
    return responseBody['ResponseMetadata']['HTTPStatusCode']
 
def parsePayload(responseBody):
    return responseBody['Payload']
 
def parseStatusCode(responseBody):
    return responseBody['statusCode']
 
def parsePayLoadObject(payload_obj):
    return json.loads(payload_obj.read().decode('utf-8'))


def lambdaHandler(event, context):
    global environDict
    global dbObj
    global applicationConfigHelper
    
    if not environDict:
        try:
            environDict = buildEnvironVarDict()
            environDict['s3Handle'] = boto3.resource('s3', config=createClientConfiguration(environDict))
            # Read timeout should be similar to timeout on SubmitCaseBatchParser lamba:
            #config = botocore.config.Config(read_timeout=int(environDict[envVblNames.ENV_LAMBDA_INVOKE_TIMEOUT_SECS]))
            environDict['lambdaHandle'] = boto3.client('lambda', region_name=environDict[envVblNames.ENV_LAMBDA_REGION], config=createClientConfiguration(environDict))
            setLogging(environDict[envVblNames.ENV_LOGGINGLEVEL])
        except Exception as e:
            logging.error('irschProcessVirusScannedAttachment-E001: error building environDict.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return 
    errror_alert = Alert(environDict)    
    
    if applicationConfigHelper is None:
        applicationConfigHelper = ApplicationConfigHelper(environDict)
        
    if not isinstance(dbObj, databaseClass):
        try:
            dbObj = databaseClass(environDict)
        except Exception as e:
            logging.error('irschProcessVirusScannedAttachment-E002: error building database object.  error = %s', e)
            errror_alert.raiseAlert("irschProcessVirusScannedAttachment", "Database Object was not created", str(e))
            return
    else:
        # warm start
        try:
            logging.info('irschProcessVirusScannedAttachment warm start - testing database connection...')
            dbObj.checkConnection()
            logging.info('irschProcessVirusScannedAttachment continuing after database connection tested')
        except Exception as e:
            logging.error('irschProcessVirusScannedAttachment - error testing database connection.  error = %s', e)
            errror_alert.raiseAlert("irschProcessVirusScannedAttachment", "error testing database connection", str(e))
            return
    
    if determineStartType(event) == 'timer':    
        return

    logging.info('irschProcessVirusScannedAttachment-I001: incoming event = %s', event)
    
    attmObj = attachment()
    
    try:
        attmObj.loadS3Attributes(event, environDict, dbObj)
    except Exception as e:
        logging.error('irschProcessVirusScannedAttachment-E003: error getting S3 object names from event data.  Error msg: %s', e)
        traceback.print_tb(sys.exc_info()[2])
        return 
    
    try:
        dbObj.attachmentReceivedBackFromSTP(attmObj, 'ProcessVirusScannedAttachment')
    except Exception as e:
        logging.error('irschProcessVirusScannedAttachment-E004: error raised from database object in setting db status.  Error msg = %s', e)
        traceback.print_tb(sys.exc_info()[2])
    
    # The file is loaded to bucket/bderet/uuid_filename,  the file is copied into bucket/attachment/uuid/filename
    # INCOMING: bucket=bucket  key=bderet/uuid_filename  uuid(sub-folder) = uuid   file = filename
    file_FolderName = attmObj.getIncomingS3Key().split('/')[-1] 
    splitKey = file_FolderName.split('_')
    folderName = splitKey[0]
    if folderName.startswith('U',0):
        attmObj.setIncomingType(constants.SUBMISSION_BATCH_FILE)
    if len(splitKey) > 2:
        x = splitKey[1:]
        attachmentName = '_'.join(x)
    else:
        attachmentName = file_FolderName.split('_')[1]
    
    destKey = constants.EXPOSED_ATTACHMENT_FOLDER + '/' + folderName + '/' + attachmentName
    originalKey = constants.UPLOAD_FOLDER + '/' + folderName + '/' + attachmentName
    
    try:
        environDict['s3Handle'].Object(attmObj.getIncomingS3Bucket(),destKey).copy_from(CopySource={'Bucket': attmObj.getIncomingS3Bucket(), 'Key': attmObj.getIncomingS3Key()})
        logging.info('irschProcessVirusScannedAttachment-I002: file = %s copied from file %s in bucket = %s and is available for access by a user', destKey, attmObj.getIncomingS3Key(), attmObj.getIncomingS3Bucket())
    except Exception as e:
        logging.error('irschProcessVirusScannedAttachment-E005: error copying file from bdert to attachments.  error msg = %s', e)
        return 
    
    exposedS3Obj = 's3://' + attmObj.getIncomingS3Bucket() + '/' + destKey
    try:
        dbStatus = dbObj.attachmentAvailableStatus(exposedS3Obj, attmObj, 'ProcessVirusScannedAttachment')
        if dbStatus == 'success':
            pass
        else:
            return dbStatus
    except Exception as e:
        logging.error('irschProcessVirusScannedAttachment-E006: error raised from database processing. Error msg = %s',e)
        traceback.print_tb(sys.exc_info()[2])
        return  
      
    try:
        environDict['s3Handle'].Object(attmObj.getIncomingS3Bucket(), attmObj.getIncomingS3Key()).delete()
        logging.info('irschProcessVirusScannedAttachment-I003: file = %s in bucket = %s is deleted', attmObj.getIncomingS3Key(), attmObj.getIncomingS3Bucket())
    except Exception as e:
        logging.error('irschProcessVirusScannedAttachment-E007: error raised deleting file from bucket = %s, file = %s,  error msg = %s', attmObj.getIncomingS3Bucket(), attmObj.getIncomingS3Key(),e)
    try:
        environDict['s3Handle'].Object(attmObj.getIncomingS3Bucket(), originalKey).delete()
        logging.info('irschProcessVirusScannedAttachment-I004: file = %s in bucket = %s is deleted', originalKey, attmObj.getIncomingS3Bucket())
    except Exception as e:
        logging.error('irschProcessVirusScannedAttachment-E008: error raised deleting file from bucket = %s, file = %s,  error msg = %s', attmObj.getIncomingS3Bucket(), originalKey, e)
    
    # Checks if the type is `SUBMISSION_BATCH_FILE`
    # Invokes submit case api by getting attm_id and btch_reqs_id
    # Parses the response for status codes to confirm the invocation
    
    if (attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE):
        try:
            return_dict = {}
            return_dict = dbObj.getPrincipleIdForBatch(attmObj, folderName, attachmentName, 'ProcessVirusScannedAttachment')
            if return_dict['prin_id'] is not None: 
                isSuccess = pushToSubmitCaseBatchParserQueue(return_dict)
                                    
                if not isSuccess:
                    dbObj.setAttachmentProcessResultCode(return_dict['attm_id'], return_dict['btch_reqs_id'], constants.UNSUCCESSFUL)
                else:
                    logging.info('Successfully invoked SubmitCaseBatchParser')
                return isSuccess 
    
        except Exception as e:
            dbObj.setAttachmentProcessResultCode(return_dict['attm_id'], return_dict['btch_reqs_id'], constants.UNSUCCESSFUL)
            logging.error(e)
            errror_alert.raiseAlert("irschProcessVirusScannedAttachment", "SubmitCase API was not invoked ", str(e))
    elif folderName.startswith('R',0) or folderName.startswith('C',0):
        handleSendToRemoteApp(attmObj, folderName, attachmentName, errror_alert)


def pushToSubmitCaseBatchParserQueue(return_dict):
    '''
    Pushes the attmId to the SubmitCaseBatchParser queue for processing a batch file.
    Return True on success
    '''
    global submitCaseBatchParserSqsHelper

    attmIdDict = {
        'attmId' : return_dict['attm_id'],
        'source': 'ProcessVirusScannedAttachment'
    }
    event_secure_invoke_msg = buildLambdaSecureInvokeEvent(return_dict['prin_id'], 'POST', '/submitcasebatchparser', attmIdDict)
    
    try:
        submitCaseBatchParserQueueUrl = environDict.get(envVblNames.ENV_SUBMITCASEBATCHPARSER_QUEUE_URL)
        if submitCaseBatchParserSqsHelper is None:
            regionName = environDict.get(envVblNames.ENV_SQS_REGION)
            submitCaseBatchParserSqsHelper = SqsHelper(submitCaseBatchParserQueueUrl, regionName=regionName)
             
        outgoingBody = json.dumps(event_secure_invoke_msg)
        logging.info(f"pushToSubmitCaseBatchParserQueue posting msg to queue {submitCaseBatchParserQueueUrl}: outgoingBody={outgoingBody}")
        queueResp = submitCaseBatchParserSqsHelper.sendMessageToQueue(outgoingBody)
        messageId = queueResp.get('MessageId')
        logging.info(f"pushToSubmitCaseBatchParserQueue: messageId={messageId} queueResp={queueResp}")
        if messageId is not None:
            return True
    except Exception as e:
        logging.error(f"Failed to pushToSubmitCaseBatchParserQueue: e={e}")
        # Propagate exception so alert is raised and AWS retries
        raise e
    return False
        
def handleSendToRemoteApp(attmObj, folderName, attachmentName, errror_alert):
    try:
        partnerCache = applicationConfigHelper.getPartnerCache()
        result = dbObj.getAttachmentType(folderName, attachmentName)
        if result is not None:
            attmType = result['attm_typ_cd']
            if attmType == constants.SUBMITTER_ATTACHMENT:
                rschReq = folderName[1:]
                cases = dbObj.getCasesForRschReq (rschReq)
                for case in cases:
                    subjRschId = case['subj_rsch_id']
                    teamId = case['curr_rsch_team_id']
                    try:
                        teamName = ResearchTeamCode(teamId).name
                    except ValueError:
                        teamName = None
                    if teamName is not None:
                        partnerConfig = partnerCache[teamName]
                        logging.info('partnerConfig is %s ' % partnerConfig)
                        if partnerConfig is not None and partnerConfig['SendToPartner'] == True:
                            sendMessageToSubmitToRemoteApp(subjRschId, SubmitToRemoteAppTypeCode.SUBMIT_TO_PARTNER.value, teamName)
            elif attmType == constants.CHALLENGE_ATTACHMENT:
                subjRschId = folderName[1:]
                teamIdObj = dbObj.getTeamForCase(subjRschId)
                if teamIdObj != None:
                    teamName = None
                    if ResearchTeamCode.hasValue(teamIdObj.get('curr_rsch_team_id')):
                        teamName = ResearchTeamCode(teamIdObj.get('curr_rsch_team_id')).name
                    if teamName is not None:
                        partnerConfig = partnerCache.get(teamName)
                        if partnerConfig is not None and partnerConfig['SendToPartner'] == True and partnerConfig['SendChallenge'] == True:
                            sendMessageToSubmitToRemoteApp(subjRschId, SubmitToRemoteAppTypeCode.SEND_CHALLENGE_TO_PARTNER.value, teamName)
                        
    except Exception as e:
        logging.error(e)
        errror_alert.raiseAlert("irschProcessVirusScannedAttachment", "Error while trying to SendToRemoteApp", str(e))
                    
                    
def sendMessageToSubmitToRemoteApp(subjRschId, typeCode, teamName):
    global submitToRemoteAppSQSHelper
    
    message = {
        'subjectResearchId' : subjRschId,
        'submitToRemoteAppTypeCode': typeCode,
        'researchTeamName' : teamName
    }
    
    try:
        submitToRemoteAppQueueUrl = environDict.get(envVblNames.ENV_SUBMITTOREMOTEAPP_QUEUE_URL)
        if submitToRemoteAppSQSHelper is None:
            regionName = environDict.get(envVblNames.ENV_SQS_REGION)
            submitToRemoteAppSQSHelper = SqsHelper(submitToRemoteAppQueueUrl, regionName=regionName)
             
        outgoingBody = json.dumps(message)
        logging.info(f"sendMessageToSubmitToRemoteApp posting msg to queue {submitToRemoteAppQueueUrl}: outgoingBody={outgoingBody}")
        queueResp = submitToRemoteAppSQSHelper.sendMessageToQueue(outgoingBody)
        messageId = queueResp.get('MessageId')
        logging.info(f"sendMessageToSubmitToRemoteApp: messageId={messageId} queueResp={queueResp}")
    except Exception as e:
        logging.error(f"Failed to sendMessageToSubmitToRemoteApp: e={e}")
        # Propagate exception so alert is raised and AWS retries
        raise e



if __name__ == '__main__':
    pass