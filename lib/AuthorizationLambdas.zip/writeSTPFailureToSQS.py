'''
Created on Mar 18, 2019

@author: MorganB
'''
import logging
import boto3
import json

from common.util.awsUtils import createClientConfiguration

sqsObj = None 

def writeSTPFailureToSQS(attmObj,environDict):
    global sqsObj
        
    if not sqsObj:
        try:
            sqsObj = boto3.resource('sqs', config=createClientConfiguration(environDict))
        except Exception as e:
            logging.error('writeSTPFailureToSQS-E001: Error establishing SQS connection.  error msg = %s', e)
            raise
    try: 
        logging.info(f"writeSTPFailureToSQS: get_queue_by_name ({environDict['stpFailureQueue']})") 
        sqsQueue = sqsObj.get_queue_by_name(QueueName= environDict['stpFailureQueue'])  
        queueMessage = json.dumps(attmObj.getAll())
        logging.info(f"writeSTPFailureToSQS: sending queueMessage={queueMessage} ...")
        queueResponse = sqsQueue.send_message(MessageBody= queueMessage)
        logging.info(f"writeSTPFailureToSQS: back from sending message")
    except Exception as e:
        logging.error('writeSTPFailureToSQS-E002: Error writing message to the SQS queue.  error msg = %s', e)
        raise
    
    logging.info('writeSTPFailureToSQS-I001: Queue message ID = %s',queueResponse.get('MessageId'))
    

if __name__ == '__main__':
    pass