'''
Created on Feb 14, 2019

@author: MorganB
'''
import logging
import json
import traceback
import sys
import datetime
from common.userTypes import UserType
from common.envVblNames import ENV_TOKEN_EXPIRATION_TIME, ENV_OL_SECRET_KEY
from common.util.stringUtils import isBlank
from SetLambdaLogging import setLogging
from buildUIResponse import buildUIResponse
from invokeRecordLogonLambda import recordUserInfo
from extractLambdaInput import extractLambdaInput
from buildSessionTokenResponse import buildSessionTokenResponseBody
from buildEnvironVarDict import buildEnvironVarDict
from common.dbConn import DatabaseConnection

environDict = {}
dbConn = None

def lambdaHandler(event, context):
    '''
    Mock LogonValidation
    '''
    global environDict
    global dbConn
    if not environDict:
        try:
            environDict = buildEnvironVarDict()
        except Exception as e:
            logging.error('mockGUIAuthenticationLambda - error generating environDict.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return 
    
    setLogging(environDict['loggingLevel'])
        
    if dbConn is None:
        try:
            logging.info('mockGUIAuthenticationLambda cold start initializing dbConn')
            dbConn = DatabaseConnection(environDict)
        except Exception as e:
            logging.error('mockGUIAuthenticationLambda caught exception initializing dbConn: ' + str(e))
            logging.error('mockGUIAuthenticationLambda - error building DatabaseConnection object.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return buildUIResponse(500, 'Internal error processing Authentication request')
    else:
        logging.info('mockGUIAuthenticationLambda warm start - testing database connection...')
        try:
            dbConn.checkConnection()
            logging.info('mockGUIAuthenticationLambda continuing after database connection tested')
        except Exception as e:
            logging.error('mockGUIAuthenticationLambda - error testing database connection.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return buildUIResponse(500, 'Internal error processing Authentication request')
    
    try:
        incomingContent = extractLambdaInput(event)
    except:
        traceback.print_tb(sys.exc_info()[2])
        return buildUIResponse(400, 'Improper input to Lambda function')
    
    # In the mock call, everything is sent under 'code' 
    if 'code' in incomingContent:
        pass
    else:
        logging.error('mockGUIAuthenticationLambda - missing code in incoming message')
        return buildUIResponse(500, 'Internal error processing Authentication request')

    incomingData = incomingContent['code']
    logging.info('mockGUIAutenticationLambda-INFO incomingData=' + incomingData)
    
    decodedIncomingData = decodeMockOneLoginResponse(incomingData) 
    
    responseBody = buildSessionTokenResponseBody(decodedIncomingData,environDict,dbConn)

    # invoke the lambda that will update the user info within the iResearch database 
    try:
        logging.info('Invoking recordLogin at ' + environDict['recordLoginArn'] + " with body=" + str(decodedIncomingData))
        #if recordUserInfo(decodedIncomingData,environDict['recordLoginArn']) == False:
        if recordUserInfo(decodedIncomingData,responseBody["session_token"],event,environDict['recordLoginArn'],environDict) == False:
            logging.error('mockGUIAutenticationLambda-lambdaHandler - False value returned from invokeRecordLogon module' )
            return buildUIResponse(500, 'Internal error processing Authentication request')
    except Exception as e:
        logging.error ('Exception = %s', e)
        logging.error('mockGUIAutenticationLambda-lambdaHandler - Error occurred in invokeRecordLogon module' )
        traceback.print_tb(sys.exc_info()[2])
        return buildUIResponse(500, 'Internal error processing Authentication request')
    
    # send the session token and related information to the invoking browser application  
    try:
        msgBody = str(json.dumps(responseBody))
        logging.info('IRSCHRESPONSE body=' + msgBody)
        return buildUIResponse(200, msgBody, 'application/json')
    except:
        traceback.print_tb(sys.exc_info()[2])
        return buildUIResponse(500, 'Internal error sending response')

def decodeMockOneLoginResponse(data):
    dataParts = data.split(':')
    userName = dataParts[0]
    nameDomain = userName.split('@')
    if len(nameDomain) == 1:
        # user name did not include @domain
        familyName = userName
        email = userName + '@dnb.com'
    else:
        # user name included @domain so keep it as email address
        familyName = nameDomain[0]
        email = userName
    rolesList = dataParts[1].split(',')
    if isBlank(dataParts[2]):
        teamsList = []
    else:
        teamsList = dataParts[2].split(',')
    company = None
    if len(dataParts) > 3:
        # Can't figure out how to pass a space from mockOneLogin.html so within company name only, underscore is mapped to space:
        company = dataParts[3].replace("_", " ")
    groupList = rolesList + teamsList
    expTime = 3600 * 24 * 365 * 10  # expires session in 10 years 
    x = datetime.datetime.utcnow() + datetime.timedelta(seconds=expTime)

    ddict = {
        'given_name': 'Mock',
        'family_name': familyName,
        'email' : email,
        'loginKey' : email,
        'user_type': UserType.USER_TYPE_UI.value,
        'exp': int(x.timestamp()),
        'groups' : groupList
    }
    if company is not None:
        ddict['company'] = company
    return ddict

if __name__ == '__main__':
    #pass
    decodedResponse = decodeMockOneLoginResponse('SubmitterSuper7:IRESEARCH_ACCESS,IRESEARCH_SUBMITTER_US_SUPER7:IRESEARCH_TEAM_US_SUPER7')
    print('decodeMockOneLoginResponse(SubmitterSuper7:IRESEARCH_ACCESS,IRESEARCH_SUBMITTER_US_SUPER7:IRESEARCH_TEAM_US_SUPER7):')
    print('  email:' + decodedResponse['email'])
    groups = decodedResponse['groups']
    for group in groups:
        print('  group:' + group)
    