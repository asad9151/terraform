''''
Created on Oct 10, 2018

@author: MorganB
'''
import json
import logging
import requests
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
#from requests.packages.urllib3.util.retry import Retry
from urllib3.util.retry import Retry

from common.envVblNames import getEnvironAsBool
from decodeJWT import decodeJWT


class OLAuthClass():
    TIMEOUT_SECS = 5
    MAX_RETRIES = 3
    RETURN_CODES_TO_RETRY = [ 502, 503, 504 ]

    def __init__(self,environDict):
        self.id_token = ''
        self.access_token = ''
        self.refresh_token = ''
        self.token_type = 'Bearer'
        self.expires_in = '3600'
        self.decodedOLJWTPayload = {}
        self.OLURL = environDict["oneLoginAuthUrl"]
        self.OLclientID = environDict['oneLoginClientId']
        self.OLclientSecret = environDict['oneLoginSecretKey']
        self.redirectURL = environDict['oneloginRedirectUrl']
        self.S3Handle = ''
        self.headerValue = None
        self.payload = None
        self.olresp = None
        self.textDict = None
        OLverifyTxt = environDict.get('oneLoginVerify')
        self.OLverify = getEnvironAsBool(OLverifyTxt) if OLverifyTxt is not None else True


    def validateAuthCode(self, authCode):

        self.headerValue = {'Content-Type': 'application/x-www-form-urlencoded'}
        self.payload = {'grant_type':'authorization_code', 'code': authCode, 'redirect_uri': self.redirectURL}
        try:
            logging.info(f"validateAuthCode: Set total={OLAuthClass.MAX_RETRIES} retries on session for return codes {OLAuthClass.RETURN_CODES_TO_RETRY}")
            s = requests.Session()
            retries = Retry(total=OLAuthClass.MAX_RETRIES, backoff_factor=1, status_forcelist=OLAuthClass.RETURN_CODES_TO_RETRY)
            s.mount("https://", HTTPAdapter(max_retries=retries))
            
            logging.info(f"validateAuthCode: POST to url={self.OLURL} with basic auth and headers={self.headerValue} using clientId={self.OLclientID}: data={self.payload} timeout={OLAuthClass.TIMEOUT_SECS}s verify={self.OLverify} ...")
            #print(f"self.OLclientSecret={self.OLclientSecret}")
            self.olresp = requests.post(self.OLURL, 
                                        data=self.payload,
                                        headers=self.headerValue, 
                                        auth=HTTPBasicAuth(self.OLclientID, self.OLclientSecret), 
                                        timeout=OLAuthClass.TIMEOUT_SECS,
                                        verify=self.OLverify)
            logging.info(f"validateAuthCode returned with status_code={self.olresp.status_code} text={self.olresp.text}")
        except ConnectionError as err1:
            logging.error('OLAuthClass-validateAuthCode - Error connecting to OneLogin to validate authentication code. Error = %s', err1)
            raise
        except Exception as err2:
            logging.error('OLAuthClass-validateAuthCode - Unforeseen error validating authentication code.  error = %s', err2)
            raise
        
        if self.olresp.status_code != 200:
            if self.olresp.status_code == 401:
                return self.olresp.status_code
            else:
                logging.error('validateAuthCode: code = %s', authCode)
                logging.error('validateAuthCode: OLDataClass error - OneLogin return code = %s',self.olresp.status_code) 
                logging.error('validateAuthCode: OLDataClass error =  %s',self.olresp.text)
                return self.olresp.status_code
        
        self.textDict = json.loads(self.olresp.text) 
        if 'access_token' in self.textDict:
            self.access_token = self.textDict['access_token']
        else:
            logging.error('OLAuthClass-validateAuthCode - OLDataClass error - access_token missing from OneLogin response')
            raise Exception('access_token missing from OneLogin response')
        if 'id_token' in self.textDict:
            self.id_token = self.textDict['id_token']
        else:
            logging.error('OLAuthClass-validateAuthCode - OLDataClass error - id_token missing from OneLogin response')
            raise Exception('id_token missing from OneLogin response')
        if 'refresh_token' in self.textDict:
            self.refresh_token = self.textDict['refresh_token']

        try:
            tokenStatus, self.decodedOLJWTPayload = decodeJWT(self.id_token)
        except Exception as err:
            logging.error('OLDataClass error - Response from code authentication.  Cannot decode id_token. error = %s', err)
            raise
        return self.olresp.status_code

    def getOLJWTPayload(self):
        return self.decodedOLJWTPayload
if __name__ == '__main__':
    pass