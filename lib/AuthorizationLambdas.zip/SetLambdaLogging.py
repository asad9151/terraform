import logging
import os


#_LOGGING_FORMAT = '%(asctime)s %(levelname)s:%(message)s'
_LOGGING_FORMAT = '%(asctime)s [%(levelname)s] %(name)s %(message)s'
#_LOGGING_DATEFORMAT = '%m/%d/%Y %I:%M:%S %p'
_LOGGING_DATEFORMAT = '%m-%d-%Y %H:%M:%S'
_DEFAULT_DEBUG_LOG_NAMES = "botocore.endpoint,urllib3.connectionpool,botocore.parsers,botocore.retryhandler"

def setLogging(logginglevel):
    root = logging.getLogger()
    if root.handlers:
        for handler in root.handlers:
            root.removeHandler(handler)

    if logginglevel == 'ERROR':
        print("Setting logging level to ERROR")
        logging.basicConfig(format=_LOGGING_FORMAT, datefmt=_LOGGING_DATEFORMAT,
                        level=logging.ERROR)
    elif logginglevel == 'INFO':
        print("Setting logging level to INFO")
        _setInfoLevelWithOverrides()
    elif logginglevel == 'DEBUG':
        print("Setting logging level to DEBUG")
        logging.basicConfig(format=_LOGGING_FORMAT, datefmt=_LOGGING_DATEFORMAT,
                        level=logging.DEBUG)
    else:
        print("Setting logging level to INFO")
        _setInfoLevelWithOverrides()
        


def _setInfoLevelWithOverrides():
    logging.basicConfig(format=_LOGGING_FORMAT, datefmt=_LOGGING_DATEFORMAT,
                    level=logging.INFO)
    # When we set up INFO level logging, we set a few module names to DEBUG level to help troubleshoot specific problems we have had, like KMS and lambda invoke
    specialDebugLogNames = os.environ.get('irsch_loggingDebugModules', _DEFAULT_DEBUG_LOG_NAMES)
    for moduleName in specialDebugLogNames.split(","):
        logging.getLogger(moduleName).setLevel(logging.DEBUG)
    logging.info(f"Overrode INFO logging level to DEBUG for: {specialDebugLogNames}")

    
if __name__ == '__main__':
    pass