'''
Updated on Mar 22, 2019

@author: MorganB
'''
import logging
from urllib.parse import unquote_plus

from common.util.stringUtils import replaceSpacesAndNonLatin
from lambdas import errorMessages
from lambdas.exceptions import LambdaConflictException

class attachment():
    
    def __init__(self):
        self.newS3Key = None
        self.oldFileName = None
        self.oldFolderName = None
        self.attachmentProcessingDict = {
            "incomingFileName": "",             # name of file without folder or bucket - from initial request data
            "incomingAttachmentKey": "",        # research-request or subject-research ID - from initial request data
            "incomingFolder": "",               # S3 folder for attachment - same as key but with an S or an R prefix
            "incomingType": "",                 # scots code to designate if submitter or researcher entered - from initial request data
            "incomingSize": "",                 # size of file - from incoming event
            "incomingUserEmail": "",            # email of user - from principalId of initial request event
            "userID": "",                       # email used as an index into user
            "incomingS3Bucket": "",             # from incoming event
            "incomingS3Key": "",                # folder and file name combined - from incoming event
            "incomingS3Arn":"",                 # S3 ARN - from incoming event
            "s3Obj": "",                        # calculated S3 obj s3://{bucket}/{key}              
            "localDirectory": "",               # local directory in Lambda to store incoming file 
            "localFileName": "",
            "adjustedFileName": "",             # name with random value prefix attached
            "attachmentId": None,               # internal id of the attachment
            "subjectResearchId": None,          # case# if a case-level attachment
            "researchRequestId": None,          # request# if a research request-level attachment
            "attachmentTimestamp": "",          # time the attachment was added
            "processStatusCd": None,            # status of the attachment processing
            "processResultCd": None,            # result of processing
            "batchRequestId": None,             # batch id, if this is a batch file
            "batchFormatCode": None,            # batch file format, if a batch file
            "batchSourceCode": None,            # source of the batch file, if a batch file
            "batchStatusCode": None,            # batch status, if a batch file
            "sessionToken": None,               # session token identifier, if known
            "batchRejectReasonComment": None,   # why batch was rejected
            "batchRejectionErrorText": None,    # detailed error behind batch rejection
            "batchTotalEntriesCount": 0,        # number of requests+rejects in the batch
            "batchRejectedEntriesCount": 0,         # number of rejects in the batch
            "authPrinIdObj": None,              # principalId from the session if available
            "batchType": "",                    # batch type that will be recorded into the btch_reqs table
            "campaignPriority" : None,          # campaignPriority that will be recorded into the btch_reqs table
            "campaignRouting" : None,           # campaignRouting that will be recorded into the btch_reqs table
            "requestAttachmentLinkResponse": None   # response from requestAttachmentLink request
            }
        
    def getAll(self):
        return self.attachmentProcessingDict
    
    def loadRequestAttributes(self,incomingContent):
        try:
            self.setIncomingFileName(incomingContent['attachmentName'])
            self.setIncomingType(incomingContent['attachmentType'])
            if 'attachmentKey' in incomingContent.keys():
                self.setIncomingAttachmentKey(incomingContent['attachmentKey'])
            if 'batchType' in incomingContent.keys():
                self.setBatchType(incomingContent['batchType'])
            if 'campaignPriority' in incomingContent.keys():
                self.setCampaignPriority(incomingContent['campaignPriority'])
            if 'campaignRouting' in incomingContent.keys():
                self.setCampaignRouting(incomingContent['campaignRouting'])
            
        except Exception as e:
            logging.error('attmObj-E001: Exception raised loading parameters for signed URL request.  error msg = %s',e)
            raise
        
    def loadS3Attributes(self, event, environDict, dbObj):
        returnValue = "NoSpecialCharsInFileName"
        #self.attachmentProcessingDict = {key:value for (key,value) in s3Attributes.items()}
        if 'Records' not in event or 's3' not in event['Records'][0]:
            logging.error('attmObj-E002: missing Records or S3 value from event data')
            raise LambdaConflictException(errorMessages.ERR_INTERNAL_REQUEST)
        try:
            self.setIncomingS3Bucket(event['Records'][0]['s3']['bucket']['name'])
        except Exception as e:
            logging.error('attmObj-E003: missing bucket name from event data.  error msg = %s',e)
            raise
        try: 
            self.setIncomingS3Key(unquote_plus(event['Records'][0]['s3']['object']['key']))
        except Exception as e:
            logging.error('attmObj-E004: missing S3Key from event data  error msg = %s',e)
            raise
        try:
            self.setIncomingS3Arn(event['Records'][0]['s3']['bucket']['arn'])
        except Exception as e:
            logging.warning ('attmObj-W001: no ARN detected  error msg = %s',e)
        try: 
            self.setIncomingSize(event['Records'][0]['s3']['object']['size'])
        except Exception as e:
            logging.warning('attmObj-W002: no size element detected  error msg = %s',e)
            
        ## get rid of special characters in key name, if any ##
        tmpS3Key = replaceSpacesAndNonLatin(self.attachmentProcessingDict['incomingS3Key'])
        if tmpS3Key != self.attachmentProcessingDict['incomingS3Key']:
            returnValue = 'SpecialCharsInFileName'
            self.newS3Key = tmpS3Key
            try:
                environDict['s3Handle'].Object(self.getIncomingS3Bucket(),self.newS3Key).copy_from(CopySource={'Bucket': self.getIncomingS3Bucket(), 'Key': self.getIncomingS3Key()})
                logging.info('attachmentClass-I001: bucket = %s, key = %s copied to key = %s', self.getIncomingS3Bucket(), self.getIncomingS3Key(), self.newS3Key)
            except Exception as e:
                logging.error('attachmentClass-E005: error copying key from %s to %s.  error msg = %s', self.getIncomingS3Key(), self.newS3Key, e)
                raise
            try:
                environDict['s3Handle'].Object(self.getIncomingS3Bucket(), self.getIncomingS3Key()).delete()
            except Exception as e:
                logging.error('attachmentClass-W003: error deleting key from %s, processing continues  error msg = %s', self.getIncomingS3Key(), e)

            self.oldFileName = self.getIncomingS3Key().split('/')[-1]
            self.oldFolderName = self.getIncomingS3Key().split('/')[-2]
            try:
                dbObj.resetIncomingFileName(self.oldFileName, self.oldFolderName,self.newS3Key.split('/')[-1])
            except Exception as e:
                logging.error('attachmentClass-E006: error raised form dbObj in resetting file name = %s.  error msg = %s', self.getIncomingS3Key(), e)
                raise
            self.attachmentProcessingDict['incomingS3Key'] = self.newS3Key
        
        self.setIncomingS3Obj()
        self.setIncomingFileName(self.getIncomingS3Key().split('/')[-1])
        self.setIncomingFolder(self.getIncomingS3Key().split('/')[-2])
    
        logging.info('attmObj-I002: attributes %s', self.attachmentProcessingDict)
        return returnValue
    
    def loadSTPRetry(self,msgDict):
        try:
            self.attachmentProcessingDict = {key:value for (key,value) in msgDict.items()}
        except Exception as e:
            logging.error('attachmentClass-E007: error encountered loading attachmentProcessDict error msg = %s, incoming data = %s', e, msgDict)
            raise
        
    def getIncomingFileName(self):
        return self.attachmentProcessingDict['incomingFileName']
    def setIncomingFileName(self, value):
        self.attachmentProcessingDict['incomingFileName'] = value
    
    def getAdjustedFileName(self):
        return self.attachmentProcessingDict['adjustedFileName']
    def setAdjustedFileName(self, value):
        self.attachmentProcessingDict['adjustedFileName'] = value
    
    
    def getIncomingAttachmentKey(self):
        return self.attachmentProcessingDict['incomingAttachmentKey']
    def setIncomingAttachmentKey(self, value):
        self.attachmentProcessingDict['incomingAttachmentKey'] = value
    
    def getIncomingFolder(self):
        return self.attachmentProcessingDict['incomingFolder']
    def setIncomingFolder(self, value):
        self.attachmentProcessingDict['incomingFolder'] = value
    
    def getIncomingType(self):
        return self.attachmentProcessingDict['incomingType']
    
    def setIncomingType(self, value):
        self.attachmentProcessingDict['incomingType'] = value
    
    def getIncomingSize(self):
        return self.attachmentProcessingDict['incomingSize']
    def setIncomingSize(self, value):
        self.attachmentProcessingDict['incomingSize'] = value
    
    def getIncomingUserEmail(self):
        return self.attachmentProcessingDict['incomingUserEmail']
    def setIncomingUserEmail(self, value):
        self.attachmentProcessingDict['incomingUserEmail'] = value
    
    def getUserID(self):
        return self.attachmentProcessingDict['userID']
    def setUserID(self, value):
        self.attachmentProcessingDict['userID'] = value
        
    def getIncomingS3Bucket(self):
        return self.attachmentProcessingDict['incomingS3Bucket']
    def setIncomingS3Bucket(self, value):
        self.attachmentProcessingDict['incomingS3Bucket'] = value 
        
    def getIncomingS3Key(self):
        return self.attachmentProcessingDict['incomingS3Key']
    def setIncomingS3Key(self, value):
        self.attachmentProcessingDict['incomingS3Key'] = value
        
    def getIncomingS3Arn(self):
        return self.attachmentProcessingDict['incomingS3Arn']
    def setIncomingS3Arn(self, value):
        self.attachmentProcessingDict['incomingS3Arn'] = value 
        
    def getIncomingS3Obj(self):
        return self.attachmentProcessingDict['s3Obj']
    def setIncomingS3Obj(self):
        self.attachmentProcessingDict['s3Obj'] = 's3://' + self.attachmentProcessingDict['incomingS3Bucket'] + '/' + self.attachmentProcessingDict['incomingS3Key']     

    def getS3Obj(self):
        return self.attachmentProcessingDict['s3Obj']
    def setS3Obj(self, s3Obj):
        self.attachmentProcessingDict['s3Obj'] = s3Obj
            
    def getLocalDirectory(self):
        return self.attachmentProcessingDict['localDirectory']
    def setLocalDirectory(self, value):
        self.attachmentProcessingDict['localDirectory'] = value
        
    def getLocalFileName(self):
        return self.attachmentProcessingDict['localFileName']
    def setLocalFileName(self, localDir):
        self.attachmentProcessingDict['localFileName'] = localDir + self.attachmentProcessingDict['incomingFolder'] + '_' + self.attachmentProcessingDict['incomingFileName']
                
    def getAttachmentId(self):
        return self.attachmentProcessingDict['attachmentId']
    def setAttachmentId(self, attachmentId):
        self.attachmentProcessingDict['attachmentId'] = attachmentId
        
    def getSubjectResearchId(self):
        return self.attachmentProcessingDict['subjectResearchId']
    def setSubjectResearchId(self, subjRschId):
        self.attachmentProcessingDict['subjectResearchId'] = subjRschId

    def getResearchRequestId(self):
        return self.attachmentProcessingDict['researchRequestId']
    def setResearchRequestId(self, rschReqId):
        self.attachmentProcessingDict['researchRequestId'] = rschReqId
        
    def getAttachmentTimestamp(self):
        return self.attachmentProcessingDict['attachmentTimestamp']
    def setAttachmentTimestamp(self, tmst):
        self.attachmentProcessingDict['attachmentTimestamp'] = tmst
    
    def getProcessStatusCd(self):
        return self.attachmentProcessingDict['processStatusCd']
    def setProcessStatusCd(self, statCd):
        self.attachmentProcessingDict['processStatusCd'] = statCd
    
    def getProcessResultCd(self):
        return self.attachmentProcessingDict['processResultCd']
    def setProcessResultCd(self, statCd):
        self.attachmentProcessingDict['processResultCd'] = statCd
        
    def getBatchRequestId(self):
        return self.attachmentProcessingDict['batchRequestId']
    def setBatchRequestId(self, reqId):
        self.attachmentProcessingDict['batchRequestId'] = reqId
        
    def getBatchFormatCode(self):
        return self.attachmentProcessingDict['batchFormatCode']
    def setBatchFormatCode(self, fmtCd):
        self.attachmentProcessingDict['batchFormatCode'] = fmtCd
        
    def getBatchSourceCode(self):
        return self.attachmentProcessingDict['batchSourceCode']
    def setBatchSourceCode(self, srcCd):
        self.attachmentProcessingDict['batchSourceCode'] = srcCd
        
    def getBatchStatusCode(self):
        return self.attachmentProcessingDict['batchStatusCode']
    def setBatchStatusCode(self, statCd):
        self.attachmentProcessingDict['batchStatusCode'] = statCd
        
    def getSessionToken(self):
        return self.attachmentProcessingDict['sessionToken']
    def setSessionToken(self, tkn):
        self.attachmentProcessingDict['sessionToken'] = tkn

    def getBatchRejectReasonComment(self):
        return self.attachmentProcessingDict['batchRejectReasonComment']
    def setBatchRejectReasonComment(self, cmnt):
        self.attachmentProcessingDict['batchRejectReasonComment'] = cmnt

    def getBatchRejectionErrorText(self):
        return self.attachmentProcessingDict['batchRejectionErrorText']
    def setBatchRejectionErrorText(self, cmnt):
        self.attachmentProcessingDict['batchRejectionErrorText'] = cmnt

    def getBatchTotalEntriesCount(self):
        return self.attachmentProcessingDict['batchTotalEntriesCount']
    def setBatchTotalEntriesCount(self, cmnt):
        self.attachmentProcessingDict['batchTotalEntriesCount'] = cmnt

    def getBatchRejectedEntriesCount(self):
        return self.attachmentProcessingDict['batchRejectedEntriesCount']
    def setBatchRejectedEntriesCount(self, cmnt):
        self.attachmentProcessingDict['batchRejectedEntriesCount'] = cmnt

    def getAuthPrinIdObj(self):
        return self.attachmentProcessingDict['authPrinIdObj']
    def setAuthPrinIdObj(self, cmnt):
        self.attachmentProcessingDict['authPrinIdObj'] = cmnt
        
    def getBatchType(self):
        return self.attachmentProcessingDict['batchType']
    def setBatchType(self, batchType):
        self.attachmentProcessingDict['batchType'] = batchType

    def getRequestAttachmentLinkResponse(self):
        return self.attachmentProcessingDict['requestAttachmentLinkResponse']
    def setRequestAttachmentLinkResponse(self, requestAttachmentLinkResponse):
        self.attachmentProcessingDict['requestAttachmentLinkResponse'] = requestAttachmentLinkResponse
        
    def getCampaignPriority(self):
        return self.attachmentProcessingDict['campaignPriority']
    def setCampaignPriority(self, campaignPriority):
        self.attachmentProcessingDict['campaignPriority'] = campaignPriority
    
    def getCampaignRouting(self):
        return self.attachmentProcessingDict['campaignRouting']
    def setCampaignRouting(self, campaignRouting):
        self.attachmentProcessingDict['campaignRouting'] = campaignRouting