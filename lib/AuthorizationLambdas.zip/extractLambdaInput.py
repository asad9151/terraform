'''
Created on Oct 10, 2018

@author: MorganB
'''
import logging
import json

def extractLambdaInput(event):
    if not event:
        logging.error('processLambdainput-extractLambdaInput - no data passed in the EVENT variable from Lambda')
        raise
    if event['body'] == None:
        logging.error('processLambdainput-extractLambdaInput - no BODY in EVENT data.  Event = %s', event)
        raise 
    try:
        incomingContent = json.loads(event['body'])
    except Exception as err:
        logging.error('processLambdainput-extractLambdaInput - Error in converting event-data to JSON.  Data = %s', err)
        raise
    return incomingContent

if __name__ == '__main__':
    pass
