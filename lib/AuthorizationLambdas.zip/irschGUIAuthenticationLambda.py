'''
Updated on Feb 22, 2019

@author: MorganB
'''
import logging
import json
import traceback
import sys
#import boto3
import os 
#from base64 import b64decode
from SetLambdaLogging import setLogging
from extractLambdaInput import extractLambdaInput
from OLAuthClass import OLAuthClass
from buildSessionTokenResponse import buildSessionTokenResponseBody
from invokeRecordLogonLambda import recordUserInfo
from determineStartType import determineStartType
from buildEnvironVarDict import buildEnvironVarDict
from buildUIResponse import buildUIResponse
from common.dbConn import DatabaseConnection
from lambdas.statsLogger import StatsLogger
from common.util.xrayUtils import setupXray

# Global variables reset only at cold start
environDict = {}
statsLogger = None
dbConn = None


def lambdaHandler(event, context):
    '''
    LogonValidation lambda
    Cached objects:
    '''
    global environDict
    global dbConn
    global statsLogger

    # set logging level
    try:
        setLogging(os.environ['irsch_loggingLevel'])
    except:
        print ('***** LOGGING ENVIRON VARIABLE MISSING *****')
    
    if statsLogger is None:
        statsLogger = StatsLogger()
    
    # if environDict does not exist (i.e., a cold start), create it for invocation and subsequent warm starts 
    if not environDict:
        try:
            environDict = buildEnvironVarDict()
            setupXray(environDict)
        except Exception as err:
            traceback.print_tb(sys.exc_info()[2])
            logging.error('irschGUIAuthenticationLambda error - problem loading environment variables in REST request.  Err = %s', err)
            return buildUIResponse(500, 'Internal error processing Authentication request')
    
    logging.info ('environDict = %s', environDict)
        
    if dbConn is None:
        try:
            logging.info('irschGUIAuthenticationLambda cold start initializing dbConn')
            dbConn = DatabaseConnection(environDict)
        except Exception as e:
            logging.error('irschGUIAuthenticationLambda caught exception initializing dbConn: ' + str(e))
            logging.error('irschGUIAuthenticationLambda - error building DatabaseConnection object.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return buildUIResponse(500, 'Internal error processing Authentication request')
    else:
        logging.info('irschGUIAuthenticationLambda warm start - testing database connection...')
        try:
            dbConn.checkConnection()
            logging.info('irschGUIAuthenticationLambda continuing after database connection tested')
        except Exception as e:
            logging.error('irschGUIAuthenticationLambda - error testing database connection.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return buildUIResponse(500, 'Internal error processing Authentication request')
        
    # check to see if this is a timer initiated invocation (keep warm).  if it is, return
    if determineStartType(event) == 'timer':
        logging.info('ireschGUIAuthenticationLambda keep-warm exiting')
        statsLogger.logStats(True, False)
        return
    statsLogger.logStats(False, True)
    
    # record incoming information 
    logging.info('ireschGUIAuthenticationLambda - incoming event = %s', event)
    # get the OneLogin authentication code sent from UI 
    try:
        incomingContent = extractLambdaInput(event)
    except:
        traceback.print_tb(sys.exc_info()[2])
        return buildUIResponse(400, 'Improper input')

    # we need to get the recirectURL to be used for the auth code decryption with OL
    # First we try to get it from the redirect_uri parameter in the request body
    # If we don't get it from redirect_uri, we get this from the referer element within the header passed in the event.  
    # If we don't get it from there, we fall back and read it from the config file. 
    if 'redirect_uri' in incomingContent:
        environDict['oneloginRedirectUrl'] = incomingContent.get('redirect_uri')
        logging.info('irsch-GUI-Authenticationlambda-buildEnvironDict: redirect url taken from redirect_uri')
        logging.info ('redirect URL (x) = %s', environDict['oneloginRedirectUrl'])
    elif 'headers' in event and 'referer' in event['headers']:
        environDict['oneloginRedirectUrl'] = event['headers']['referer'].split('?')[0]
        logging.info('irsch-GUI-Authenticationlambda-buildEnvironDict: redirect url taken from header information')
        logging.info ('redirect URL (x) = %s', environDict['oneloginRedirectUrl'])
    elif 'headers' in event and 'Referer' in event['headers']: 
        environDict['oneloginRedirectUrl'] = event['headers']['Referer'].split('?')[0]
        logging.info('irsch-GUI-Authenticationlambda-buildEnvironDict: redirect url taken from header information')
        logging.info ('redirect URL (x) = %s', environDict['oneloginRedirectUrl'])
    else:
        logging.error('Missing referer element in incoming event header section - session rejected') 
        return buildUIResponse(500, 'Missing referer element in incoming data') 
    
    # make sure an authorization code was sent to us 
    if 'code' in incomingContent:
        pass
    else:
        logging.error('irschGUIAuthenticationLambda - missing code in incoming message')
        return buildUIResponse(500, 'Internal error processing Authentication request')
    
    # validate authentication code with OneLogin & get response JSON document  
    authObj = OLAuthClass(environDict)
    try:
        olCompletionCode = authObj.validateAuthCode(incomingContent['code'])
    except:
        traceback.print_tb(sys.exc_info()[2])
        return buildUIResponse(500, 'Internal error processing Authentication request')
    if olCompletionCode != 200:
        if olCompletionCode == 401:
            logging.error('irschGUIAutenticationLambda-lambdaHandler - code authorization failed' )
            return buildUIResponse(401, 'Authorization failed')
        else: 
            logging.error('irschGUIAutenticationLambda-lambdaHandler - internal code authorization process failed' )
            return buildUIResponse(500, 'Internal error processing Authentication request')
    
    # all is well if we got here.  Build and send the response JWT to the caller
    logging.info(f"Got OLJWT={authObj.getOLJWTPayload()}")
    responseBody = buildSessionTokenResponseBody(authObj.getOLJWTPayload(),environDict,dbConn) 
    
    # invoke the lambda that will update the user info within the iResearch database 
    try:
        logging.info('Invoking recordLogin at ' + environDict['recordLoginArn'] + " with body=" + str(authObj.getOLJWTPayload()))
        if recordUserInfo(authObj.getOLJWTPayload(),responseBody["session_token"],event,environDict['recordLoginArn'],environDict) == False:
            logging.error('irschGUIAutenticationLambda-lambdaHandler - False value returned from invokeRecordLogon module' )
            traceback.print_tb(sys.exc_info()[2])
            return buildUIResponse(500, 'Internal error processing Authentication request')
    except:
        logging.error('irschGUIAutenticationLambda-lambdaHandler - Error occurred in invokeRecordLogon module' )
        traceback.print_tb(sys.exc_info()[2])
        return buildUIResponse(500, 'Internal error processing Authentication request')
    
    # send the session token and related information to the invoking browser application  
    try:
        msgBody = str(json.dumps(responseBody))
        logging.info('IRSCHRESPONSE body=' + msgBody)
        return buildUIResponse(200, msgBody, 'application/json')
    except:
        traceback.print_tb(sys.exc_info()[2])
        return buildUIResponse(500, 'Internal error sending response')

if __name__ == '__main__':
    pass