'''
Updated on March 18, 2019

@author: MorganB
'''

import logging
import traceback
import sys
import boto3
from downloadFromS3ToLocal import downloadFromS3ToLocal
from determineStartType import determineStartType
from SetLambdaLogging import setLogging
from buildEnvironVarDict import buildEnvironVarDict
from sendFileToSTP import sendFileToSTP
from databaseClass import databaseClass
from attachmentClass import attachment
from deleteLocalFile import deleteLocalFile
import constants
from writeSTPFailureToSQS import writeSTPFailureToSQS
from lambdas.attachment.attachmentHelper import AttachmentHelper
from common.alert import Alert
from common.dbConn import DatabaseConnection
from common.util.awsUtils import createClientConfiguration

environDict = {}
dbObj = type('',(object,),{})()
attachmentHelper = None
dbConn = None

def deleteDuplicateFile(attmObj):
    pass

def lambdaHandler(event, context):
    '''
    This lambda is capable of operating in 3 different modes, depending on its environment configuration:
    
    1.  "Straight-STP production mode" in which files are posted immediately to the STP "puts" folder.
        After some delay, STP picks up the file, virus scans it, and then copies it back to the iResearch datastores S3 bucket "bderet" folder.
        Important environment variables: irsch_stpServer, irsch_stpUserId, irschEncrypted_stpPassword
    
    2.  "Straight-STP mock mode" in which files are posted, after a configured delay time, to the iResearch datastores S3 bucket "bderet" folder.
        Important environment variables: irsch_stpServer should be blank; irsch_mockStpBucket, irsch_mockStpDelaySecs should be set
    
    3.  "Stp Delivery Service mode" in which files are posted immediately to the StpOutboundDelivery service.
        Depending on the STP delivery service configurations, it may be handled there in either mock mode or production mode.
        Important environment variables: irsch_stpServer and irsch_mockStpBucket should be blank; set irsch_ProcessUploadedAttmThruStpDelivery to true.
    '''
    global environDict
    global dbObj
    global attachmentHelper
    global dbConn
    
    if not environDict:
        try:
            environDict = buildEnvironVarDict()
            environDict['s3Handle'] = boto3.resource('s3', config=createClientConfiguration(environDict))
            setLogging(environDict['loggingLevel'])
        except Exception as e:
            logging.error('irschProcessUploadedAttachment-E001: error building environDict.  error = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            return 
        
    errror_alert = Alert(environDict)
    if not isinstance(dbObj, databaseClass):
        try:
            dbObj = databaseClass(environDict)
        except Exception as e:
            logging.error('irschProcessUploadedAttachment-E002: error building database object.  error msg = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            errror_alert.raiseAlert("irschProcessUploadedAttachment", "Database Object was not created", str(e))
            return    
    else:
        # warm start
        try:
            logging.info('irschProcessUploadedAttachment warm start - testing database connection...')
            dbObj.checkConnection()
            logging.info('irschProcessUploadedAttachment continuing after database connection tested')
        except Exception as e:
            logging.error('irschProcessUploadedAttachment - error testing database connection.  error = %s', e)
            errror_alert.raiseAlert("irschProcessUploadedAttachment", "error testing database connection", str(e))
            return
    
    if determineStartType(event) == 'timer':    
        return

    logging.info('irschProcessUploadedAttachment-I001: incoming event = %s', event)
    
    attmObj = attachment()
    
    try:
        if attmObj.loadS3Attributes(event, environDict, dbObj) == 'SpecialCharsInFileName':
            logging.info('irschProcessUploadedAttachment-I003: Special characters found in file-name. Processing for this file will end')
            return
    except Exception as e:
        logging.error('irschProcessUploadedAttachment-E003: error getting S3 object names from event data.  Error msg: %s', e)
        traceback.print_tb(sys.exc_info()[2])
        return 
    
    try:
        dbStatus = dbObj.attachmentArrived(attmObj, 'ProcessUploadedAttachment')
        if dbStatus == 'success':
            pass
        else:
            logging.error('irschProcessUploadedAttachment-E015: Database update failed for the following reason: %s.  Processing will continue', dbStatus)        
    except Exception as e:
        logging.error('irschProcessUploadedAttachment-E005: error raised updating database that file arrived.  Error msg = %s', e)
        traceback.print_tb(sys.exc_info()[2])
    
    if downloadFromS3ToLocal(environDict, attmObj):
        pass
    else:
        logging.error('irschProcessUploadedAttachment-E004: download of S3 file failed.  Processing ending')
    
    try:
        stpFileSendStatus = sendFileToSTP(attmObj,environDict)
    except Exception as e:
        logging.error('irschProcessUploadedAttachment-E006: error raised sending file to STP.  Error msg = %s', e)
        traceback.print_tb(sys.exc_info()[2])
        deleteLocalFile(attmObj.getLocalFileName())
        return
    
    if stpFileSendStatus == 'successful':
        try:
            dbObj.attachmentSentToSTP(attmObj,'ProcessUploadedAttachment', constants.SUCCESSFUL)
            if dbConn is None:
                dbConn = DatabaseConnection(environDict)
            if attachmentHelper is None:
                attachmentHelper = AttachmentHelper(dbConn)
            attachmentHelper.sendFileToMockSTP(attmObj, environDict)
            attachmentHelper.sendFileToStpOutboundDeliveryService(attmObj, environDict, 'ProcessUploadedAttachment')
        except Exception as e:
            logging.error('irschProcessUploadedAttachment-E007: error raised updating database that file was sent to STP.  Error msg = %s', e)
            traceback.print_tb(sys.exc_info()[2])
            dbObj.attachmentSentToSTP(attmObj,'ProcessUploadedAttachment', constants.UNSUCCESSFUL)
            try:
                writeSTPFailureToSQS(attmObj, environDict)
            except Exception as e:
                logging.error('irschProcessUploadedAttachment-E009: Failure writing to SQS.  Error = %s', e)
                traceback.print_tb(sys.exc_info()[2])
    else:
        logging.error('irschProcessUploadedAttachment-E008: error sending file to STP.  Send status = %s', stpFileSendStatus)
        try:
            dbObj.attachmentSentToSTP(attmObj,'ProcessUploadedAttachment', constants.UNSUCCESSFUL)
            try:
                writeSTPFailureToSQS(attmObj, environDict)
            except Exception as e:
                logging.error('irschProcessUploadedAttachment-E009: Failure writing to SQS.  Error = %s', e)
                traceback.print_tb(sys.exc_info()[2])
        except Exception as e:
            logging.error('irschProcessUploadedAttachment-E010: error raised updating database that file send to STP failed.  Error msg = %s', e)
            traceback.print_tb(sys.exc_info()[2]) 
    
    deleteLocalFile(attmObj.getLocalFileName())
if __name__ == '__main__':
    pass