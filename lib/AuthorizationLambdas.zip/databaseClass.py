'''
Updated on March 18, 2019

@author: MorganB
'''
import pymysql
import logging
import constants
from common.batchFormatCodes import BatchFormatCode
from common.batchStatusCodes import BatchStatusCode
from common import envVblNames

class databaseClass():
    
    def __init__(self, environDict):
        self.db_config = {
        'user': '',
        'password': '',
        'host': '',
        'database': '',
        'charset' :'utf8mb4',
        'cursorclass': pymysql.cursors.DictCursor,
        'autocommit': True
        }
    
        self.db_config['user'] = environDict[envVblNames.ENV_DB_USER]
        self.db_config['password'] = environDict[envVblNames.ENV_DB_PASSWORD]
        self.db_config['host'] = environDict[envVblNames.ENV_DB_HOST]
        self.db_config['database'] = environDict[envVblNames.ENV_DB_SCHEMA]
        self.dbconn = None
        self.cursor = None
        self.batchRequestId = None
    
        try:
            self.dbconn = pymysql.connect(**self.db_config)
            self.cursor = self.dbconn.cursor()
        except pymysql.Error as err:
            logging.error('databaseClass-E001: error connecting to database.  error = %s', err)
            errmsg = "Other database connect error"
            if hasattr(err,'errno'):
                if err.errno == err.ER_ACCESS_DENIED_ERROR:
                    errmsg = "Something is wrong with your user name or password"
                elif err.errno == err.ER_BAD_DB_ERROR:
                    errmsg = "Database does not exist"
            logging.error(f"DatabaseConnection Class: {errmsg}: {err}")
            raise
        except Exception as e:
            logging.error('databaseClass-E004: in dbObj init section.  error = %s', e)
            raise
        
        
    def checkConnection(self):
        '''
        Tests the current database connection, and tries to reconnect if not already connected.
        Ref: https://github.com/PyMySQL/PyMySQL/blob/master/pymysql/connections.py#L740
        '''
        if self.dbconn.open:
            logging.info("databaseClass: connection is open")
        else:
            logging.warning("databaseClass: connection is NOT open")
        logging.info("databaseClass: calling ping...")
        self.dbconn.ping(reconnect=True)
        if self.dbconn.open:
            logging.info("databaseClass: connection is open(2)")
        else:
            logging.error("databaseClass: connection is NOT open(2)")

    
    #########################
    def submitInsertSQLForAttachments(self, dbUpdateDict, resultCode, userSession):
        try:
            updatedRecordCount = self.cursor.execute(dbUpdateDict['sqlStatement'], dbUpdateDict['sqlValues'])
        except pymysql.err.IntegrityError as e:
            if e.args[0]== 1062:
                logging.error('databaseClass-E005: submitInsertSQLForAttachment - duplicate record found on insert - error message = %s, values = %s' , e, dbUpdateDict)
                return ('duplicate-on-insert', None)
            else:
                logging.error('databaseClass-E006: submitInsertSQLForAttachment - integrity error.  error message = %s, values = %s' , e, dbUpdateDict)
                return ('error', None)
        except Exception as e:
            logging.error('databaseClass-E007: submitInsertSQLForAttachment - error encountered in submitSQL routine.  Error message = %s  values =  %s, ', e, dbUpdateDict)
            raise
        
        if updatedRecordCount != 1:
            return ('error', None)
        addedRow = self.cursor.lastrowid
        self.dbconn.commit()
        auditInsertSQL = '''INSERT INTO upd_evnt
                                (evnt_tmst,
                                tbl_row_id, 
                                tbl_nme, 
                                colm_nme,  
                                data_ele_val,  
                                upd_reas_cd, 
                                evnt_rslt_cd, 
                                data_chg_typ_cd,  
                                row_crer_id_txt,
                                rsch_usr_id,
                                dnb_jti_val) 
                                VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'''
            
        auditInsertValues =(addedRow, 
                                'attm',
                                'folderKey/fileNname',
                                dbUpdateDict['folderKey'] + '/' + dbUpdateDict['fileName'], 
                                dbUpdateDict['event'], 
                                resultCode,
                                400, 
                                dbUpdateDict['callingFunction'],
                                userSession.userId,
                                userSession.sessionToken)
            
        try:
            self.cursor.execute(auditInsertSQL, auditInsertValues)
            self.dbconn.commit()
        except Exception as e:
            logging.error('databaseClass-W001: submitUpdateSQLForAttachments - error writing audit record.  data = %s, Error message = %s', auditInsertValues, e)
        return ('success', addedRow)
     
    #######################    
    def submitUpdateSQLForAttachments(self, dbUpdateDict, resultCode):
        selectedRecord = 'SELECT attm_id FROM attm WHERE fldr_key = %s AND fle_nme = %s'
        self.cursor.execute(selectedRecord, (dbUpdateDict['folderKey'], dbUpdateDict['fileName']))
        selectedRecordDict = self.cursor.fetchall() 
        if len(selectedRecordDict) == 0:
            logging.error('databaseClass-E008: submitUpdateSQLForAttachments - no record found for update.  Info = %s' , dbUpdateDict)
            return 'recordNotFound'

        try:
            self.cursor.execute(dbUpdateDict['sqlStatement'], dbUpdateDict['sqlValues'])
        except Exception as e:
            logging.error('databaseClass-E009: submitUpdateSQLForAttachments - error encountered in submitSQL.  data = %s, msg = %s' , dbUpdateDict, e)
            raise
        
        self.dbconn.commit()
                
        auditInsertSQL = '''INSERT INTO upd_evnt 
                                (evnt_tmst,tbl_row_id, tbl_nme, colm_nme, 
                                data_ele_val, upd_reas_cd, evnt_rslt_cd, data_chg_typ_cd, row_crer_id_txt) 
                                VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s)'''
            
        auditInsertValues =(selectedRecordDict[0]['attm_id'], 
                                'attm',
                                'folderKey/fileNname',
                                dbUpdateDict['folderKey'] + '/' + dbUpdateDict['fileName'], 
                                dbUpdateDict['event'], 
                                resultCode,
                                401, 
                                dbUpdateDict['callingFunction'])
            
        try:
            self.cursor.execute(auditInsertSQL, auditInsertValues)
            self.dbconn.commit()
        except Exception as e:
            logging.error('databaseClass-W002: submitUpdateSQLForAttachments - error writing audit record.  data = %s, Error message = %s', auditInsertValues, e)
        return 'success' 
        
    ########################
    
    def signedURLIssued(self, attmObj, callingFunction, userSession):
        dbUpdateDict = {}
        try:
            if attmObj.getIncomingType() == constants.SUBMITTER_ATTACHMENT:
                dbUpdateDict['sqlStatement'] = '''INSERT INTO attm 
                                                        (attm_tmst,
                                                        attm_typ_cd, 
                                                        rsch_reqs_id, 
                                                        row_crer_id_txt,  
                                                        row_modr_id_txt,  
                                                        fldr_key,  
                                                        fle_nme,  
                                                        prcs_stat_cd,
                                                        rsch_usr_id) 
                                                        VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s)'''
            elif attmObj.getIncomingType() == constants.CASE_RESOLUTION_ATTACHMENT or attmObj.getIncomingType() == constants.RESEARCHER_INTERNAL_ATTACHMENT  or attmObj.getIncomingType() == constants.CHALLENGE_ATTACHMENT:
                dbUpdateDict['sqlStatement'] = '''INSERT INTO attm  
                                                        (attm_tmst,
                                                        attm_typ_cd, 
                                                        subj_rsch_id,  
                                                        row_crer_id_txt,  
                                                        row_modr_id_txt,  
                                                        fldr_key,  
                                                        fle_nme,  
                                                        prcs_stat_cd,
                                                        rsch_usr_id)  
                                                        VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s) '''
            elif attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE or attmObj.getIncomingType() == constants.CFP_BATCH_FILE:
                dbUpdateDict['sqlStatement'] = '''INSERT INTO attm
                                                        (attm_tmst,
                                                        attm_typ_cd,
                                                        btch_reqs_id,
                                                        row_crer_id_txt,
                                                        row_modr_id_txt,
                                                        fldr_key,
                                                        fle_nme,
                                                        prcs_stat_cd,
                                                        rsch_usr_id)
                                                        VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s) '''
                
            elif attmObj.getIncomingType() == constants.TRAINING_MEDIA_ATTACHMENT:
                dbUpdateDict['sqlStatement'] = '''INSERT INTO attm  
                                                        (attm_tmst,
                                                        attm_typ_cd,  
                                                        row_crer_id_txt,  
                                                        row_modr_id_txt,  
                                                        fldr_key,  
                                                        fle_nme,  
                                                        prcs_stat_cd,
                                                        rsch_usr_id)  
                                                        VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s) '''
            
            else:
                logging.error('databaseClass-E011: urlIssued processing - attachmentType is not valid = %s', attmObj.getIncomingType())
                return 'error'
            
            if attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE or attmObj.getIncomingType() == constants.CFP_BATCH_FILE:
                dbUpdateDict['sqlValues'] =    (attmObj.getIncomingType(),
                                                    self.batchRequestId,
                                                    callingFunction,
                                                    callingFunction,
                                                    attmObj.getIncomingFolder(),
                                                    attmObj.getAdjustedFileName(),
                                                    constants.URL_ISSUED,
                                                    userSession.userId)
            elif attmObj.getIncomingType() == constants.TRAINING_MEDIA_ATTACHMENT:
                dbUpdateDict['sqlValues'] =    (attmObj.getIncomingType(),
                                                    #17,  #substitute this for next training media id available
                                                    callingFunction,
                                                    callingFunction,
                                                    attmObj.getIncomingFolder(),
                                                    attmObj.getAdjustedFileName(),
                                                    constants.URL_ISSUED,
                                                    userSession.userId)
            else:
                dbUpdateDict['sqlValues'] =    (attmObj.getIncomingType(),
                                                    attmObj.getIncomingAttachmentKey(),
                                                    callingFunction,
                                                    callingFunction,
                                                    attmObj.getIncomingFolder(),
                                                    attmObj.getAdjustedFileName(),
                                                    constants.URL_ISSUED,
                                                    userSession.userId)
        except Exception as e :
            logging.error('databaseClass-E012: error building SQL statements.  error = %s', e)

        dbUpdateDict['folderKey'] = attmObj.getIncomingFolder()
        dbUpdateDict['fileName'] = attmObj.getAdjustedFileName()
        dbUpdateDict['event'] = constants.URL_ISSUED
        dbUpdateDict['callingFunction'] = callingFunction
        logging.info('dpUpdateDict = %s', dbUpdateDict)
        retVal = self.submitInsertSQLForAttachments (dbUpdateDict, constants.SUCCESSFUL, userSession)
        status = retVal[0]
        attmId = retVal[1]
        if (attmId is not None):
            attmObj.setAttachmentId(attmId)
        return status
        
    ###############################
    def attachmentArrived(self, attmObj, callingFunction):
        dbUpdateDict = {}
        try:
            dbUpdateDict['sqlStatement'] = '''UPDATE attm SET  
                                                    attm_tmst = NOW(), 
                                                    s3_obj_key = %s,  
                                                    attm_sz_msmt = %s,  
                                                    row_modr_id_txt = %s,  
                                                    prcs_stat_cd = %s  
                                                    WHERE 
                                                    fldr_key = %s AND 
                                                    fle_nme = %s '''
        
            dbUpdateDict['sqlValues'] = (attmObj.getIncomingS3Obj(),
                                              attmObj.getIncomingSize(),
                                              callingFunction, 
                                              constants.FILE_RECEIVED,
                                              attmObj.getIncomingFolder(),
                                              attmObj.getIncomingFileName()
                                              )
        except Exception as e:
            logging.error('databaseClass-E013: attachment received processing - error building SQL statements.  error = %s', e)
            raise
        dbUpdateDict['folderKey'] = attmObj.getIncomingFolder()
        dbUpdateDict['fileName'] = attmObj.getIncomingFileName()
        dbUpdateDict['event'] = constants.FILE_RECEIVED
        dbUpdateDict['callingFunction'] = callingFunction
        logging.info('databaseClass-I001: attachmentArrived calling submitUpdateSQLForAttachments')
        return self.submitUpdateSQLForAttachments (dbUpdateDict, constants.SUCCESSFUL)
            
    ###############################
    def attachmentSentToSTP(self, attmObj, callingFunction, disposition):
        dbUpdateDict = {}
        try:
            dbUpdateDict['sqlStatement'] = '''UPDATE attm SET  
                                                row_modr_id_txt = %s,  
                                                prcs_stat_cd = %s,
                                                prcs_rslt_cd = %s  
                                                WHERE 
                                                fldr_key = %s AND 
                                                fle_nme = %s '''
            dbUpdateDict['sqlValues'] = (callingFunction, 
                                              constants.FILE_SUBMITTED_TO_VIRUS_SCAN,
                                              disposition,
                                              attmObj.getIncomingFolder(),
                                              attmObj.getIncomingFileName()
                                              )
        except Exception as e:
            logging.error('databaseClass-E014: attachment received processing - error building SQL statements.  error = %s', e)
            return 'error'
        dbUpdateDict['folderKey'] = attmObj.getIncomingFolder()
        dbUpdateDict['fileName'] = attmObj.getIncomingFileName()
        dbUpdateDict['event'] = constants.FILE_SUBMITTED_TO_VIRUS_SCAN
        dbUpdateDict['callingFunction'] = callingFunction
        logging.info('databaseClass-I002: attachmentSentToSTP calling submitUpdateSQLForAttachments')
        if disposition == constants.SUCCESSFUL:
            return self.submitUpdateSQLForAttachments (dbUpdateDict, constants.SUCCESSFUL)
        else:
            return self.submitUpdateSQLForAttachments (dbUpdateDict, constants.UNSUCCESSFUL)
    
    ####################
    def attachmentReceivedBackFromSTP(self, attmObj, callingFunction):
        splitName = attmObj.getIncomingFileName().split('_')
        origFolder = splitName[0]
        if len(splitName) > 2:
            x = splitName[1:]
            origFileName = '_'.join(x)
        else:
            origFileName = splitName[1]
        
        dbUpdateDict = {}
        try:
            dbUpdateDict['sqlStatement'] = '''UPDATE attm SET  
                                                row_modr_id_txt = %s,  
                                                prcs_stat_cd = %s 
                                                WHERE 
                                                fldr_key = %s AND 
                                                fle_nme = %s '''
            dbUpdateDict['sqlValues'] =    (callingFunction, 
                                                constants.FILE_RETURNED_FROM_VIRUS_SCAN,
                                                origFolder,
                                                origFileName
                                                )
        except Exception as e:
            logging.error('databaseClass-E015: attachment received back from STP processing - error building SQL statements.  error = %s', e)
            raise
        dbUpdateDict['fileName'] = origFileName
        dbUpdateDict['folderKey'] = origFolder
        dbUpdateDict['event'] = constants.FILE_RETURNED_FROM_VIRUS_SCAN
        dbUpdateDict['callingFunction'] = callingFunction
        logging.info('databaseClass-I003: attachmentReceivedBackFromSTP calling submitUpdateSQLForAttachments')
        return self.submitUpdateSQLForAttachments (dbUpdateDict, constants.SUCCESSFUL)
    
    #####################    
    def attachmentAvailableStatus(self, exposedS3Obj, attmObj, callingFunction):
        dbUpdateDict = {}
        splitName = attmObj.getIncomingFileName().split('_')
        origFolder = splitName[0]
        if len(splitName) > 2:
            x = splitName[1:]
            origFileName = '_'.join(x)
        else:
            origFileName = splitName[1]
        
        try:
            dbUpdateDict['sqlStatement'] = '''UPDATE attm SET  
                                            row_modr_id_txt = %s,  
                                            prcs_stat_cd = %s,
                                            prcs_rslt_cd = %s,
                                            s3_obj_key = %s   
                                            WHERE 
                                            fldr_key = %s AND 
                                            fle_nme = %s '''
            dbUpdateDict['sqlValues'] = (callingFunction, 
                                              constants.PROCESSING_COMPLETE,
                                              constants.FILE_AVAILABLE,
                                              exposedS3Obj,
                                              origFolder,
                                              origFileName
                                              )
        except Exception as e:
            logging.error('databaseClass-E016: attachment available processing - error building SQL statements.  error = %s', e)
            raise
        dbUpdateDict['fileName'] = origFileName
        dbUpdateDict['folderKey'] = origFolder
        dbUpdateDict['event'] = constants.PROCESSING_COMPLETE
        dbUpdateDict['callingFunction'] = callingFunction
        logging.info('databaseClass-I004: attachmentAvailableStatus calling submitUpdateSQLForAttachments')
        return self.submitUpdateSQLForAttachments (dbUpdateDict, constants.FILE_AVAILABLE)
    
    #################################
    def attachmentHasVirus(self, attmObj, callingFunction):
        dbUpdateDict = {}
        try:
            dbUpdateDict['sqlStatement'] = '''UPDATE attm SET  
                                                row_modr_id_txt = %s,  
                                                prcs_stat_cd = %s,
                                                prcs_rslt_cd = %s,
                                                s3_obj_key = %s   
                                                WHERE 
                                                fldr_key = %s AND 
                                                fle_nme = %s '''
            dbUpdateDict['sqlValues'] =    (callingFunction, 
                                                constants.PROCESSING_COMPLETE,
                                                constants.VIRUS_FOUND,
                                                None,
                                                attmObj.getIncomingFolder(),
                                                attmObj.getIncomingFileName()
                                                )
        except Exception as e:
            logging.error('databaseClass-E017: virus found processing - error building SQL statements.  error = %s', e)
            raise
        dbUpdateDict['folderKey'] = attmObj.getIncomingFolder()
        dbUpdateDict['fileName'] = attmObj.getAdjustedFileName()
        dbUpdateDict['event'] = constants.VIRUS_FOUND
        dbUpdateDict['callingFunction'] = callingFunction
        logging.info('databaseClass-I005: attachmentHasVirus calling submitUpdateSQLForAttachments')
        return self.submitUpdateSQLForAttachments (dbUpdateDict, constants.VIRUS_FOUND)
    
    ################## FILE_RENAMED_DUE_TO_SPECIAL_CHARACTERS
    def resetIncomingFileName(self, oldFileName, oldFolderName, newFileName):
        dbUpdateDict = {}
        dbUpdateDict['sqlStatement'] = '''UPDATE attm SET  
                                            row_modr_id_txt = %s,  
                                            fle_nme = %s   
                                            WHERE 
                                            fldr_key = %s AND 
                                            fle_nme = %s '''
        
        dbUpdateDict['sqlValues'] =    ("attmObj", 
                                            newFileName,
                                            oldFolderName,
                                            oldFileName
                                            )
        dbUpdateDict['fileName'] = oldFileName
        dbUpdateDict['folderKey'] = oldFolderName
        dbUpdateDict['event'] = constants.FILE_RENAMED_DUE_TO_SPECIAL_CHARACTERS
        dbUpdateDict['callingFunction'] = "ProcessUploadedAttachment"
        try:
            logging.info('databaseClass-I006: resetIncomingFileName calling submitUpdateSQLForAttachments')
            return self.submitUpdateSQLForAttachments (dbUpdateDict, constants.SUCCESSFUL)
        except Exception as e:
            logging.error('databaseClass-E018: Problem updating database with new file name - error building SQL statements.  error = %s', e)
            raise
    
    
    ######################
    def countAttachmentResearchRequestInstances(self,rschReqsId):
        # Count only non-deleted attachments that are not stuck
        countRRRequestSQL = 'SELECT * FROM attm WHERE rsch_reqs_id = %s and prcs_rslt_cd <> 33914'
        self.cursor.execute(countRRRequestSQL, rschReqsId)
        rrRowDict = self.cursor.fetchall()
        return len(rrRowDict)
    
    def countAttachmentSubjectResearchInstances(self,subjRschId, incomingType):
        # Count only non-deleted attachments that are not stuck
        countSRRequestSQL = 'SELECT * FROM attm WHERE subj_rsch_id = %s and prcs_rslt_cd <> 33914 and attm_typ_cd = %s'
        params = (subjRschId, incomingType)
        self.cursor.execute(countSRRequestSQL, params)
        srRowDict = self.cursor.fetchall() 
        return len(srRowDict)
    
    def researchRequestIDValid(self, key):
        findRRID = 'SELECT rsch_reqs_id FROM rsch_reqs WHERE rsch_reqs_id = %s'
        self.cursor.execute(findRRID, key)
        rrIdDict = self.cursor.fetchall() 
        if len(rrIdDict) > 0:
            return True
        return False
    
    def subjectResearchIDValid(self, key):
        findSRID = 'SELECT rsch_reqs_id FROM rsch_reqs WHERE rsch_reqs_id = %s'
        self.cursor.execute(findSRID, key)
        srIdDict = self.cursor.fetchall() 
        if len(srIdDict) > 0:
            return True
        return False
    
    #####################
    # Description : Inserts batch record and updates in `upd_events` table 
    def submitInsertSQLForBatch(self, dbUpdateDict, resultCode, userSession):
        try:
            updatedRecordCount = self.cursor.execute(dbUpdateDict['sqlStatement'], dbUpdateDict['sqlValues'])
        except pymysql.err.IntegrityError as e:
            if e.args[0]== 1062:
                logging.error('databaseClass-E005: submitInsertSQLForBatch - duplicate record found on insert - error message = %s, values = %s' , e, dbUpdateDict)
                return 'duplicate-on-insert'
            else:
                logging.error('databaseClass-E006: submitInsertSQLForBatch - integrity error.  error message = %s, values = %s' , e, dbUpdateDict)
                return 'error'
        except Exception as e:
            logging.error('databaseClass-E007: submitInsertSQLForBatch - error encountered in submitSQL routine.  Error message = %s  values =  %s, ', e, dbUpdateDict)
            raise

        if updatedRecordCount != 1:
            return 'error'
        addedRow = self.cursor.lastrowid
        self.batchRequestId = str(addedRow)
        self.dbconn.commit()
        auditInsertSQL = '''INSERT INTO upd_evnt
                                (evnt_tmst,
                                tbl_row_id,
                                tbl_nme,
                                colm_nme,
                                data_ele_val,
                                data_chg_typ_cd,
                                row_crer_id_txt,
                                rsch_usr_id,
                                dnb_jti_val)
                                VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s)'''

        auditInsertValues =(addedRow,
                                'btch_reqs',
                                'btch_reqs_id',
                                dbUpdateDict['folderKey']+'/'+dbUpdateDict['fileName'],
                                400,
                                dbUpdateDict['callingFunction'],
                                userSession.userId,
                                userSession.sessionToken)

        try:
            self.cursor.execute(auditInsertSQL, auditInsertValues)
            self.dbconn.commit()
        except Exception as e:
            logging.error('databaseClass-W001: submitUpdateSQLForBatch - error writing audit record.  data = %s, Error message = %s', auditInsertValues, e)
        return ('success',self.batchRequestId)

    # Description : Inserts the batch record in `btch_reqs` table
    
    def batchRecordHandle(self, attmObj, batchSrcId, callingFunction, userSession):
        dbUpdateDict = {}
        try:
            dbUpdateDict['sqlStatement'] = '''INSERT INTO btch_reqs
                                                    (stat_tmst,
                                                    rsch_usr_id,
                                                    btch_frmt_cd,
                                                    btch_src_cd,
                                                    prcs_stat_cd,
                                                    row_crer_id_txt,
                                                    row_modr_id_txt,
                                                    dnb_jti_val,
                                                    btch_typ,
                                                    cmpgn_prty_cd,
                                                    cmpgn_rt_cd)
                                                    VALUES (NOW(), %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'''
            dbUpdateDict['sqlValues'] = (userSession.userId,
                                              BatchFormatCode.EXCEL_SPREADSHEET.value,
                                              batchSrcId,
                                              BatchStatusCode.RECEIVED.value,
                                              callingFunction,
                                              callingFunction,
                                              userSession.sessionToken,
                                              attmObj.getBatchType(),
                                              attmObj.getCampaignPriority(),
                                              attmObj.getCampaignRouting())
        except Exception as e :
            logging.error('databaseClass-E012: error building SQL statements.  error = %s', e)
        dbUpdateDict['callingFunction'] = callingFunction
        dbUpdateDict['event'] = constants.FILE_RECEIVED
        dbUpdateDict['folderKey'] = attmObj.getIncomingFolder()
        dbUpdateDict['fileName'] = attmObj.getAdjustedFileName()
        dbUpdateDict['batchType'] = attmObj.getBatchType()
        logging.info('dpUpdateDict = %s', dbUpdateDict)
        return self.submitInsertSQLForBatch (dbUpdateDict, constants.SUCCESSFUL, userSession)
    
    # Description: Returns the `principal id` by joining and querying `attm`, `lgin_ses` and `btch_reqs`
    
    def getPrincipleIdForBatch(self, attmObj, folder_name, file_name, callingFunction):
        dbUpdateDict = {}
        selectedRecord =  """SELECT AT.*, 
                                  BR.btch_frmt_cd as BR_btch_frmt_cd,
                                  BR.btch_src_cd as BR_btch_src_cd,
                                  BR.prcs_stat_cd as BR_prcs_stat_cd,
                                  BR.stat_tmst as BR_stat_tmst,
                                  BR.btch_rej_reas_cmnt as BR_btch_rej_reas_cmnt,
                                  BR.btch_rej_err_txt as BR_btch_rej_err_txt,
                                  BR.tot_entr_cnt as BR_tot_entr_cnt,
                                  BR.rej_entr_cnt as BR_rej_entr_cnt,
                                  BR.dnb_jti_val as BR_dnb_jti_val,
                                  LS.auth_prin_id_obj as LS_auth_prin_id_obj
                                  FROM attm AT
                                  left join btch_reqs BR on BR.btch_reqs_id = AT.btch_reqs_id
                                  left join lgin_ses LS on LS.dnb_jti_val = BR.dnb_jti_val
                                  where AT.fldr_key = %s and AT.fle_nme = %s 
                                  and AT.attm_id is not null and AT.btch_reqs_id is not null
                                  """
        
        self.cursor.execute(selectedRecord, (folder_name, file_name))
        selectedRecordDict = self.cursor.fetchone()
        if len (selectedRecordDict) == 0:
            logging.error('databaseClass-E008: getPrincipleIdForBatch - no record found for update.  Info = ')
            return 'recordNotFound'
        
        return_dict = {}
        return_dict['prin_id'] = selectedRecordDict['LS_auth_prin_id_obj']
        return_dict['attm_id'] = selectedRecordDict['attm_id']
        return_dict['btch_reqs_id'] = selectedRecordDict['btch_reqs_id']
        return return_dict
    
    # Description: Updates the attm table with process result code
    
    def setAttachmentProcessResultCode(self, attm_id, batch_reqs_id, result_code):
        try:
            selectedRecord = 'UPDATE attm SET prcs_rslt_cd = %s WHERE attm_id = %s and btch_reqs_id = %s'
            self.cursor.execute(selectedRecord, (result_code, attm_id, batch_reqs_id))
        except Exception as e:
            logging.error(str(e))
            return -1
        return 0
    
    def getAttachmentType(self, folder_name, file_name):
        sql = '''
                select attm_typ_cd
                from attm
                where 
                fldr_key = %s and 
                fle_nme = %s 
            '''
        self.cursor.execute(sql, (folder_name, file_name))
        selectedRecordDict = self.cursor.fetchone()
        if selectedRecordDict is None or len (selectedRecordDict) == 0:
            return None
        
        return_dict = {}
        return_dict['attm_typ_cd'] = selectedRecordDict['attm_typ_cd']
        return return_dict
    
    def getCasesForRschReq (self, rschReqId):
        sql = '''
            select sr.subj_rsch_id, sr.curr_rsch_team_id
            from rsch_reqs rr
            join subj_rsch sr
             on rr.rsch_reqs_id = sr.rsch_reqs_id
            where rr.rsch_reqs_id = %s;            
            '''
        self.cursor.execute(sql, (rschReqId))
        rv = self.cursor.fetchall()
        cases=[]
        for result in rv:
            cases.append(result)
        return cases;
        
    def getTeamForCase(self, subjRschId):
        sql = '''
            select curr_rsch_team_id
            from subj_rsch
            where 
            subj_rsch_id = %s 
            '''
        
        self.cursor.execute(sql, (subjRschId))
        selectedRecordDict = self.cursor.fetchone()
        if len (selectedRecordDict) == 0:
            return None
        
        return_dict = {}
        return_dict['curr_rsch_team_id'] = selectedRecordDict['curr_rsch_team_id']
        return return_dict