'''
Updated on Feb 16, 2019

@author: MorganB

DEPRECATED - Use common.util.s3Helper.getS3ObjectsFromEvent() instead
'''

import logging
from urllib.parse import unquote_plus

def getS3Attributes(event):
    
    incomingDict = {}
    if 'Records' not in event or 's3' not in event['Records'][0]:
        logging.error('getS3Attributes - missing Records or S3 value from event data')
        raise Exception('getS3Attributes - missing Records or S3 value from event data')
    try:
        incomingDict['incomingS3Bucket'] = event['Records'][0]['s3']['bucket']['name']
    except:
        logging.error('getS3Attributes - missing bucket name from event data')
        raise Exception('getS3Attributes - missing bucket name from event data')
    try: 
        incomingDict['incomingS3Key'] = unquote_plus(event['Records'][0]['s3']['object']['key'])
    except:
        logging.error('getS3Attributes - missing object name from event data')
        raise Exception('getS3Attributes - missing object name from event data')
    try:
        incomingDict['incomingS3Arn'] = event['Records'][0]['s3']['bucket']['arn']
    except:
        incomingDict['incomingS3Arn'] = None
        logging.info ('getS3Attributes - no ARN detected')
    try: 
        incomingDict['incomingAttachmentSize'] = (event['Records'][0]['s3']['object']['size'])
    except:
        incomingDict['incomingAttachmentSize'] = None
        logging.error('getS3Attributes - no size element detected')
        raise Exception('getS3Attributes - no size element detected')
    
    
    incomingDict['incomingAttachmentName'] = incomingDict['incomingS3Key'].split('/')[-1]
    incomingDict['incomingAttachmentFolder'] = incomingDict['incomingS3Key'].split('/')[-2]
    
    logging.info('getS3Attributes attributes %s', incomingDict)
    
    return (incomingDict)


if __name__ == '__main__':
    pass