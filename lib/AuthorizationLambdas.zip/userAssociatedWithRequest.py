'''
Created on Mar 6, 2019

@author: MorganB
'''

def userAssociatedWithRequest(attmObj, dbObj, emailAddr):
    return True

if __name__ == '__main__':
    pass