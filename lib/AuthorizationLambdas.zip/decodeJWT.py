'''
Updated on March 7, 2019

@author: MorganB
'''
import jwt
import logging
import datetime

def decodeJWT(encoded_JWT, verifyOption=False, key=None, alg='HS256'):
    # 'alg options = HS256' 'RS256'
    if verifyOption == False:
        try:
            return 'validToken', jwt.decode(encoded_JWT, verify=verifyOption)
            #except jwt.ExpiredSignatureError:
        except Exception as err:
            logging.error('decodeJWT-E001: error decoding JWT with verify=False, error msq = %s', err)
            logging.error('decodeJWT-E002: Failing JWT = %s',encoded_JWT)
            raise
    if verifyOption == True:
        try:
            decodedJWT = jwt.decode(encoded_JWT, key, algorithms=alg)
            if int(datetime.datetime.utcnow().timestamp()) < decodedJWT['exp']:
                return 'validToken', decodedJWT
            else:
                logging.info('decodeJWT-W001: Token expired.  encoded_JWT = %s', encoded_JWT)
                return 'expiredToken', None
        except jwt.ExpiredSignatureError as e1:
            logging.info('decodeJWT-W002: Token expired.  encoded_JWT = %s', encoded_JWT)
            return 'expiredToken', None
        except Exception as e2:
            logging.error('decodeJWT-E003: error decoding JWT with verify=True, error msq = %s', e2)
            logging.error('decodeJWT-E004: Failing JWT = %s.  Key = %s  key type = %s',encoded_JWT, key, alg)
            raise

if __name__ == '__main__':
    pass