'''
Created on Mar 10, 2019

@author: MorganB
'''

import constants
import logging
from lambdas.exceptions import LambdaConflictException

def attachmentLimitReached(attmObj,dbObj,environDict):
    if attmObj.getIncomingType() == constants.SUBMITTER_ATTACHMENT:
        if dbObj.countAttachmentResearchRequestInstances(attmObj.getIncomingAttachmentKey()) < int(environDict['researchRequestAttachmentLimit']):
            return False
        else:
            return True
    elif attmObj.getIncomingType() == constants.CASE_RESOLUTION_ATTACHMENT or attmObj.getIncomingType() == constants.CHALLENGE_ATTACHMENT:
        if dbObj.countAttachmentSubjectResearchInstances(attmObj.getIncomingAttachmentKey(), attmObj.getIncomingType()) < int(environDict['subjectResearchAttachmentLimit']):
            return False
        else:
            return True
    elif attmObj.getIncomingType() == constants.RESEARCHER_INTERNAL_ATTACHMENT:
        if dbObj.countAttachmentSubjectResearchInstances(attmObj.getIncomingAttachmentKey(), attmObj.getIncomingType()) < int(environDict['internalSubjectResearchAttachmentLimit']):
            return False
        else:
            return True
    elif attmObj.getIncomingType() == constants.SUBMISSION_BATCH_FILE:
        #if dbObj.countAttachmentSubjectResearchInstances(attmObj.getIncomingAttachmentKey()) < int(environDict['subjectResearchAttachmentLimit']):
        #    return False
        #else:
        return False
    elif attmObj.getIncomingType() == constants.CFP_BATCH_FILE:
        return False
    elif attmObj.getIncomingType() == constants.TRAINING_MEDIA_ATTACHMENT:
        return False
    else:
        # Should have been caught earlier during validation
        logging.error('incoming attachment type not recognized. Attachment type = %s',attmObj.getIncomingType())
        raise LambdaConflictException('internal error: incoming attachment type not recognized')

if __name__ == '__main__':
    pass