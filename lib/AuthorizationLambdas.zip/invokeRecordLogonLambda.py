
import boto3
import logging
import json
import base64
import ast
from common import envVblNames
from common.util.awsUtils import createClientConfiguration
from lambdas.lambdaCommon import parsePayloadFromInvokeResponse, parseHTTPStatusCodeFromInvokeResponse, parseStatusCodeFromPayload
from lambdas.lambdaStatusCodes import LambdaStatusCodes


def recordUserInfo(olJWTBody, dnbSessionToken, awsEvent, lambdaFunctionName, environDict):
    # Payload=b'bytes'
    #### need the lambda function name passed - it goes with the FuntionName below ####
    try:
        client = boto3.client('lambda', region_name=environDict[envVblNames.ENV_LAMBDA_REGION], config=createClientConfiguration(environDict))
    except Exception as err:
        logging.error('invokeUserUpdateLambda-updateUserInfo error - problem establishing lambda client.  Err = %s', err)
        #raise
        return False
    
    tempDict = {} 
    tempDict['body']= olJWTBody
    tempDict['aws_event'] = awsEvent
    logging.debug('dnbSessionToken=' + dnbSessionToken)
    #logging.debug('dnbSessionToken b64decode(' + dnbSessionToken.split('.')[1] + '===')
    #logging.debug('dnbSessionToken base64.b64decode.decode=' + base64.b64decode(dnbSessionToken.split('.')[1] + '===').decode('utf-8'))
    tempDict['dnb_jwt_body'] = ast.literal_eval(base64.b64decode(dnbSessionToken.split('.')[1] + '===').decode('utf-8'))
    
    return invokeRecordLogon(tempDict, lambdaFunctionName, client)
    
    
def invokeRecordLogon(payloadDict, lambdaFunctionName, client):
    try:
        payload = json.dumps(payloadDict)
        logging.info('data sent to recordLogon = %s', payload)
        response = client.invoke(
            FunctionName= lambdaFunctionName,
            InvocationType='RequestResponse',
            Payload= payload
        )
    except Exception as err:
        logging.error('invokeRecordLogonLambda:recordUserInfo error - problem invoking lambda function.  Err = %s', err)
        raise

    logging.info('invokeRecordLogon: response=' + str(response))
    isSuccess = True
    httpStatusCode = parseHTTPStatusCodeFromInvokeResponse(response)
    if httpStatusCode != LambdaStatusCodes.OK.value and httpStatusCode != LambdaStatusCodes.OK_LAMBDA_EVENT_INVOKE.value:
        isSuccess = False
        errmsg = 'httpStatusCode=' + str(httpStatusCode)
        logging.error('Failed to RecordLogon #1: errmsg=' + errmsg + ' response=' + str(response))
    else:
        responsePayload = parsePayloadFromInvokeResponse(response)
        if responsePayload:
            logging.info('Response payload from RecordLogon:' + str(responsePayload))
            #print('Response payload from RetrieveCase:' + str(responsePayload))
            statusCode = parseStatusCodeFromPayload(responsePayload)
            responseBody = responsePayload.get('body')
            if responseBody is not None:
                #resultDict[RetrieveResearchApiSubmissionService.RESULT_BODY] = json.loads(responseBody)
                pass
            if statusCode != LambdaStatusCodes.OK.value:
                isSuccess = False
                errmsg = 'statusCode=' + str(statusCode)
                logging.error('Failed to RecordLogon: errmsg=' + errmsg + ' response=' + str(response))
                
    if isSuccess:
        return True
    else:
        logging.error('invokeUserUpdateLambda-updateUserInfo error - error status - %s / %s - returned from invocation of lambda', str(httpStatusCode), str(statusCode))
        return False 
    
    
if __name__ == '__main__':
        pass