/**
 * Run lambda services via express. To use this install express:
 * npm install express --save
 * To use post requests also install body-parser:
 * npm install body-parser --save
 */
const express = require('express');
const app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
const port = 8080;
const ValidateUpdateAndCloseService = require('../handlers/validateUpdateAndCloseService');

app.get('/', function (req, res) {
    res.send('Hello World!')
})

app.post('/validateUpdateAndClose', function(req, res) {

    console.log("req.body=" + JSON.stringify(req.body));
    const service = new ValidateUpdateAndCloseService();
    const response = service.doService(req.body)

    console.log("ValidateUpdateAndClose response: " + JSON.stringify(response))

    res.send(response);
});

app.listen(port, () => console.log('URL: http://localhost:' + port + '/'))
