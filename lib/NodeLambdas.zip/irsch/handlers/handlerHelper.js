/**
 * Generic helper functions for AWS lambdas
 */
'use strict';

module.exports = class HandlerHelper {
    
    getQueryParameter(event, paramName, defaultValue) {
        if (event.queryStringParameters !== null && event.queryStringParameters !== undefined) {
            if (event.queryStringParameters[paramName] !== undefined && 
                event.queryStringParameters[paramName] !== null && 
                event.queryStringParameters[paramName] !== "") {
                console.log("Query " + paramName + ": " + event.queryStringParameters[paramName]);
                return event.queryStringParameters[paramName];
            }
        }
        
        console.log("Query " + paramName + " not found, defaulting to: " + defaultValue);
        return defaultValue;
    }
    
    initializeLambda(context) {
        // This will allow us to freeze open connections to a database without timing out...
        context.callbackWaitsForEmptyEventLoop = false;
    }
}
