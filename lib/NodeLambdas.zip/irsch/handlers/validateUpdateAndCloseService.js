/**
 * Service for ValidateUpdateAndClose, allows it to be run through either lambda or locally using express
 */
'use strict';
const UpdateCaseValidator = require('../sharedValidators/updateCaseValidator');
const CloseCaseValidator = require('../sharedValidators/closeCaseValidator');

module.exports = class ValidateUpdateAndCloseService{
    constructor() {
        this.updateCaseValidator = new UpdateCaseValidator();
        this.closeCaseValidator = new CloseCaseValidator();
    }
    
    doService(body) {
        let responseCode = 200;
        const researchTypes = body.researchTypes;
//        console.log('researchTypes: ', researchTypes);
        const submittedData = body.submittedData;
//        console.log('submittedData: ', submittedData);
        const researchResult = body.researchResult;
//        console.log('researchResult: ', researchResult);
        let closeCaseData = {};
        closeCaseData.resolutions = [];
        for(var x = 0; x < researchTypes.length; x++) {
        	closeCaseData.resolutions.push(researchTypes[x]);
        }
        closeCaseData.researchComment = body.researchComment;
//        console.log("closeCaseData: ", closeCaseData);
        const subjectDuns = body.subjectDuns
        
        // First validate update
        const updateCaseValidator = new UpdateCaseValidator();
                
        let result = updateCaseValidator.validate(researchTypes, researchResult);
        let rejectionErrors = result.rejectionErrors;
        if (rejectionErrors.length > 0) {
            console.log("Failed in UpdateCaseValidator: " + JSON.stringify(result));
            responseCode = 400;
        } else {
            // If update was successfully validated, then validate close
            const closeCaseValidator = new CloseCaseValidator();
            
            result = closeCaseValidator.validate(researchTypes, researchResult, submittedData, closeCaseData, subjectDuns); 
            rejectionErrors = result.rejectionErrors;
            if (rejectionErrors.length > 0) {
                console.log("Failed in CloseCaseValidator: " + JSON.stringify(result));
                responseCode = 400;
            }
        }
        
        const responseBody = {
            data: result
        };
        const response = {
            statusCode: responseCode,
            body: JSON.stringify(responseBody)
        };
        
        return response;
    }
}