/**
 * Lambda handler for ValidateUpdateAndClose service - irsch/handlers/validateUpdateAndCloseLambda.handler
 */
'use strict';
console.log('Loading ValidateUpdateAndClose function');
const ValidateUpdateAndCloseService = require('../handlers/validateUpdateAndCloseService');


/**
 * Entry point for lambda invoke
 */
exports.handler = function(event, context, callback) {
    const HandlerHelper = require('../handlers/handlerHelper');
    const handlerHelper = new HandlerHelper();

    handlerHelper.initializeLambda(context);
    console.log("ValidateUpdateAndClose got event: " + JSON.stringify(event));
    
    if(event.body !== undefined) {
        console.log("event.body = " + JSON.stringify(event.body));
        
        const service = new ValidateUpdateAndCloseService();
        const response = service.doService(event.body)
            
        console.log("ValidateUpdateAndClose response: " + JSON.stringify(response))
        callback(null, response);
    }
    else {
        console.log("Keepwarm Rule Execution");
    }
    
}    
