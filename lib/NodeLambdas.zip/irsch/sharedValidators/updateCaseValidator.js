/*
 * Common update-case validation module for UI and services
 */
'use strict';

const ValidatorCommon = require('../sharedValidators/validatorCommon');
const ErrorMessages = require('../sharedValidators/validationErrorMessages');
let ValidationErrorMessages = ErrorMessages();
let commonValidator;

module.exports = class UpdateCaseValidator {
    constructor() {
        commonValidator = new ValidatorCommon();
    }
/* END_NODE_ONLY_CODE */    

    
    /* BEGIN_NOTES_FOR_SHARED CODE:  For Node.js, function instantiation needed is: 
	 * 									validate(
	 * 
	 * 								 For Angular, function instantiation needed is:
	 * 									this.validate = function(
	 *
	 * END_NOTES_FOR_SHARED CODE:*/  
    validate(researchTypes, researchResult, UIRequest) {
    /* END_NODE_ONLY_CODE */
    	var rejErrs = [];
    	 /* console.log("updateCaseValidator researchTypes: ", researchTypes);
         console.log("updateCaseValidator researchResult: ", researchResult); */
         
        if(researchResult.chiefExecutiveOfficerJobTitle && !researchResult.chiefExecutiveOfficerName) {
            if(researchResult.chiefExecutiveOfficerName == undefined) {
        		commonValidator.addRejectionError(rejErrs, "researchResult.chiefExecutiveOfficerName", ValidationErrorMessages.ceoError, ValidationErrorMessages.ceoError, null, UIRequest);
        	}
        	else {
        		commonValidator.addRejectionError(rejErrs, "researchResult.chiefExecutiveOfficerName", ValidationErrorMessages.ceoError, ValidationErrorMessages.ceoError, researchResult.chiefExecutiveOfficerName, UIRequest);
        	}
        }
        if(researchResult.chiefExecutiveOfficerName && !researchResult.chiefExecutiveOfficerJobTitle) {
            if(researchResult.chiefExecutiveOfficerJobTitle == undefined) {
        		commonValidator.addRejectionError(rejErrs, "researchResult.chiefExecutiveOfficerJobTitle", ValidationErrorMessages.ceoError, null, UIRequest);
        	}
    		else {
    			commonValidator.addRejectionError(rejErrs, "researchResult.chiefExecutiveOfficerJobTitle", ValidationErrorMessages.ceoError, ValidationErrorMessages.ceoError, researchResult.chiefExecutiveOfficerJobTitle, UIRequest);
    		}
        }
        if(researchResult.duplicateDunsNumbers != undefined && researchResult.duplicateDunsNumbers.length > 0) {
            for(let i = 0; i < researchResult.duplicateDunsNumbers.length; i++){
                if(researchResult.duplicateDunsNumbers[i].deletedDuns == undefined || !researchResult.duplicateDunsNumbers[i].deletedDuns) {
                    commonValidator.addRejectionError(rejErrs, "researchResult.duplicateDunsNumbers[i].deletedDuns", ValidationErrorMessages.duplicateDunsNumbers, ValidationErrorMessages.duplicateDunsNumbers, researchResult.duplicateDunsNumbers[i].deletedDuns, UIRequest);
                }
                else if(researchResult.duplicateDunsNumbers[i].retainedDuns == undefined || !researchResult.duplicateDunsNumbers[i].retainedDuns) {
                    commonValidator.addRejectionError(rejErrs, "researchResult.duplicateDunsNumbers[i].retainedDuns", ValidationErrorMessages.duplicateDunsNumbers, ValidationErrorMessages.duplicateDunsNumbers, researchResult.duplicateDunsNumbers[i].retainedDuns, UIRequest);
                }
            }
        }
        
        const result = {
            rejectionErrors: rejErrs
        };
        // console.log("UpdateCaseValidator: ", result);
         return result;
    }
};

