/**
 * Common functions for sharedValidators
 */
'use strict';

module.exports = class ValidatorCommon {
/* END_NODE_ONLY_CODE */
	
	
	/* BEGIN_NOTES_FOR_SHARED CODE:  For Node.js, function instantiation needed is: 
	 * 									getResearchTypeBySubType( 
	 * 									getResearchTypeByAnyOfSubType(
	 * 									getResolutionCodeMatchFromCloseCaseData(
	 * 									getCloseCaseDataResolutionByAnyOfResolutionCode(
	 * 									addRejectionError(
	 * 
	 * 								 For Angular, function instantiation needed is:
	 * 									this.getResearchTypeBySubType = function( 
	 * 									this.getResearchTypeByAnyOfSubType = function(
	 * 									this.getResolutionCodeMatchFromCloseCaseData = function(
	 * 									this.getCloseCaseDataResolutionByAnyOfResolutionCode = function(
	 * 									this.addRejectionError = function(
	 *
	 * END_NOTES_FOR_SHARED CODE:*/    
    /**
     * Returns the element of the researchTypes array that is for the given subtype code, if exists; or null if not.
       "researchTypes": [{
            "researchTypeCode": 33532,
            "researchSubTypeCode": 33574,
            "resolutionCode": 34321,
            "subResolutionCode": 33730
         }, 
         { ... }
       ]
     */
    getResearchTypeBySubType(researchTypes, researchSubTypeCode) {
    /* END_NODE_ONLY_CODE */
    	for (let i = 0; i < researchTypes.length; i++) {
            //console.log("researchTypes[" + i + "].researchSubTypeCode=" + researchTypes[i].researchSubTypeCode);
            if (researchTypes[i].researchSubTypeCode === researchSubTypeCode) {
                // console.log("getResearchTypeBySubType researchTypeReturned: ", researchTypes[i]);
                return researchTypes[i];
            }
        }
        return null;
    }
    
    /**
     * Returns all the elements of the researchTypes array on any of the given researchSubTypeCodes.
     * returns an empty array if none found.
     */
    getResearchTypeByAnyOfSubType(researchTypes, researchSubTypeCodes) {
    /* END_NODE_ONLY_CODE */
    	const rschTypesFd = [];
        for (let i = 0; i < researchSubTypeCodes.length; i++) {
            //console.log("researchSubTypeCodes[" + i + "]=" + researchSubTypeCodes[i]);
            const researchType = this.getResearchTypeBySubType(researchTypes, researchSubTypeCodes[i]);
            if (researchType != null) {
                rschTypesFd.push(researchType);
            }
        }
        // console.log("getResearchTypeByAnyOfSubType rschTypesFd: ", rschTypesFd);
        return rschTypesFd;
    }
    getResolutionCodeMatchFromCloseCaseData(closeCaseData, resolutionCode) {
    /* END_NODE_ONLY_CODE */
        for(let i = 0; i < closeCaseData.resolutions.length; i++) {
            if(closeCaseData.resolutions[i].resolutionCode === resolutionCode) {
                return closeCaseData.resolutions[i].resolutionCode;
            }
        }
        return null;
    } 
    getCloseCaseDataResolutionByAnyOfResolutionCode(closeCaseData, resolutionCodes) {
    /* END_NODE_ONLY_CODE */
        const resolutionCodesFd = [];
        for(let i = 0; i < resolutionCodes.length; i++) {
            const resolutionCode = this.getResolutionCodeMatchFromCloseCaseData(closeCaseData, resolutionCodes[i]);
            if(resolutionCode !== null) {
                resolutionCodesFd.push(resolutionCode);
            }
        }
        return resolutionCodesFd;
    }
    addRejectionError(rejectionErrors, jsonPath, errDesc, errDescAPI, provVal, UIRequest) {
    /* END_NODE_ONLY_CODE */
        /* console.log('rejectionErrors: ', rejectionErrors);
        console.log('jsonPath: ', jsonPath);
        console.log('errDesc: ', errDesc);
        console.log('errDescAPI: ', errDescAPI);
        console.log('provVal: ', provVal);
        console.log('UIRequest: ', UIRequest); */
     
    	if(UIRequest === undefined) {
        	let rejectionError = {
    			jsonPathName: jsonPath,
                errorDescription: errDescAPI,
                providedValue: provVal
        	};
        	rejectionErrors.push(rejectionError);
        }
        else {
        	let rejectionError = {
                jsonPathName: jsonPath,
                errorDescription: errDesc,
                providedValue: provVal
            };
        	rejectionErrors.push(rejectionError);
        }
    }
};

