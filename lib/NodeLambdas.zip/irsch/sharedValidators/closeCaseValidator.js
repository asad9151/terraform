/*
 * Common update-case validation module for UI and services
 */
'use strict';
const ValidatorCommon = require('../sharedValidators/validatorCommon');
const ErrorMessages = require('../sharedValidators/validationErrorMessages');
let ValidationErrorMessages = ErrorMessages();
let commonValidator;

module.exports = class CloseCaseValidator{
    constructor() {
        commonValidator = new ValidatorCommon();
    }
/* END_NODE_ONLY_CODE */
    
    
/* BEGIN_NOTES_FOR_SHARED CODE:  For Node.js, function instantiation and function call syntax needed is: 
 * 									validate( 
 * 									this.checkIsChangedDuns(
 * 									this.checkIfResearchCommentIsMandatoryForResolutionCode(
 * 									this.checkIfResearchCommentIsMandatoryForResearchType(
 * 									this.checkIfJsonPathIsMandatoryForResearchTypeResolution(
 * 
 * 									checkIsChangedDuns(
 * 									checkIfResearchCommentIsMandatoryForResolutionCode(
 * 									checkIfResearchCommentIsMandatoryForResearchType(
 * 									checkIfJsonPathIsMandatoryForResearchTypeResolution(
 * 
 * 								 For Angular, function instantiation and function call syntax needed is:
 * 									this.validate = function( 
 * 									checkIsChangedDuns(
 * 									checkIfResearchCommentIsMandatoryForResolutionCode(
 * 									checkIfResearchCommentIsMandatoryForResearchType(
 * 									checkIfJsonPathIsMandatoryForResearchTypeResolution(
 * 
 * 									function checkIsChangedDuns(
 * 									function checkIfResearchCommentIsMandatoryForResolutionCode(
 * 									function checkIfResearchCommentIsMandatoryForResearchType(
 * 									function checkIfJsonPathIsMandatoryForResearchTypeResolution(
 * 
 * END_NOTES_FOR_SHARED CODE:*/
        validate(researchTypes, researchResult, submittedData, closeCaseData, subjectDuns, UIRequest) {
        /* END_NODE_ONLY_CODE */ 
            var rejErrs = [];

            /* console.log("researchSubTyes: ", researchTypes);
             console.log("researchResult: ", researchResult);
             console.log("submittedData: ", submittedData);
             console.log("closeCaseData: ", closeCaseData); */
            this.checkIsChangedDuns(rejErrs, researchTypes, submittedData, researchResult, subjectDuns, UIRequest);
            this.checkIfResearchCommentIsMandatoryForResolutionCode(rejErrs, closeCaseData, UIRequest);
            this.checkIfResearchCommentIsMandatoryForResearchType(rejErrs, researchTypes, closeCaseData, UIRequest)
            this.checkIfJsonPathIsMandatoryForResearchTypeResolution(rejErrs, researchTypes, researchResult, submittedData, closeCaseData, subjectDuns, UIRequest);
            /* END_NODE_ONLY_CODE */ 
            const result = {
                rejectionErrors: rejErrs
            };
            /* console.log("SharedCloseCaseValidator error result to compare with UI error message: ", result); */
            return result;
    }
    checkIsChangedDuns(rejectionErrors, researchTypes, submittedData, researchResult, subjectDuns, UIRequest) {
    /* END_NODE_ONLY_CODE */ 
        // If research sub-type 34378, 33576, 33575, 33574, OR 33564 and researchResult.duns exist
        // For isChangedDuns, when turned ON (set to true) it means that the researcher has determined that the subject's D-U-N-S Number is different from the one that the submitter had entered or selected as the research subject for this case.  When turned OFF (set to false) it means that the researcher has determined that the subject's D-U-N-S Number is identical to the one that the submitter had entered or selected as the research subject for this case."
        const rschTypesFd = commonValidator.getResearchTypeByAnyOfSubType(researchTypes, [33576, 33575, 33574, 33564]);
        //console.log("rschTypesFd=" + rschTypesFd);
        if (rschTypesFd.length > 0){
            //console.log("check researchResult.duns=" + researchResult.duns);
        	if (researchResult && researchResult.duns) {
//                console.log("check researchResult.isChangedDuns=" + researchResult.isChangedDuns);
                if (researchResult.isChangedDuns !== undefined && (researchResult.isChangedDuns === true || researchResult.isChangedDuns === false)) {
                	commonValidator.addRejectionError(rejectionErrors, "researchResult.isChangedDuns", "isChangedDuns must be null if duns is provided in researchResult for a research request for a New D-U-N-S.", "isChangedDuns must be null if duns is provided in researchResult for a research request for a New D-U-N-S.", researchResult.isChangedDuns, UIRequest);
                }
            }
        }
        // else {
        //     if (researchResult && researchResult.duns) {
        //         // Check to ensure that resolution duns is not equal to subject D-U-N-S
        //         if(subjectDuns == researchResult.duns) {
        //             commonValidator.addRejectionError(rejectionErrors, "researchResult.duns", "researchResult.duns should not be the same value as the subject D-U-N-S.", "researchResult.duns should not be the same value as the subject D-U-N-S.", researchResult.duns, UIRequest);
        //         }
        //         // Check to ensure that isChangedDuns is set to true when a resolution Duns is found that is not equal to the subject Duns
        //         else if(researchResult.isChangedDuns == undefined) {
        //             commonValidator.addRejectionError(rejectionErrors, "researchResult.isChangedDuns", "isChangedDuns must be true if duns is provided in researchResult for a research request that is not for a new D-U-N-S.", "isChangedDuns must be true if duns is provided in researchResult for a research request that is not for a new D-U-N-S.", null, UIRequest);
        //         }
        //         else if(researchResult.isChangedDuns == false) {
        //             commonValidator.addRejectionError(rejectionErrors, "researchResult.isChangedDuns", "isChangedDuns must be true if duns is provided in researchResult for a research request that is not for a new D-U-N-S.", "isChangedDuns must be true if duns is provided in researchResult for a research request that is not for a new D-U-N-S.", researchResult.isChangedDuns, UIRequest);
        //         }
        //     }
        // }
    }
    checkIfResearchCommentIsMandatoryForResolutionCode (rejectionErrors, closeCaseData, UIRequest) {
    /* END_NODE_ONLY_CODE */ 
        const resolutionTypesFd = commonValidator.getCloseCaseDataResolutionByAnyOfResolutionCode(closeCaseData, [33728, 34000, 34477, 34335, 34828]);
        // console.log("resolutionTypesFd: ", resolutionTypesFd);
        if(resolutionTypesFd.length > 0) {
            if(closeCaseData.researchComment !== undefined) {
            	if(closeCaseData.researchComment === null) {
                    commonValidator.addRejectionError(rejectionErrors, "closeCase.researchComment", "Closing research comment is mandatory for the resolution code selected.", "closeCase.researchComment " + ValidationErrorMessages.commentMandatoryForResolution, closeCaseData.researchComment, UIRequest)
                }
            	else if(closeCaseData.researchComment.length === 0 || !closeCaseData.researchComment) {
                    commonValidator.addRejectionError(rejectionErrors, "closeCase.researchComment", "Closing research comment is mandatory for the resolution code selected.", "closeCase.researchComment " + ValidationErrorMessages.commentMandatoryForResolution, closeCaseData.researchComment, UIRequest)
                }
            }
            else if(closeCaseData.researchComment === undefined) {
            	commonValidator.addRejectionError(rejectionErrors, "closeCase.researchComment", "Closing research comment is mandatory for the resolution code selected.", "closeCase.researchComment " + ValidationErrorMessages.commentMandatoryForResolution, null, UIRequest)
            }
        }
    }
    checkIfResearchCommentIsMandatoryForResearchType (rejectionErrors, researchTypes, closeCaseData, UIRequest) {
    /* END_NODE_ONLY_CODE */ 
    	const rschTypesFd = commonValidator.getResearchTypeByAnyOfSubType(researchTypes, [33533, 33534, 33535, 33536, 33543, 33544, 33545, 33546, 33547, 33548, 33556, 33557, 33561, 33566, 33567, 33568, 33569, 33570, 33571, 33572, 33573, 33755]);
        if(rschTypesFd.length > 0) {
            for(var x = 0; x < closeCaseData.resolutions.length; x++) {
                if(closeCaseData.resolutions[x].resolutionCode !== 33921) {
                    if(closeCaseData.researchComment !== undefined) {
                        if(closeCaseData.researchComment.length === 0 || !closeCaseData.researchComment) {
                            commonValidator.addRejectionError(rejectionErrors, "closeCase.researchComment", "Closing research comment is mandatory for the selected research type.", "closeCase.researchComment " + ValidationErrorMessages.commentMandatoryForResearchSubType, closeCaseData.researchComment, UIRequest)
                        }
                    }
                    else if(closeCaseData.researchComment === undefined) {
                        commonValidator.addRejectionError(rejectionErrors, "closeCase.researchComment", "Closing research comment is mandatory for the selected research type.", "Closing research comment is mandatory for the resolution code selected", null, UIRequest)
                    }
                }
            }
        }
    }
    checkIfJsonPathIsMandatoryForResearchTypeResolution (rejectionErrors, researchTypes, researchResult, submittedData, closeCaseData, subjectDuns, UIRequest) {
    /* END_NODE_ONLY_CODE */ 
        for(var x = 0; x < closeCaseData.resolutions.length; x++) {
            //Data Was Changed or Added Resolution
            if(closeCaseData.resolutions[x].resolutionCode === 33726) {
                switch(researchTypes[x].researchSubTypeCode) {
                    //Business Name
                    case 33550:
                        if(researchResult.organizationName == undefined || !researchResult.organizationName) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.organizationName", ValidationErrorMessages.organizationName, ValidationErrorMessages.API, researchResult.organizationName, UIRequest);
                        }
                        break;
                    
                    //Trade style
                    case 33766:
                        if(researchResult.tradeStyleName == undefined || !researchResult.tradeStyleName) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.tradeStyleName", ValidationErrorMessages.tradeStyleName, ValidationErrorMessages.API, researchResult.tradeStyleName, UIRequest);
                        }
                        break;
                        
                    //CEO
                    case 33552:
                        if(researchResult.chiefExecutiveOfficerName == undefined || !researchResult.chiefExecutiveOfficerName) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.chiefExecutiveOfficerName", ValidationErrorMessages.chiefExecutiveOfficerName, ValidationErrorMessages.API, researchResult.chiefExecutiveOfficerName, UIRequest);
                        }
                        break;
                        
                    //Employees
                    case 33551:
                        if(researchResult.numberOfEmployees == undefined || !researchResult.numberOfEmployees) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.numberOfEmployees", ValidationErrorMessages.numberOfEmployees, ValidationErrorMessages.API, researchResult.numberOfEmployees, UIRequest);
                        }
                        break;
                        
    
                    //Sales
                    case 33553:
                        if(researchResult.salesAmount == undefined || !researchResult.salesAmount) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.salesAmount", ValidationErrorMessages.salesAmount, ValidationErrorMessages.API, researchResult.salesAmount, UIRequest);
                        }
                        break;

                    //LOB
                    case 33554:
                        if(researchResult.primaryIndustryCode == undefined || !researchResult.primaryIndustryCode) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.primaryIndustryCode", ValidationErrorMessages.primaryIndustryCode, ValidationErrorMessages.API, researchResult.primaryIndustryCode, UIRequest);
                        }
                        break;

    
                    //Address
                    case 33549:
                        if((researchResult.addresses == undefined  && researchResult.countryCode == undefined) || !researchResult.countryCode && !researchResult.addresses[0].streetAddress && !researchResult.addresses[0].town && !researchResult.addresses[0].territory && !researchResult.addresses[0].postalCode) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.countryCode && researchResult.addresses[0].streetAddress && researchResult.addresses[0].town && researchResult.addresses[0].territory && researchResult.addresses[0].postalCode", ValidationErrorMessages.addresses, ValidationErrorMessages.addressesAPI, null, UIRequest);
                        }
                        break;

        
                    //Legal
                    case 33538:
                        if(researchResult.legalFormDescription == undefined || !researchResult.legalFormDescription) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.legalFormDescription", ValidationErrorMessages.legalFormDescription, ValidationErrorMessages.API, researchResult.legalFormDescription, UIRequest);
                        }
                        break;

                    //Principals & Titles
                    case 33539:
                        if(researchResult.principals == undefined || researchResult.principals.length === 0) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.principals", ValidationErrorMessages.principals, ValidationErrorMessages.API, researchResult.principals, UIRequest);
                        }
                        break;
    
                    //Related Companies & Affiliates
                    case 33540:
                        if(researchResult.relatedOrganizations == undefined || researchResult.relatedOrganizations.length === 0) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.relatedOrganizations", ValidationErrorMessages.relatedOrganizations, ValidationErrorMessages.API, researchResult.relatedOrganizations, UIRequest);
                        }
                        break;

                    //Stock Ownership
                    case 33541:
                        if(researchResult.shareOwnership == undefined || researchResult.shareOwnership.length === 0) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.shareOwnership", ValidationErrorMessages.shareOwnership, ValidationErrorMessages.API, researchResult.shareOwnership, UIRequest);
                        }
                        break;
        
                    //Year Started
                    case 33542:
                        if(researchResult.startYear == undefined || !researchResult.startYear) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.startYear", ValidationErrorMessages.startYear, ValidationErrorMessages.API, researchResult.startYear, UIRequest);
                        }
                        break;
                        
                    //Control Date
                    case 33767:
                        if(researchResult.controlDate == undefined || !researchResult.controlDate) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.controlDate", ValidationErrorMessages.controlDate, ValidationErrorMessages.API, researchResult.controlDate, UIRequest);
                        }
                        break;	
        
                    //Operating Status
                    case 33558:
                        if(researchResult.isActiveBusiness == undefined || (researchResult.isActiveBusiness !== true && researchResult.isActiveBusiness !== false)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.isActiveBusiness", ValidationErrorMessages.isActiveBusiness, ValidationErrorMessages.activeBusiness, researchResult.isActiveBusiness, UIRequest);
                        }
                        break;	

                    //DNB Rating
                    case 33566:
                        if(researchResult.dnbRating == undefined || !researchResult.dnbRating) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.dnbRating", ValidationErrorMessages.dnbRating, ValidationErrorMessages.API, researchResult.dnbRating, UIRequest);
                        }
                        break;
                    
                    //Acquisition occurred
                    case 33559:
                        if((closeCaseData.resolutions[x].subResolutionCode === 33733 || closeCaseData.resolutions[x].subResolutionCode === 33886 || closeCaseData.resolutions[x].subResolutionCode === 33887) && (researchResult.duns == undefined || !researchResult.duns)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.duns", ValidationErrorMessages.duns, ValidationErrorMessages.API, researchResult.duns, UIRequest);
                        }
                        if((closeCaseData.resolutions[x].subResolutionCode === 33882 || closeCaseData.resolutions[x].subResolutionCode === 33883 || closeCaseData.resolutions[x].subResolutionCode === 33886 || closeCaseData.resolutions[x].subResolutionCode === 33887) && (researchResult.acquirer == undefined)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.acquirer.duns", ValidationErrorMessages.acquirer.duns, ValidationErrorMessages.API, researchResult.acquirer, UIRequest);
                        }
                        else if((closeCaseData.resolutions[x].subResolutionCode === 33882 || closeCaseData.resolutions[x].subResolutionCode === 33883 || closeCaseData.resolutions[x].subResolutionCode === 33886 || closeCaseData.resolutions[x].subResolutionCode === 33887) && (researchResult.acquirer.duns == undefined ||!researchResult.acquirer.duns)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.acquirer.duns", ValidationErrorMessages.acquirer.duns, ValidationErrorMessages.API, researchResult.acquirer.duns, UIRequest);
                        }
                        if((closeCaseData.resolutions[x].subResolutionCode === 33884 || closeCaseData.resolutions[x].subResolutionCode === 33885) && (researchResult.relatedOrganizations == undefined || researchResult.relatedOrganizations.length === 0)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.relatedOrganizations", ValidationErrorMessages.relatedOrganizations, ValidationErrorMessages.API, researchResult.relatedOrganizations, UIRequest);    
                        }
                        if((closeCaseData.resolutions[x].subResolutionCode === 33888 || closeCaseData.resolutions[x].subResolutionCode === 33889) && (researchResult.isActiveBusiness == undefined || researchResult.isActiveBusiness !== false)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.isActiveBusiness", ValidationErrorMessages.inactiveBusiness, ValidationErrorMessages.activeBusinessFalse, researchResult.isActiveBusiness, UIRequest);
                            // console.log("isActiveBusiness Status: ", researchResult.isActiveBusiness);
                        }
                        break;

                    //Merger occurred
                    case 33768:
                        if((closeCaseData.resolutions[x].subResolutionCode === 33733 || closeCaseData.resolutions[x].subResolutionCode === 33892 || closeCaseData.resolutions[x].subResolutionCode === 33893 || closeCaseData.resolutions[x].subResolutionCode === 33894 || closeCaseData.resolutions[x].subResolutionCode === 33895) && (researchResult.duns == undefined || !researchResult.duns)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.duns", ValidationErrorMessages.duns, ValidationErrorMessages.API, researchResult.duns, UIRequest);
                        }
                        if((researchResult.acquirer == undefined) && (closeCaseData.resolutions[x].subResolutionCode === 33890 || closeCaseData.resolutions[x].subResolutionCode === 33891 || closeCaseData.resolutions[x].subResolutionCode === 33894 || closeCaseData.resolutions[x].subResolutionCode === 33895)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.acquirer.duns", ValidationErrorMessages.acquirer.survivingDuns, ValidationErrorMessages.API, researchResult.acquirer, UIRequest);
                        }
                        else if((researchResult.acquirer == undefined || researchResult.acquirer.duns == undefined || !researchResult.acquirer.duns) && (closeCaseData.resolutions[x].subResolutionCode === 33890 || closeCaseData.resolutions[x].subResolutionCode === 33891 || closeCaseData.resolutions[x].subResolutionCode === 33894 || closeCaseData.resolutions[x].subResolutionCode === 33895)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.acquirer.duns", ValidationErrorMessages.acquirer.survivingDuns, ValidationErrorMessages.API, researchResult.acquirer.duns, UIRequest);
                        }
                        break;
                    
                    //Incorrect Ownership
                    case 33562:
                        if((researchResult.owner == undefined || !researchResult.owner.ownerIdentity.duns) && (closeCaseData.resolutions[x].subResolutionCode === 33730 || closeCaseData.resolutions[x].subResolutionCode === 33731 || closeCaseData.resolutions[x].subResolutionCode === 33732 || closeCaseData.resolutions[x].subResolutionCode === 33734 || closeCaseData.resolutions[x].subResolutionCode === 33774)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.owner.ownerIdentity.duns", ValidationErrorMessages.owner.ownerIdentity.duns, ValidationErrorMessages.API, researchResult.owner, UIRequest);
                        }
                        else if((researchResult.owner.ownerIdentity.duns == undefined || !researchResult.owner.ownerIdentity.duns) && (closeCaseData.resolutions[x].subResolutionCode === 33730 || closeCaseData.resolutions[x].subResolutionCode === 33731 || closeCaseData.resolutions[x].subResolutionCode === 33732 || closeCaseData.resolutions[x].subResolutionCode === 33734 || closeCaseData.resolutions[x].subResolutionCode === 33774)) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.owner.ownerIdentity.duns", ValidationErrorMessages.owner.ownerIdentity.duns, ValidationErrorMessages.API, researchResult.owner.ownerIdentity.duns, UIRequest);
                        }
                        break;
                }
            }

            //Data Was Deleted Resolution
            if(closeCaseData.resolutions[x].resolutionCode === 33772) {
                switch(researchTypes[x].researchSubTypeCode) {
                    
                    //Duplicate Record
                    case 33560:
                        if(researchResult.duplicateDunsNumbers === undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.duplicateDunsNumbers", ValidationErrorMessages.duplicateDunsNumbers, ValidationErrorMessages.API, null, UIRequest);
                        }
                        else if(researchResult.duplicateDunsNumbers.length === 0) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.duplicateDunsNumbers[0].retainedDuns", ValidationErrorMessages.duplicateDunsNumbers, ValidationErrorMessages.API, null, UIRequest);
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.duplicateDunsNumbers[0].deletedDuns", ValidationErrorMessages.duplicateDunsNumbers, ValidationErrorMessages.API, null, UIRequest);
                        }
                        else if(researchResult.duplicateDunsNumbers.length > 0) {
                            if(!researchResult.duplicateDunsNumbers[0].retainedDuns) {
                                commonValidator.addRejectionError(rejectionErrors, "researchResult.duplicateDunsNumbers[0].retainedDuns", ValidationErrorMessages.duplicateDunsNumbers, ValidationErrorMessages.API, null, UIRequest);
                            }
                            if(!researchResult.duplicateDunsNumbers[0].deletedDuns) {
                                commonValidator.addRejectionError(rejectionErrors, "researchResult.duplicateDunsNumbers[0].deletedDuns", ValidationErrorMessages.duplicateDunsNumbers, ValidationErrorMessages.API, null, UIRequest);
                            }
                        }
                        break;
                }
            }
            // Multiple Linkages Resolved Resolution
            if(closeCaseData.resolutions[x].resolutionCode === 34000) {
                switch(researchTypes[x].researchSubTypeCode) {
                    
                    // Multiple Child Linkages
                    case 33993:
                        let count = 0
                        if(closeCaseData.resolutions[x].subResolutionCode === 34001) {
                            if(researchResult.childOrganizations == undefined || (submittedData.childOrganizations.length > researchResult.childOrganizations.length)) {
                                commonValidator.addRejectionError(rejectionErrors, "researchResult.childOrganizations", ValidationErrorMessages.childOrganizationsRequester, ValidationErrorMessages.API, researchResult.childOrganizations, UIRequest);
                            }
                            else {
                                console.log("researchResult.childOrganizations.length: ", researchResult.childOrganizations.length)
                                for(var child = 0; child < researchResult.childOrganizations.length; child++){
                                    if(!researchResult.childOrganizations[child].linkageChangeActionCode){
                                        
                                        // if(!vm.closeErrors.includes(" Choosing how the linkage should be corrected for each child linkage is required.")){
                                            commonValidator.addRejectionError(rejectionErrors, "researchResult.childOrganizations", ValidationErrorMessages.childOrganizations, ValidationErrorMessages.childOrganizationsAPI, researchResult.childOrganizations, UIRequest);
                                        // }
                                           console.log("Run count: ", count++);
                                        
                                    }
                                }
                            }
                        }
                        break;
                }
            }

            // DUNS Number Could Not Be Created Resolution
            if(closeCaseData.resolutions[x].resolutionCode === 34335) {
                switch(researchTypes[x].researchSubTypeCode) {
                    
                    case 33574:     //New DUNS - Full Risk Review
                    
                    case 33576:     //New DUNS - Self Request DUNS Number
                    
                    case 33575:     //New DUNS - Mini Inquiry - Identity Data Only
                    
                    case 33564:     //New DUNS - Linkage 
                        if(researchResult.duns) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.duns", ValidationErrorMessages.dunsShouldNotBeProvided, ValidationErrorMessages.valueNotNeeded, researchResult.duns, UIRequest);
                        } 
                        break;
                }
            }

            //DUNS Number Created Resolution (34321) & DUNS Number Already Exits Resolution (34322)
            if(closeCaseData.resolutions[x].resolutionCode === 34321  || closeCaseData.resolutions[x].resolutionCode === 34322) { 
                switch(researchTypes[x].researchSubTypeCode) {
        
                    case 33574:     //New DUNS - Full Risk Review
                                 
                    case 33576:     //New DUNS - Self Request DUNS Number

                    case 33575:     //New DUNS - Mini Inquiry - Identity Data Only

                    case 33564:     //New DUNS - Linkage

                        if(!researchResult.duns || researchResult.duns == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.duns", ValidationErrorMessages.duns, ValidationErrorMessages.API, researchResult.duns, UIRequest);
                        } 
                        if(!researchResult.organizationName || researchResult.organizationName == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.organizationName", ValidationErrorMessages.organizationName, ValidationErrorMessages.API, researchResult.organizationName, UIRequest);
                        }
                        if(!researchResult.countryCode || researchResult.countryCode == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.countryCode", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.countryCode, UIRequest);
                        }
                        if(researchResult.addresses == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].streetAddress", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses, UIRequest);
                        } 
                        else if(!researchResult.addresses[0].streetAddress) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].streetAddress", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses[0].streetAddress, UIRequest);
                        }
                        if(researchResult.addresses == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].town", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses, UIRequest);
                        }
                        else if(!researchResult.addresses[0].town) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].town", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses[0].town, UIRequest);
                        }
                        break;
                }
            }

            //DUNS Number Created Resolution (34321) & DUNS Number Already Exits Resolution (34322)
            if(closeCaseData.resolutions[x].resolutionCode === 34321) { 
                switch(researchTypes[x].researchSubTypeCode) {

                    case 34378:		//Full Credit Risk Review - Full Credit Risk Review

                        if(!researchResult.duns || researchResult.duns == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.duns", ValidationErrorMessages.duns, ValidationErrorMessages.API, researchResult.duns, UIRequest);
                        } 
                        if(!researchResult.organizationName || researchResult.organizationName == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.organizationName", ValidationErrorMessages.organizationName, ValidationErrorMessages.API, researchResult.organizationName, UIRequest);
                        }
                        if(!researchResult.countryCode || researchResult.countryCode == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.countryCode", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.countryCode, UIRequest);
                        }
                        if(researchResult.addresses == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].streetAddress", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses, UIRequest);
                        } 
                        else if(!researchResult.addresses[0].streetAddress) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].streetAddress", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses[0].streetAddress, UIRequest);
                        }
                        if(researchResult.addresses == undefined) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].town", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses, UIRequest);
                        }
                        else if(!researchResult.addresses[0].town) {
                            commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].town", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses[0].town, UIRequest);
                        }
                        break;
                }
            }
            if(closeCaseData.resolutions[x].resolutionCode === 34475 || closeCaseData.resolutions[x].resolutionCode === 34476 || closeCaseData.resolutions[x].resolutionCode === 34477 || closeCaseData.resolutions[x].resolutionCode === 34828) { 
                switch(researchTypes[x].researchSubTypeCode) {

                    case 34378:		//Full Credit Risk Review - Full Credit Risk Review
                    if(researchResult.duplicateDunsNumbers != undefined && researchResult.duplicateDunsNumbers.length > 0) {
                        for(let i = 0; i < researchResult.duplicateDunsNumbers.length; i++){
                            if(researchResult.duplicateDunsNumbers[i].deletedDuns == subjectDuns) {
                                if(!researchResult.duns || researchResult.duns == undefined) {
                                    commonValidator.addRejectionError(rejectionErrors, "researchResult.duns", ValidationErrorMessages.duns, ValidationErrorMessages.API, researchResult.duns, UIRequest);
                                } 
                                if(!researchResult.organizationName || researchResult.organizationName == undefined) {
                                    commonValidator.addRejectionError(rejectionErrors, "researchResult.organizationName", ValidationErrorMessages.organizationName, ValidationErrorMessages.API, researchResult.organizationName, UIRequest);
                                }
                                if(!researchResult.countryCode || researchResult.countryCode == undefined) {
                                    commonValidator.addRejectionError(rejectionErrors, "researchResult.countryCode", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.countryCode, UIRequest);
                                }
                                if(researchResult.addresses == undefined) {
                                    commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].streetAddress", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses, UIRequest);
                                } 
                                else if(!researchResult.addresses[0].streetAddress) {
                                    commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].streetAddress", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses[0].streetAddress, UIRequest);
                                }
                                if(researchResult.addresses == undefined) {
                                    commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].town", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses, UIRequest);
                                }
                                else if(!researchResult.addresses[0].town) {
                                    commonValidator.addRejectionError(rejectionErrors, "researchResult.addresses[0].town", ValidationErrorMessages.addressesUI, ValidationErrorMessages.API, researchResult.addresses[0].town, UIRequest);
                                }
                            }
                        }
                    }
                    break;
                }
            }
        }
    }

};

