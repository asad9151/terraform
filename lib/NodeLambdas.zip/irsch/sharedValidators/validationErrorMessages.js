'use strict';

module.exports = function validationErrorMessages () {
/* END_NODE_ONLY_CODE */

	return {
        //Update Research Results Validation Error Messages
        ceoError: "Chief Executive Office Name is required with Chief Executive Officer Title.",
        
        // Close Case Validation Error Messages
        acquirer:
            {
                duns: "Acquired By DUNS is required.",
                survivingDuns: "Surviving DUNS is required.",
            },
        addresses: "The Business Address section must contain an updated value.",
        addressesUI: "Address fields on the 'Primary Business Information' tab are required.",
        businessName: "Business Name is required.",
        chiefExecutiveOfficerName: "Primary Principal Name and Primary Principal Title are required.",
        childOrganizations: "Choosing how the linkage should be corrected for each child linkage is required.",
        childOrganizationsRequester: "Choosing how the linkage should be corrected for each child linkage that was submitted by the requester is required.", 
        controlDate: "Control Date is required.",
        country: "Country is required.",
        countryReturnComment: "Country Return Comment is required.",
        dnbRating: "D&B Rating is required.",
        duns: "New/ Resolution D-U-N-S Number is required.",
        dunsRequired: "D-U-N-S Number is required.",
        dunsShouldNotBeProvided: "A New / Resolution D-U-N-S Number should not be provided when 'D-U-N-S Number could not be created' is a selected resolution.",
        duplicateDunsNumbers: "Retained D-U-N-S Number and Deleted D-U-N-S Number are required.",
        isActiveBusiness: "Operational Status is required.",
        inactiveBusiness: "Inactive Operating Status is required.",
        legalFormDescription: "Legal Form Description is required.",
        numberOfEmployees: "Employees is required.",
        organizationName: "Primary Business Name is required.",
        owner:
            {
                ownerIdentity:
                    {
                        duns: "Owner DUNS is required.",
                    }
            },
        parentBusiness: "Parent Business Name is required.",
        parentBusinessInvalid: "Parent Business Name should not be provided.",
        parentDunsInvalid: "Parent DUNS should not be provided.",
        parentCountry: "Parent Country is required.",
        parentCountryInvalid: "Parent Country should not be provided.",
        physicalStreet: "Physical Street Address is required.",
        primaryIndustryCode: "Industry Code is required.",
        principals: "An additional Principal Name and Principal Title is required.",
        relatedOrganizations: "A Related Organization and/or Affiliate is required.",
        salesAmount: "Annual Sales is required.",
        shareOwnership: "Share Owner Name and % of Stock Ownership are required.",
        sicRequired: "SIC is required.",
        startYear: "Year Started is required.",
        tradeStyleName: "Trade Style Name is required.",

        // API response
        addressesAPI: "Required field missing. At least one address field requires a value.",
        API: "Required field missing.",  //{{ field }} is required
        valueNotNeeded: "A duns should not be provided with resolution code 34335.",
        activeBusiness: "Required field missing. isActiveBusiness should be set to true or false",
        activeBusinessFalse: "Required field missing. isActiveBusiness should be set to false.",
        childOrganizationsAPI: "Required field missing. 'linkageChangeActionCode' is required for each 'childOrganizationIdentity'.",
        commentMandatoryForResearchSubType: "is mandatory for a provided researchSubTypeCode.",
        commentMandatoryForResolution: "is mandatory for the provided resolution code."
    }
};

