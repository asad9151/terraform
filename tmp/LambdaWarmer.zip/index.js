'use strict'

/**
 * Keep your Lambda functions warm
 * @author Gopinath Mulumudi <MulumudiG@dnb.com>
 * @version 1.1.3
 * @license MIT
 * Modifications to reuse the same warmer logic to run as a self function to help keep other functions warm
 */
const id = Date.now().toString() + '-' + ('0000' + Math.floor(Math.random()*1000).toString()).substr(-4)

let warm = false
let lastAccess = null

//This data is going to come from event now
//const funcName = process.env.AWS_LAMBDA_FUNCTION_NAME
//const funcVersion = process.env.AWS_LAMBDA_FUNCTION_VERSION

const delay = ms => new Promise(res => setTimeout(res, ms))
console.info("This is a cold start of the function")
exports.handler = (event,context,cfg = {}) => { //To be able to execute in a lambda function
  console.info("START: Executing the function")
  console.info("EVENT\n" + JSON.stringify(event, null, 2))

  let config = Object.assign({}, {
    flag: 'warmer', // default test flag
    concurrency: 'concurrency', // default concurrency field
    test: 'test', // default test flag
    log: true, // default logging to true
    correlationId: id, // default the correlationId
    delay: 75 // default the delay to 75ms
  },cfg)

  // If the event is a warmer ping
  if (event && event[config.flag]) {

    const funcName = event.AWS_LAMBDA_FUNCTION_NAME
    const funcVersion = event.AWS_LAMBDA_FUNCTION_VERSION

    console.info("FUNCTION_NAME = " + funcName+ " FUNCTION_VERSION or Alias = "+funcVersion)

    let concurrency = event[config.concurrency]
      && !isNaN(event[config.concurrency])
      && event[config.concurrency] > 1
      ? event[config.concurrency] : 1

    console.info("Concurrency = " + concurrency)

    let invokeCount = event['__WARMER_INVOCATION__']
      && !isNaN(event['__WARMER_INVOCATION__'])
      ? event['__WARMER_INVOCATION__'] : 1

    let invokeTotal = event['__WARMER_CONCURRENCY__']
      && !isNaN(event['__WARMER_CONCURRENCY__'])
      ? event['__WARMER_CONCURRENCY__'] : concurrency

    let correlationId = event['__WARMER_CORRELATIONID__']
      ? event['__WARMER_CORRELATIONID__'] : config.correlationId

    // Create log record
    let log = {
      action: 'warmer',
      function: funcName + ':' + funcVersion,
      id,
      correlationId,
      count: invokeCount,
      concurrency: invokeTotal,
      warm,
      lastAccessed: lastAccess,
      lastAccessedSeconds: lastAccess === null ? null : ((Date.now()-lastAccess)/1000).toFixed(1)
    }

    // Log it
    config.log && console.info(log) // eslint-disable-line no-console

    // flag as warm
    warm = true
    lastAccess = Date.now()

    // Fan out if concurrency is >= 1
    if (concurrency >= 1 && !event[config.test]) {
      console.info("Concurrency >= 1 and event is not test")
      // init Lambda service
      let lambda = require('./lib/lambda-service')
       console.info("After loading the lambda service module")
      // init promise array
      let invocations = []

      // loop through concurrency count
      for (let i=1; i <= concurrency; i++) {

        // Set the params and wait for the final function to finish
        let params = {
          FunctionName: funcName + ':' + funcVersion,
          InvocationType: 'Event',
          LogType: 'None',
          Payload: Buffer.from(JSON.stringify({
            [config.flag]: true, // send warmer flag
            '__WARMER_INVOCATION__': i, // send invocation number
            '__WARMER_CONCURRENCY__': concurrency, // send total concurrency
            '__WARMER_CORRELATIONID__': correlationId // send correlation id
          }))
        }
        //console.info("Params object for invocation " + i + " \n "+JSON.stringify(params, null, 2))
        // Add promise to invocations array
        invocations.push(lambda.invoke(params).promise())

      } // end for
      console.info("Starting to make async invocations to the destination lambda function")
      // Invoke concurrent functions
      Promise.all(invocations)
        .then(() => true)
     console.info("Completed making async invocations to the destination lambda function")
    } /*else if (invokeCount > 1) {
      return delay(config.delay).then(() => true)
    }*/

    return Promise.resolve(true)
  } else {
    warm = true
    lastAccess = Date.now()
    return Promise.resolve(false)
  }

} // end module
